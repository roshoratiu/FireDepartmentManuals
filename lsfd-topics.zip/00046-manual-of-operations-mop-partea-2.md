# MANUAL OF OPERATIONS (MOP) - PARTEA 2

- **Topic ID:** 46
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=46
- **Posts:** 1

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

 MANUAL OF OPERATIONS (MOP) - PART 2

---

**12. DIVISION 3: WILDLAND & ENVIRONMENTAL OPERATIONS**

 **12.01 Descriere și Scop**
 **Division 3: Wildland & Environmental Operations** este responsabilă pentru gestionarea incendiilor de vegetație (**Wildland Firefighting**), protecția resurselor naturale și suportul aerian asociat. Membrii acestei divizii sunt specializați în tactici de stingere în teren accidentat, operarea vehiculelor off-road și coordonarea cu agențiile de mediu pentru a minimiza impactul ecologic. Divizia integrează operațiuni la sol cu suportul aerian (**Helitack**) pentru o eficiență maximă în zonele greu accesibile.

 **12.02 Sistemul TIER**
 Avansarea în cadrul diviziei se bazează pe acumularea calificărilor specifice, conform structurii:
- **TIER 1: Entry Level** - Membru de bază, calificat ca **Wildland Firefighter - Type 2**.
- **TIER 2: Advanced Firefighter** - Membru experimentat, calificat ca **Wildland Firefighter - Type 1**.
- **TIER 3: Specialized Operator** - Operator specializat pe vehicule (**Wildland Engine Operator**) sau operațiuni aeriene (**Wildland Helitack**).
- **TIER 4: Division Lead** - Deține toate calificările și poate fi numit **Wildland Operations Coordinator** de către **Bureau Commander**.

 **12.03 Poziții și Calificări**

 **Wildland Operations Coordinator (Division Lead)**
 Este liderul diviziei, numit de **Bureau Commander** bazat pe calificări și experiență. Acționează ca **Incident Commander** la incidentele majore de tip **Wildfire**, având autoritate tehnică supremă în operațiunile wildland. Coordonează resursele tactice, gestionează relațiile **Multi-Agency** (cu US Forest Service sau State Forestry) și supervizează operațiunile aeriene. Este responsabil pentru planificarea strategică a sezonului de incendii și monitorizarea condițiilor meteo (**Fire Weather**). Răspunde direct la **Bureau Commander**.

 **Wildland Firefighter Type 1**
 Reprezintă nivelul avansat de operare. Acești membri pot conduce un **Hand Crew** sau o echipă mică în teren. Sunt responsabili pentru tactici complexe, cum ar fi operațiunile de **Firing** (inclusiv **Backburns** și **Burnouts**) pentru a elimina combustibilul din calea focului. Ei monitorizează comportamentul focului și acționează ca **Safety Officer** pentru echipele mai puțin experimentate.

 **Wildland Firefighter Type 2**
 Este nivelul de intrare în divizie. Responsabilitățile principale includ construcția de **Fire Line** folosind **Hand Tools** (precum Pulaski, McLeod, lopeți), executarea operațiunilor de **Mop-up** (stingerea focarelor rămase) și identificarea rutelor de evacuare (**Escape Routes**) și a zonelor de siguranță (**Safety Zones**). Lucrează sub supravegherea directă a unui Type 1.

 **Wildland Engine Operator**
 Specialistul care conduce și operează **Brush Trucks** și **Wildland Engines** în condiții off-road dificile. Execută atacuri mobile asupra focului (**Pump-and-Roll**), gestionează alimentarea cu apă în zone remote (**Drafting** din surse naturale) și asigură protecția structurilor (**Structure Protection**) aflate în calea incendiului de vegetație.

 **Wildland Helitack Crew Member**
 Membru al echipajului aeropurtat, specializat în inserția rapidă cu elicopterul (prin aterizare sau **Rappelling**). Responsabilitățile includ recunoașterea aeriană (**Aerial Reconnaissance**), stabilirea zonelor de aterizare sigure (**Helispot Operations**) și coordonarea operațiunilor de stingere cu cupa de apă (**Water Bucket Operations**) prin comunicare radio sol-aer.

 **Environmental Response Specialist**
 Se concentrează pe protecția resurselor naturale și mitigarea daunelor ecologice. Gestionează deversările minore (**Spill Mitigation**) și evaluează impactul operațiunilor de stingere asupra mediului înconjurător, coordonând acțiunile cu agențiile de protecție a mediului.

 **13. DIVISION 4: WATER RESCUE OPERATIONS**

 **13.01 Descriere și Scop**
 **Division 4: Water Rescue Operations** gestionează răspunsul la toate urgențele acvatice, incluzând salvarea din ape rapide (**Swift Water**), operațiuni maritime, scufundări de căutare (**Dive Rescue**) și răspuns la inundații. Obiectivul principal este salvarea vieților în medii acvatice dinamice, punând accent pe siguranța echipei și recuperarea victimelor.

 **13.02 Sistemul TIER**
 Progresia în divizie se face prin specializare tehnică:
- **TIER 1: Entry Level** - Nivel de conștientizare (**Water Rescue Awareness**).
- **TIER 2: Technician** - Specializare pe o disciplină (Swift Water, Marine, Ice sau Flood).
- **TIER 3: Advanced Multi-Role** - Deține multiple specializări tehnice (ex: Dive + Swift Water).
- **TIER 4: Division Lead** - Deține toate calificările și poate fi numit **Water Rescue Coordinator** de către **Bureau Commander**.

 **13.03 Poziții și Calificări**

 **Water Rescue Coordinator (Division Lead)**
 Liderul diviziei, numit de **Bureau Commander** bazat pe calificări și experiență. Coordonează întreaga activitate a diviziei și acționează ca **Incident Commander** la incidentele pe apă, având autoritate tehnică supremă în operațiunile acvatice. Este responsabil pentru gestionarea echipamentului specializat (bărci, echipament de scufundare), dezvoltarea procedurilor operaționale (**SOPs**) și coordonarea **Multi-Agency** cu **Coast Guard** sau **Harbor Patrol**. Evaluează riscurile hidraulice și stabilește strategia de intervenție. Răspunde direct la **Bureau Commander**.

 **Swift Water Rescue Technician**
 Specialist în salvarea din ape curgătoare cu debit mare. Execută intrări în apă pentru salvarea victimelor, utilizând tehnici precum **Live Bait Rescue** sau sisteme de frânghii tensionate (**Tension Diagonal**). Este expert în citirea hidraulicii râului, evitarea obstacolelor periculoase (**Strainers**) și asigură siguranța în aval (**Downstream Safety**).

 **Marine Operations Specialist**
 Responsabil pentru operarea ambarcațiunilor departamentale (**Fire Boats** și **Rescue Boats**). Gestionează stingerea incendiilor pe nave (**Vessel Firefighting**), navigația maritimă folosind radar și GPS, și recuperarea victimelor de la suprafața apei. Coordonează tiparele de căutare (**Search Patterns**) pe ocean sau lacuri.

 **Dive Rescue Technician**
 Execută operațiuni de căutare și salvare subacvatică (**Underwater Search and Rescue**). Utilizează echipament **SCUBA** pentru recuperarea victimelor înecate, a vehiculelor scufundate sau a probelor pentru poliție. Respectă cu strictețe protocolul de siguranță **Buddy System** și procedurile pentru scafandru pierdut (**Lost Diver Protocol**).

 **Ice Rescue Technician**
 Specializat în salvarea victimelor căzute prin gheață. Utilizează echipamente specifice precum **Ice Awls**, sănii de salvare și costume impermeabile (**Dry Suits**). Evaluează grosimea gheții și gestionează victimele care suferă de hipotermie severă, coordonând extracția rapidă și sigură.

 **Flood Response Operator**
 Gestionează evacuările în masă în timpul inundațiilor urbane. Utilizează ambarcațiuni cu fund plat pentru a naviga pe străzi inundate, efectuează salvări de pe acoperișuri (**High-Water Rescue**) și extragerea victimelor din vehicule blocate în viituri. Coordonează operațiunile în scenarii cu victime multiple.

 **14. DIVISION 5: FIRE INVESTIGATION & PREVENTION**

 **14.01 Descriere și Scop**
 **Division 5: Fire Investigation & Prevention** gestionează investigarea cauzelor incendiilor, inspecții de prevenire și programe de educație publică. Obiectivul principal este reducerea riscului de incendiu și determinarea cauzelor pentru acțiuni corective și legale. Membrii acestei divizii lucrează îndeaproape cu **Law Enforcement** pentru cazurile de **Arson**.

 **14.02 Sistemul TIER**
 Progresia în cadrul diviziei se face pe baza expertizei tehnice și a autorității legale:
- **TIER 1: Entry Level** - Membri concentrați pe educație și inspecții de bază (**Fire Safety Officer**).
- **TIER 2: Inspector** - Membri cu autoritate de aplicare a codului (**Fire Inspector**).
- **TIER 3: Investigator** - Specialiști în investigarea scenelor și colectarea probelor (**Fire Investigator** / **Arson Investigator**).
- **TIER 4: Division Lead** - Deține toate calificările diviziei și poate fi numit **Fire Prevention Chief** de către **Bureau Commander**.

 **14.03 Poziții și Calificări**

 **Fire Prevention Chief (Division Lead)**
 Liderul diviziei, numit de **Bureau Commander** bazat pe calificări și experiență. Este autoritatea supremă tehnică în materie de **Fire Code Enforcement** și investigare. Coordonează toate investigațiile majore, gestionează relația cu **District Attorney** și **Police Department**, și dezvoltă strategiile de prevenire la nivelul orașului. Răspunde direct la **Bureau Commander**.

 **Fire Investigator**
 Specialistul responsabil cu determinarea **Origin & Cause** a incendiilor. Execută **Scene Size-up**, colectează probe fizice respectând **Chain of Custody**, intervievează martori și redactează rapoarte tehnice detaliate.

 **Arson Investigator**
 Un nivel avansat de investigație, concentrat pe incendii intenționate (**Arson**). Lucrează în colaborare strânsă cu detectivii de poliție, gestionează mandatele, pregătește dosarele pentru instanță și depune mărturie ca expert. Necesită cunoștințe avansate de drept penal și **Evidence Collection**.

 **Fire Inspector**
 Responsabil pentru inspecțiile de siguranță în clădiri comerciale și rezidențiale. Verifică conformitatea cu **Fire Code**, emite citații pentru încălcări (**Notice of Violation**), verifică sistemele de alarmă și sprinklere, și efectuează **Re-inspections** pentru a asigura remedierea problemelor.

 **Fire Marshal**
 Un rol avansat de inspecție cu autoritate sporită. Revizuiește planurile de construcție (**Plan Review**), emite permise de operare, gestionează aplicarea strictă a codului și coordonează închiderea afacerilor care prezintă un pericol iminent.

 **Public Education Officer**
 Gestionează programele de outreach comunitar. Organizează prezentări în școli, tururi de stație și campanii de informare publică. Dezvoltă materiale educaționale și gestionează prezența departamentului în social media pentru campaniile de siguranță.

 **Fire Safety Officer**
 Nivelul de intrare în prevenție. Oferă consultanță pentru siguranța la domiciliu, conduce exerciții de evacuare (**Fire Drills**) în clădiri de birouri și oferă instruire pentru utilizarea extinctoarelor.

 **15. DIVISION 6: TRAINING & PROFESSIONAL DEVELOPMENT**

 **15.01 Descriere și Scop**
 **Division 6: Training & Professional Development** este responsabilă pentru menținerea standardelor operaționale prin **Recruit Academy**, **Field Training Program**, certificări și educație continuă. Divizia asigură că toți membrii sunt competenți și pregătiți pentru provocările din teren.

 **15.02 Sistemul TIER**
- **TIER 1: Assistant** - Instructori asistenți sau FTO juniori.
- **TIER 2: Instructor/FTO** - Membri complet calificați să predea și să evalueze.
- **TIER 3: Senior/Coordinator** - Coordonatori de programe și instructori principali.
- **TIER 4: Division Lead** - Deține toate calificările și poate fi numit **Training Division Chief** de către **Bureau Commander**.

 **15.03 Poziții și Calificări**

 **Training Division Chief (Division Lead)**
 Liderul diviziei, numit de **Bureau Commander** bazat pe calificări și experiență. Coordonează întregul program de instruire al departamentului. Gestionează bugetul de training, dezvoltă standardele **SOP**, supraveghează **Academy Operations** și asigură conformitatea cu standardele statale și federale. Este responsabil pentru tracking-ul tuturor certificărilor membrilor. Răspunde direct la **Bureau Commander**.

 **Academy Director**
 Liderul operațional al **Recruit Academy**. Dezvoltă curriculum-ul, programează cursurile, alocă instructorii și urmărește progresul recruților. Este responsabil pentru disciplina recruților și standardele fizice.

 **Senior Academy Instructor**
 Instructor cu experiență care conduce echipele de instruire. Este expert în materie (**Subject Matter Expert**) pe domenii specifice (ex: **SCBA**, scări, furtunuri). Dezvoltă scenarii și asigură siguranța în timpul exercițiilor practice (**Live Fire**).

 **Field Training Officer (FTO) Coordinator**
 Gestionează programul **Field Training Program**. Selectează și instruiește FTO-urile, alocă **Probationary Firefighters** către mentori și revizuiește toate **Daily Observation Reports (DORs)** pentru a asigura consistența evaluării.

 **Field Training Officer (FTO)**
 Mentorul direct pentru noii angajați. Oferă instruire la locul de muncă (**On-the-Job Training**), completează **Task Books**, evaluează performanța zilnică și face recomandări pentru trecerea de perioada de probă sau terminarea angajării.

 **Certification Officer**
 Gestionează baza de date a certificărilor. Urmărește datele de expirare, programează cursuri de recertificare și coordonează instructorii externi sau vendorii pentru traininguri specializate.

 **Skills Development Instructor**
 Predă cursuri avansate și specializate (ex: **Technical Rescue**, **Hazmat**). Se concentrează pe educația continuă a personalului existent și pe introducerea de noi echipamente și tactici.

 **Scenario Designer**
 Creează scenarii de antrenament realiste și provocatoare. Planifică exerciții la scară largă (**Multi-Company Drills**), coordonează logistica necesară (recuzită, actori) și facilitează sesiunile de **After-Action Review (AAR)**.
 **15.04 Programe de Training**

 **Field Training Program (FTP):** Programul obligatoriu pentru Probationary Firefighters, oferind instruire directă (On-the-Job Training) de la un FTO pentru a atinge competențele operaționale de bază necesare pentru a deveni Firefighter.
 **Supervisor Training Program (STP):** Program obligatoriu pentru avansarea la Engineer, concentrat pe dezvoltarea abilităților de supervizare, operarea complexă a Apparatus-urilor, managementul resurselor și cunoștințe avansate de Incident Command System (ICS).
 **Officer Training Program (OTP):** Program obligatoriu pentru avansarea la Captain, axat pe comandă avansată, planificare strategică, managementul stației și luarea deciziilor la incidente majore (Major Incidents).

 **15.05 Cum se Solicită o Calificare**
 Orice membru care dorește să obțină o calificare nouă urmează procedura standardizată gestionată de **Division 6: Training & Professional Development**:

1. Membrul contactează **Division 6: Training & Professional Development** și specifică calificarea dorită.
2. **Division 6** verifică eligibilitatea (rank, calificări prealabile, disponibilitate program) și contactează membrul cu detaliile: cerințe, program de instruire și metoda de evaluare.
3. Membrul parcurge instruirea și evaluarea conform planului stabilit de **Division 6**.
4. La finalizare, **Certification Officer** înregistrează oficial calificarea în dosarul de personal al membrului.

 **Notă:** **Division 6** gestionează și recertificările periodice. Membrii sunt responsabili pentru monitorizarea propriilor calificări și pentru solicitarea recertificării înainte de expirare.

 **16. DIVISION 7: FLEET, LOGISTICS & COMMUNICATIONS**

 **16.01 Descriere și Scop**
 **Division 7: Fleet, Logistics & Communications** asigură suportul logistic necesar operațiunilor. Gestionează flota de vehicule (**Fleet**), lanțul de aprovizionare (**Supply Chain**) și infrastructura de comunicații (**Dispatch/Radio**). Obiectivul este menținerea stării de **Readiness** 24/7.

 **16.02 Sistemul TIER**
- **TIER 1: Entry Level** - Tehnicieni suport sau dispeceri de bază.
- **TIER 2: Specialist** - Tehnicieni flotă sau ofițeri de logistică.
- **TIER 3: Manager** - Manageri de secțiune (Fleet, Comms).
- **TIER 4: Division Lead** - Deține toate calificările și poate fi numit **Support Services Chief** de către **Bureau Commander**.

 **16.03 Poziții și Calificări**

 **Support Services Chief (Division Lead)**
 Liderul diviziei, numit de **Bureau Commander** bazat pe calificări și experiență. Coordonează toate serviciile de suport logistic. Gestionează bugetul diviziei, achizițiile majore de echipamente și vehicule, relațiile cu vendorii și planificarea strategică a infrastructurii IT și a facilităților. Răspunde direct la **Bureau Commander**.

 **Fleet Manager**
 Supervizează mentenanța flotei. Monitorizează starea de funcționare a tuturor **Apparatus**, programează întreținerea preventivă (**PM**), gestionează reparațiile și stocurile de piese. Este responsabil pentru testarea anuală a pompelor și scărilor.

 **Senior Fleet Technician**
 Execută diagnoze complexe și reparații majore. Asigură controlul calității (**QA**) pentru lucrările de mentenanță și oferă suport tehnic de urgență în teren pentru vehiculele defecte.

 **Communications Manager**
 Supraveghează centrul de dispecerat (**Metropolitan Fire Communications**). Gestionează canalele radio, procedurile de comunicare, sistemele **CAD** și protocoalele de **Failover** pentru continuitatea comunicațiilor.

 **Lead Dispatcher**
 Coordonează activitatea dispecerilor pe tură. Gestionează alocarea resurselor, monitorizează statusul unităților și servește ca interfață principală cu **Incident Commanders** la incidente majore.

 **Supply Officer**
 Gestionează inventarul și distribuția. Se ocupă de achiziția consumabilelor medicale, echipamentului de curățenie și uniformelor. Menține stocurile minime necesare în stații și depozite.

 **Facilities Coordinator**
 Responsabil pentru întreținerea clădirilor (stațiilor). Gestionează tichetele de reparații pentru facilități, coordonează contractorii pentru lucrări și se ocupă de infrastructura IT de bază din stații.

 **17. DIVISION 8: ADMINISTRATION & HUMAN RESOURCES**

 **17.01 Descriere și Scop**
 **Division 8: Administration & Human Resources** gestionează capitalul uman, procesele administrative, afacerile interne și imaginea publică a departamentului. Asigură conformitatea cu politicile și procese administrative transparente.

 **17.02 Sistemul TIER**
- **TIER 1: Assistant** - Asistenți HR sau Records.
- **TIER 2: Officer** - Ofițeri HR sau coordonatori recrutare.
- **TIER 3: Senior** - Ofițeri Afaceri Interne sau PIO.
- **TIER 4: Division Lead** - Deține toate calificările și poate fi numit **Administrative Services Chief** de către **Bureau Commander**.

 **17.03 Poziții și Calificări**

 **Administrative Services Chief (Division Lead)**
 Liderul diviziei administrative, numit de **Bureau Commander** bazat pe calificări și experiență. Coordonează HR, Internal Affairs și relațiile publice. Gestionează rapoartele executive și conformitatea legală a departamentului. Răspunde direct la **Bureau Commander**.

 **Human Resources Officer**
 Gestionează ciclul de viață al angajaților. Se ocupă de **Onboarding**, contracte, beneficii, dosare de personal și conformitatea cu politicile de muncă. Gestionează plângerile administrative non-disciplinare.

 **Recruitment Coordinator**
 Coordonează procesul de recrutare. Organizează campaniile de angajare, screening-ul aplicațiilor, panel-urile de interviu și verificările de background pentru candidați.

 **Internal Affairs Officer**
 Conduce investigațiile interne disciplinare. Asigură **Due Process** pentru angajații investigați, colectează probe, intervievează martori și redactează rapoarte finale cu recomandări de sancțiuni către conducere.

 **Employee Relations Officer**
 Mediază disputele dintre angajați și management. Se ocupă de programele de reîntoarcere la muncă după accidentări, acomodări speciale și menținerea unui climat de lucru pozitiv.

 **Records Management Officer**
 Arhivarul șef al departamentului. Gestionează clasificarea și retenția documentelor, asigură accesul controlat la dosare sensibile și răspunde la solicitările oficiale de înregistrări.

 **Public Information Officer (PIO)**
 Gestionează comunicarea externă. Este purtătorul de cuvânt la incidentele majore, redactează comunicate de presă, gestionează relația cu media și coordonează mesajul public cu **Fire Chief** și **Incident Commanders**.

 **18. POLITICI OPERAȚIONALE**

 **18.01 Scop**
 Acest capitol stabilește reglementările și așteptările operaționale pentru angajații Departamentului în timpul desfășurării activității în teren.

 **18.02 Utilizarea Asistenței Civile**
 Angajații nu au permisiunea de a solicita asistența civililor care nu servesc într-o capacitate oficială la un incendiu, intervenție medicală sau **Rescue**. Aceasta este exclusă doar în circumstanțe exigente (ex: **Mass Casualty Incident**) unde există o credință rezonabilă că situația este o chestiune de viață și de moarte. În acest caz, numele complet al civilului trebuie inclus în **Incident Report**. Angajatul este responsabil pentru acțiunile civilului.

 **18.03 Ride Alongs**
 Angajații pot înrola un (1) individ ca **Ride Along** în **Apparatus** sau în **Fire Station**. Membrii publicului trebuie să prezinte identificare legală, să aibă peste 18 ani și să semneze un **Waiver** de responsabilitate. Trebuie efectuat un **Pat Down** pentru arme înainte de începere.

 **18.03.01 Comportamentul unui Ride Along**
 Acești indivizi nu au niciun statut în cadrul Departamentului și nu au permisiunea de a asista în nicio capacitate operațională. Ei trebuie plasați într-o zonă sigură (**Cold Zone**) unde nu vor servi ca distragere.
 ***((**: Indivizii care participă la Ride Along și aleg să facă "trolling" vor fi ejectați imediat pe motive Out-of-Character.**))***

 **18.03.02 Încheierea unui Ride Along**
 Un **Ride Along** poate fi terminat oricând de către **Incident Commander** sau **Station Captain** dacă prezența civilului cauzează un risc sau o problemă majoră. La final, individului trebuie să i se asigure transportul înapoi la locația de start.

 **18.04 Găsirea Obiectelor de Valoare**
 Bani, bijuterii sau alte proprietăți valoroase găsite la o scenă de urgență trebuie predate imediat către **Incident Commander**, un **Peace Officer** (Poliție) sau un **Investigator** autorizat pentru păstrare în siguranță. Angajații nu pot păstra proprietăți găsite pentru uz personal.

 **18.05 Personal În Afara Serviciului**
 Angajații care ajung la o scenă de urgență în timp ce sunt **Off-Duty** sunt interziși să se angajeze în incident, cu excepția cazului în care sunt solicitați specific de **Incident Commander**. Altfel, aceștia sunt considerați civili și nu trebuie să intervină în operațiuni.

 **18.06 Descoperirea unui Incident în Timpul Răspunsului**
 Echipajele care răspund la un apel și descoperă un alt incident pe traseu trebuie să facă un **Size-up** rapid. Dacă noul incident este critic (**Emergent**), echipajul va informa **Dispatch**-ul, se va opri la noul incident și **Dispatch**-ul va aloca o altă unitate pentru apelul original. Dacă nu este critic, vor notifica **Dispatch**-ul și vor continua spre destinația inițială.

 **18.07 Găsirea unui Cadavru**
 Echipajele care descoperă o persoană evident decedată trebuie să evite modificarea sau perturbarea corpului și a scenei, pentru a prezerva probele. Trebuie notificat **Metropolitan Fire Communications**, care va contacta **Law Enforcement** și **Coroner**.

 **18.08 Panic Alarm și Conștientizarea Distress-ului**
 Toți **Firefighters** sunt echipați cu o **Panic Alarm** pe stația radio Motorola. Aceasta permite comunicarea rapidă și silențioasă către **Dispatch** că angajatul este în pericol iminent ("Distress"), unde comunicarea verbală ar risca agravarea situației.
 ***((**: Se utilizează comanda /hq cu sintaxa: *Panic Alarm Activated - Nume Prenume*.**))***

 **18.09 Dash Camera Footage**
 Majoritatea **Apparatus**-urilor sunt echipate cu camere de bord. Înregistrările video pornesc automat la pornirea motorului. Înregistrările audio pornesc automat la activarea **Lights and Sirens**. Accesul la aceste înregistrări este restricționat pentru **Fire Administration** și **Professional Standards Division**.

 **18.10 Comenzi Faction **((****))****
 Utilizarea comenzilor de facțiune (ex: /dep, /duty, /towcar) în scopuri abuzive sau nerealiste este strict interzisă și va rezulta în acțiuni disciplinare.

 **19. POLITICI DE COMUNICARE**

 **19.01 Scop**
 Acest capitol stabilește standardele pentru sistemele de comunicație utilizate de angajați.

 **19.02 Telefoane**
 Liniile fixe din **Fire Station** trebuie să fie răspunse profesional: *"Fire Station [Număr], [Rank] [Numele de familie]"*.

 **19.03 Telefoane Mobile**
 Angajații pot purta telefoane personale, dar acestea nu trebuie folosite în timpul operării pe o scenă activă, în timpul **Training**-ului sau când conduc un **Apparatus**. Dispozitivele trebuie să fie pe modul vibrații. Înregistrările video/foto cu telefoanele personale la scenă sunt interzise fără permisiunea **Chief Fire Officers**.

 **19.04 Pagere**
 **Pagers** sunt necesare atât **On-Duty** cât și **Off-Duty**. Acestea sunt folosite de **Dispatch** pentru rechemarea personalului ("Recall") în situații de urgență majoră sau deficit de resurse.

 **19.05 Computere și MDT-uri**
 Computerele din stație și **Mobile Data Terminals (MDT)** din vehicule sunt strict pentru uz departamental. Accesarea site-urilor ilegale sau explicite este interzisă.

 **19.06 Comunicații Radio**
 Se utilizează "Plain English" (limbaj clar), fără coduri radio (10-codes), pentru a menține un standard clar. Comunicațiile trebuie să fie lipsite de argou sau vulgarități. Locațiile trebuie referențiate prin numele străzii (folosind /streetname **((**).

 **19.06.01 Utilizarea Frazelor**
- *"[Callsign] responding emergent/non-emergent to [Locație]."*
- *"[Callsign] on scene at [Locație]."*
- *"[Callsign] transporting to [Spital] with [Număr Pacienți] loaded."*
- *"[Callsign] clear from last, back in service."*

 **19.06.02 Frecvențe**
 Angajații trebuie să aibă radioul setat pe frecvențele corecte la începutul fiecărui **Shift**. Canalele departamentale sunt:
- **Stația 712 — Metropolitan Fire Communications (Dispatch / Canal Principal):** Canalul de bază pe care se desfășoară toate comunicațiile cu **Dispatch** și raportările generale ale scenei. Toate unitățile monitorizează 712 în permanență.
- **Stația 713 — IC1 / TAC1 (Tactic Channel 1):** Canal tactic dedicat incidentelor active. Alocat de **Incident Commander** când traficul radio pe 712 trebuie degrevat sau când un sector al incidentului necesită coordonare separată.
- **Stația 714 — IC2 / TAC2 (Tactic Channel 2):** Canal tactic secundar, folosit la incidente simultane sau la sectorizarea unui incident major cu mai multe zone de operare. Echipajele de pe 714 raportează periodic pe 712 prin IC sau prin **Operations Coordinator**.

 **19.06.03 Format de Comunicare Radio**
 Toate transmisiile radio respectă un format standardizat pentru claritate și identificare rapidă. **Nu se folosesc prescurtări, coduri informale sau argou**.

 **Format general (transmisie de raport sau anunț):**
- *"[Rank] [Prenume] [Nume], [mesaj]."*    Exemple:  - *"Lieutenant Maria Ionescu, Engine 7 la scena in [locatie], structura pe doua niveluri cu smoke showing, preiau Command."* - *"Firefighter Dan Popescu, primary search finalizat, nicio victima gasita, etajul doi clear."* - *"Engineer Alex Dumitrescu, water supply stabilit de la hidrantul din [locatie], pump pressures nominale."*

 **Format cu destinatar (cerere directă sau raport adresat):**
- *"[Rank] [Prenume] [Nume] towards [Rank] [Prenume] [Nume], [mesaj]."*    Exemple:  - *"Firefighter Radu Marin towards Lieutenant Maria Ionescu, victima localizata in camera 204, solicit EMS la etajul doi."* - *"Captain George Stancu towards Battalion Chief Ana Popa, solicit doua Engines si un Truck aditional pentru exposure protection."*

 **Notă:** Destinatarul confirmă recepția înainte de a răspunde: *"[Rank] [Prenume] [Nume], copy."* Dacă nu există confirmare în 15-20 de secunde, transmisia se repetă.

 **19.07 Asignări Radio**
- **Command 1 (CM1):** Rezervat pentru **Incident Command**.
- **Battalion 11 (B11):** **Battalion Chief**.
- **Rescue Ambulance (RA##):** Unități **ALS**.
- **Engine (E##):** Unități de stingere primare.

 **19.08 Terminologie și Coduri de Răspuns**

 **Coduri de răspuns:** Codurile indică modul și urgența deplasării unui echipaj. Dispatch le anunță la alocarea apelului; IC le poate modifica pe parcursul intervenției.
- **Code 0 — Emergency Traffic / Canal Liber:** Declarat exclusiv de **Incident Commander** sau de **Dispatch**. Toate transmisiile de pe canal se opresc imediat; se acordă prioritate absolută traficului de urgență. Se folosește la **Mayday**, **Firefighter Down** sau orice situație care pune în pericol imediat viața unui angajat. Se anunță de trei ori: *"Code 0, Code 0, Code 0 — [motiv] — [Rank] [Prenume] [Nume] has Priority Traffic."*
- **Code 1 — Răspuns Non-Urgent:** Echipajul se deplasează fără lumini sau sirene, respectând codul rutier. Se folosește la apeluri de rutină care nu prezintă risc iminent pentru viață sau proprietate.
- **Code 2 — Răspuns Urgent:** Echipajul se deplasează cu lumini de avertizare active, fără sirenă. Se folosește când situația este importantă dar nu critica — de exemplu, reinforcements non-emergente sau transfer de pacient stabil.
- **Code 3 — Răspuns de Urgență:** Echipajul se deplasează cu lumini și sirenă active, cu prioritate de trecere. Se folosește la incendii active, accidente cu victime, urgențe medicale critice și orice incident în care întârzierea prezintă risc vital.
- **Code 4 — Scenă Securizată:** Declarat de **Incident Commander** la finalizarea intervenției. Indică faptul că scena este sub control, riscurile au fost eliminate și resursele suplimentare nu mai sunt necesare. Echipajele raportează *"Clear from scene, back in service"* și revin pe Stația 712.

 **Terminologie generală:**
- **MCI (Mass Casualty Incident):** Incident cu victime multiple care depășesc capacitatea de răspuns imediată. Necesită activarea planului MCI și solicitarea de resurse suplimentare.
- **Priority Traffic:** Mesaj urgent care necesită liniște pe frecvență. Se anunță înainte de transmisie; celelalte unități suspendă comunicările.
- **Mayday:** Semnal de urgență transmis de un pompier aflat în pericol iminent. Declanșează automat **Code 0** și activarea **RIT (Rapid Intervention Team)**.
- **PAR (Personnel Accountability Report):** Verificarea periodică a prezenței și stării întregului personal activ la scenă, solicitată de IC.

 **19.09 Email-uri și Scrisori Departamentale**
 Comunicarea oficială folosește formatul proprietar: DD/MMM/YYYY pentru date și format militar (XX:XX) pentru oră.

 **19.10 Metropolitan Fire Communications**
 Cunoscut și ca **Dispatch**, gestionează toate apelurile de urgență și resursele. **Dispatch** are autoritate asupra alocării unităților, cu excepția cazului în care un **Department Officer** (ex: **Station Captain**) modifică ordinul pe baza nevoilor locale.

 **19.11 Partajarea Informațiilor**
 **19.11.01 Informații Pacient**
 Protejate strict de legile de confidențialitate (HIPAA). Nu se discută detalii despre pacienți în public sau cu persoane neautorizate.

 **19.11.02 Documente Departamentale**
 Documente precum **MOP**, **Patient Care Reports** sau **Incident Reports** sunt protejate și nu pot fi partajate extern.

 **19.12 Discord **((****))****
 Membrii facțiunii trebuie să fie prezenți pe serverul de **Discord** al facțiunii pentru anunțuri administrative și coordonare **OOC**. Nickname-ul trebuie să fie numele caracterului. Canalele de voce pot fi utilizate pentru coordonare vocală, dar comunicarea **IC** (radio traffic) se face text sau prin script.

 **20. POLITICI FLOTĂ ȘI FACILITĂȚI**

 **20.01 Scop**
 Stabilește regulile pentru utilizarea și întreținerea **Fire Stations** și a **Apparatus**-urilor.

 **20.02 Responsabilitate**
 **Station Captains** au autoritate asupra stației lor. Sunt responsabili pentru curățenie, starea echipamentului și comportamentul personalului în incintă.

 **20.03 Conceptul Open House**
 Departamentul operează un concept de "uși deschise", permițând cetățenilor să viziteze stația la ore rezonabile. Stația trebuie să fie mereu curată și prezentabilă.

 **20.04 Vizitatori**
 Vizitatorii trebuie întâmpinați cu politețe și escortați. Nu au voie să umble liberi prin stație. Vizitatorii sub 18 ani necesită supraveghere prioritară. Vizitele sunt interzise între orele 22:00 și 11:00, cu excepția permisiunilor speciale.

 **20.05 Înregistrări și Ordine**
 Nu se completează documentație (rapoarte) în timp ce echipajul este pe o scenă activă. Toate rapoartele se fac după încheierea incidentului ("Clear from scene").

 **20.06 Callsign-uri si Apparatus**

 Fiecare unitate operationala a Departamentului are un callsign unic, utilizat exclusiv pe radio si in rapoartele de incident. Callsign-ul identifica stația, rolul unitatii si numarul individual al vehiculului.

 **Legenda prefixelor:**
- **RA##** — Rescue Ambulance (ALS)
- **E##** — Engine
- **R##** — Rescue
- **SQ##** — Squad
- **FR##** — First Response
- **LS##** — Line Supervisor (SUV)
- **BU##** — Battalion Unit
- **CU##** — Command Unit
- **FC#** — Fire Chief

 **Ierarhia de comanda vehicule:** **LS** (Supervisor SUV) → **BU** (Battalion) → **CU** (Command) → **FC** (Fire Chief)

---

---

 **Fire Station 3 — Davis**
- **RA310, RA311, RA312** — Rescue Ambulance (ALS)
- **E318, E319** — Engine
- **FR325** — First Response
- **LS31** — Line Supervisor
- **CU31** — Command Unit

 **Fire Station 132 — Marina**
- **RA111** — Rescue Ambulance (ALS)
- **E125** — Engine
- **CU11** — Command Unit

 **Fire Station 72 — El Burro**
- **RA710 — RA730** — Rescue Ambulance (ALS)
- **FR750 — FR760** — First Response
- **E760 — E770** — Engine
- **R785, R787** — Rescue
- **SQ795, SQ797** — Squad
- **LS71, LS72** — Line Supervisor
- **BU71, BU72** — Battalion Unit
- **CU71, CU72** — Command Unit
- **FC1** — Fire Chief

 **20.07 Îndatoriri Stație**
 **Firefighters** sunt responsabili pentru curățenia zilnică ("Station Chores"): măturat, spălat podele, curățat **Apparatus**, golirea gunoiului. **Dorm**-urile trebuie eliberate de lenjerie la începutul turei.

 **20.08 Reparații**
 Angajații trebuie să raporteze imediat echipamentele defecte unui **Department Officer**. Nu au voie să autorizeze reparații singuri.
 ***((**: Reparațiile la Pay N Spray sunt pentru daune mecanice OOC. Nu există sistem de combustibil script-wise.**))***

 **20.09 Pregătirea Apparatus**
 Vehiculele trebuie să fie gata de desfășurare ("Response Ready") în orice moment. Curățenia nu trebuie să scoată vehiculul din serviciu (**OOS**) decât dacă este absolut necesar și aprobat.

 **20.10 Arme de Foc și Alte Arme**
 Armele de foc, muniția și alte arme sunt strict interzise în **Fire Station** și în **Apparatus**. Excepție fac **Peace Officers** aflați în serviciu.

 **20.11 Vehicule Personale**
 Parcarea vehiculelor personale este interzisă în interiorul stației sau pe trotuarul din față, cu excepția bicicletelor/motocicletelor mici, cu aprobarea **Station Captain**.

 **20.12 Desfășurarea Apparatus**
 Scopul este un răspuns standardizat și ordonat.
- **Rescue Ambulances:** Trebuie să aibă un echipaj de 2 persoane.
- **Engine/Truck Companies:** Trebuie să aibă un echipaj de minim 2 persoane.

 ***((**: "Solo crewing" este permis doar dacă nu sunt alți membri on-duty. Dacă există personal, formarea echipajelor complete este prioritară.**))***

 **20.13 Desfășurări de Răspuns**
 Personalul trebuie să aștepte la stație pentru alocarea apelurilor. Echipajele care nu respectă regulile de desfășurare vor fi sancționate disciplinar.

 **20.13.01 Desfășurare la Incident**
- **Medical Incidents:** Se trimite o **Rescue Ambulance** și, dacă este disponibil, un **Engine** pentru suport (manpower) și un **Medical Supervisor**.
- **Fire Incidents:** Se trimit **Engines** și **Trucks** conform deciziei **Incident Commander**-ului, plus cel puțin o **Rescue Ambulance** pentru siguranța pompierilor ("Standby").

---

---

**))**
---

---

---

---

---

---

---

---

---

---

---

---

---

---

---
