# Model Dosar

- **Topic ID:** 54
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=54
- **Posts:** 2

---

## #1 — Kellan Dunley

============================================================
 INSTRUCȚIUNI PENTRU FTO — DOSAR PRINCIPAL FTP
 ============================================================

 Acest template se completează O SINGURĂ DATĂ, la momentul în care îți este repartizat un trainee.
 Postează-l ca PRIMUL POST în threadul dedicat trainee-ului tău.

 Ulterior, vei actualiza dosarul (prin editarea postului inițial) în aceste momente:
 → Când trainee-ul avansează la o fază nouă (actualizezi tracker-ul de faze)
 → Când adaugi un link DOR nou în indexul de rapoarte
 → Când emiti un Strike (îl adaugi în tabelul de strike-uri)
 → La finalul programului (completezi secțiunea DECIZIE FINALĂ)

 LEGENDA SIMBOLURI TRACKER FAZE:
 □ = Neîncepută
 ▶ = În desfășurare
 ✓ = Finalizată cu succes
 ✗ = Repetată / Eșuată

 LEGENDA STATUS FINAL:
 → **PROMOVAT** — Trainee a absolvit FTP; se înaintează dosarul la Division 6
 → **RESPINS** — Trainee nu a îndeplinit standardele la Evaluarea Finală
 → **EXCLUS** — Trainee eliminat din program înainte de Evaluarea Finală

 ============================================================
 ÎNCEPE SĂ COPIEZI DE LA LINIA [birou] DE MAI JOS
 ============================================================

 (( ============================================================
 INSTRUCȚIUNI PENTRU FTO — CITEȘTE ÎNAINTE DE UTILIZARE
 ============================================================

 Acest template se completează la finalul fiecărei zile de activitate cu trainee-ul.
 Copiază tot conținutul marcat cu [birou] și postează-l pe forum în threadul dedicat trainee-ului.

 SCALA DE EVALUARE (înlocuiește [EVALUARE] cu una din variantele de mai jos):
 → **DOES NOT MEET** — Nu îndeplinește așteptările; corecție imediată necesară
 → **MEETS** — Îndeplinește așteptările; performanță de bază acceptabilă
 → **EXCEEDS** — Depășește așteptările; performanță solidă, auto-motivat
 → **OUTSTANDING** — Excepțional; acordat rar, doar pentru performanțe remarcabile

 RECOMANDARE FINALĂ (înlocuiește [RECOMANDARE] cu una din variantele de mai jos):
 → **CONTINUARE FAZĂ** — Trainee continuă faza curentă; progres normal
 → **AVANSARE LA FAZA URMĂTOARE** — Trainee a îndeplinit toate obiectivele fazei; FTO recomandă avansarea
 → **INSTRUIRE REMEDIALĂ** — Trainee prezintă deficiențe care necesită intervenție suplimentară
 → **STRIKE NIVEL I** — Sancțiune minoră (greșeli procedurale, inatenție, activitate scăzută)
 → **STRIKE NIVEL II** — Sancțiune medie (insubordonare, neglijență, disruption la scenă)
 → **STRIKE NIVEL III** — Sancțiune severă (misconduct grav, unsafe behavior, fail RP)

 Dacă în aceeași zi se acordă atât o evaluare DOR cât și un Strike, completează ambele secțiuni.
 Câmpurile marcate cu (*) sunt obligatorii. Cele marcate cu [opțional] pot fi lăsate goale dacă nu se aplică.

 ============================================================
 ÎNCEPE SĂ COPIEZI DE LA LINIA [birou] DE MAI JOS
 ============================================================ ))

![](https://i.imgur.com/2jlMxHe.png)

TRAINING DIVISION

---

 **DOSAR FIELD TRAINING PROGRAM**
 **FTP Personnel File**
 *Los Santos Fire Department | Training & Professional Development Bureau*

 **— PROFIL TRAINEE —**

 **Nume Complet (IC):** Prenume Nume
 **Rank:** Probationary Firefighter
 **Stație Atribuită:** Station ##
 **Data Intrării în FTP:** ZZ luna AAAA (IC) | ZZ/LL/AAAA (OOC)
 **Data Estimată de Finalizare:** ZZ luna AAAA (IC) | ZZ/LL/AAAA (OOC)
 **Număr Dosar:** FTP-[AAAA]-[###] *(ex: FTP-2026-001)*

 **— FIELD TRAINING OFFICER ATRIBUIT —**

 **Nume FTO (IC):** Prenume Nume
 **Rank FTO:** Rank
 **Supervizor Program:** Prenume Nume | Rank *(Captain+ sau Division 6 Lead)*

 **— TRACKER FAZE FTP —**

 *Actualizează simbolul și detaliile la fiecare tranziție de fază.*

 **□ FAZA I — Introduction (Observare)**
 Durată minimă: 1 săptămână operațională
 Data start: [—] | Data finalizare: [—]
 Zile active: [—] | Status: [Neîncepută]

 **□ FAZA II — Operațiuni Asistate**
 Durată minimă: 2–3 săptămâni operaționale
 Data start: [—] | Data finalizare: [—]
 Zile active: [—] | Status: [Neîncepută]

 **□ FAZA III — Conducere Controlată**
 Durată minimă: 3–4 săptămâni operaționale
 Data start: [—] | Data finalizare: [—]
 Zile active: [—] | Status: [Neîncepută]

 **□ FAZA IV — Evaluare Finală**
 Durată: 1 zi operațională
 Data evaluare: [—]
 Rezultat: [—] | Status: [Neîncepută]

 **— INDEX RAPOARTE DOR —**

 *Adaugă linkul fiecărui DOR postat, în ordine cronologică.
 Format: Ziua # | Faza # | Data | Link*

 **Faza I:**
- Ziua 1 | Faza I | [Data] | [**DOR #1**](https://lsfd.ro-rp.mp/LINK)
- Ziua 2 | Faza I | [Data] | [**DOR #2**](https://lsfd.ro-rp.mp/LINK)
- *— adaugă rânduri pe măsură ce postezi DOR-uri —*

 **Faza II:**
- Ziua 1 | Faza II | [Data] | [**DOR #**](https://lsfd.ro-rp.mp/LINK)
- *— adaugă rânduri pe măsură ce postezi DOR-uri —*

 **Faza III:**
- Ziua 1 | Faza III | [Data] | [**DOR #**](https://lsfd.ro-rp.mp/LINK)
- *— adaugă rânduri pe măsură ce postezi DOR-uri —*

 **Faza IV:**
- Ziua evaluare | Faza IV | [Data] | [**DOR Final**](https://lsfd.ro-rp.mp/LINK)

 **Total DOR-uri postate:** [0]

 **— ISTORIC STRIKE-URI —**

 *Completează fiecare rând la momentul emiterii unui Strike.
 Dacă trainee-ul nu a primit niciun Strike, lasă tabelul cu „Fără sancțiuni înregistrate".*

 **Fără sancțiuni înregistrate.**

 *Model de completare când apare un Strike:*
 *Strike #1 | Nivel I | [Data] | Motiv: [descriere scurtă] | DOR referință: [link]*
 *Strike #2 | Nivel II | [Data] | Motiv: [descriere scurtă] | DOR referință: [link]*

 **Total strike-uri:** [0] | **Nivel I:** [0] | **Nivel II:** [0] | **Nivel III:** [0]

 **— OBSERVAȚII GENERALE FTO —**

 *Secțiune opțională — actualizabilă pe parcurs.
 Notează aici observații generale despre profilul trainee-ului, punctele forte, ariile de îmbunătățire
 sau orice informație relevantă care nu se regăsește în DOR-uri.*

 [Data] — [Observație]
 [Data] — [Observație]

 **— DECIZIE FINALĂ —**

 *Completează această secțiune EXCLUSIV la finalizarea FTP-ului (după Faza IV).*

 **Decizie:** [NECOMPLETATĂ]
 **Justificare:** [—]
 **Data deciziei (IC):** [—]
 **Data deciziei (OOC):** [—]
 **Aprobat de:** [—] | [Rank]
 **Dosar înaintat la Division 6:** [ DA / NU ]

 **— SEMNĂTURĂ FTO —**

 **Dosar deschis de:** Prenume Nume | Rank | LSFD
 **Data deschiderii:** ZZ/LL/AAAA
 **Ultima actualizare:** ZZ/LL/AAAA

 *Dosarul FTP este un document oficial al LSFD — Training & Professional Development Bureau.
 Toate informațiile trebuie să fie complete, corecte și actualizate la zi.
 Falsificarea sau neglijarea deliberată a dosarului constituie conduită gravă.*
---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

![](https://i.imgur.com/2jlMxHe.png)

TRAINING DIVISION

---

 **RAPORT DE OBSERVARE ZILNICĂ**
 **Daily Observation Report — DOR**
 *Field Training Program | Los Santos Fire Department*

 **— INFORMAȚII RAPORT —**

 **Trainee:** Prenume Nume (*)
 **Rank Trainee:** Probationary Firefighter
 **FTO:** Prenume Nume (*)
 **Rank FTO:** Rank FTO (*)
 **Faza FTP:** Faza [I / II / III / IV] — Ziua [#] (*)
 **Data IC:** ZZ luna AAAA (*)
 **Data OOC:** ZZ/LL/AAAA (*)

 **— ACTIVITATE ȘI INCIDENTE NOTABILE —**

 **Sumar activitate:**
 [Descrie pe scurt ce activități au avut loc în această tură: patrulare, intervenții, training în stație etc. 2-4 propoziții.]

 **Incidente notabile — POZITIVE:**
 [Descrie momentele în care trainee-ul a demonstrat performanță bună, inițiativă sau aplicare corectă a procedurilor. Fii specific — ce a făcut, în ce context, de ce este notabil. Dacă nu există, scrie: N/A]

 **Incidente notabile — NEGATIVE:**
 [Descrie erorile, momentele de ezitare sau comportamentele inadecvate observate. Explică ce s-a întâmplat, cum a reacționat trainee-ul la corecție și ce trebuie îmbunătățit. Dacă nu există, scrie: N/A]

 **— EVALUAREA CATEGORIILOR DOR —**

 *Înlocuiește [EVALUARE] cu scala corespunzătoare (culoare + text conform legendei de mai sus).
 Adaugă un comentariu scurt, specific și obiectiv pentru fiecare categorie.*

 **1. Comunicare Radio:** [EVALUARE]
 *Comentariu: [ex: A folosit corect callsign-ul și frazele standard. Tinde să transmită informații nesolicitate pe frecvență.]*

 **2. Siguranța la Fața Locului:** [EVALUARE]
 *Comentariu: [ex: A identificat pericolele la sosire dar a omis verificarea zonei din spatele vehiculului înainte de descărcare.]*

 **3. Cunoștințe Medicale:** [EVALUARE]
 *Comentariu: [ex: A realizat corect triajul și a aplicat DR ABC. A ezitat în aplicarea garoului la pacientul cu hemoragie activă.]*

 **4. Proceduri de Stingere:** [EVALUARE]
 *Comentariu: [ex: Bună coordonare la poziționarea furtunului. A necesitat reamintire pentru verificarea EIP înainte de intrare.]*

 **5. Luarea Deciziilor:** [EVALUARE]
 *Comentariu: [ex: Decizii corecte în situații de rutină. Sub presiune tinde să aștepte îndrumare în loc să acționeze independent.]*

 **6. Managementul Stresului:** [EVALUARE]
 *Comentariu: [ex: Calm și eficient la scena cu un pacient. La MCI cu două victime a prezentat semne de agitație vizibilă.]*

 **7. Profesionalism:** [EVALUARE]
 *Comentariu: [ex: Conduită exemplară în stație și față de public. Limbajul radio ocazional neprotocolar.]*

 **8. Lucrul în Echipă:** [EVALUARE]
 *Comentariu: [ex: Colaborare bună cu echipajul. Nu a comunicat proactiv când a identificat o deficiență de echipament.]*

 **9. Redactarea Rapoartelor:** [EVALUARE]
 *Comentariu: [ex: Raportul de incident complet și bine structurat. Câteva erori gramaticale minore. Depus în termen.]*

 **10. Conformitatea cu SOP-urile:** [EVALUARE]
 *Comentariu: [ex: Respectă procedurile de bază în mod consistent. Nu cunoaște procedura de Scene Release — de studiat.]*

 **— RECOMANDARE FTO —**

 **Recomandare:** [RECOMANDARE]

 **Justificare:**
 [Explică pe scurt motivul recomandării tale. De ce consideri că trainee-ul ar trebui să continue / să avanseze / să primească remedial sau strike? Fii concret și bazează-te pe observațiile din această tură. Minimum 2-3 propoziții.]

 **Obiective pentru ziua următoare:**
 [Listează 2-3 domenii specifice pe care trainee-ul trebuie să le îmbunătățească sau să le demonstreze în tura următoare. Fii specific — nu „să fie mai atent", ci „să aplice DR ABC fără prompting la prima evaluare a pacientului".]
- [Obiectiv 1]
- [Obiectiv 2]
- [Obiectiv 3 — opțional]

 **Strike emis în această tură:** [DA / NU]
 [Dacă DA — specifică Nivelul și motivul complet în câmpul de mai jos]
 **Detalii strike [opțional]:**
 [Descriere completă a incidentului care a generat strike-ul, acțiunile imediate luate și consecințele comunicate trainee-ului.]

 **— SEMNĂTURĂ FTO —**

 **Raport completat de:** Prenume Nume | Rank | LSFD
 **Data emiterii:** ZZ/LL/AAAA

 *Acest raport este un document oficial al LSFD — Training & Professional Development Bureau.
 Falsificarea sau omiterea deliberată a informațiilor relevante constituie conduită gravă.*
---

---

---

---

---

---

---

---

---

---

```
[birou=TRAINING DIVISION white]

[center][b]DOSAR FIELD TRAINING PROGRAM[/b]
[b]FTP Personnel File[/b]
[i]Los Santos Fire Department | Training & Professional Development Bureau[/i][/center]

[hr]

[center][b]— PROFIL TRAINEE —[/b][/center]

[b]Nume Complet (IC):[/b] Prenume Nume
[b]Rank:[/b] Probationary Firefighter
[b]Stație Atribuită:[/b] Station ##
[b]Data Intrării în FTP:[/b] ZZ luna AAAA (IC) | ZZ/LL/AAAA (OOC)
[b]Data Estimată de Finalizare:[/b] ZZ luna AAAA (IC) | ZZ/LL/AAAA (OOC)
[b]Număr Dosar:[/b] FTP-[AAAA]-[###]   [i](ex: FTP-2026-001)[/i]

[hr]

[center][b]— FIELD TRAINING OFFICER ATRIBUIT —[/b][/center]

[b]Nume FTO (IC):[/b] Prenume Nume
[b]Rank FTO:[/b] Rank
[b]Supervizor Program:[/b] Prenume Nume | Rank   [i](Captain+ sau Division 6 Lead)[/i]

[hr]

[center][b]— TRACKER FAZE FTP —[/b][/center]

[i]Actualizează simbolul și detaliile la fiecare tranziție de fază.[/i]

[b]□ FAZA I — Introduction (Observare)[/b]
Durată minimă: 1 săptămână operațională
Data start: [—]     |     Data finalizare: [—]
Zile active: [—]    |     Status: [Neîncepută]

[b]□ FAZA II — Operațiuni Asistate[/b]
Durată minimă: 2–3 săptămâni operaționale
Data start: [—]     |     Data finalizare: [—]
Zile active: [—]    |     Status: [Neîncepută]

[b]□ FAZA III — Conducere Controlată[/b]
Durată minimă: 3–4 săptămâni operaționale
Data start: [—]     |     Data finalizare: [—]
Zile active: [—]    |     Status: [Neîncepută]

[b]□ FAZA IV — Evaluare Finală[/b]
Durată: 1 zi operațională
Data evaluare: [—]
Rezultat: [—]       |     Status: [Neîncepută]

[hr]

[center][b]— INDEX RAPOARTE DOR —[/b][/center]

[i]Adaugă linkul fiecărui DOR postat, în ordine cronologică.
Format: Ziua # | Faza # | Data | Link[/i]

[b]Faza I:[/b]
[list]
[*]Ziua 1 | Faza I | [Data] | [url=LINK][b]DOR #1[/b][/url]
[*]Ziua 2 | Faza I | [Data] | [url=LINK][b]DOR #2[/b][/url]
[*][i]— adaugă rânduri pe măsură ce postezi DOR-uri —[/i]
[/list]

[b]Faza II:[/b]
[list]
[*]Ziua 1 | Faza II | [Data] | [url=LINK][b]DOR #[/b][/url]
[*][i]— adaugă rânduri pe măsură ce postezi DOR-uri —[/i]
[/list]

[b]Faza III:[/b]
[list]
[*]Ziua 1 | Faza III | [Data] | [url=LINK][b]DOR #[/b][/url]
[*][i]— adaugă rânduri pe măsură ce postezi DOR-uri —[/i]
[/list]

[b]Faza IV:[/b]
[list]
[*]Ziua evaluare | Faza IV | [Data] | [url=LINK][b]DOR Final[/b][/url]
[/list]

[b]Total DOR-uri postate:[/b] [0]

[hr]

[center][b]— ISTORIC STRIKE-URI —[/b][/center]

[i]Completează fiecare rând la momentul emiterii unui Strike.
Dacă trainee-ul nu a primit niciun Strike, lasă tabelul cu „Fără sancțiuni înregistrate".[/i]

[b]Fără sancțiuni înregistrate.[/b]

[i]Model de completare când apare un Strike:[/i]
[i]Strike #1 | Nivel I | [Data] | Motiv: [descriere scurtă] | DOR referință: [link][/i]
[i]Strike #2 | Nivel II | [Data] | Motiv: [descriere scurtă] | DOR referință: [link][/i]

[b]Total strike-uri:[/b] [0]   |   [b]Nivel I:[/b] [0]   |   [b]Nivel II:[/b] [0]   |   [b]Nivel III:[/b] [0]

[hr]

[center][b]— OBSERVAȚII GENERALE FTO —[/b][/center]

[i]Secțiune opțională — actualizabilă pe parcurs.
Notează aici observații generale despre profilul trainee-ului, punctele forte, ariile de îmbunătățire
sau orice informație relevantă care nu se regăsește în DOR-uri.[/i]

[Data] — [Observație]
[Data] — [Observație]

[hr]

[center][b]— DECIZIE FINALĂ —[/b][/center]

[i]Completează această secțiune EXCLUSIV la finalizarea FTP-ului (după Faza IV).[/i]

[b]Decizie:[/b] [NECOMPLETATĂ]
[b]Justificare:[/b] [—]
[b]Data deciziei (IC):[/b] [—]
[b]Data deciziei (OOC):[/b] [—]
[b]Aprobat de:[/b] [—] | [Rank]
[b]Dosar înaintat la Division 6:[/b] [ DA / NU ]

[hr]

[center][b]— SEMNĂTURĂ FTO —[/b][/center]

[b]Dosar deschis de:[/b] Prenume Nume | Rank | LSFD
[b]Data deschiderii:[/b] ZZ/LL/AAAA
[b]Ultima actualizare:[/b] ZZ/LL/AAAA

[i]Dosarul FTP este un document oficial al LSFD — Training & Professional Development Bureau.
Toate informațiile trebuie să fie complete, corecte și actualizate la zi.
Falsificarea sau neglijarea deliberată a dosarului constituie conduită gravă.[/i]

[/birou]
```

```
[birou=TRAINING DIVISION white]

[center][b]RAPORT DE OBSERVARE ZILNICĂ[/b]
[b]Daily Observation Report — DOR[/b]
[i]Field Training Program | Los Santos Fire Department[/i][/center]

[hr]

[center][b]— INFORMAȚII RAPORT —[/b][/center]

[b]Trainee:[/b] Prenume Nume (*)
[b]Rank Trainee:[/b] Probationary Firefighter
[b]FTO:[/b] Prenume Nume (*)
[b]Rank FTO:[/b] Rank FTO (*)
[b]Faza FTP:[/b] Faza [I / II / III / IV] — Ziua [#] (*)
[b]Data IC:[/b] ZZ luna AAAA (*)
[b]Data OOC:[/b] ZZ/LL/AAAA (*)

[hr]

[center][b]— ACTIVITATE ȘI INCIDENTE NOTABILE —[/b][/center]

[b]Sumar activitate:[/b]
[Descrie pe scurt ce activități au avut loc în această tură: patrulare, intervenții, training în stație etc. 2-4 propoziții.]

[b]Incidente notabile — [color=#336600]POZITIVE[/color]:[/b]
[Descrie momentele în care trainee-ul a demonstrat performanță bună, inițiativă sau aplicare corectă a procedurilor. Fii specific — ce a făcut, în ce context, de ce este notabil. Dacă nu există, scrie: N/A]

[b]Incidente notabile — [color=#cc0000]NEGATIVE[/color]:[/b]
[Descrie erorile, momentele de ezitare sau comportamentele inadecvate observate. Explică ce s-a întâmplat, cum a reacționat trainee-ul la corecție și ce trebuie îmbunătățit. Dacă nu există, scrie: N/A]

[hr]

[center][b]— EVALUAREA CATEGORIILOR DOR —[/b][/center]

[i]Înlocuiește [EVALUARE] cu scala corespunzătoare (culoare + text conform legendei de mai sus).
Adaugă un comentariu scurt, specific și obiectiv pentru fiecare categorie.[/i]

[b]1. Comunicare Radio:[/b] [EVALUARE]
[i]Comentariu: [ex: A folosit corect callsign-ul și frazele standard. Tinde să transmită informații nesolicitate pe frecvență.][/i]

[b]2. Siguranța la Fața Locului:[/b] [EVALUARE]
[i]Comentariu: [ex: A identificat pericolele la sosire dar a omis verificarea zonei din spatele vehiculului înainte de descărcare.][/i]

[b]3. Cunoștințe Medicale:[/b] [EVALUARE]
[i]Comentariu: [ex: A realizat corect triajul și a aplicat DR ABC. A ezitat în aplicarea garoului la pacientul cu hemoragie activă.][/i]

[b]4. Proceduri de Stingere:[/b] [EVALUARE]
[i]Comentariu: [ex: Bună coordonare la poziționarea furtunului. A necesitat reamintire pentru verificarea EIP înainte de intrare.][/i]

[b]5. Luarea Deciziilor:[/b] [EVALUARE]
[i]Comentariu: [ex: Decizii corecte în situații de rutină. Sub presiune tinde să aștepte îndrumare în loc să acționeze independent.][/i]

[b]6. Managementul Stresului:[/b] [EVALUARE]
[i]Comentariu: [ex: Calm și eficient la scena cu un pacient. La MCI cu două victime a prezentat semne de agitație vizibilă.][/i]

[b]7. Profesionalism:[/b] [EVALUARE]
[i]Comentariu: [ex: Conduită exemplară în stație și față de public. Limbajul radio ocazional neprotocolar.][/i]

[b]8. Lucrul în Echipă:[/b] [EVALUARE]
[i]Comentariu: [ex: Colaborare bună cu echipajul. Nu a comunicat proactiv când a identificat o deficiență de echipament.][/i]

[b]9. Redactarea Rapoartelor:[/b] [EVALUARE]
[i]Comentariu: [ex: Raportul de incident complet și bine structurat. Câteva erori gramaticale minore. Depus în termen.][/i]

[b]10. Conformitatea cu SOP-urile:[/b] [EVALUARE]
[i]Comentariu: [ex: Respectă procedurile de bază în mod consistent. Nu cunoaște procedura de Scene Release — de studiat.][/i]

[hr]

[center][b]— RECOMANDARE FTO —[/b][/center]

[b]Recomandare:[/b] [RECOMANDARE]

[b]Justificare:[/b]
[Explică pe scurt motivul recomandării tale. De ce consideri că trainee-ul ar trebui să continue / să avanseze / să primească remedial sau strike? Fii concret și bazează-te pe observațiile din această tură. Minimum 2-3 propoziții.]

[b]Obiective pentru ziua următoare:[/b]
[Listează 2-3 domenii specifice pe care trainee-ul trebuie să le îmbunătățească sau să le demonstreze în tura următoare. Fii specific — nu „să fie mai atent", ci „să aplice DR ABC fără prompting la prima evaluare a pacientului".]
[list]
[*][Obiectiv 1]
[*][Obiectiv 2]
[*][Obiectiv 3 — opțional]
[/list]

[b]Strike emis în această tură:[/b] [DA / NU]
[Dacă DA — specifică Nivelul și motivul complet în câmpul de mai jos]
[b]Detalii strike [opțional]:[/b]
[Descriere completă a incidentului care a generat strike-ul, acțiunile imediate luate și consecințele comunicate trainee-ului.]

[hr]

[center][b]— SEMNĂTURĂ FTO —[/b][/center]

[b]Raport completat de:[/b] Prenume Nume | Rank | LSFD
[b]Data emiterii:[/b] ZZ/LL/AAAA

[i]Acest raport este un document oficial al LSFD — Training & Professional Development Bureau.
Falsificarea sau omiterea deliberată a informațiilor relevante constituie conduită gravă.[/i]

[/birou]
```

---

## #2 — Kellan Dunley

> [Kellan Dunley](https://lsfd.ro-rp.mp/memberlist.php?mode=viewprofile&u=91&sid=b8b678ab48adb7ef6f41cffb63b10a63) wrote: [↑](https://lsfd.ro-rp.mp/viewtopic.php?p=91&sid=b8b678ab48adb7ef6f41cffb63b10a63#p91)Sun May 17, 2026 6:42 pm
>  ============================================================
>  INSTRUCȚIUNI PENTRU FTO — DOSAR PRINCIPAL FTP
>  ============================================================
>
>  Acest template se completează O SINGURĂ DATĂ, la momentul în care îți este repartizat un trainee.
>  Postează-l ca PRIMUL POST în threadul dedicat trainee-ului tău.
>
>  Ulterior, vei actualiza dosarul (prin editarea postului inițial) în aceste momente:
>  → Când trainee-ul avansează la o fază nouă (actualizezi tracker-ul de faze)
>  → Când adaugi un link DOR nou în indexul de rapoarte
>  → Când emiti un Strike (îl adaugi în tabelul de strike-uri)
>  → La finalul programului (completezi secțiunea DECIZIE FINALĂ)
>
>  LEGENDA SIMBOLURI TRACKER FAZE:
>  □ = Neîncepută
>  ▶ = În desfășurare
>  ✓ = Finalizată cu succes
>  ✗ = Repetată / Eșuată
>
>  LEGENDA STATUS FINAL:
>  → **PROMOVAT** — Trainee a absolvit FTP; se înaintează dosarul la Division 6
>  → **RESPINS** — Trainee nu a îndeplinit standardele la Evaluarea Finală
>  → **EXCLUS** — Trainee eliminat din program înainte de Evaluarea Finală
>
>  ============================================================
>  ÎNCEPE SĂ COPIEZI DE LA LINIA [birou] DE MAI JOS
>  ============================================================
>
>  (( ============================================================
>  INSTRUCȚIUNI PENTRU FTO — CITEȘTE ÎNAINTE DE UTILIZARE
>  ============================================================
>
>  Acest template se completează la finalul fiecărei zile de activitate cu trainee-ul.
>  Copiază tot conținutul marcat cu [birou] și postează-l pe forum în threadul dedicat trainee-ului.
>
>  SCALA DE EVALUARE (înlocuiește [EVALUARE] cu una din variantele de mai jos):
>  → **DOES NOT MEET** — Nu îndeplinește așteptările; corecție imediată necesară
>  → **MEETS** — Îndeplinește așteptările; performanță de bază acceptabilă
>  → **EXCEEDS** — Depășește așteptările; performanță solidă, auto-motivat
>  → **OUTSTANDING** — Excepțional; acordat rar, doar pentru performanțe remarcabile
>
>  RECOMANDARE FINALĂ (înlocuiește [RECOMANDARE] cu una din variantele de mai jos):
>  → **CONTINUARE FAZĂ** — Trainee continuă faza curentă; progres normal
>  → **AVANSARE LA FAZA URMĂTOARE** — Trainee a îndeplinit toate obiectivele fazei; FTO recomandă avansarea
>  → **INSTRUIRE REMEDIALĂ** — Trainee prezintă deficiențe care necesită intervenție suplimentară
>  → **STRIKE NIVEL I** — Sancțiune minoră (greșeli procedurale, inatenție, activitate scăzută)
>  → **STRIKE NIVEL II** — Sancțiune medie (insubordonare, neglijență, disruption la scenă)
>  → **STRIKE NIVEL III** — Sancțiune severă (misconduct grav, unsafe behavior, fail RP)
>
>  Dacă în aceeași zi se acordă atât o evaluare DOR cât și un Strike, completează ambele secțiuni.
>  Câmpurile marcate cu (*) sunt obligatorii. Cele marcate cu [opțional] pot fi lăsate goale dacă nu se aplică.
>
>  ============================================================
>  ÎNCEPE SĂ COPIEZI DE LA LINIA [birou] DE MAI JOS
>  ============================================================ ))
>
> ![](https://i.imgur.com/2jlMxHe.png)
>
>
> TRAINING DIVISION
>
> ---
>
>
>  **DOSAR FIELD TRAINING PROGRAM**
>  **FTP Personnel File**
>  *Los Santos Fire Department | Training & Professional Development Bureau*
>
>  **— PROFIL TRAINEE —**
>
>  **Nume Complet (IC):** Prenume Nume
>  **Rank:** Probationary Firefighter
>  **Stație Atribuită:** Station ##
>  **Data Intrării în FTP:** ZZ luna AAAA (IC) | ZZ/LL/AAAA (OOC)
>  **Data Estimată de Finalizare:** ZZ luna AAAA (IC) | ZZ/LL/AAAA (OOC)
>  **Număr Dosar:** FTP-[AAAA]-[###] *(ex: FTP-2026-001)*
>
>  **— FIELD TRAINING OFFICER ATRIBUIT —**
>
>  **Nume FTO (IC):** Prenume Nume
>  **Rank FTO:** Rank
>  **Supervizor Program:** Prenume Nume | Rank *(Captain+ sau Division 6 Lead)*
>
>  **— TRACKER FAZE FTP —**
>
>  *Actualizează simbolul și detaliile la fiecare tranziție de fază.*
>
>  **□ FAZA I — Introduction (Observare)**
>  Durată minimă: 1 săptămână operațională
>  Data start: [—] | Data finalizare: [—]
>  Zile active: [—] | Status: [Neîncepută]
>
>  **□ FAZA II — Operațiuni Asistate**
>  Durată minimă: 2–3 săptămâni operaționale
>  Data start: [—] | Data finalizare: [—]
>  Zile active: [—] | Status: [Neîncepută]
>
>  **□ FAZA III — Conducere Controlată**
>  Durată minimă: 3–4 săptămâni operaționale
>  Data start: [—] | Data finalizare: [—]
>  Zile active: [—] | Status: [Neîncepută]
>
>  **□ FAZA IV — Evaluare Finală**
>  Durată: 1 zi operațională
>  Data evaluare: [—]
>  Rezultat: [—] | Status: [Neîncepută]
>
>  **— INDEX RAPOARTE DOR —**
>
>  *Adaugă linkul fiecărui DOR postat, în ordine cronologică.
>  Format: Ziua # | Faza # | Data | Link*
>
>  **Faza I:**
> - Ziua 1 | Faza I | [Data] | [**DOR #1**](https://lsfd.ro-rp.mp/LINK)
> - Ziua 2 | Faza I | [Data] | [**DOR #2**](https://lsfd.ro-rp.mp/LINK)
> - *— adaugă rânduri pe măsură ce postezi DOR-uri —*
>
>  **Faza II:**
> - Ziua 1 | Faza II | [Data] | [**DOR #**](https://lsfd.ro-rp.mp/LINK)
> - *— adaugă rânduri pe măsură ce postezi DOR-uri —*
>
>  **Faza III:**
> - Ziua 1 | Faza III | [Data] | [**DOR #**](https://lsfd.ro-rp.mp/LINK)
> - *— adaugă rânduri pe măsură ce postezi DOR-uri —*
>
>  **Faza IV:**
> - Ziua evaluare | Faza IV | [Data] | [**DOR Final**](https://lsfd.ro-rp.mp/LINK)
>
>  **Total DOR-uri postate:** [0]
>
>  **— ISTORIC STRIKE-URI —**
>
>  *Completează fiecare rând la momentul emiterii unui Strike.
>  Dacă trainee-ul nu a primit niciun Strike, lasă tabelul cu „Fără sancțiuni înregistrate".*
>
>  **Fără sancțiuni înregistrate.**
>
>  *Model de completare când apare un Strike:*
>  *Strike #1 | Nivel I | [Data] | Motiv: [descriere scurtă] | DOR referință: [link]*
>  *Strike #2 | Nivel II | [Data] | Motiv: [descriere scurtă] | DOR referință: [link]*
>
>  **Total strike-uri:** [0] | **Nivel I:** [0] | **Nivel II:** [0] | **Nivel III:** [0]
>
>  **— OBSERVAȚII GENERALE FTO —**
>
>  *Secțiune opțională — actualizabilă pe parcurs.
>  Notează aici observații generale despre profilul trainee-ului, punctele forte, ariile de îmbunătățire
>  sau orice informație relevantă care nu se regăsește în DOR-uri.*
>
>  [Data] — [Observație]
>  [Data] — [Observație]
>
>  **— DECIZIE FINALĂ —**
>
>  *Completează această secțiune EXCLUSIV la finalizarea FTP-ului (după Faza IV).*
>
>  **Decizie:** [NECOMPLETATĂ]
>  **Justificare:** [—]
>  **Data deciziei (IC):** [—]
>  **Data deciziei (OOC):** [—]
>  **Aprobat de:** [—] | [Rank]
>  **Dosar înaintat la Division 6:** [ DA / NU ]
>
>  **— SEMNĂTURĂ FTO —**
>
>  **Dosar deschis de:** Prenume Nume | Rank | LSFD
>  **Data deschiderii:** ZZ/LL/AAAA
>  **Ultima actualizare:** ZZ/LL/AAAA
>
>  *Dosarul FTP este un document oficial al LSFD — Training & Professional Development Bureau.
>  Toate informațiile trebuie să fie complete, corecte și actualizate la zi.
>  Falsificarea sau neglijarea deliberată a dosarului constituie conduită gravă.*
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
>
> ```
> [birou=TRAINING DIVISION white]
>
> [center][b]DOSAR FIELD TRAINING PROGRAM[/b]
> [b]FTP Personnel File[/b]
> [i]Los Santos Fire Department | Training & Professional Development Bureau[/i][/center]
>
> [hr]
>
> [center][b]— PROFIL TRAINEE —[/b][/center]
>
> [b]Nume Complet (IC):[/b] Prenume Nume
> [b]Rank:[/b] Probationary Firefighter
> [b]Stație Atribuită:[/b] Station ##
> [b]Data Intrării în FTP:[/b] ZZ luna AAAA (IC) | ZZ/LL/AAAA (OOC)
> [b]Data Estimată de Finalizare:[/b] ZZ luna AAAA (IC) | ZZ/LL/AAAA (OOC)
> [b]Număr Dosar:[/b] FTP-[AAAA]-[###]   [i](ex: FTP-2026-001)[/i]
>
> [hr]
>
> [center][b]— FIELD TRAINING OFFICER ATRIBUIT —[/b][/center]
>
> [b]Nume FTO (IC):[/b] Prenume Nume
> [b]Rank FTO:[/b] Rank
> [b]Supervizor Program:[/b] Prenume Nume | Rank   [i](Captain+ sau Division 6 Lead)[/i]
>
> [hr]
>
> [center][b]— TRACKER FAZE FTP —[/b][/center]
>
> [i]Actualizează simbolul și detaliile la fiecare tranziție de fază.[/i]
>
> [b]□ FAZA I — Introduction (Observare)[/b]
> Durată minimă: 1 săptămână operațională
> Data start: [—]     |     Data finalizare: [—]
> Zile active: [—]    |     Status: [Neîncepută]
>
> [b]□ FAZA II — Operațiuni Asistate[/b]
> Durată minimă: 2–3 săptămâni operaționale
> Data start: [—]     |     Data finalizare: [—]
> Zile active: [—]    |     Status: [Neîncepută]
>
> [b]□ FAZA III — Conducere Controlată[/b]
> Durată minimă: 3–4 săptămâni operaționale
> Data start: [—]     |     Data finalizare: [—]
> Zile active: [—]    |     Status: [Neîncepută]
>
> [b]□ FAZA IV — Evaluare Finală[/b]
> Durată: 1 zi operațională
> Data evaluare: [—]
> Rezultat: [—]       |     Status: [Neîncepută]
>
> [hr]
>
> [center][b]— INDEX RAPOARTE DOR —[/b][/center]
>
> [i]Adaugă linkul fiecărui DOR postat, în ordine cronologică.
> Format: Ziua # | Faza # | Data | Link[/i]
>
> [b]Faza I:[/b]
> [list]
> [*]Ziua 1 | Faza I | [Data] | [url=LINK][b]DOR #1[/b][/url]
> [*]Ziua 2 | Faza I | [Data] | [url=LINK][b]DOR #2[/b][/url]
> [*][i]— adaugă rânduri pe măsură ce postezi DOR-uri —[/i]
> [/list]
>
> [b]Faza II:[/b]
> [list]
> [*]Ziua 1 | Faza II | [Data] | [url=LINK][b]DOR #[/b][/url]
> [*][i]— adaugă rânduri pe măsură ce postezi DOR-uri —[/i]
> [/list]
>
> [b]Faza III:[/b]
> [list]
> [*]Ziua 1 | Faza III | [Data] | [url=LINK][b]DOR #[/b][/url]
> [*][i]— adaugă rânduri pe măsură ce postezi DOR-uri —[/i]
> [/list]
>
> [b]Faza IV:[/b]
> [list]
> [*]Ziua evaluare | Faza IV | [Data] | [url=LINK][b]DOR Final[/b][/url]
> [/list]
>
> [b]Total DOR-uri postate:[/b] [0]
>
> [hr]
>
> [center][b]— ISTORIC STRIKE-URI —[/b][/center]
>
> [i]Completează fiecare rând la momentul emiterii unui Strike.
> Dacă trainee-ul nu a primit niciun Strike, lasă tabelul cu „Fără sancțiuni înregistrate".[/i]
>
> [b]Fără sancțiuni înregistrate.[/b]
>
> [i]Model de completare când apare un Strike:[/i]
> [i]Strike #1 | Nivel I | [Data] | Motiv: [descriere scurtă] | DOR referință: [link][/i]
> [i]Strike #2 | Nivel II | [Data] | Motiv: [descriere scurtă] | DOR referință: [link][/i]
>
> [b]Total strike-uri:[/b] [0]   |   [b]Nivel I:[/b] [0]   |   [b]Nivel II:[/b] [0]   |   [b]Nivel III:[/b] [0]
>
> [hr]
>
> [center][b]— OBSERVAȚII GENERALE FTO —[/b][/center]
>
> [i]Secțiune opțională — actualizabilă pe parcurs.
> Notează aici observații generale despre profilul trainee-ului, punctele forte, ariile de îmbunătățire
> sau orice informație relevantă care nu se regăsește în DOR-uri.[/i]
>
> [Data] — [Observație]
> [Data] — [Observație]
>
> [hr]
>
> [center][b]— DECIZIE FINALĂ —[/b][/center]
>
> [i]Completează această secțiune EXCLUSIV la finalizarea FTP-ului (după Faza IV).[/i]
>
> [b]Decizie:[/b] [NECOMPLETATĂ]
> [b]Justificare:[/b] [—]
> [b]Data deciziei (IC):[/b] [—]
> [b]Data deciziei (OOC):[/b] [—]
> [b]Aprobat de:[/b] [—] | [Rank]
> [b]Dosar înaintat la Division 6:[/b] [ DA / NU ]
>
> [hr]
>
> [center][b]— SEMNĂTURĂ FTO —[/b][/center]
>
> [b]Dosar deschis de:[/b] Prenume Nume | Rank | LSFD
> [b]Data deschiderii:[/b] ZZ/LL/AAAA
> [b]Ultima actualizare:[/b] ZZ/LL/AAAA
>
> [i]Dosarul FTP este un document oficial al LSFD — Training & Professional Development Bureau.
> Toate informațiile trebuie să fie complete, corecte și actualizate la zi.
> Falsificarea sau neglijarea deliberată a dosarului constituie conduită gravă.[/i]
>
> [/birou]
> ```
>
>
> ![](https://i.imgur.com/2jlMxHe.png)
>
>
> TRAINING DIVISION
>
> ---
>
>
>  **RAPORT DE OBSERVARE ZILNICĂ**
>  **Daily Observation Report — DOR**
>  *Field Training Program | Los Santos Fire Department*
>
>  **— INFORMAȚII RAPORT —**
>
>  **Trainee:** Prenume Nume (*)
>  **Rank Trainee:** Probationary Firefighter
>  **FTO:** Prenume Nume (*)
>  **Rank FTO:** Rank FTO (*)
>  **Faza FTP:** Faza [I / II / III / IV] — Ziua [#] (*)
>  **Data IC:** ZZ luna AAAA (*)
>  **Data OOC:** ZZ/LL/AAAA (*)
>
>  **— ACTIVITATE ȘI INCIDENTE NOTABILE —**
>
>  **Sumar activitate:**
>  [Descrie pe scurt ce activități au avut loc în această tură: patrulare, intervenții, training în stație etc. 2-4 propoziții.]
>
>  **Incidente notabile — POZITIVE:**
>  [Descrie momentele în care trainee-ul a demonstrat performanță bună, inițiativă sau aplicare corectă a procedurilor. Fii specific — ce a făcut, în ce context, de ce este notabil. Dacă nu există, scrie: N/A]
>
>  **Incidente notabile — NEGATIVE:**
>  [Descrie erorile, momentele de ezitare sau comportamentele inadecvate observate. Explică ce s-a întâmplat, cum a reacționat trainee-ul la corecție și ce trebuie îmbunătățit. Dacă nu există, scrie: N/A]
>
>  **— EVALUAREA CATEGORIILOR DOR —**
>
>  *Înlocuiește [EVALUARE] cu scala corespunzătoare (culoare + text conform legendei de mai sus).
>  Adaugă un comentariu scurt, specific și obiectiv pentru fiecare categorie.*
>
>  **1. Comunicare Radio:** [EVALUARE]
>  *Comentariu: [ex: A folosit corect callsign-ul și frazele standard. Tinde să transmită informații nesolicitate pe frecvență.]*
>
>  **2. Siguranța la Fața Locului:** [EVALUARE]
>  *Comentariu: [ex: A identificat pericolele la sosire dar a omis verificarea zonei din spatele vehiculului înainte de descărcare.]*
>
>  **3. Cunoștințe Medicale:** [EVALUARE]
>  *Comentariu: [ex: A realizat corect triajul și a aplicat DR ABC. A ezitat în aplicarea garoului la pacientul cu hemoragie activă.]*
>
>  **4. Proceduri de Stingere:** [EVALUARE]
>  *Comentariu: [ex: Bună coordonare la poziționarea furtunului. A necesitat reamintire pentru verificarea EIP înainte de intrare.]*
>
>  **5. Luarea Deciziilor:** [EVALUARE]
>  *Comentariu: [ex: Decizii corecte în situații de rutină. Sub presiune tinde să aștepte îndrumare în loc să acționeze independent.]*
>
>  **6. Managementul Stresului:** [EVALUARE]
>  *Comentariu: [ex: Calm și eficient la scena cu un pacient. La MCI cu două victime a prezentat semne de agitație vizibilă.]*
>
>  **7. Profesionalism:** [EVALUARE]
>  *Comentariu: [ex: Conduită exemplară în stație și față de public. Limbajul radio ocazional neprotocolar.]*
>
>  **8. Lucrul în Echipă:** [EVALUARE]
>  *Comentariu: [ex: Colaborare bună cu echipajul. Nu a comunicat proactiv când a identificat o deficiență de echipament.]*
>
>  **9. Redactarea Rapoartelor:** [EVALUARE]
>  *Comentariu: [ex: Raportul de incident complet și bine structurat. Câteva erori gramaticale minore. Depus în termen.]*
>
>  **10. Conformitatea cu SOP-urile:** [EVALUARE]
>  *Comentariu: [ex: Respectă procedurile de bază în mod consistent. Nu cunoaște procedura de Scene Release — de studiat.]*
>
>  **— RECOMANDARE FTO —**
>
>  **Recomandare:** [RECOMANDARE]
>
>  **Justificare:**
>  [Explică pe scurt motivul recomandării tale. De ce consideri că trainee-ul ar trebui să continue / să avanseze / să primească remedial sau strike? Fii concret și bazează-te pe observațiile din această tură. Minimum 2-3 propoziții.]
>
>  **Obiective pentru ziua următoare:**
>  [Listează 2-3 domenii specifice pe care trainee-ul trebuie să le îmbunătățească sau să le demonstreze în tura următoare. Fii specific — nu „să fie mai atent", ci „să aplice DR ABC fără prompting la prima evaluare a pacientului".]
> - [Obiectiv 1]
> - [Obiectiv 2]
> - [Obiectiv 3 — opțional]
>
>  **Strike emis în această tură:** [DA / NU]
>  [Dacă DA — specifică Nivelul și motivul complet în câmpul de mai jos]
>  **Detalii strike [opțional]:**
>  [Descriere completă a incidentului care a generat strike-ul, acțiunile imediate luate și consecințele comunicate trainee-ului.]
>
>  **— SEMNĂTURĂ FTO —**
>
>  **Raport completat de:** Prenume Nume | Rank | LSFD
>  **Data emiterii:** ZZ/LL/AAAA
>
>  *Acest raport este un document oficial al LSFD — Training & Professional Development Bureau.
>  Falsificarea sau omiterea deliberată a informațiilor relevante constituie conduită gravă.*
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
> ---
>
>
> ---

```
[birou=TRAINING DIVISION white]

[center][b]RAPORT DE OBSERVARE ZILNICĂ[/b]
[b]Daily Observation Report — DOR[/b]
[i]Field Training Program | Los Santos Fire Department[/i][/center]

[hr]

[center][b]— INFORMAȚII RAPORT —[/b][/center]

[b]Trainee:[/b] Prenume Nume (*)
[b]Rank Trainee:[/b] Probationary Firefighter
[b]FTO:[/b] Prenume Nume (*)
[b]Rank FTO:[/b] Rank FTO (*)
[b]Faza FTP:[/b] Faza [I / II / III / IV] — Ziua [#] (*)
[b]Data IC:[/b] ZZ luna AAAA (*)
[b]Data OOC:[/b] ZZ/LL/AAAA (*)

[hr]

[center][b]— ACTIVITATE ȘI INCIDENTE NOTABILE —[/b][/center]

[b]Sumar activitate:[/b]
[Descrie pe scurt ce activități au avut loc în această tură: patrulare, intervenții, training în stație etc. 2-4 propoziții.]

[b]Incidente notabile — [color=#336600]POZITIVE[/color]:[/b]
[Descrie momentele în care trainee-ul a demonstrat performanță bună, inițiativă sau aplicare corectă a procedurilor. Fii specific — ce a făcut, în ce context, de ce este notabil. Dacă nu există, scrie: N/A]

[b]Incidente notabile — [color=#cc0000]NEGATIVE[/color]:[/b]
[Descrie erorile, momentele de ezitare sau comportamentele inadecvate observate. Explică ce s-a întâmplat, cum a reacționat trainee-ul la corecție și ce trebuie îmbunătățit. Dacă nu există, scrie: N/A]

[hr]

[center][b]— EVALUAREA CATEGORIILOR DOR —[/b][/center]

[i]Înlocuiește [EVALUARE] cu scala corespunzătoare (culoare + text conform legendei de mai sus).
Adaugă un comentariu scurt, specific și obiectiv pentru fiecare categorie.[/i]

[b]1. Comunicare Radio:[/b] [EVALUARE]
[i]Comentariu: [ex: A folosit corect callsign-ul și frazele standard. Tinde să transmită informații nesolicitate pe frecvență.][/i]

[b]2. Siguranța la Fața Locului:[/b] [EVALUARE]
[i]Comentariu: [ex: A identificat pericolele la sosire dar a omis verificarea zonei din spatele vehiculului înainte de descărcare.][/i]

[b]3. Cunoștințe Medicale:[/b] [EVALUARE]
[i]Comentariu: [ex: A realizat corect triajul și a aplicat DR ABC. A ezitat în aplicarea garoului la pacientul cu hemoragie activă.][/i]

[b]4. Proceduri de Stingere:[/b] [EVALUARE]
[i]Comentariu: [ex: Bună coordonare la poziționarea furtunului. A necesitat reamintire pentru verificarea EIP înainte de intrare.][/i]

[b]5. Luarea Deciziilor:[/b] [EVALUARE]
[i]Comentariu: [ex: Decizii corecte în situații de rutină. Sub presiune tinde să aștepte îndrumare în loc să acționeze independent.][/i]

[b]6. Managementul Stresului:[/b] [EVALUARE]
[i]Comentariu: [ex: Calm și eficient la scena cu un pacient. La MCI cu două victime a prezentat semne de agitație vizibilă.][/i]

[b]7. Profesionalism:[/b] [EVALUARE]
[i]Comentariu: [ex: Conduită exemplară în stație și față de public. Limbajul radio ocazional neprotocolar.][/i]

[b]8. Lucrul în Echipă:[/b] [EVALUARE]
[i]Comentariu: [ex: Colaborare bună cu echipajul. Nu a comunicat proactiv când a identificat o deficiență de echipament.][/i]

[b]9. Redactarea Rapoartelor:[/b] [EVALUARE]
[i]Comentariu: [ex: Raportul de incident complet și bine structurat. Câteva erori gramaticale minore. Depus în termen.][/i]

[b]10. Conformitatea cu SOP-urile:[/b] [EVALUARE]
[i]Comentariu: [ex: Respectă procedurile de bază în mod consistent. Nu cunoaște procedura de Scene Release — de studiat.][/i]

[hr]

[center][b]— RECOMANDARE FTO —[/b][/center]

[b]Recomandare:[/b] [RECOMANDARE]

[b]Justificare:[/b]
[Explică pe scurt motivul recomandării tale. De ce consideri că trainee-ul ar trebui să continue / să avanseze / să primească remedial sau strike? Fii concret și bazează-te pe observațiile din această tură. Minimum 2-3 propoziții.]

[b]Obiective pentru ziua următoare:[/b]
[Listează 2-3 domenii specifice pe care trainee-ul trebuie să le îmbunătățească sau să le demonstreze în tura următoare. Fii specific — nu „să fie mai atent", ci „să aplice DR ABC fără prompting la prima evaluare a pacientului".]
[list]
[*][Obiectiv 1]
[*][Obiectiv 2]
[*][Obiectiv 3 — opțional]
[/list]

[b]Strike emis în această tură:[/b] [DA / NU]
[Dacă DA — specifică Nivelul și motivul complet în câmpul de mai jos]
[b]Detalii strike [opțional]:[/b]
[Descriere completă a incidentului care a generat strike-ul, acțiunile imediate luate și consecințele comunicate trainee-ului.]

[hr]

[center][b]— SEMNĂTURĂ FTO —[/b][/center]

[b]Raport completat de:[/b] Prenume Nume | Rank | LSFD
[b]Data emiterii:[/b] ZZ/LL/AAAA

[i]Acest raport este un document oficial al LSFD — Training & Professional Development Bureau.
Falsificarea sau omiterea deliberată a informațiilor relevante constituie conduită gravă.[/i]

[/birou]
```

---
