# Changelog MOP

- **Topic ID:** 76
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=76
- **Posts:** 1

---

## #1 — Aisha Dubois

![Antet Scrisoare](https://i.imgur.com/2jlMxHe.png)
**25 Mai, 2026**

 Los Santos Fire Department
 Sherling Road 234, Los Santos
 San Andreas

 **MANUAL OF OPERATIONS — NOTA DE ACTUALIZARE**
 Los Santos Fire Department — Editia Mai 2026

---

---

 Prin prezenta se aduce la cunostinta intregului personal al Departamentului ca **Manual of Operations** si documentele conexe au suferit o serie de actualizari structurale si procedurale. Modificarile descrise mai jos sunt in vigoare de la data prezentei note.

 **+ Adaugat** **- Sters** **~ Modificat / Rescris**

---

---

 **I. MANUAL OF OPERATIONS — Partea I (MOP.md)**

 **Capitol 5 — Calificari si Certificari**

- **+** **Sectiunea 5.11 — Cum se Obtin Calificarile** *(sectiune noua)*  Adaugata dupa sectiunea 5.10 (Administration). Descrie procesul standardizat in 4 pasi: contactarea Division 6, verificarea eligibilitatii, parcurgerea instruirii si inregistrarea oficiala de catre Certification Officer. Asigura o procedura uniforma pentru orice calificare, indiferent de divizie.

 **Capitol 10 — Primary Operations Bureau**

- **+** **Sectiunea 10.04 — Incident Commander: Desemnare si Autoritate** *(sectiune noua)*  Adaugata dupa sectiunea 10.03 (Pozitii si Calificari). Cuprinde trei sub-sectiuni:   - **+** **10.04.01 — Desemnarea IC**  Defineste regula generala (IC = cel mai mare rank prezent la scena), exceptia pentru incidente specializate (IC trebuie sa detina calificarile specifice tipului de incident — ex: un Captain fara Hazmat Operations nu poate fi IC la o scena Hazmat) si procedura de Transfer of Command cu fraza standardizata. - **+** **10.04.02 — Autoritatea si Prioritatea IC pe Canal**  Defineste prioritatea absoluta a IC pe Statia 712, regulile de sectorizare a comunicatiilor pe canalele tactice (Statia 713 / Statia 714) si procedura de revenire pe canalul principal la incheierea incidentului. - **+** **10.04.03 — Responsabilitatile IC la Scena**  Lista completa a responsabilitatilor IC: preluarea comenzii cu anuntul standardizat pe 712, evaluarea si stabilirea strategiei, alocarea resurselor, mentinerea Accountability, solicitarea de resurse suplimentare si declararea Code 4.

---

---

 **II. MANUAL OF OPERATIONS — Partea a II-a (MOP-PARTII.md)**

 **Capitol 15 — Division 6: Training & Professional Development**

- **+** **Sectiunea 15.05 — Cum se Solicita o Calificare** *(sectiune noua)*  Adaugata dupa sectiunea 15.04 (Programe de Training). Procedura in 4 pasi, identica cu 5.11 din Partea I, cu nota suplimentara privind recertificarile periodice — responsabilitatea membrului de a-si monitoriza calificarile inainte de expirare.

 **Capitol 19 — Politici de Comunicare**

- **~** **Sectiunea 19.06.02 — Frecvente Radio** *(rescrisa complet)*  Inlocuieste versiunea anterioara fara structura clara. Canalele sunt acum definite explicit:  - **Statia 712 — Metropolitan Fire Communications (Dispatch / Canal Principal)**: toate unitatile monitorizeaza permanent. - **Statia 713 — IC1 / TAC1 (Tactic Channel 1)**: canal tactic alocat de IC cand traficul pe 712 trebuie degrevat. - **Statia 714 — IC2 / TAC2 (Tactic Channel 2)**: canal tactic secundar pentru incidente simultane sau sectorizare majora.
- **+** **Sectiunea 19.06.03 — Format de Comunicare Radio** *(sectiune noua)*  Adaugata intre 19.06.02 si 19.07. Standardizeaza doua formate de transmisie:  - *Transmisie generala:* „[Rank] [Prenume] [Nume], [mesaj]." - *Transmisie cu destinatar:* „[Rank] [Prenume] [Nume] catre[Rank] [Prenume] [Nume], [mesaj]."   Include exemple concrete si procedura de confirmare a receptiei (destinatarul confirma inainte de a raspunde; lipsa confirmarii in 15-20 secunde → repetarea transmisiei).
- **~** **Sectiunea 19.08 — ~~Terminologie~~ Terminologie si Coduri de Raspuns** *(redenumita si extinsa)*  Sectiunea a fost redenumita si completata cu codurile de raspuns formalizate:  - **+** **Code 0 — Emergency Traffic / Canal Liber:** declarat exclusiv de IC sau Dispatch; se anunta de trei ori; prioritate absoluta pentru Mayday sau Firefighter Down. - **+** **Code 1 — Raspuns Non-Urgent:** deplasare fara lumini sau sirene. - **+** **Code 2 — Raspuns Urgent:** lumini active, fara sirena. - **~** **Code 3 — Raspuns de Urgenta:** lumini si sirena, prioritate de trecere. (exista anterior, reformulat) - **~** **Code 4 — Scena Securizata:** declarat de IC la finalizare. (exista anterior, reformulat) - **+** **Mayday:** declanseaza automat Code 0 si activarea RIT. - **+** **PAR (Personnel Accountability Report):** verificarea periodica a prezentei personalului activ la scena, solicitata de IC.

---

---

 **III. QUALIFICATIONS REGISTRY (CALIFICARI.md)**

- **+** **Sectiune introductiva — Cum se Obtine o Calificare** *(adaugata inaintea primei grupe de calificari)*  Rezuma procesul in 4 pasi direct in registru, pentru acces rapid fara a consulta MOP: contactare Division 6 → verificare eligibilitate → instruire si evaluare → inregistrare de catre Certification Officer.

---

---

 **IV. CALLSIGN-URI SI APPARATUS (MOP-PARTII, Sectiunea 20.06)**

- **~** **Sectiunea 20.06 — ~~Asignari Statie si Pozitii Apparatus~~ Callsign-uri si Apparatus** *(rescrisa complet)*  Inlocuieste referinta depasita la "Station 11". Adaugata legenda prefixelor, ierarhia de comanda vehicule si callsign-urile pentru toate statiile operationale.

 **Legenda prefixe:**
- **RA** — Rescue Ambulance (ALS) **|** **E** — Engine **|** **R** — Rescue **|** **SQ** — Squad
- **FR** — First Response **|** **LS** — Line Supervisor (SUV) **|** **BU** — Battalion **|** **CU** — Command **|** **FC** — Fire Chief

 **Ierarhia vehicule:** LS (Supervisor SUV) → BU (Battalion) → CU (Command) → FC (Fire Chief)

 **Fire Station 3 — Davis:** RA310-312 | E318-319 | FR325 | LS31 | CU31
 **Fire Station 132 — Marina:** RA111 | E125 | CU11
 **Fire Station 72 — El Burro:** RA710-730 | FR750-760 | E760-770 | R785/787 | SQ795/797 | LS71-72 | BU71-72 | CU71-72 | FC1

---

---

 Orice intrebare referitoare la aceste modificari se adreseaza in scris catre **Division 6: Training & Professional Development**.

 **Fire Chief, Los Santos Fire Department**
 **25 Mai 2026**

Los Santos Fire Department — "City's **Bravest**, City's **Best**"

**To report an emergency call 9-1-1**

---
