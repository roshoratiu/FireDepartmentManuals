# CAPITOLUL IX – NEGOCIERI COLECTIVE ȘI RELAȚIA CU ADMINISTRAȚIA

- **Topic ID:** 39
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=39
- **Posts:** 1

---

## #1 — Kellan Dunley

![](https://i.imgur.com/2jlMxHe.png)

FIREFIGHTER UNION MANUAL

---

 CAPITOLUL IX – NEGOCIERI COLECTIVE ȘI RELAȚIA CU ADMINISTRAȚIA
---

---

- **(9.1)** Rolul Firefighter Union în procesul de negociere colectivă

---

---

- Negocierile colective reprezintă una dintre cele mai importante responsabilități ale Firefighter Union. Prin acest proces, sindicatul acționează ca reprezentant oficial al membrilor în discuțiile cu:    • administrația orașului;   • conducerea Fire Department;   • autoritățile responsabile de bugete și politici publice.    Negocierile colective influențează:    • salariile;   • orele de lucru;   • sporurile de risc;   • asigurările medicale;   • pensionarea;   • protecția juridică;   • condițiile de muncă;   • dotările și echipamentele operaționale;    Firefighter Union are datoria de a apăra interesele membrilor și de a asigura un echilibru corect între resursele administrației și nevoile reale ale pompierilor.

 -
---

---

- **(9.2)** Principiile de bază ale negocierii colective

---

---

- Procesul de negociere colectivă se desfășoară după principii clare:    **(9.2.1) Reprezentare corectă și nediscriminatorie**   Union reprezintă în mod egal TOȚI membrii, indiferent de rang, vechime sau rol operațional.    **(9.2.2) Transparență decizională**   Membrii au dreptul să fie informați în mod regulat despre progresul negocierilor.    **(9.2.3) Proporționalitate și realism**   Cererile trebuie să reflecte nevoile reale, dar și situația economică a administrației.    **(9.2.4) Protejarea profesiei**   Negocierile urmăresc și protejarea demnității și statutului profesional al pompierilor, nu doar beneficii financiare.

 -
---

---

- **(9.3)** Pregătirea negocierilor colective

---

---

- Înainte de a intra în negocieri oficiale, Union desfășoară un proces intern complex:    **(9.3.1) Analiza financiară și operațională**   Union analizează:    • bugetul orașului;   • resursele FD;   • rapoartele financiare;   • necesarul real de personal și echipamente;   • istoricul cheltuielilor.    **(9.3.2) Consultarea membrilor**   Se realizează prin:    • ședințe în stații;   • chestionare interne;   • discuții cu reprezentanții sindicali;   • propuneri scrise din partea membrilor.    **(9.3.3) Stabilirea priorităților**   Prioritățile pot include:    • majorări salariale;   • îmbunătățirea echipamentelor;   • reducerea orelor suplimentare obligatorii;   • crearea unui fond pentru sănătatea mentală;   • noi programe de training.    **(9.3.4) Formarea echipei de negociere**   De obicei formată din:    • Președintele Union;   • Vicepreședinte;   • Trezorier;   • consilier juridic;   • specialist financiar;   • pompieri cu experiență operațională.

 -
---

---

- **(9.4)** Procesul oficial de negociere colectivă

---

---

- **(9.4.1) Deschiderea negocierilor**   Include:    • prezentarea cererilor Union;   • prezentarea propunerilor administrației;   • stabilirea calendarului și etapelor de discuție.    **(9.4.2) Discuțiile tehnice**   Se analizează:    • impactul bugetar al cererilor;   • costurile salariale pe termen scurt și lung;   • necesarul de personal;   • justificările pentru sporuri.    **(9.4.3) Negocierile privind echipamentele și condițiile de muncă**   Se evaluează:    • calitatea echipamentelor actuale;   • durata de viață a acestora;   • costurile de înlocuire;   • standardele noi de siguranță.    **(9.4.4) Negocierile salariale și de beneficii**   Union cere:    • salarii competitive;   • sporuri pentru misiuni cu risc ridicat;   • plata corectă a orelor suplimentare;   • programe medicale extinse;   • compensații pentru expunerea la toxine.    **(9.4.5) Medierea conflictelor**   Dacă părțile nu ajung la un acord:    • se apelează la mediator neutru;   • se propun compromisuri rezonabile;   • în cazuri rare, se trece la arbitraj economic.

 -
---

---

- **(9.5)** Contractul Colectiv de Muncă (CCM)

---

---

- Rezultatul negocierilor este CCM, document obligatoriu pentru:    • Fire Department;   • administrația orașului;   • membrii Union.    CCM stabilește:    • salariile de bază;   • programul de lucru;   • protecția juridică;   • beneficii și asigurări;   • pensii;   • obligațiile membrilor;   • proceduri în cazuri speciale.    Union are obligația de a explica fiecare articol membrilor și de a se asigura că drepturile sunt respectate în practică.

 -
---

---

- **(9.6)** Relația Union cu administrația orașului

---

---

- Relația trebuie să fie:    • profesională;   • fermă;   • cooperantă;   • respectuoasă;   • dar niciodată submisivă.    În situațiile în care administrația:    • reduce bugetul fără justificare;   • ignoră probleme grave de siguranță;   • refuză negocierile;   • impune măsuri abuzive;    Union poate declanșa:    • conferințe de presă;   • proteste;   • solicitări oficiale către Consiliul Local;   • acțiuni legale;   • campanii de informare publică.

 -
---

---

- **(9.7)** Gestionarea conflictelor cu administrația

---

---

- Procedurile interne pentru gestionarea conflictelor includ:    • întâlniri de mediere;   • comisii mixte Union–Administrație;   • rapoarte oficiale;   • note de protest;   • consultarea membrilor înaintea deciziilor critice.    În cazuri extreme, Union poate:    • contesta deciziile în instanță;   • solicita vot de neîncredere;   • cere demiterea oficialilor responsabili.

 -
---

---

- **(9.8)** Comunicarea cu membrii în timpul negocierilor

---

---

- Union are obligația de a informa membrii în mod constant. Comunicarea se face prin:    • rapoarte periodice scrise;   • ședințe în stații;   • platforme digitale interne;   • voturi consultative;   • prezentări publice.    Nicio negociere majoră nu este încheiată fără acordul membrilor.

 -
---

---

- **(9.9)** Aprobarea finală a contractului

---

---

- Contractul colectiv este adoptat doar după:    • analiza Comitetului Executiv;   • votul membrilor (majoritate 50% + 1);   • semnarea de către administrație;   • intrarea oficială în vigoare.    Orice membru are dreptul să consulte CCM oricând, la cerere.

 -
---

---

- **(9.10)** Importanța negocierilor colective pentru stabilitatea Fire Department

---

---

- Negocierile colective nu sunt doar un proces administrativ — ele reprezintă fundamentul stabilității profesionale și operaționale.    Prin negocieri solide, Union asigură:    • salarii corecte;   • condiții sigure de lucru;   • echipamente performante;   • protecție juridică;   • sănătate mentală și fizică pe termen lung;   • un climat profesional stabil.    Un sindicat puternic nu doar protejează membrii, ci contribuie la eficiența întregului Fire Department.

 -

---
