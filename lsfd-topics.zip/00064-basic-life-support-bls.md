# Basic Life Support - BLS

- **Topic ID:** 64
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=64
- **Posts:** 2

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

BASIC LIFE SUPPORT

---

---

---

**1. PROCEDURĂ GENERALĂ**
---

---

 1.1 **Arrival on Scene (sosirea la scenă)**
- Fiecare apel este dinamic: scena se poate schimba rapid, iar echipajul trebuie să se adapteze constant. La apropierea de scenă cu ambulanța, parcați într-o poziție sigură, vizibilă și utilă pentru accesul la echipament. Nu opriți direct lângă pacient dacă zona este instabilă, aglomerată sau expusă traficului.    La accidente rutiere: parcati cu ambulanta la 15-30 m in spatele zonei de impact, in unghi fata de directia traficului, cu luminile de urgenta active, pentru a forma un scut de protectie. Lasati motorul pornit pana scena este evaluata.    Dacă PD/SD este deja prezent, respectați perimetrul stabilit și solicitați indicații privind zona sigură de staționare. Dacă nu există perimeter, primul echipaj trebuie să facă un scene size-up (evaluarea scenei) înainte de contactul cu pacientul.

 1.1.1 **BSI - Body Substance Isolation (izolarea substanțelor corporale)**
```
[SHOW]
BSI protejează echipajul de expunerea la substanțe biologice (sânge, vomă, salivă, urină, LCR). Este primul pas — aplicați-l INAINTE de contactul cu pacientul, fără excepție.

Echipament standard:

Mănuși medicale nitrile sau latex: obligatorii la orice contact cu pacientul sau echipamentul utilizat. Mărimea corectă — mânușile prea mari alunecă și compromit dexteritatea; prea mici se rup. Purtați INTOTDEAUNA mânuși înainte de contactul cu pacientul.
Eye protection (protecție oculară): ochelari sau vizieră — folosiți la orice risc de proiectare a fluidelor (sângerare activă, aspirație, intubare, naștere). Nu sacrificați ochii pentru confortul procedurii.
Surgical mask (mască chirurgicală): la pacient cu suspiciune de boală transmisibilă pe cale aeriană (TB, gripa, COVID), contact prelungit, sau când examinați cavitatea bucală, nazofaringele.
N95/FFP2: boli cu transmitere aerogenă confirmată sau suspectată (TB bacilifer, varicela).
Halat de protecție: proceduri cu risc mare de stropire (naștere, traumă majoră cu hemoragie masivă).

Schimbarea mânușilor: Schimbati mânușile între pacienți. Nu atingeți fața, radioul, sau ușile ambulanței cu mânuși contaminate. La scoaterea mânușilor: întoarceți prima mănușă invers (prins de exterior), scoateți-o, țineți-o în pumnul mânușii încă purtate, introduceți degetele sub mânușa a doua și scoateți-o tot invers, înglobând prima.

Greșeli comune:

Punerea mânușilor după contactul cu pacientul — prea târziu.
Atingerea feței sau radioului cu mânuși contaminate — cross-contaminare.
Schimbarea mânușilor incomplete (scoaterea incorectă — se contamineaza mâna).
Omisiunea eye protection la intubari, aspiratie sau naşteri active.
```

 1.1.2 **Scene Safety (siguranța scenei)**
```
[SHOW]
Siguranța echipajului are prioritate absolută. Un echipaj rănit devine un al doilea pacient și reduce capacitatea de răspuns. Nu intrați niciodată într-o scenă nesigură.

Evaluarea scenei (scene size-up):

Trafic activ, vehicule instabile, combustibil scurs sau foc vizibil.
Fire electrice căzute, instalatii deteriorate, structuri instabile.
Hazmat (materiale periculoase): miros neidentificat, vapori vizibili, etichete de pericol pe vehicule sau clădiri, victime multiple in acelasi loc fara cauza clara.
Arme, situatii de violenta activa, persoane agitate sau agresive.
Seringi, ace sau obiecte ascutite pe sol.
Animale necontrolate.
Multimi agitate.

Reguli de scene safety:

Nu intrați într-o crime scene (scenă de crimă) sau într-o zonă violentă fără confirmare de la PD/SD că scena este sigură.
Mentineti o escape route (ruta de retragere) functionale in permanenta. Daca scena se degradeaza, retrageti-va imediat si anuntati Dispatch/IC.
Parcati ordonat. Blocati doar benzile strict necesare si lasati spatiu pentru Engine, Truck, Squad sau alte ambulante.
Folositi luminile de urgenta ca scut vizual la accidente rutiere — nu le stingeti pana scena nu este complet securizata.
La suspiciune Hazmat: opriti-va la distanta, in directia vantului (upwind), solicitati Hazmat si asteptati.

Ce NU trebuie să faceți: Nu va grabiti spre pacient fara sa evaluati scena. Nu traversati o scena activa de violenta chiar daca pacientul este vizibil. Nu ignorati semnele de Hazmat — puteti deveni si voi victima.
```

 1.1.3 **Mechanism of Injury - MOI (mecanismul de rănire)**
```
[SHOW]
MOI descrie cum s-a produs leziunea și ghidează nivelul de suspiciune față de leziuni interne invizibile. Un pacient care pare bine poate ascunde leziuni interne grave dacă MOI este semnificativ.

High index of suspicion (indice ridicat de suspiciune) la:

Coliziuni auto: viteza >40 km/h, airbag declansat, deformare habitaclu, ejectie din vehicul, deces in acelasi vehicul, timp de descarcerare >20 min.
Caderi: adult — cadere de la >3x inaltimea proprie (sau >6 m); copil — >3 m. Suprafata de impact si zona lovita determina severitatea.
Traumă penetrantă: impuscare, injunghiere — directia, profunzimea si organele din traiect sunt esentiale.
Explozie: blast injury — undele de presiune produc leziuni pulmonare, gastrointestinale si cerebrale invizibile exterior.
Electrocutare: leziunile interne pot fi mult mai grave decat arsura de intrare/iesire.
Inec/quasi-inec: hipoxie prelungita cu risc neurologic si edem pulmonar tardiv.

Ce observati la fata locului:

Vehiculele (deformari, pozitie, directia impactului).
Parbrizul (crapat in forma de steaua = head impact).
Volanul deformat.
Pozitia pacientului in raport cu scena (aruncat, cazut, blocat).
Obiectele din jur (treapta de la care a cazut, arma, substanta inghita).
Urmele de sange, distanta de la punctul de impact.

Notă: Comparati intotdeauna ce vedeti cu ce declara pacientul si martorii. Daca povestea nu se potriveste cu scena (ex. traumă minora dar stare alterata), tratati cazul ca potential grav si anuntati ALS.
```

 1.1.4 **Patient Count (numărul de pacienți)**
```
[SHOW]
La sosire, estimați rapid câți pacienți sunt implicați — verificați vehiculele, cladirile adiacente, martorii.
Daca numarul de pacienti depaseste capacitatea unitatii, solicitati resurse suplimentare INAINTE de inceperea tratamentului individual.
Dacă sunt mai mult de trei pacienți, incepeti triage si organizați o zonă de colectare pentru pacienții care pot merge (GREEN).
Daca sunt mai mult de patru pacienti sau exista resurse insuficiente, solicitati MCI response (raspuns pentru incident cu victime multiple), conform procedurilor locale.
La MCI: prioritatea este salvarea celui mai mare numar de victime cu resursele disponibile — nu petreceti timp excesiv cu un singur pacient critic daca exista altii cu sanse mai bune.
```

 1.1.5 **Triage (triaj)**
```
[SHOW]
Triage (triajul) este procesul prin care pacienții sunt prioritizați atunci când există mai multe victime decât poate trata imediat echipajul. Scopul este ca resursele să ajungă prima dată la pacienții cu leziuni care pun viața în pericol și cu sanse reale de supravietuire.

START Triage — Respiratii, Perfuzie, Status Mental:

RED - IMMEDIATE (roșu - imediat): necesita interventie imediata.

Frecventa respiratorie >30/min.
Pacientul nu respira initial, dar a inceput dupa deschiderea airway-ului (head tilt / jaw thrust).
Puls radial absent sau perfuzie capilara >2 secunde.
Status mental alterat — nu urmeaza comenzi simple ("strângeți mâna mea").

YELLOW - DELAYED (galben - întârziat):

Nu îndeplineste criteriile RED sau BLACK.
Nu poate merge fără ajutor dar este stabil.

GREEN - MINOR (verde - minor):

Poate merge singur când i se cere.

BLACK - DECEASED/EXPECTANT (negru):

Nu respiră nici după deschiderea airway-ului.
În MCI: resursele se direcționează spre victime cu șanse mai mari — nu se incepe RCP in MCI activ daca exista alte victime RED neingrijite.

Cum se executa triage-ul:

1. Evaluare rapida (30-60 sec per pacient) prin respiratie → perfuzie → status mental.
2. Aplicati triage tag (eticheta) la gat, brat sau glezna pacientului — vizibil din departare.
3. Dirijati GREEN intr-o zona sigura de asteptare.
4. Identificati si marcati RED — prioritizati tratamentul.
5. Treceti la urmatorul pacient — nu ramaneti la unul singur pana nu ati evaluat toti.
6. Reasignati categoriile daca starea se schimba (un YELLOW poate deveni RED).

[SHOW]
```

 1.1.6 **Additional Resources (resurse suplimentare)**
```
[SHOW]
Solicitati o alta ambulanta daca numarul sau severitatea pacientilor depaseste capacitatea echipajului.
Solicitati PD/SD pentru trafic, violenta, scene nesigure, perimeter sau crowd control (controlul multimii). Nu faceti crowd control singuri.
Solicitati Hazmat pentru materiale periculoase, Engine/Truck pentru incendii, victime blocate sau extrication.
Solicitati ALS ori de câte ori pacientul necesita proceduri avansate (IV, medicamente ALS, intubare, defibrilare manuala).
Actualizati Dispatch cu numarul de pacienti, severitatea generala si resursele necesare. Comunicati clar: "Dispatch, Ambulance 1, la locatie, avem 3 pacienti, cel putin 1 critic, solicitam a doua ambulanta si ALS."
```

 1.2 **Initial Assessment (evaluarea inițială): DR ABC / DR CAB**
- Dupa scene size-up, echipajul trece la initial assessment. DR ABC și DR CAB sunt doua scheme rapide pentru pacienți inconștienți, nereactivi sau potențial instabili.    **Cand folositi DR CAB (C inainte de A):** La stop cardiac confirmat sau suspect — compresiile trebuie sa inceapa inainte de orice altceva. Circulatia intrerupe functia cerebrala in 4-6 minute; fiecare secunda conteaza.    **Cand folositi DR ABC (A inainte de C):** La pacientul care respira sau la care mecanismul nu este stop cardiac — evaluati si asigurati airway-ul inainte de a trata circulatia.    **Notă:** Dacă există major bleeding (hemoragie majoră vizibila), controlați sângerarea imediat ce a fost identificată — hemoragia necontrolata ucide in minute.

 1.2.1 **Danger (pericol)**
```
[SHOW]
Verificați scena pentru pericole active si potentiale: trafic, foc, fum, combustibil, fire electrice, arme, seringi, zone instabile sau persoane agresive.

Nu va grabiti spre pacient fara aceasta evaluare. Un pacient inconscient intr-o zona cu fum poate insemna Hazmat sau incendiu — nu intrati fara echipament adecvat.

Daca scena nu este sigura: retrageti-va, anuntati Dispatch, asteptati unitatile specializate. Nu puteti ajuta pacientul daca deveniti si voi victime.
```

 1.2.2 **Response (răspuns)**
```
[SHOW]
Verificați dacă pacientul răspunde — metoda rapida si standardizata:

Verbal: Strigati clar, la distanta de ureche: "Sir/Ma'am, can you hear me? Open your eyes!" (Domnule/Doamna, ma auziti? Deschideti ochii!). Repetati de doua ori cu voce ferma.

Stimul dureros (daca nu exista raspuns verbal):

Trapezius pinch (ciupirea trapezului): prindeti muschiul trapez (zona umarului, intre gat si umar) si strangeti ferm 5 secunde. Raspunsul la durere (grimasa, retragere) indica P pe scala AVPU.
Sternum rub (frecarea sternului): aplicati presiune cu articulatiile degetelor pe treimea inferioara a sternului, miscand circular ferm. Evitati la suspiciune de traumă toracica.

AVPU scale (scala AVPU):

A - Alert: pacientul este treaz, orientat, vorbeste coerent.
V - Voice: raspunde la stimul verbal (deschide ochii sau vocalize).
P - Pain: raspunde doar la stimul dureros.
U - Unresponsive: nu raspunde la nimic — GCS 3, situatie critica.

Notă: Un pacient Alert care vorbeste coerent si logic nu necesita evaluare de tip inconscient. Continuati cu intrebari, vitals si examinare orientata pe plangerea principala.
```

 1.2.3 **Airway (căi respiratorii)**
```
[SHOW]
La un pacient inconștient, limba (cel mai frecvent obstrucator al airway-ului) și țesuturile moi pot bloca calea respiratorie. Sângele, voma, mâncarea sau obiectele străine pot produce aceeași problemă. Orice airway compromis trebuie corectat imediat.

Head Tilt-Chin Lift (înclinarea capului și ridicarea bărbiei)
Folosiți când NU suspectați traumă cervicală sau spinală.

1. Puneti palma mainii non-dominante pe fruntea pacientului.
2. Cu doua sau trei degete ale mainii dominante, prinzeti marginea inferioara a mandibulei (NU tesuturile moi sub barbie — comprimati traheea si blocati airway-ul).
3. Inclinati usor capul posterior (extensia capului) si ridicati bárbia anterior si superior.
4. Verificati: deschidere vizibila a gurii, flux de aer audibil sau simtit.

Jaw-Thrust (împingerea mandibulei)
Folositi la orice suspiciune de head/neck/spine injury — mentine coloana cervicala neutrala.

1. Pozitionati-va la capul pacientului, cu coatele pe sol sau suprafata de lucru pentru stabilitate.
2. Plasati policele pe zigomatice (pometii obrajilor), iar celelalte degete sub unghiurile mandibulei (colturi ale maxilarului inferior — palpati osul).
3. Impingeti mandibula anterior si superior, fara a roti sau extinde capul/gatul.
4. Gura se deschide usor — verificati vizual airway-ul.

Greșeli comune airway:

Head tilt la pacient cu traumă cervicala — poate agrava leziunea spinala.
Prinderea tesuturilor moi sub barbie in chin lift — comprima traheea.
Jaw thrust insuficient — capul se roteste in loc sa se propulseze mandibula anterior.
Ignorarea sonituilor anormale (stridor, gurgling, snoring) — toate necesita actiune imediata.

Sunete ce indica probleme de airway:

Snoring (sforait): obstructie partiala prin limba — corectati pozitia, aplicati OPA/NPA.
Gurgling (bolborosit): secretii, sange sau lichid in airway — aspiratie imediata.
Stridor (stiuierat inspirator ascutit): obstructie la laringe (edem, corp strain) — urgenta, solicitati ALS.
Wheezing (siuierat expirator): bronhospasm — bronhodilatatoare (daca protocol permite).

Recovery Position (poziția laterală de siguranță)
Daca pacientul este inconştient, RESPIRA si nu are leziuni ce contraindica miscarea, asezati-l in recovery position pentru a mentine airway-ul deschis si a reduce riscul de aspiratie.

Cum se execută:

1. Îngenuncheați lângă pacient.
2. Așezați brațul cel mai aproape de voi în unghi drept față de corp, cu cotul flectat și palma in sus.
3. Aduceti bratul opus peste pieptul pacientului si puneti dosul palmei pe obrajul dinspre voi.
4. Cu cealalta mana, îndoiți genunchiul opus departe de voi.
5. Rotiți pacientul spre voi trăgând de genunchiul îndoit, menținând capul sustinut de mana pacientului.
6. Ajustați capul pentru a deschide airway-ul, ajustati mana de sub obraz pentru stabilitate.
7. Monitorizați respirația continuu până la transport.

[altspoiler=HOW TO PERFORM RECOVERY POSITION]https://youtu.be/Py6i884c9JE[/altspoiler]

Dacă airway-ul nu poate fi menținut prin manevre BLS, solicitați ALS support și pregătiți transport rapid.
```

 1.2.4 **Breathing (respirație)**
```
[SHOW]
Evaluați respirația după asigurarea airway-ului. Durata evaluarii: maxim 10 secunde. Metoda: look, listen and feel (priveste, asculta si simte).

Look (priveste): ridicarea si coborarea toracelui. Observati simetria — un torace care se misca asimetric sugereaza pneumotorax, flail chest sau obstructie unilaterala.

Listen (asculta): sunete respiratorii audibile la nare/gura (flux de aer). Cu stetoscopul la axile (cel mai fidel) si apexul pulmonar.

Feel (simte): fluxul de aer la nare sau gura cu dosul mainii.

Valori normale de frecventa respiratorie (FR):

Adult: 12-20 respiratii/min.
Copil (1-8 ani): 15-30 respiratii/min.
Sugar (sub 1 an): 25-50 respiratii/min.

Semne de insuficienta respiratorie:

FR <10 sau >30/min la adult.
Efort respirator marcat (folosirea muschilor accesorii — ridica umerii, trage intercoastal).
Cianoza (coloratie albastra-violacee a buzelor, degetelor).
Respiratie paradoxala (toracele se retrage la inspiratie — flail chest).
Agonala gasping (gafait rar, neregulat) — NU este respiratie normala; tratati ca stop cardiac.

Actiune: Administrati oxygen (O2) daca pacientul este hipoxic (SpO2 <94%), respira ineficient sau prezinta semne de distress respirator. Daca respiratia este absenta sau ineficienta, incepeti ventilatie cu BVM.
```

 1.2.5 **Circulation (circulație)**
```
[SHOW]
Identificati si controlati orice bleeding (sangerare) externa. Verificati pulse (pulsul), skin signs (semnele pielii) si perfusion (perfuzia).

Locatii de palpare a pulsului:

Puls radial (incheietura mainii): fata anterioara a incheieturii, lateral (de partea policelui) — palpati cu 2-3 degete (nu cu policele — simtiti propriul puls). Util la pacientul stabil, TA sistolica >80 mmHg.
Puls brahial (bratul): fata interna a bratului, la jumatate distanta intre cot si umar — folosit la sugari (mai accesibil decat carotida).
Puls carotidian (gat): lateral de trahee (nu pe trahee), la marginea mediana a muschiului sternocleidomastoidian. Folosit la pacienti inconstenti sau instabili. Nu apasati bilateral simultan (reflex vagal + risc compresie pe artere la varstnici cu ateroscleroza). TA sistolica >60 mmHg.
Puls femural (inghinal): triunghiul femural, sub ligamentul inghinal — util in soc sever sau la pacient obez.

Interpretarea skin signs (semnele pielii):

Palida, rece, umeda (diaforetica): soc hipovolemic, infarct miocardic, hipoglicemie.
Rosie, calda, uscata: caldura (heatstroke), anafilaxie (initial), febra.
Cianoza (albastruie): hipoxie severa, insuficienta cardiaca, frig.
Marmorata (pete violacee): soc decompensat, hipoperfuzie severa.
Icter (galben): disfunctie hepatica.

CRT - Capillary Refill Time (timp de reumplere capilara): Apasati ferma pe patul unghial sau pe stern, eliberati si masurati cat dureaza recolorarea roz. Normal: <2 secunde. >2 sec = hipoperfuzie periferica. Nu este fidel la frig (vasoconstrictie fiziologica) sau varstnici.

Valori orientative pentru pulse rate (frecventa pulsului):

Newborn: 100-150/minut.
Infant (1-12 luni): 80-120/minut.
Copil (1-8 ani): 70-110/minut.
Adult: 60-100/minut.
Adult atletic: 40-60/minut (bradicardie fiziologica — normala daca pacientul este asimptomatic).
```

 1.3 **Palpation (palpare)**
```
[SHOW]
Palpation (palparea) este tehnica de examinare prin atingere — identifica durere, umflare, deformare, crepitatie, instabilitate sau repere anatomice.

Tehnica:

Incepeti cu palpare usoara (light palpation) si cresceti progresiv presiunea — nu surprindeti pacientul cu presiune brusca.
Observati fata pacientului la palpare — grimasa sau vocalizare indica durere localizata chiar daca pacientul nu o poate comunica verbal.
Nu aplicati presiune pe fracturi evidente, rani deschise sau zone cu deformare vizibila.
Comparati bilateral: palpatii aceeasi zona pe ambele parti si comparati — asimetria este semnificativa (ex. pieptul: sonoritati diferite, tensiune musculara diferita).
La abdomen: palpati in toate cele 4 cadrane; incepeti cu zona nedureroasa si terminati cu zona dureroasa (altfel pacientul se va apara reflex si evaluarea devine dificila).

Ce cautati:

Crepitatie (crepitatie osoasa): senzatie sau sunet de frecare → fractura; nu provocati intentionat, dar notati daca apare la palpare usoara.
Instabilitate: zone osoase care nu rezista presiunii normale (pelvis, coaste, clavicula).
Rigiditate musculara (guarding): contractura involuntara a muschilor abdominali la palpare → peritonita sau traumă intraabdominala.
Rebound tenderness: durere la eliberarea rapida a presiunii → iritatie peritoneala.
Subcutaneous emphysema: senzatie de bule de celofan sub piele → aer in tesuturile moi (pneumotorax, trahee, esofag).
```

---

---

**2. WOUND CARE (TRATAMENTUL RĂNILOR)**
---

---

 2.1 **Bleeding Control (controlul sângerării)**
```
[SHOW]
Controlul sângerării este prioritar. Gunshot wounds (răni prin împuscare), stab wounds (răni prin înjunghiere), lacerațiile mari și amputările pot produce hemoragii rapide și letale. Un adult poate supravietui pierderea a ~750 mL sânge (Clasa I); pierderea de >1500 mL (Clasa III) produce soc sever; >2000 mL (Clasa IV) este critica fara interventie imediata.

Nu îndepărtați obiectele înfipte (cuțite, sticlă, fragmente metalice, impuscaturi vizibile). Obiectul infalipta poate tampona vasele — scoaterea poate declansa hemoragie masiva. Stabilizati obiectul cu bulky gauze pe ambele parti si fixati cu bandaj, fara a apasa pe obiect.

DPT - Dressing, Pressure, Tourniquet

Dressing (pansament)

1. Aplicati BSI (manusi) — mereu.
2. Expuneti rana cu trauma shears (foarfeca de traumă), taiand hainele din jur. Nu indepartati hainele lipite de rana — taiati in jurul lor.
3. Evaluati rapid rana: locatie, profunzime estimata, origine arteriala sau venoasa (sangerarea arteriala e pulsatila, rosie aprins; cea venoasa e continua, mai intunecata).
4. Aplicati dressing-ul direct pe rana.

Pressure (presiune directă)

5. Aplicati direct pressure (presiune directa) cu toata palma deasupra dressing-ului. NU cu un singur deget (presiunea se disperseaza pe un punct mic). Folositi greutatea corpului vostru, nu doar forta degetelor — va obositi mai greu.
6. Daca sangele trece prin dressing, NU il scoateti — scoaterea perturba cheagul in formare. Puneti un dressing NOU PESTE primul si continuati presiunea mai ferma.
7. Mentineti presiunea continua minimum 3-5 minute la rani venoase, 10 minute la rani arteriale. Nu verificati rana la fiecare 30 secunde — perturbati cheagul.
8. Dupa oprirea sangerarii, fixati dressing-ul cu bandaj sau leucoplast, fara a lasa neaplicata presiunea (bandajul de fixare trebuie sa fie ferm, nu strangulant).

Tourniquet (garou)

9. Daca sangerarea severa CONTINUA la un membru (brat sau picior) dupa presiune directa, sau daca hemoragia este masiva initial (amputare, rana arteriala larga), aplicati tourniquet INAINTE de a pierde timp cu pansamente.
10. Plasati tourniquet-ul la 5-8 cm PROXIMAL de rana (mai sus fata de inima). NU aplicati pe articulatii (cot, genunchi) — nu este eficient. Aplicati pe treimea superioara a bratului (pentru rani de brat/mana) sau pe treimea superioara a coapsei (pentru rani de picior).
11. Strangeti tourniquet-ul suficient pentru a opri complet sangerarea (pulsul distal dispare, rana nu mai sangereaza). Jumatate de masura nu opreste sangerarea si creste riscul de leziune nervoasa. Durerea este intensa — aceasta este normala.
12. Notati ORA EXACTA a aplicarii pe tourniquet sau pe fruntea pacientului cu marker. Comunicati ora la predarea pacientului. Tourniquet-ul nu trebuie mentinut mai mult de 2 ore fara evaluare chirurgicala.
13. Nu acoperiti tourniquet-ul cu haine — trebuie sa fie vizibil la spital.

Hemostaza prin impachetare (wound packing) — pentru rani non-amputare, non-extremitate (inghinal, axilar, gat):

1. Nu puteti pune tourniquet pe gat, inghinal sau axilar — impachetati rana direct.
2. Folositi gauze hemostatic (ex. Combat Gauze cu kaolin sau chitosan) daca e disponibil, sau gauze steril standard.
3. Introduceti gauze-ul IN rana, impachetand compact cu degetul indexul, umplind complet cavitatea.
4. Aplicati presiune directa ferma cu ambele maini minimum 3 minute.
5. Bandajati ferm deasupra.

Greșeli comune:

Presiune insuficienta sau intermitenta — sangerarea continua, cheagul nu se formeaza.
Scoaterea dressing-ului imbibat — perturba cheagul, relanseaza hemoragia.
Tourniquet prea jos (prea aproape de rana) sau pe articulatii — ineficient.
Tourniquet prea slab (jumatate de tura) — nu opreste sangerarea, dar comprima venele → sange mai multa sangerare paradoxala.
Omisiunea notarii orei de aplicare — informatia critica la spital.

[altspoiler=TRAUMA DRESSING][/altspoiler]
[altspoiler=TOURNIQUET][/altspoiler]
```

 2.2 **Wound Cleaning (curățarea rănilor)**
```
[SHOW]
Wound cleaning se face pentru răni minore (lacerații mici, abraziuni, rani contaminate) sau cand riscul de infectie este ridicat. In hemoragii majore, oprirea sangerarii are intotdeauna prioritate.

Cum se executa:

1. Aplicati BSI.
2. Expuneti rana si evaluati adancimea, contaminarea si marginile.
3. Irigati rana cu saline solution (solutie salina 0.9%) din seringa de 20-60 mL cu ac sau cateter de irigare, la presiune moderata (nu la presiune inalta care impinge murdaria mai adanc). Volumul de irigare: minim 100-200 mL pentru rani contaminate.
4. Stergeti usor zona periranei cu gauze pad umezit — nu frecati interiorul ranii.
5. Avertizati pacientul ca poate simti usturime sau disconfort.
6. Nu folositi apa oxigenata sau betadina in interiorul ranii (toxice pentru tesuturile de granulatie si incetinesc vindecarea). Betadina este acceptabila pe pielea din jurul ranii.
7. Dupa curatare, aplicati dressing-ul potrivit (steril, absorbant, neaderent) si monitorizati.

Rani care NU trebuie curatate in prespital: Rani profunde cu obiecte infipte (stabilizati, nu curatati), amputari (acoperiticel amputat in gauze umed steril si puneti pe gheata, nu direct pe gheata), rani articulare sau cu os expus (acoperiti steril, transport rapid).
```

---

---

**3. FRACTURES (FRACTURI)**
---

---

- Fracture (fractura) este o ruptură a osului produsă de impact, compresie, torsiune sau stres repetat. Semnele pot include: durere locala, deformare vizibila, umflatura, echimoze, incapacitatea de a folosi membrul, crepitatie la palpare usoara.    Evaluati intotdeauna **PMS distal** inainte SI dupa orice imobilizare:  - **P - Pulse:** pulsul distal de fractura (radial la fracturi de brat, pedios/tibial posterior la fracturi de picior). - **M - Motor:** miscarea voluntara distala (misca degetele?). - **S - Sensation:** sensibilitatea distala (simte atingerea pe degete?).   PMS alterat dupa imobilizare = reevaluati pozitia atelei imediat.    **Tipuri principale:**  - **Closed fracture (fractură închisă/simplă):** pielea este intactă, osul nu este expus. Risc de sangerare interna (ex. fractura de femur: 500-1500 mL sange in tesuturile coapsei). - **Open fracture (fractură deschisă/compusă):** osul a strapuns pielea sau rana comunica cu osul. Risc major de infectie. Nu impingeti osul inapoi.

 3.1 **Open/Compound Fracture (fractură deschisă/compusă)**
```
[SHOW]
In open fracture, controlati bleeding-ul fara a apasa direct pe os sau fragmente osoase. Nu incercati sa reduceti (sa impingeti osul inapoi) — cresteti riscul de infectie si lezare vasculara.

Cum se executa:

1. Aplicati BSI si expuneti zona cu trauma shears.
2. Evaluati PMS distal si notati-le.
3. Nu atingeti osul expus cu mainile sau materiale nestrile.
4. Plasati bulky gauze (tifon voluminos steril) pe ambele parti ale osului expus, ca suport, fara a apasa pe os.
5. Controlati bleeding-ul cu presiune aplicata pe tesuturile din jur, nu pe os.
6. Acoperiti rana si osul cu dressing steril umed (umezit cu NS), pentru a preveni uscarea fragmentului osos expus.
7. Imobilizati membrul in pozitia gasita, daca nu exista indicatie clara de realiniere (deficit neurovascular cu compromitere acuta a membrului distal).
8. Reevaluati PMS dupa imobilizare.
9. Transportati rapid si anuntati spitalul despre open fracture (necesita interventie ortopedica de urgenta).

Greșeli comune:

Apasare directa pe os sau fragmente osoase — lezare vasculara si nervoasa suplimentara.
Incercarea de a reduce/realinia fara indicatie — creste durerea, riscul de infectie, lezarea vaselor.
Neacoperirea osului cu dressing umed — osul se usuca si necroza se instaleaza mai rapid.
Omisiunea evaluarii PMS post-imobilizare.

[altspoiler=COMPOUND FRACTURE][/altspoiler]
```

 3.2 **Vacuum Splint (atelă vacuum)**
```
[SHOW]
Vacuum splint imobilizeaza membrul fracturat prin crearea unui vid intern care rigidizeaza bila de polistiren din interior, modelandu-se perfect pe forma membrului.

Folosit pentru: fracturi de glezna, picior, gamba (tibia/fibula), brat (humerus), antebrațul (radius/cubitus). NU pentru fracturi de femur (necesita tractiune).

Dimensionare: Alegeti splint-ul cu dimensiunile adecvate membrului — prea mic nu acopera zona fracturata si nu imobilizeaza adecvat.

Cum se aplică:

1. Evaluati PMS distal inainte de aplicare.
2. Luați vacuum splint-ul potrivit si deschideti supapa — distribuiti materialul intern (bile de polistiren) uniform pe toata suprafata.
3. Asezati splint-ul pe sol sau pe o suprafata dreapta; plasati membrul pe splint fara mișcări bruște.
4. Modelati manual splint-ul in jurul membrului, mentinand o usoara tractiune longitudinala (nu forte, doar suficient pentru a alinia membrul).
5. Fixati curelele: deasupra si dedesubtul fracturii, fara a strânge excesiv.
6. Scoateti aerul cu pompa manuala pana cand splint-ul devine rigid. Verificati: splint-ul trebuie sa mentina forma fara suport.
7. Reevaluați PMS distal dupa imobilizare. Daca PMS s-a deteriorat, decomprimati splint-ul si ajustati.

Greșeli comune:

Bile de polistiren distribuite neuniform — zone rigide si zone moi → imobilizare inadecvata.
Curelele prea stranse — comprima vasele, agraveza durerea, cianoza distala.
Splint aplicat cu angulatie — membrul ramane in pozitie anormala, crescand durerea.
Omisiunea verificarii PMS post-aplicare.

[altspoiler=VACUUM SPLINT][/altspoiler]
```

 3.3 **Traction Splint (atelă de tracțiune)**
```
[SHOW]
Traction splint se foloseste EXCLUSIV pentru suspiciune de fractura de femur (osul coapsei). Scopul tractiunii longitudinale: reduce durerea (spasmul muscular), limiteaza sangerarea interna (spatiul inchis reduce pierderea de sange) si aliniaza fractira pentru transport.

Indicat: fractura izolata de femur (treimea medie sau superioara), cu sau fara crepitatie, deformare sau scurtare a membrului.

Contraindicatii absolute:

Fractura de tibie/fibula asociata (nu puteti aplica priza la glezna).
Fractura de pelvis instabila (tractiunea poate agrava).
Fractura de genunchi sau ligamente implicate.
Amputare partiala sau completa a membrului distal.
Avulsie sau rana larga la glezna (locul de aplicare al prizei).

Cum se aplică (procedura generala):

1. Evaluati PMS distal inainte de aplicare.
2. Mentineti tractiunea manuala in ax (un echipier tine piciorul, aplicand tractiune longitudinala usoara pe toata durata procedurii).
3. Masurati atela de la inghinal la calcai + 20-25 cm extra; ajustati lungimea.
4. Aplicati priza la glezna (ankle hitch) — curea sau dispozitiv specific sub calcai si maleole.
5. Pozitionati atela sub membrul afectat (in timp ce colegul mentine tractiunea).
6. Conectati priza la mecanismul de tractiune al atelei si aplicati tractiunea progresiv pana la ameliorarea durerii (de obicei 4-6 kg forta, nu mai mult).
7. Fixati curelele pe toata lungimea membrului.
8. Reevaluati PMS distal.

Greșeli comune:

Aplicarea la fractura de tibie concomitenta — priza la glezna fracturata agraveza leziunea.
Tractiune excesiva — nu reduceti fractura, provocati durere si lezati vasele.
Pierderea tractiunii manuale in timpul procedurii — spasmul muscular revine, durerea creste.
Lasarea atentiei de la PMS dupa aplicare — compresia vasculara poate aparea dupa.

[altspoiler=TRACTION SPLINT][/altspoiler]
```

 3.4 **Triangular Bandage (bandaj triunghiular)**
```
[SHOW]
Triangular bandage ca sling (esarfa de sustinere) imobilizeaza si sustine membrul superior, reducand durerea, umflatura si miscarile inutile.

Folosit pentru: suspiciune de fractura de brat (humerus), antebraț, clavicula, sau luxatie de umar.

Swathing (legarea brațului de trunchi): dupa aplicarea sling-ului, legati brațul de trunchi cu o a doua fasie de bandaj (swathe) — imobilizeaza suplimentar si impiedica miscarile laterale. Util mai ales pentru humerus.

Cum se aplică sling-ul:

1. Evaluati PMS distal inainte de aplicare.
2. Asezati brațul pacientului intr-o pozitie confortabila — cot flectat la 90°, antebrațul orizontal sau usor ridicat.
3. Plasati un colt al bandajului triunghiular sub cot si desfasurati-l pana acopera antebrațul si mana.
4. Ridicati coltul inferior al bandajului peste brat si aduceti ambele capete la ceafa; legati lateral (nu pe coloana vertebrala — incomod si dureros).
5. Coltul de la cot se fixeaza cu un ac de siguranta sau se rasuceste si pliaza sub bandaj.
6. Verificati ca degetele sunt vizibile si accesibile pentru evaluarea PMS.
7. Reevaluati PMS dupa aplicare.

Greșeli comune:

Nod pe coloana vertebrala — dureros la pozitionare, incomod la transport.
Sling prea larg — brațul atarna in loc sa fie sustinut.
Degetele ascunse in sling — nu puteti evalua PMS distal.
Brațul coborat sub 90° fara indicatie — poate creste durerea in anumite fracturi.

[altspoiler=TRIANGULAR BANDAGE][/altspoiler]
```

 3.5 **X-Collar / Cervical Collar (guler cervical)**
```
[SHOW]
X-Collar imobilizeaza coloana cervicala, limitand miscarile gâtului la pacientii cu suspiciune de traumă spinala cervicala. NU elimina necesitatea imobilizarii manuale pana nu este fixat corect pe backboard.

Indicatii: coliziune auto cu MOI semnificativ, cadere de la inaltime, sport de contact, violenta (strangulare, lovituri la cap), pacient inconstient cu MOI traumatic necunoscut.

Dimensionarea colerului: X-Collar vine in mai multe marimi. Marimea corecta: masurarea distantei de la umar la barbie (cu capul in pozitie neutra). Comparati cu scalele de pe colier. Un X-Collar prea mare extinde gâtul (riscant); prea mic comprima traheea sau nu imobilizeaza.

Semne care CONTRAINDICA aplicarea X-Collar: traumă laringiana sau traheala direct la gât (aplicarea poate agrava), edem masiv al gâtului (nu permite aplicarea corecta), agitatie extrema care face imposibila imobilizarea.

Cum se aplică:

1. Un echipier mentine cervical stabilization (stabilizare cervicala manuala) cu ambele maini — mâinile pe lateral la cap, fara tractiune.
2. Al doilea echipier masoara si pregateste X-Collar-ul potrivit.
3. Glisati suportul posterior al colerului in spatele gâtului, fara a misca capul.
4. Aduceti suportul mandibulei (barbia) in fata si plasati-l sub mandibula cu gura inchisa.
5. Strangeti sistemul de fixare lateral — ferm, fara a obstructa respiratia sau venele jugulare (verificati ca nu apasati tracheea sau vasele gâtului).
6. Verificati: capul este in pozitie neutra (nu extensie, nu flexie), gura se poate deschide daca pacientul vomita.
7. Continuati imobilizarea manuala pana la fixarea pe backboard — X-Collar singur nu imobilizeaza complet coloana.

Greșeli comune:

Aplicarea fara stabilizare manuala prealabila — capul se misca in timpul aplicarii.
Martime gresita — extensie sau flexie inadvertenta a gâtului.
Strangere excesiva — compresia traheei sau venelor jugulare (creste presiunea intracraniana).
Aplicarea la pacient vomitand — poate comprima airway-ul si impiedica drenajul; mai intai controlati airway-ul.
Renuntarea la stabilizare manuala dupa aplicarea colerului — colerele cervicale limiteaza partial miscarea dar nu o elimina.

[altspoiler=X-COLLAR][/altspoiler]
```

---

---

**4. BURNS (ARSURI)**
---

---

 4.1 **Burn Degrees (gradele arsurilor)**
```
[SHOW]
Burns (arsurile) sunt leziuni ale pielii sau țesuturilor produse de căldură (termic), electricitate, radiații, chimice sau frecare. Severitatea depinde de profunzime, suprafata afectata, localizare si starea generala a pacientului.

First-degree burn (gradul I — superficiala): afecteaza epidermul; roșeață, piele uscată, durere ușoară, fara bășici. Ex.: arsura solara usoara.

Second-degree burn (gradul II — parțiala): afecteaza epidermul si partial derma; rosu/alb, umeda, bășici (flictene), durere severa. Atentie: nu spargeti flictenele — protejaza tesuturile.

Third-degree burn (gradul III — totala): distruge epidermul, derma si poate afecta hipodermul; piele alba, rigida, uscata, negricioasa sau carbonizata; durere redusa sau absenta in zona centrala (nervii sunt distrusi — dar marginile ard intens).

Fourth-degree burn (gradul IV): afecteaza tesut subcutanat, muschi, tendoane sau os; aspect negru/carbonizat; urgenta majora, amputare frecvent necesara.

Rule of Nines (Regula lui 9) — estimarea suprafetei arse:

Cap si gat: 9%.
Brat drept (intreg): 9%.
Brat stang (intreg): 9%.
Trunchi anterior: 18%.
Trunchi posterior: 18%.
Coapsa + gamba + picior drept: 18%.
Coapsa + gamba + picior stang: 18%.
Perineu/organe genitale: 1%.

La copii: capul reprezinta proportional mai mult (18%), membrele mai putin. Folositi palma pacientului (inclusiv degete) = ~1% din suprafata corporala pentru suprafete mici sau neregulate.

Arsuri majore (transport rapid, ALS, spital de traumă/arsuri):

Grad II >10% suprafata corporala (adult), >5% (copil sau varstnic).
Orice arsura grad III.
Arsuri la fata, mâini, picioare, organe genitale, perineu, articulatii majore.
Arsuri circumferentiale (in jurul membrului sau toracelui — pot comprima circulatia/ventilatia).
Arsuri prin inhalare (pana la dovedirea contrarie la orice victima a incendiului in spatiu inchis).
Arsuri electrice si chimice.

[altspoiler=BURN DEGREES][/altspoiler]
```

 4.2 **Burn Treatment (tratamentul arsurilor)**
```
[SHOW]
Principii generale: opriti cauza, evaluati airway-ul si circulatia, monitorizati pentru soc, controlati hipotermia (arsurile mari = pierdere masiva de caldura).

Pași generali:

1. Opriți sursa: foc (tavaliti pacientul sau stingeti), abur, lichid fierbinte, curent electric (deconectati sursa INAINTE de contact — nu atingeti un pacient electrocutat cu curentul inca activ), substanta chimica.
2. Asigurati BSI — substante chimice pot fi activ periculoase.
3. Indepartati bijuterii, curele, haine stranse si sintetice din jurul zonei arse DAC nu sunt lipite de piele — sinteticele continua sa arda sau sa retina caldura.
4. Evaluati airway-ul: raguseala, stridor, arsuri faciale, pâr ars in nari, carbon in sputa → sugestiv pentru inhalare de fum; solicitati ALS si pregatiti intubare.
5. Acoperiți zona cu sterile non-adherent dressing (pansament steril neaderent).

First/Second-degree burns (suprafete mici, grad I si II):

1. Raciti zona cu apa rece curgand (15-20°C) timp de 10-20 minute — reduce durerea si adancimea arsurii daca aplicat in primele 3 ore. NU apa cu gheata (vasoconstrictie, degeratura secundara). NU gheata direct pe arsura.
2. Nu spargeti flictenele (bașicile) — protejeaza, reduc riscul de infectie.
3. Acoperiți lejer cu dry sterile dressing (pansament steril uscat). NU pansamente aderente, vata sau materiale pufoase (se lipesc de arsura la indepartare).
4. Transportați dacă arsura este mare, pe zone sensibile, sau pacientul este instabil.

Third/Fourth-degree burns (suprafete mari, grad III si IV):

1. NU raciti agresiv suprafete mari — risc real de hipotermie; raciti doar cu umezire usoara.
2. Acoperiți cu sterile non-adherent dressing, fara presiune excesiva.
3. Separati degetele afectate cu pansamente sterile uscate intre ele — altfel se lipesc la vindecare.
4. Mentineti pacientul cald (patUri, folii de aluminiu) — arsurile mari elimina calura masiv.
5. Monitorizati respiratia, SpO2, circulatia si pregatiti transport rapid.

Arsuri chimice:

Indepartati hainele contaminate (cu precautie, purtati BSI complet).
Irigati abundent cu apa curganda 15-30 minute — nu neutralizati cu substante opuse (acid + baza = reactie exoterma).
Irigati ochii cu apa curata sau NS din coltzul intern spre extern, continuu, 15-20 min.
Identificati substanta daca posibil — informati spitalul.

Arsuri electrice:

Deconectati sursa inainte de orice contact.
Evaluati ritm cardiac — electrocutarea poate produce aritmii (FV, TV, bloc cardiac).
Leziunile interne sunt mult mai grave decat arsura externa de intrare/iesire.
Monitorizare EKG si transport rapid.
Solicitati ALS.

Greșeli comune:

Racire cu gheata — vasoconstrictie, agrava ischemia tisulara, risc de degeratura.
Spargerea flictenelor — pierdere de bariera de protectie, risc de infectie.
Acoperire cu materiale aderente (vata, tifon cu fir gros) — durere si lezare la indepartare.
Neglijarea hipotermiei la arsuri mari — soc termic suprapus celui circulator.
Atingerea unui pacient electrocutat cu curentul inca activ — deveniti victima.
```

---

---

**5. CARDIAC SUPPORT (SUPORT CARDIAC)**
---

---

- Cardiac arrest (stopul cardiac) este suspectat când pacientul este:  - unresponsive (inconştient/nereactiv); - not breathing normally (nu respiră normal — absenta respiratiei sau gafait agonic); - pulseless (fară puls carotidian).   **ATENTIE:** Gasping-ul agonic (gafait rar, neregulat, cu miscari vagi ale gâtului) NU este respiratie normala — tratati ca stop cardiac si incepeti CPR imediat. Intarzierea CPR pentru a "evalua mai bine" reduce dramatic sansele de supravietuire.    Heart attack (atacul de cord / infarct) nu este același lucru cu cardiac arrest, dar poate evolua în stop cardiac. Infarctul prezinta durere toracica dar pacientul este constient si are puls. Tratati cu aspirina, O2 si transport rapid.

 5.1 **CPR - Cardiopulmonary Resuscitation (resuscitare cardio-pulmonară)**
```
[SHOW]
CPR menține temporar circulatia sangelui si oxigenarea creierului si organelor vitale, pana la defibrilare sau recuperarea spontana a ritmului cardiac. Fara CPR, creierul incepe sa fie lezat ireversibil dupa 4-6 minute de la oprirea circulatiei.

Cum se executa:

1. Confirmati scene safety si verificati raspunsul pacientului.
2. Strigati dupa ajutor si solicitati AED si resurse suplimentare.
3. Verificati pulsul carotidian maxim 10 secunde (nu mai mult — nu pierdeti timp). Daca nu sunteti sigur ca exista puls, incepeti CPR.
4. Pozitionati pacientul pe o suprafata dura si plana — CPR pe saltea moale sau pat este ineficient (toracele se comprima in suprafata, nu spre stern).
5. Pozitionati mainile: podul palmei mainii dominante pe treimea inferioara a sternului (nu pe procesul xifoid — risc de ruptura, NU eficient; nu pe coaste). Mana non-dominanta deasupra. Degetele ridicate (nu apasa pe coaste). Bratele drepte, blocat la coate.
6. Incepeti compresiile:

Adancime: 5-6 cm la adult (nu mai putin — compresie insuficienta; nu mai mult — fractura de stern, pneumotorax, tamponada).
Ritm: 100-120 compresii/minut (ritmul cantecului "Stayin' Alive" de la Bee Gees).
Revenire completa: lasati toracele sa revina complet dupa fiecare compresie — daca tineti apasati, inima nu se umple de sange intre compresii.
Nu intrerupeti compresiile mai mult de 10 secunde pentru nicio procedura.

7. Raportul 30:2 cu 2 salvatori: 30 compresii, opriti scurt, administrati 2 ventilații cu BVM (fiecare ventilatie 1 secunda, suficient cat sa vedeti chest rise — NU hiperventiati). Fara BVM: compresii continue fara ventilatie (hands-only CPR).
8. Rotiti operatorul la compresii la fiecare 2 minute — oboseala reduce calitatea compresiilor chiar daca nu o simtiti.
9. Daca pacientul vomita: rotiti-l rapid pe o parte, curatati airway-ul, verificati pulsul si reluati CPR daca absent.
10. Daca pulsul revine (ROSC) dar pacientul nu respiră adecvat: ventilati o data la 5-6 secunde si pregatiti transportul.

Calitatea compresiilor — cel mai important factor:

Compresii prea superficiale (sub 5 cm): circulatia generata este insuficienta.
Compresii fara revenire completa: inima nu se umple, debitul cardiac scade.
Pauze excesive: fiecare intrerupere produce o prabusire a presiunii de perfuzie — revenirea la presiune buna dureaza mai multe compresii.
Ritm prea lent (<80/min) sau prea rapid (>130/min): ambele reduc eficienta.

Compresii la copii:

Copil (1-8 ani): adancime 1/3 din diametrul toracelui (~5 cm), 2 degete sau palma.
Sugar (<1 an): doua degete in centrul toracelui, sub linia imaginara inter-mamelonar; adancime ~4 cm.
Raport: 30:2 cu 1 salvator; 15:2 cu 2 salvatori la copil.

Greșeli comune CPR:

Compresii pe procesul xifoid — risc de ruptura, perforatie hepatica.
Compresii pe coaste — fracturi costale, pneumotorax.
Mainile nu sunt ridicate (apasa pe coaste in loc de stern).
Bratele ndoite la coate — se oboseste rapid, compresii inconsistente.
Hiperventilatia — creste presiunea intratoracica si reduce intoarcerea venoasa.
Pauze lungi pentru verificarea pulsului — nu verificati mai des decat la 2 minute.

* Hands-only CPR (CPR doar cu mâinile) este acceptabil daca sunteti singur sau nu puteti ventila in siguranta.
* AED/DEA nu inlocuieste compresiile. Opriti compresiile DOAR pentru analiza/soc, apoi reluati imediat.

[altspoiler=CPR DEMONSTRATION][/altspoiler]
```

 5.2 **AED/DEA - Automated External Defibrillator (defibrilator extern automat)**
```
[SHOW]
AED/DEA analizeaza ritmul cardiac si livreaza un soc electric sincronizat pentru ritmuri soc-abile (VF, VT fara puls). Fiecare minut fara defibrilare reduce sansele de supravietuire cu 7-10%. Utilizati AED cat mai devreme.

Cum se foloseste:

1. Luati AED din ambulanta/vehicul si asezati-l langa pacient.
2. Porniti dispozitivul — urmatii instrucțiunile vocale sau vizuale.
3. Expuneti toracele (uscati pielea daca este umeda — apa conduce curentul in afara toracelui, nu prin inima).
4. Aplicati pads (electrozii) conform diagramei de pe ambalaj:

Padul superior-drept: sub clavicula dreapta, la dreapta sternului.
Padul inferior-stang: pe linia axilara stanga, la nivelul inimii (ICS 4-5 stang), Nu pe san la femei — lateralizati sub san.

5. Conectati cablul pads-urilor la AED (daca nu este pre-conectat).
6. Opriti contactul cu pacientul si anuntati verbal: "CLEAR" (Liberi!) sau "Toti departe!" Verificati vizual ca nimeni nu atinge pacientul sau suprafata pe care sta.
7. Lasati AED-ul sa analizeze (20-40 sec). Nu miscati, nu atingeti pacientul in acest timp.
8. Daca socul este recomandat: repetati "CLEAR!", reverificati vizual, apasati butonul SHOCK.
9. Reluati CPR IMEDIAT dupa soc (nu verificati pulsul prima data — reluati 30 compresii). AED va reinitia analiza dupa 2 minute.
10. Daca "no shock advised": continuati CPR 2 minute, lasati AED sa reanalzieze.
11. Continuati ciclurile CPR/AED pana la ROSC, preluarea de ALS sau ordin de oprire de la medic.

Situatii speciale:

Pacient umed sau in apa: scoateti pacientul din apa, uscati rapid toracele inainte de aplicarea pads-urilor.
Pacemaker implantat: nu asezati padul direct pe dispozitiv (bombilita pe piept) — deplasati padul la 8 cm distanta.
Patch transdermal (plasture medicamentos pe piept): indepartati-l si stergeti zona inainte de aplicare.
Peri excesiv pe piept: radeti rapid zona de pad daca aveti razor in kit; altfel aplicati pads-urile apasand ferm (fire de par pot impiedica contactul bun).
Copii sub 8 ani sau <25 kg: folositi pads pediatrice daca sunt disponibile; daca nu, aplicati pads adult (unul anterior, unul posterior — sandwich).

Greșeli comune AED:

Pads aplicati prea aproape unul de altul — curentul nu traverseaza inima eficient.
Contact cu pacientul in timpul analizei sau socului — pericol real pentru operator.
Intarzierea pornirii AED pentru CPR — porniti AED imediat ce este disponibil, paralel cu CPR.
Verificarea pulsului dupa soc inainte de reluarea CPR — pierdere de timp; incepeti compresiile imediat.
Pads pe haine sau pe zona umeda — analiza incorecta, soc ineficient.

[altspoiler=CARDIAC SUPPORT][/altspoiler]
```

---

---

**6. OXYGEN ADMINISTRATION (ADMINISTRAREA OXIGENULUI)**
---

---

- Oxygen (oxigenul) este indicat cand pacientul are respiratory distress (dificultate respiratorie), SpO2 <94%, traumă severa, soc, stop cardiac, sau status mental alterat. NU administrati O2 in exces la pacientii stabili — hipoxia hipercapnica (BPOC) poate fi agravata de O2 concentratie ridicata.    **Tinta SpO2:**  - Pacient fara BPOC: 94-99%. - Pacient cu BPOC sau insuficienta respiratorie cronica: 88-92% (risc de eliminare a impulsului hipoxic de ventilatie). - Post-ROSC: 94-98% (evitati hipoxia si hipeoxia — ambele agraveaza leziunea neurologica).

 6.1 **Nasal Cannula - NC (canulă nazală)**
```
[SHOW]
Canula nazala este un tub cu doua canule scurte care se introduc in nari. Confortabila, tolerata bine, adecvata pentru distress respirator usor-moderat sau la pacienti care nu tolereaza masca.

Debit si concentratia O2 estimata:

1 L/min ≈ 24% FiO2.
2 L/min ≈ 28% FiO2.
4 L/min ≈ 36% FiO2.
6 L/min ≈ 44% FiO2.

Limita superioara: 6 L/min — peste aceasta, mucoasa nazala se usuca si iritatia devine semnificativa. La nevoie de concentratie mai mare, treceti la NRB mask.

Cum se aplică:

1. Alegeti canula potrivita (adult, copil, sugar).
2. Conectati tubul la sursa de oxygen si setati debitul.
3. Verificati fluxul — simtiti aerul la canule.
4. Introduceti canulele in nari (nu prea adanc — 1-2 cm).
5. Treceiti tubul pe dupa urechi si ajustati slider-ul sub barbie pentru un confort optim.
6. Monitorizati SpO2 si ajustati debitul in functie de raspuns.

Greșeli comune:

Canulele introduse prea adanc — iritatie si disconfort, nu cresteti eficienta.
Debit insuficient pentru gradul de hipoxie — cresteti debitul sau schimbati pe NRB.
Folosire la pacient cu respiratie exclusiv bucala — canula nazala devine ineficienta; folositi masca.

[altspoiler=NASAL CANNULA][/altspoiler]
```

 6.2 **Non-Rebreather Mask - NRB (mască cu rezervor)**
```
[SHOW]
Non-rebreather mask furnizeaza concentratia cea mai mare de O2 disponibila non-invaziv (~90-95% FiO2 la debit adecvat) prin un reservoir bag (sac rezervor) si valve unidirectionale care impiedica reinhalarea aerului expirat.

Debit uzual: 10-15 L/min — saculetul nu trebuie sa colabeze in inspiratie. Daca colabeaza, cresteti debitul.

Indicatii: traumă severa, soc, hipoxie importanta, inhalare de fum, CO intoxicatie (O2 100% accelereaza eliminarea CO), post-ROSC.

Cum se aplică:

1. Conectati masca la sursa de oxygen.
2. Umpleti reservoir bag inainte de aplicare — acoperiti supapa cu degetul si lasati O2 sa umple saculetul complet. Un saculet neumplut nu furnizeaza O2 adecvat in primele inspiratii.
3. Asezati masca ferm peste nas si gura.
4. Ajustati barele metalice ale nasului pentru etanseizare pe nas — masca nu trebuie sa lase aer sa scape lateral.
5. Ajustati elasticul pentru etansare confortabila.
6. Verificati ca saculetul se umfla la expiratie si nu colabeaza complet la inspiratie.

Greșeli comune:

Saculetul neumplut inainte de aplicare — primele respiratii sunt hipoxice.
Debit prea mic (sub 10 L/min) — saculetul colabeaza, pacientul respira aer expirat.
Masca aplicata incorect cu scurgeri laterale — FiO2 real mult mai scazut.
Aplicare la pacient somnolent fara monitorizare — riscul de hipoventilatire in masca.

[altspoiler=NON-REBREATHER MASK][/altspoiler]
```

 6.3 **BVM - Bag Valve Mask (balon-valvă-mască)**
```
[SHOW]
BVM este folosit cand pacientul nu respira sau respira prea slab pentru a mentine viata. Tehnica corecta este critica — un seal (etansare) imperfect, hiperventilatia sau volumul excesiv sunt erori frecvente cu consecinte grave.

Optimal: doi salvatori. Unul mentine masca (etansare si airway); celalalt comprima bag-ul. Cu un singur salvator: tehnica C-E (police + index formeaza C pe masca, celelalte degete formeaza E pe mandibula) — dificil sa mentii un seal bun.

Cum se foloseste:

1. Conectati BVM la sursa de oxygen (15 L/min).
2. Deschideti airway-ul prin head tilt-chin lift sau jaw-thrust.
3. Asezati masca cu vârful (triunghiular) pe radacina nasului, bazul pe barbie. Aplicati tehnica C-E: C = police si index apasa masca pe fata; E = celelalte trei degete ridica mandibula in sus si anterior (jaw thrust integrat).
4. Verificati seal-ul (etansarea) — nu trebuie sa simtiti aer scapand lateral. Daca simtiti, ajustati priza.
5. Comprimati bag-ul cu cealalta mana — suficient cat sa vedeti chest rise vizibil. NU mai mult — volumul tidal tinta la adult este ~500 mL, adica o comprimare a 1/2 - 1/3 din bag-ul adult.
6. Durata ventilatie: 1 secunda per ventilatie.
7. Frecventa: O ventilatie la 5-6 secunde (10-12/min) la pacient cu puls; 2 ventilatii la fiecare 30 compresii in CPR.
8. Lasati bag-ul sa se reumple complet inainte de urmatoarea ventilatie.

Frecvent gresit — presiune pe tesuturile moi sub barbie: degetele de tip E trebuie sa apese pe OS (corpul mandibulei), nu pe tesuturile moi sub barbie. Apasarea pe tesuturile moi comprima traheea si blocheaza airway-ul exact in timp ce incercati sa-l deschideti.

Greșeli comune BVM:

Seal imperfect: aer scapa intre masca si fata — ventilati aerul in atmosfera, nu in plamani. Verificati etansarea la fiecare ventilatie.
Hiperventilatia: prea multa frecventa sau volum excesiv → presiune intratoracica crescuta → intoarcere venoasa scazuta → debit cardiac redus in CPR → outcome mai rau. Ventilati lent si controlat.
Volum excesiv per ventilatie: stomacul se umfla cu aer (distensie gastrica) → risc de voma si aspiratie, diafragma ridicata → ventilatie ineficienta. Suficient cat sa vedeti chest rise.
Apasare pe tesuturile moi: blocheaza airway-ul — apasati pe os.
Capul in pozitie gresita: fara sniffing position/head tilt → airway blocat de baza limbii → nu intra aer chiar daca bag-ul e comprimat.

[altspoiler=BAG VALVE MASK][/altspoiler]
```

---

## #2 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

BASIC LIFE SUPPORT

---

---

---

**7. EQUIPMENT (APARATURĂ)**
---

---

 7.1 **Stretcher/Gurney (targă)**
```
[SHOW]
Stretcher/Gurney este targa mobila pentru incarcarea, transportul si descarcarea pacientului. Modelul hidraulic reduce efortul echipajului si riscul de ranire pentru ambele parti.

Reguli generale:

Verificati ca targa este blocata complet inainte de a aseza pacientul.
Nu lasati targa sa ruleze liber sau necontrolat.
Fixati curelele pacientului inainte de fiecare miscare a tărgii (transport, incline, transfer).
La incline sau praguri: anuntati pacientul; mentineti centrul de greutate jos; cel de jos sustine greutatea.

Unloading the gurney (descărcarea tărgii):

1. Deschideți ușile ambulanței și verificați spațiul din spate (obiecte pe sol, suprafata neteda).
2. Prindeți ferm gurney-ul cu ambele mâini înainte de eliberarea din sistemul de prindere al ambulantei.
3. Acționați maneta de release (eliberare) cu cotul sau genunchiul, pastrand mainile pe targa.
4. Trageți controlat pana cand sistemul de susținere este activ și picioarele coboară și se blocheaza automat.
5. Confirmați vizual si fizic blocarea picioarelor înainte de desprindere completă.

Loading the gurney (încărcarea tărgii):

1. Aliniați gurney-ul cu sistemul de încărcare al ambulanței — ghidaje si rola de podea.
2. Un echipier impinge, celalalt ghideaza din interior.
3. Împingeți targa până când se fixează în sistemul de lock — auziti si simtiti click-ul.
4. Verificați fizic (trageti) că targa este blocata înainte de plecare.
5. Securizati curelele pacientului si IV daca exista.

[altspoiler=HOW TO LOAD THE GURNEY][/altspoiler]
```

 7.2 **Backboard / Spine Board (placă spinală)**
```
[SHOW]
Backboard-ul este utilizat pentru imobilizare spinala si transfer la pacienti cu suspiciune de leziune de coloana sau pacienti care nu pot fi mobilizati in siguranta altfel.

Cand NU este necesar backboard: Pacient constient si orientat, fara durere cervicala sau spinala spontana sau la palpare, fara deficit neurologic, fara MOI semnificativ, fara intoxicatie. Imobilizarea excesiva poate agrava disconfortul si incetini evaluarea.

Log Roll (rostogolire controlată) — 3-4 salvatori:

1. Un salvator controleaza capul si coloana cervicala — da comanda (el conduce manevra). Mentine capul in pozitie neutra cu ambele maini la urechile pacientului.
2. Al doilea salvator controleaza umerii si toracele superior.
3. Al treilea salvator controleaza bazinul si coapsele.
4. Al patrulea (daca exista) controleaza gambele si picioarele.
5. La comanda "Log roll on three: one, two, three": toti rotesc pacientul simultan, intr-o singura miscare controlata, mentinand axa coloana vertebrala.
6. Rapid: al doilea sau al treilea gliseaza backboard-ul sub pacient.
7. La comanda: toti readuc pacientul pe spate pe backboard.
8. Ajustati pozitia, aplicati X-Collar daca nu este deja, fixati cu head blocks si curelele backboard-ului (torace, bazin, picioare).
9. Verificati ca nasul este aliniat cu sternul si ombilicul — capul nu trebuie sa fie rotat.

Greșeli comune:

Miscari nesincronizate la log roll — coloana se rasuceste sau indoaie.
Capul lasat la latitudinea pacientului sa se miste liber — salvatorul de la cap comanda, nu pacientul.
Fixarea incompleta a curelelor — pacientul aluneca la transfer sau transport.
Backboard fara head blocks — capul ramane nefixat lateral.

[altspoiler=BACKBOARD][/altspoiler]
```

---

---

**8. APPROVED MEDICATIONS (MEDICAMENTE PERMISE)**
---

---

- Medicamentele BLS se administreaza conform protocolului departamental si nivelului de certificare. Verificati intotdeauna: alergii, contraindicatii, data expirarii si starea medicamentului. Documentati: medicament, doza, cale, ora, raspunsul pacientului.    **Reguli generale BLS pentru medicamente:**  - Numai la pacient constient si capabil sa inghita in siguranta, cu exceptia formelor IN sau IM. - Confirmatii ca pacientul nu are alergii la medicament inainte de administrare. - Nu administrati doze suplimentare fara reevaluare clinica. - Solicitati ALS pentru medicamente in afara competentei BLS sau cand starea se agraveaza.

 8.1 **Pain Relief (calmarea durerii)**
```
[SHOW]
Aspirin (Acid Acetilsalicilic)
Indicatii: Suspiciune de STEMI sau SCA (sindrom coronarian acut) — simptome de atac de cord cu durere toracica tipica (opresiva, iradiata, cu transpiratii, greata). Inhibitia plachetara rapida reduce dimensiunea cheagului coronarian. Administrati cat mai devreme.
Contraindicatii: Alergie confirmata la aspirina sau AINS; ulcer peptic activ cu hemoragie; copii sub 16 ani (sindrom Reye — asociere fatala cu boli virale febrile); coagulopatie severa cunoscuta; hemoragie activa.
Precautii: Astm aspirina-sensibil (bronhospasm la AINS — intrebati in istoricul); insuficienta hepatica severa.
Doza: 162-325 mg PO MASTICATA (mestecata bine, nu inghitita intreaga — absorbtia este semnificativ mai rapida prin suprafata mucoasei bucale). Nu administrati cu apa daca medicamentul este deja mestec.
Cai: PO (masticata).
Onset: 15-30 min pentru efectul antitrombotic initial.
Ce NU trebuie facut: Nu administrati la pacient cu greata severa sau varsaturi active — riscul de aspiratie; solicitati ALS pentru Aspirin IV sau alternativa.

Ibuprofen (AINS)
Indicatii: Durere usoara pana la moderata; inflamatie; febra; fracturi minore; cefalee; durere musculara sau articulara.
Contraindicatii: Insuficienta renala (chiar si moderata — IBU reduce fluxul sanguin renal); ulcer peptic activ sau istoric de hemoragie GI; sarcina (trimestrul III — inchide prematur ductus arteriosus); coagulopatie; insuficienta cardiaca severa; hipersensibilitate la AINS; varsta sub 6 luni; deshidratare severa.
Precautii: Varstnici (risc crescut de efecte adverse renale si GI — reduceti doza); hipertensiune (AINS cresc TA prin retentie sodica).
Doza: 400-600 mg PO la 6-8h; maxim 2400 mg/zi. Administrati cu apa si, ideal, cu putina mancare daca disponibila (reduce iritatia gastrica).
Cai: PO.
Ce NU trebuie facut: Nu administrati concomitent cu Aspirina (risc GI cumulat, IBU poate reduce efectul antitrombotic al Aspirinei); nu la pacient deshidratat sever (IRC acuta).
```

 8.2 **Poisoning & Overdose (intoxicații și supradoze)**
```
[SHOW]
Activated Charcoal (Carbune Activat)
Indicatii: Ingestii toxice recente (ideal sub 30-60 minute) la pacient constient, alert si cooperant, capabil sa inghita in siguranta. Adsorbe la suprafata sa majoritatea medicamentelor si toxinelor, reducand absorbtia gastro-intestinala.
Contraindicatii: Alterare a constiintei sau risc de aspiratie (nu poate inghiti sigur); ingestie de corozivi (acizi sau baze tari — carbunele nu adsoarbe si complica endoscopia); hidrocarburi (benzina, motorina — risc de aspiratie pulmonara); alcooli (etanol, metanol, etileng licol — nu adsorb la carbune); fier (iron), litiu, metale grele — nu se leaga de carbune; obstructie intestinala; voma activa sau persistenta.
Doza: 25-50 g PO (adult); 1 g/kg la copii (maxim 50 g). Se administreaza suspendat in apa — agitati bine (sedimenteaza rapid). Unele preparate vin pre-suspendate cu indulcitor pentru a imbunatati toleranta.
Cai: PO (servit cu pai pentru a reduce colorarea dintilor si pentru administrare usoara).
Cum se administreaza: Explicati pacientului ca va fi negru, nu va semnifica nici o complicatie. Pacientul trebuie sa bea incet. Monitorizati dupa administrare pentru voma (risc de aspiratie).
Ce NU trebuie facut: Nu administrati la pacient somnolent sau cu reflexe diminuate — aspira cu uurinta carbunele care produce pneumonie chimica severa. Nu administrati prin sonda fara evaluare ALS.

Naloxone / Narcan (Naloxona)
Indicatii: Suspiciune de supradoza cu opioide: triada clasica — depresie respiratorie (FR <12/min sau respiratie superficiala), mioza (pupile punctiforme), alterare a constiintei + context (ace, medicamente opioide, consum cunoscut). Poate salva viata in secunde la pacientul in apnee prin supradoza.
Contraindicatii: Nu exista contraindicatii absolute. Precautie la dependenti de opioide — poate precipita sevraj violent acut (agitatie, tahicardie, HTA, convulsii). Daca pacientul este in stop cardiac, administrati fara ezitare; sevrajul este o consecinta gestionabila.
Doza BLS:

IN (intranazal — preferat BLS): 2 mg (1 mg per nara; 0.5-1 mL per nara din solutia 2 mg/mL). Repetati la 2-3 minute daca fara raspuns. Dispozitiv: MAD (Mucosal Atomization Device) sau Narcan Nasal Spray presetat.
IM: 0.4-2 mg IM in vastus lateralis sau deltoid. Repetati la 2-3 min daca fara raspuns.

Cai: IN (preferat BLS), IM.
Onset: IN: 3-5 min; IM: 5-10 min.
Durata actiunii: 30-90 minute — MAI SCURTA decat durata majoritatii opioidelor. Pacientul poate reintra in depresie respiratorie dupa disparitia efectului naloxonei! Monitorziati continuu si transportati chiar daca raspunde.
Raspuns asteptat: FR creste, SpO2 creste, pacientul incepe sa se trezeasca. Daca pacientul nu raspunde la 4-8 mg naloxona, cauza probabil NU este numai supradoza de opioide — evaluati alte cauze.
Ce NU trebuie facut: Nu administrati doza excesiva dintr-odata la dependent (precipita sevraj violent cu potential de agresivitate); titrati in doze mici (0.4 mg, nu 2 mg dintr-odata) la dependent cunoscut. Nu lasati pacientul nesupravegheat dupa administrare — re-sedarea este posibila.

Nota dupa Narcan: Pacientul trezit prin naloxona poate deveni agitat, confuz si agresiv (sevraj acut). Pastrati scena sigura, explicati calm situatia, pregatiti transport. NU lasati pacientul sa refuze transportul fara evaluare ALS — durata Narcan este mai scurta decat a opioidului, pacientul va redeveni somnolent.
```

 8.3 **Diabetic Emergency (urgenta diabetica)**
```
[SHOW]
Oral Glucose (Glucoza Orala)
Indicatii: Hipoglicemie simptomatica documentata sau suspectata (glicemie <70 mg/dL sau simptome: transpiratie, tremur, confuzie, agitatie) la pacient constient, alert si capabil sa inghita in siguranta. Este mai simplu, mai rapid si mai eficient decat IV la acest grup de pacienti.
Contraindicatii: Alterare a constiintei sau somnolenta (risc de aspiratie); incapacitate de a inghiti; voma activa; hipoglicemie severa cu pierderea cunostintei (necesita glucoza IV sau glucagon — ALS sau IM).
Doza: 15-20 g glucoza PO = 150-200 mL suc de fructe natural (fara indulcitor artificial) SAU 3-4 comprimate de glucoza SAU gel de glucoza conform marcajului. Repetati dupa 15 minute daca simptomele persista si glucometria ramane sub 70 mg/dL.
Cai: PO.
Monitorizare: Repetati glucometria la 15 minute. Chiar daca pacientul se simte mai bine, transportati — hipoglicemia poate recidiva, mai ales la pacientii cu insulina cu actiune lunga sau sulfoniluree.
Ce NU trebuie facut: Nu administrati la pacient somnolent sau confuz fara a verifica ca poate inghiti — aspiratia de lichid zaharat produce pneumonie aspiratica.
```

---
