# [MODEL] Fire Incident Report

- **Topic ID:** 11
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=11
- **Posts:** 2

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

 Administrative & Support

---

 **FIRE INCIDENT REPORT**
 Los Santos Fire Department · Fire Suppression & Operations

**I — INFORMAȚII GENERALE**

- **PERSONAL:** Rank Prenume Nume, Rank Prenume Nume  **UNITATE:** Numărul unității  **DISPECERAT:** 911 / Departamental / Găsit  **ORA SOSIRII:** DD/LLL/YYYY HH:MM  **ORA ÎNCHEIERII:** DD/LLL/YYYY HH:MM

**II — INFORMAȚII INCIDENT**

- **ADRESĂ:** Strada, zona, reper  **TIP INCIDENT:** Incendiu / MVA / Scurgere / Altele  **UNITĂȚI PREZENTE:** Enumerați tipurile de unități implicate  **VICTIME:** Numărul de victime  **VEHICULE IMPLICATE:** Numărul de vehicule implicate  **CLĂDIRI IMPLICATE:** Numărul de clădiri implicate  **PAGUBE:** Descrieți pagubele produse  **SURSA INCENDIULUI:** Electric / Scurgeri / Provocat intenționat / Altele

**III — PROCEDURI & MĂSURI APLICATE**

- **INSTRUMENTE & ECHIPAMENTE:** —  **TIPURI DE FURTUNURI:** —  **TIPURI DE EXTINCTOARE:** —  **TIPURI DE SPUMĂ:** —

**IV — NARAȚIUNE**

- Introduceți narațiunea aici. Descrieți circumstanțele incidentului, acțiunile echipajului, procedurile aplicate și evoluția situației pe parcursul intervenției.

 Semnat,
 Nume Prenume

---

## #2 — Aisha Dubois

Titlu:
```
[DDMMHHMM] Locatie
```

 Model:
```
[birou= Administrative & Support Bureau]
[center][size=130][b]FIRE INCIDENT REPORT[/b][/size]
[size=85][color=#888888]Los Santos Fire Department  ·  Fire Suppression & Operations[/color][/size][/center]

[divbox=#1B2A4A][center][color=white][size=92][b]I — INFORMAȚII GENERALE[/b][/size][/color][/center][/divbox]
[list=none][size=88]
[b]PERSONAL:[/b]          Rank Prenume Nume,  Rank Prenume Nume
[b]UNITATE:[/b]            Numărul unității
[b]DISPECERAT:[/b]      911 / Departamental / Găsit
[b]ORA SOSIRII:[/b]      DD/LLL/YYYY  HH:MM
[b]ORA ÎNCHEIERII:[/b]  DD/LLL/YYYY  HH:MM
[/size][/list]

[divbox=#1B2A4A][center][color=white][size=92][b]II — INFORMAȚII INCIDENT[/b][/size][/color][/center][/divbox]
[list=none][size=88]
[b]ADRESĂ:[/b]                        Strada, zona, reper
[b]TIP INCIDENT:[/b]                Incendiu / MVA / Scurgere / Altele
[b]UNITĂȚI PREZENTE:[/b]         Enumerați tipurile de unități implicate
[b]VICTIME:[/b]                        Numărul de victime
[b]VEHICULE IMPLICATE:[/b]      Numărul de vehicule implicate
[b]CLĂDIRI IMPLICATE:[/b]        Numărul de clădiri implicate
[b]PAGUBE:[/b]                        Descrieți pagubele produse
[b]SURSA INCENDIULUI:[/b]       Electric / Scurgeri / Provocat intenționat / Altele
[/size][/list]

[divbox=#1B2A4A][center][color=white][size=92][b]III — PROCEDURI & MĂSURI APLICATE[/b][/size][/color][/center][/divbox]
[list=none][size=88]
[b]INSTRUMENTE & ECHIPAMENTE:[/b]  —
[b]TIPURI DE FURTUNURI:[/b]              —
[b]TIPURI DE EXTINCTOARE:[/b]           —
[b]TIPURI DE SPUMĂ:[/b]                    —
[/size][/list]

[divbox=#1B2A4A][center][color=white][size=92][b]IV — NARAȚIUNE[/b][/size][/color][/center][/divbox]
[list=none][size=88]
Introduceți narațiunea aici. Descrieți circumstanțele incidentului, acțiunile echipajului, procedurile aplicate și evoluția situației pe parcursul intervenției.
[/list]

Semnat,
Nume Prenume
[/birou]
```

---
