# Aisha Dubois

- **Topic ID:** 57
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=57
- **Posts:** 1

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

 Administrative & Support

---

 **PERSONNEL RECORD**
 Los Santos Fire Department · Administrative & Support Bureau

**I — DATE PERSONALE**

- **NUME COMPLET:** Aisha Dubois  **NUMĂR INSIGNĂ:** #0001  **DATA ANGAJĂRII:** 03/JAN/2019  **STATUS:** Activ

**II — RANG & POZIȚIE**

- **RANG CURENT:** Fire Chief  **TIP CONTRACT:** Permanent  **PROMOVAT DE:** City of Los Santos — Office of Emergency Services · 14/SEP/2024

**III — DIVIZII & BIROURI**

- **DIVIZIE PRIMARĂ:** Primary Operations Bureau — Fire Operations & EMS  **SPECIALIZARE:** Suppression · EMS · HazMat · Technical Rescue  **STAȚIE:** LSFD Headquarters — Station 1 Davis    **— BIROURI SECUNDARE —**  · Training & Professional Development · Director · Din: 12/MAR/2021  · Administration & Human Resources · Director · Din: 07/NOV/2022  · Fire Investigation & Prevention · Director · Din: 19/JUN/2023

**IV — CALIFICĂRI & CERTIFICĂRI**

- **— CORE OPERATIONS —**    ✓ Basic Life Support (BLS) · 08/FEB/2019    ✓ Fire Suppression (Fire 1) · 08/FEB/2019    ✓ Vehicle Extrication · 15/MAR/2019    ✓ Rope Rescue · 15/MAR/2019    ✓ Apparatus Driver · 04/AUG/2020    ✓ Fire 2 · 04/AUG/2020    ✓ Interior Operations · 11/NOV/2021    ✓ Fire 3 · 11/NOV/2021    ✓ Pump Operations · 11/NOV/2021     **— EMERGENCY MEDICAL —**    ✓ Emergency Medical Technician (EMT) · 22/MAR/2019    ✓ Field Medic · 30/SEP/2020    ✓ Advanced Life Support (ALS) — Critical Care Provider / Paramedic · 14/JAN/2022     **— PRIMARY OPERATIONS — SPECIALIZĂRI —**    ✓ Fire Attack Specialist · 10/APR/2019    ✓ Engine Operator · 11/NOV/2021    ✓ Ventilation Specialist · 03/JUL/2020    ✓ Heavy Rescue Technician · 18/OCT/2020    ✓ Rope Rescue Operator · 05/FEB/2021    ✓ Crash Response Specialist · 22/JUN/2021    ✓ Apparatus Engineer · 11/NOV/2021    ✓ Incident Safety Officer · 08/MAR/2022    ✓ Operations Coordinator · 08/MAR/2022     **— DIV. 2: HAZMAT, SPECIAL OPERATIONS & DISASTER RESPONSE —**    ✓ Hazmat Operations · Tier I · 17/MAY/2020    ✓ Decontamination Specialist · Tier I · 17/MAY/2020    ✓ Hazmat Technician · Tier II · 09/OCT/2020    ✓ Hazmat Entry Technician · Tier II · 09/OCT/2020    ✓ Hazmat Equipment Officer · 14/JAN/2021    ✓ CBRN Response Officer · Tier III · 29/APR/2021    ✗ HSOD Coordinator · Tier IV — Division Lead     **— DIV. 3: WILDLAND & ENVIRONMENTAL OPERATIONS —**    ✓ Wildland Firefighter — Type 2 · Tier I · 03/JUN/2019    ✓ Wildland Firefighter — Type 1 · Tier II · 21/NOV/2020    ✓ Wildland Engine Operator · Tier III · 08/AUG/2021    ✓ Wildland Helitack · Tier III · 30/NOV/2021    ✓ Environmental Response Specialist · 15/MAR/2022    ✗ Wildland Incident Commander · Tier IV    ✗ Wildland Operations Coordinator · Tier IV — Division Lead     **— DIV. 4: WATER RESCUE OPERATIONS —**    ✓ Water Rescue Awareness · Tier I · 12/APR/2019    ✓ Swift Water Rescue Technician · Tier II · 07/SEP/2020    ✓ Marine Operations Specialist · Tier II · 07/SEP/2020    ✓ Ice Rescue Technician · Tier II · 19/FEB/2021    ✓ Flood Response Operator · Tier II · 19/FEB/2021    ✓ Dive Rescue Technician · Tier III · 04/OCT/2021    ✗ Water Rescue Coordinator · Tier IV — Division Lead     **— DIV. 5: FIRE INVESTIGATION & PREVENTION —**    ✓ Fire Safety Officer · Tier I · 22/MAR/2021    ✓ Public Education Officer · 10/JUL/2021    ✓ Fire Inspector · Tier II · 18/DEC/2021    ✓ Fire Investigator · Tier III · 05/MAY/2022    ✓ Arson Investigator · Tier III · 05/MAY/2022    ✓ Fire Marshal · 29/OCT/2022    ✓ Fire Prevention Chief · Tier IV — Division Lead · 19/JUN/2023     **— DIV. 6: TRAINING & PROFESSIONAL DEVELOPMENT —**    ✓ Field Training Officer (FTO) · Tier I · 19/FEB/2022    ✓ Fire Instructor · Tier II · 08/JUN/2022    ✓ Academy Instructor · Tier II · 08/JUN/2022    ✓ Certification Officer · Tier II · 11/AUG/2022    ✓ Scenario Designer · 30/SEP/2022    ✓ FTO Coordinator · Tier III · 12/MAR/2021    ✓ Senior Academy Instructor · Tier III · 14/JAN/2023    ✓ Curriculum Developer · Tier III · 14/JAN/2023    ✓ Academy Director · Tier III · 07/APR/2023    ✗ Training Division Chief · Tier IV — Division Lead     **— DIV. 7: FLEET, LOGISTICS & COMMUNICATIONS —**    ✓ Fleet Technician / Dispatcher · Tier I · 03/MAY/2021    ✓ Supply Officer · Tier II · 19/SEP/2021    ✓ Facilities Coordinator · Tier II · 19/SEP/2021    ✗ Senior Fleet Technician · Tier II    ✗ Lead Dispatcher · Tier III    ✗ Fleet Manager · Tier III    ✗ Communications Manager · Tier III    ✗ Support Services Chief · Tier IV — Division Lead     **— DIV. 8: ADMINISTRATION & HUMAN RESOURCES —**    ✓ HR Assistant / Records Assistant · Tier I · 14/JAN/2022    ✓ Human Resources Officer · Tier II · 07/NOV/2022    ✓ Recruitment Coordinator · Tier II · 07/NOV/2022    ✓ Employee Relations Officer · Tier II · 03/MAR/2023    ✓ Records Management Officer · Tier II · 03/MAR/2023    ✓ Internal Affairs Officer · Tier III · 29/JUN/2023    ✓ Public Information Officer (PIO) · Tier III · 29/JUN/2023    ✓ Administrative Services Chief · Tier IV — Division Lead · 07/NOV/2022

**V — ISTORIC PROMOVĂRI**

- **03/JAN/2019** · Recruit · Angajare inițială — Recruit Academy Cohort #12  **08/FEB/2019** · Probationary Firefighter · Promovat de Battalion Chief Raymond Okafor  **04/AUG/2020** · Firefighter · Promovat de Captain Marcus Webb  **11/NOV/2021** · Engineer · Promovat de Deputy Chief Sandra Vail  **08/MAR/2022** · Lieutenant · Promovat de Deputy Chief Sandra Vail · Vacancy Promotion  **14/OCT/2022** · Captain · Promovat de Deputy Chief Sandra Vail · Promotional Exam — Scor 94/100  **02/MAY/2023** · Battalion Chief · Promovat de Fire Chief Elias Drummond  **18/DEC/2023** · Deputy Chief · Promovat de Fire Chief Elias Drummond · Bureau Commander — Operations  **14/SEP/2024** · Fire Chief · Numit de City of Los Santos — Office of Emergency Services

**VI — DISTINCȚII & MENȚIUNI**

- **17/AUG/2019** · Life Saving Award · Acordat de Captain Marcus Webb · Resuscitare reușită la incident MVA pe Route 68 — pacient stabilizat pe teren și transportat cu succes  **03/NOV/2020** · Commendation Letter · Acordat de Battalion Chief Raymond Okafor · Coordonare exemplară la incidentul HazMat din portul LS — izolarea rapidă a scurgerii de clor a prevenit victime civile  **22/MAR/2021** · Medal of Bravery · Acordat de Deputy Chief Sandra Vail · Intrare în structură parțial prăbușită pentru extragerea a doi civili blocați — Davis Apartment Fire  **10/JAN/2022** · Employee of the Month · Acordat de Deputy Chief Sandra Vail · Performanță excepțională în coordonarea Field Training Program și reducerea timpilor de răspuns la Station 1  **08/JUN/2022** · Perfect Attendance Citation · Acordat de Battalion Chief Raymond Okafor · Zero absențe nemotivate pe parcursul anului fiscal 2021-2022  **29/APR/2023** · Medal of Valor · Acordat de Fire Chief Elias Drummond · Comandă tactică exemplară la incendiul de la depozitul chimic Banning — prevenirea exploziei secundare și evacuarea a 34 de civili  **14/SEP/2024** · Distinguished Service Medal · Acordat de City of Los Santos · Recunoașterea excelenței profesionale și a contribuțiilor la modernizarea LSFD — acordat la ceremonia de numire ca Fire Chief  **01/JAN/2025** · Commendation Letter · Acordat de Office of Emergency Services · Gestionarea răspunsului la inundațiile din Chumash — coordonare multi-agenție cu LSPD și Coast Guard

**VII — SANCȚIUNI & SUSPENDĂRI**

- — Nicio sancțiune înregistrată în dosarul de personal —

**VIII — REINTEGRARE**

- — Această secțiune se completează exclusiv pentru foștii membri LSFD care solicită reintegrarea. Nu este cazul pentru acest dosar. —

**IX — NOTE COMMAND STAFF**

- **14/SEP/2024 · Office of Emergency Services:**  Dubois este numită Fire Chief în urma unui proces de selecție competitiv din care a ieșit cu cel mai mare punctaj agregat din istoria recentă a departamentului. Se remarcă prin abilități excepționale de leadership tehnic și administrativ, disciplină operațională și capacitatea de a construi coeziune instituțională. Este primul Fire Chief din istoria LSFD care deține calificări active în cinci bureaus simultane la momentul numirii.    **02/MAY/2023 · Fire Chief Elias Drummond:**  Dubois continuă să fie unul dintre cei mai capabili ofițeri pe care i-am condus. Promovarea la Battalion Chief este consecința directă a performanței consistente, a judecății tactice solide și a dedicației față de dezvoltarea subordonaților. Recomand cu fermitate pentru orice poziție de Bureau Commander.    **14/OCT/2022 · Deputy Chief Sandra Vail:**  Promovată la Captain în urma unuia dintre cele mai înalte scoruri la Promotional Exam din ultimii trei ani. Dubois demonstrează o înțelegere excepțională a ICS și a dinamicii operaționale. Capacitatea sa de a menține calmul și claritatea decizională în scenarii de stress ridicat o diferențiează clar de colegi.

---
