# CAPITOLUL VII – ARBITRAJ ȘI MECANISME DE APEL ALE FIREFIGHTER UNION

- **Topic ID:** 37
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=37
- **Posts:** 1

---

## #1 — Kellan Dunley

![](https://i.imgur.com/2jlMxHe.png)

FIREFIGHTER UNION MANUAL

---

 CAPITOLUL VII – ARBITRAJ ȘI MECANISME DE APEL ALE FIREFIGHTER UNION
---

---

- **(7.1)** Importanța mecanismelor de apel în protecția membrilor

---

---

- Procedura disciplinară nu este completă fără existența unui sistem robust de apel și arbitraj. Într-o profesie unde deciziile se iau sub presiune intensă, iar consecințele pot fi interpretate greșit, dreptul la contestarea unei sancțiuni devine esențial.    Arbitrajul reprezintă garanția legală și morală că niciun membru nu va fi pedepsit în mod nedrept, pe baza unor evaluări incomplete, părtinitoare sau grăbite. Firefighter Union consideră acest drept unul fundamental, parte integrantă din protecția profesională oferită membrilor săi.

 -
---

---

- **(7.2)** Dreptul oficial la apel

---

---

- Orice membru sancționat are dreptul să depună apel în termen de 10 zile lucrătoare de la momentul comunicării oficiale a sancțiunii.    Firefighter Union oferă membrilor:    • consiliere procedurală completă;   • sprijin juridic specializat;   • analiză tehnică a întregului dosar;   • evaluare independentă a proporționalității sancțiunii.    Acest drept nu poate fi restricționat de conducerea Fire Department sau de factorii administrativi.

 -
---

---

- **(7.3)** Etapele procedurii de apel

---

---

- Procedura de apel se desfășoară în mai multe faze, fiecare dintre ele asigurând membrului protecția procesuală necesară.    **(7.3.1) Depunerea cererii de apel**   Membrul, asistat de Union, redactează un document oficial care include:    • datele de identificare;   • descrierea sancțiunii contestate;   • motivele și argumentele apelului;   • dovezi suplimentare (dacă există);   • solicitarea expresă de reanalizare.    **(7.3.2) Verificarea preliminară de către Union**   Comitetul Executiv verifică:    • respectarea procedurii disciplinare;   • existența sau absența abuzurilor;   • corectitudinea probei administrate;   • proporționalitatea sancțiunii;   • dacă reprezentarea sindicală a fost oferită corect.    Dacă sunt identificate nereguli grave, Union poate cere anularea imediată a sancțiunii.

 -
---

---

- **(7.4)** Arbitrajul intern (Internal Review Board)

---

---

- Dacă apelul nu se poate soluționa prin verificarea preliminară, acesta este înaintat către comisia de arbitraj intern.    Comisia este formată din:    • trei membri seniori ai Union, independenți;   • un consilier juridic;   • un membru neutru al Fire Department, fără implicare în caz.    **(7.4.1) Procedura ședinței de arbitraj**   În timpul ședinței:    • se analizează dosarul complet;   • se audiază membrul și reprezentantul său;   • investigatorul poate fi chemat pentru clarificări;   • Union prezintă argumentele tehnice și juridice;   • comisia deliberează în absența membrului.    **(7.4.2) Rezultatele posibile**   Comisia poate decide:    • menținerea sancțiunii;   • reducerea sancțiunii;   • anularea sancțiunii;   • retrimiterea cazului la reinvestigare;   • escaladarea către arbitraj extern.    Decizia este comunicată membrului în scris.

 -
---

---

- **(7.5)** Arbitrajul extern (Independent Arbitration)

---

---

- Arbitrajul extern este utilizat în cazurile grave sau atunci când Union constată:    • nerespectarea procedurilor;   • sancțiuni abuzive;   • investigații părtinitoare;   • ingerință politică sau administrativă;   • probe insuficiente sau incorect administrate.    **(7.5.1) Alegerea arbitrului independent**   Arbitrul trebuie să fie:    • total independent;   • certificat în arbitraj profesional;   • fără legături cu FD sau Union;   • acceptat de ambele părți.    **(7.5.2) Procedura arbitrajului extern**   În cadrul sesiunii:    • se analizează întreg dosarul;   • membrul și Union sunt audiați;   • Fire Department își prezintă poziția;   • pot fi aduse probe noi;   • arbitrul poate solicita clarificări suplimentare.    **(7.5.3) Decizia arbitrului**   Decizia arbitrului este definitivă și obligatorie. Ea poate dispune:    • anularea sancțiunii;   • reducerea sancțiunii;   • plata salariului reținut ilegal;   • reintegrarea în funcție;   • modificarea procedurilor interne ale FD.    Fire Department este obligat să respecte decizia fără întârziere.

 -
---

---

- **(7.6)** Dreptul la reprezentare juridică completă

---

---

- Firefighter Union oferă membrilor:    • consiliere juridică;   • avocați specializați în dreptul muncii;   • susținere în cazurile de litigii administrative;   • suport procedural pentru apeluri și arbitraj.    Niciun membru nu trebuie să fie nevoit să se apere singur în fața unei proceduri complexe.

 -
---

---

- **(7.7)** Protecția membrilor împotriva represaliilor

---

---

- Union protejează orice membru împotriva:    • sancțiunilor pentru depunerea unui apel;   • tratamentului diferențiat;   • intimidării sau presiunilor;   • mutării disciplinare fără motiv;   • retrogradării nejustificate.    Este interzis ca FD să penalizeze un membru pentru simplul fapt că și-a exercitat drepturile sindicale.

 -
---

---

- **(7.8)** Reevaluarea cazurilor închise și revizuirea sancțiunilor istorice

---

---

- Union poate solicita redeschiderea unui caz în situații precum:    • apariția unor dovezi noi;   • descoperirea unor erori semnificative în investigația inițială;   • neconformități grave în procedura disciplinară;   • suspiciuni privind lipsa de imparțialitate a arbitrului;   • încălcări ale drepturilor membrului.    Această procedură asigură corectitudinea pe termen lung a întregului sistem disciplinar.

 -
---

---

- **(7.9)** Rolul preventiv al Union în arbitraj

---

---

- Pe lângă rolul de apărare, Union are o funcție preventivă:    • analizează anual cazurile disciplinare;   • identifică tipare de abuz;   • semnalează probleme de siguranță;   • solicită actualizări procedurale;   • propune măsuri de prevenire a conflictelor interne.    Raportul anual de arbitraj al Union ajută FD să îmbunătățească procedurile interne.

 -
---

---

- **(7.10)** Importanța arbitrajului în menținerea moralului și a încrederii în instituție

---

---

- Un sistem disciplinar corect, completat de un mecanism funcțional de apel și arbitraj, contribuie direct la:    • creșterea moralului membrilor;   • consolidarea încrederii în conducere;   • stabilitatea operațională a departamentului;   • protejarea imaginii publice a profesiei.    Arbitrajul este un pilon esențial al unui Fire Department modern și stabil.

 -

---
