# ACADEMIE LSFD - MANUAL

- **Topic ID:** 48
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=48
- **Posts:** 1

---

## #1 — Kellan Dunley

![](https://i.imgur.com/2jlMxHe.png)

OFFICE OF THE FIRE CHIEF

---

 **LOS SANTOS FIRE DEPARTMENT**
 **MANUALUL OFICIAL AL ACADEMIEI DE PREGĂTIRE**
 Biroul pentru Instruire și Standarde Profesionale

---

---

- **SCOPUL PROGRAMULUI DE ACADEMIE**

---

---

- Programul Academiei are rolul de a forma membri operaționali capabili să intervină în siguranță, disciplinat și eficient în cadrul operațiunilor de stingere a incendiilor, salvare tehnică și asistență medicală de urgență.    Academia reprezintă etapa fundamentală de tranziție dintre statutul de nou membru și cel de operator activ al departamentului. În această perioadă sunt dezvoltate competențele tactice, capacitatea de integrare în echipă, înțelegerea lanțului de comandă și aplicarea strictă a procedurilor operaționale standard.    Obiectivul principal al programului este pregătirea personalului astfel încât fiecare membru să poată:  • opera în condiții de siguranță personală și colectivă;  • aplica proceduri standardizate în mod consecvent;  • lua decizii corecte în condiții de stres;  • menține disciplina operațională în orice tip de incident.

 -

- **DURATA ȘI STRUCTURA PROGRAMULUI**

---

---

- Programul Academiei se desfășoară pe o perioadă standard de 3 până la 4 săptămâni, fiind organizat în module progresive, structurate astfel:    • Faza I – Fundamente operaționale (Siguranță, Echipament, Proceduri de bază);  • Faza II – Operațiuni de stingere și salvare;  • Faza III – Asistență medicală de urgență (BLS);  • Faza IV – Scenarii integrate și evaluare finală.    Fiecare fază presupune instruire teoretică, aplicații practice și evaluări intermediare.

 -

- **STANDARDE DE CONDUITĂ ȘI DISCIPLINĂ**

---

---

- Academia funcționează în regim disciplinar strict. Respectarea lanțului de comandă și executarea imediată a ordinelor instructorilor reprezintă condiții obligatorii.    Se impune următoarea conduită:    • Prezentare punctuală la toate sesiunile programate;  • Ținută corespunzătoare și echipament complet;  • Limbaj profesional;  • Respect față de instructori și colegi;  • Respectarea tuturor normelor de siguranță.    Abaterile disciplinare sunt clasificate în trei categorii:    **Abateri minore** – întârziere, neatenție, comunicare deficitară.  **Abateri moderate** – nerespectarea repetată a procedurilor, lipsă de coordonare operațională.  **Abateri grave** – încălcarea normelor de siguranță, punerea în pericol a echipei, refuzul executării unei sarcini.    În funcție de gravitate, pot fi aplicate:  • avertisment formal;  • sesiune suplimentară de remediere;  • suspendarea temporară din program;  • reluarea fazei curente;  • eliminarea din program (în cazuri grave sau repetate).

 -

- **POLITICA DE SIGURANȚĂ OPERAȚIONALĂ**

---

---

- Siguranța personalului are prioritate absolută în cadrul tuturor activităților academice.    În operațiunile de stingere:  • Echipamentul individual de protecție trebuie purtat integral și corect.  • Aparatul autonom de respirat (SCBA) este obligatoriu în medii cu potențial periculos.  • Sistemul PASS trebuie activat și verificat înaintea intrării în structură.  • Operațiunile interioare se desfășoară exclusiv în echipe, conform principiului „doi în interior, doi în exterior”.  • Nicio persoană nu operează singură în mediu structural afectat de incendiu.    În operațiunile medicale:  • Se aplică măsuri de protecție conform principiului izolării substanțelor biologice (BSI).  • Siguranța scenei trebuie confirmată înainte de abordarea pacientului.  • Se menține permanent o cale de retragere.    Orice încălcare a normelor de siguranță conduce la oprirea imediată a exercițiului și reevaluarea candidatului.

 -

- **SISTEMUL DE EVALUARE**

---

---

- Evaluarea în cadrul Academiei se realizează prin:    • teste scrise;  • verificări practice pe nivelul de competență;  • evaluări tactice în scenarii simulate;  • analiză comportamentală și disciplinară.    Promovarea fiecărei faze este condiționată de:  • demonstrarea competențelor minime obligatorii;  • aplicarea corectă a procedurilor;  • menținerea standardelor de siguranță;  • conduită profesională adecvată.    Candidații care nu îndeplinesc standardele pot fi:  • direcționați către sesiuni de remediere;  • reevaluați într-un termen stabilit;  • relocați într-o serie ulterioară de academie.    Scopul evaluării nu este excluderea, ci formarea unui personal competent și sigur operațional.

 -

- **TRANZIȚIA CĂTRE STATUTUL DE PROBAȚIUNE**

---

---

- Absolvirea Academiei conferă statutul de Pompier/EMT aflat în perioadă de probă.    Această etapă presupune integrarea în unități operaționale sub supravegherea unui Ofițer de Instruire în Teren (FTO) și are rolul de a confirma aplicarea corectă a competențelor dobândite.    Detaliile fazei de probă și ale programului FTO sunt reglementate în Capitolul IV al prezentului manual.

 **CAPITOLUL II**
 **PREGĂTIRE OPERAȚIONALĂ – STINGERE ȘI SALVARE**

---

---

- **FUNDAMENTE OPERAȚIONALE ÎN INTERVENȚII DE INCENDIU**

---

---

- Pregătirea operațională în domeniul intervențiilor la incendiu reprezintă baza formării fiecărui pompier. În cadrul Academiei, accentul este pus pe siguranță, coordonare în echipă și aplicarea consecventă a procedurilor standard.    Recrutul trebuie să demonstreze înțelegerea comportamentului focului, capacitatea de a opera echipamentul specific și disciplina necesară intervențiilor în medii cu risc ridicat.

 -

- **ECHIPAMENTUL INDIVIDUAL DE PROTECȚIE (EIP)**

---

---

- Echipamentul individual de protecție constituie prima linie de apărare a pompierului împotriva temperaturilor extreme, gazelor toxice și riscurilor mecanice.    EIP complet include:  • cască structurală;  • glugă ignifugă;  • haină și pantaloni de intervenție;  • mănuși structurale;  • cizme de protecție;  • aparat autonom de respirat (SCBA);  • sistem PASS.    În cadrul Academiei, recruții sunt instruiți să efectueze:  • echiparea completă într-un interval de timp controlat;  • verificarea etanșeității măștii SCBA;  • verificarea presiunii buteliei;  • activarea și testarea sistemului PASS.    Intrarea într-un mediu cu potențial periculos fără utilizarea corespunzătoare a SCBA este considerată abatere gravă.

 -
---

---

- **PRINCIPII DE INTERVENȚIE – ATAC EXTERIOR ȘI INTERIOR**

---

---

- La sosirea la locul incendiului, prima etapă constă în evaluarea dimensiunii scenei (size-up). Se analizează:    • gradul de implicare al structurii;  • riscul de propagare;  • existența victimelor;  • stabilitatea structurală;  • necesitatea unei intervenții defensive sau ofensive.    **Atacul defensiv (exterior)** este aplicat atunci când structura este complet implicată sau prezintă risc major de colaps. În această situație, obiectivul principal este limitarea propagării și protejarea zonelor adiacente.    **Atacul ofensiv (interior)** este permis doar atunci când:  • structura prezintă stabilitate relativă;  • există posibilitatea salvării victimelor;  • sunt disponibile resurse suficiente;  • echipele operează conform principiului echipei de minimum două persoane.    Nicio operațiune interioară nu se desfășoară fără echipă și fără comunicare permanentă cu Comandantul Incidentului.

 -

- **OPERAȚIUNI INTERIOARE – DISCIPLINĂ ȘI CONTROL**

---

---

- Operațiunile interioare impun cel mai ridicat nivel de disciplină și coordonare.    Procedura standard include:  • verificarea temperaturii ușilor înainte de deschidere;  • deschiderea controlată pentru prevenirea fenomenelor de tip backdraft;  • avansarea furtunului cu menținerea contactului fizic între membri;  • menținerea poziției joase pentru reducerea expunerii la temperaturi ridicate;  • raportarea constantă a progresului către IC.    Recruții sunt instruiți să recunoască semnele potențiale de flashover și instabilitate structurală și să prioritizeze retragerea în siguranță atunci când condițiile o impun.

 -

- **VENTILAȚIA STRUCTURALĂ**

---

---

- Ventilația are rolul de a evacua gazele fierbinți și fumul acumulat, facilitând accesul echipelor și reducând riscul dezvoltării rapide a incendiului.    Se disting două metode principale:    **Ventilația verticală** – realizată prin deschideri controlate la nivelul acoperișului, cu verificarea prealabilă a stabilității acestuia.    **Ventilația orizontală** – realizată prin deschiderea sau spargerea controlată a ferestrelor și ușilor pentru crearea unui flux de aer dirijat.    Ventilația se execută exclusiv coordonat cu echipele de atac interior pentru a evita intensificarea incendiului.

 -

- **CĂUTARE ȘI SALVARE – PRINCIPIUL VEIS**

---

---

- Operațiunile de căutare și salvare sunt prioritare atunci când există informații privind persoane posibil surprinse în interior.    Procedura VEIS (Vent–Enter–Isolate–Search) presupune:  • ventilarea controlată a punctului de acces;  • intrarea într-o cameră specifică;  • izolarea spațiului prin închiderea ușilor;  • efectuarea căutării sistematice.    Recruții sunt instruiți să efectueze căutarea în poziție joasă, să mențină orientarea și să evacueze imediat orice victimă identificată.

 -

- **INTERVENȚII LA ACCIDENTE RUTIERE (MVA)**

---

---

- Intervențiile la accidente rutiere implică atât riscuri mecanice, cât și riscuri de incendiu sau scurgeri de combustibil.    Procedura standard include:  • stabilizarea vehiculului;  • deconectarea sursei electrice;  • evaluarea structurii pentru puncte de tăiere;  • utilizarea echipamentelor hidraulice (spreader, cutter, ram) în mod controlat;  • coordonarea permanentă cu echipajul medical.    Înainte de începerea extragerii, vehiculul trebuie stabilizat complet pentru a preveni mișcările necontrolate.

 -

- **ECHIPA DE INTERVENȚIE RAPIDĂ (RIT)**

---

---

- RIT este desemnată pentru salvarea pompierilor aflați în pericol în timpul operațiunilor interioare.    Echipa RIT rămâne pregătită, complet echipată, și intervine exclusiv la ordinul IC.    Recruții sunt instruiți să:  • înțeleagă procedura de apel „Mayday”;  • identifice semnalul PASS activat;  • aplice tehnici de localizare și extragere a unui pompier căzut.

---

---

 **CAPITOLUL III**
 **ASISTENȚĂ MEDICALĂ DE URGENȚĂ – NIVEL BLS**

---

---

- **PRINCIPII GENERALE DE INTERVENȚIE MEDICALĂ**

---

---

- Personalul operativ trebuie să fie capabil să acorde asistență medicală de bază în orice tip de incident, până la transferul responsabilității către personal medical avansat sau unități spitalicești.    Intervenția medicală începe întotdeauna cu asigurarea siguranței scenei și evaluarea rapidă a situației. Stabilitatea zonei, existența riscurilor și numărul victimelor trebuie determinate înainte de contactul direct cu pacientul.    Fiecare intervenție medicală trebuie să urmeze o structură logică, standardizată și repetabilă, astfel încât îngrijirea acordată să fie eficientă și sigură.

 -

- **PROTECȚIA PERSONALULUI ȘI SECURITATEA SCENEI**

---

---

- Siguranța personalului este prioritară în orice intervenție medicală.    Înainte de abordarea pacientului trebuie confirmate:  • stabilitatea scenei;  • absența pericolelor imediate;  • controlul traficului sau al mulțimii;  • existența unei căi sigure de retragere.    Se aplică principiul izolării substanțelor biologice (BSI):  • purtarea mănușilor medicale;  • protecție oculară atunci când există risc de expunere la fluide;  • mască de protecție în situații specifice.    Nicio intervenție nu se inițiază într-un mediu instabil sau nesecurizat.

 -

- **EVALUAREA INIȚIALĂ A PACIENTULUI**

---

---

- Evaluarea inițială este realizată printr-o abordare sistematică menită să identifice rapid afecțiunile care pun viața în pericol.    Se utilizează schema DR CAB / DR ABC:    • D – evaluarea pericolelor și a mediului;  • R – verificarea reacției pacientului;  • C – circulația și hemoragiile majore;  • A – căile respiratorii;  • B – respirația.    Nivelul de conștiență se stabilește prin metoda AVPU:  • Alert;  • Verbal;  • Pain;  • Unresponsive.    Această evaluare trebuie realizată rapid, dar complet, și repetată pe durata intervenției.

 -

- **TRIEREA PACIENȚILOR ÎN INCIDENTE CU VICTIME MULTIPLE**

---

---

- În situațiile cu mai multe victime, stabilirea priorităților este esențială.    Pacienții sunt clasificați după gravitate:    • Prioritate imediată – afecțiuni care pun viața în pericol;  • Prioritate întârziată – răni serioase, dar stabile;  • Răni minore – pacienți ambulatori;  • Decedați sau fără șanse de supraviețuire.    Trierea trebuie realizată rapid și actualizată constant pe măsură ce situația evoluează. Scopul principal este alocarea eficientă a resurselor disponibile.

 -

- **CONTROLUL HEMORAGIILOR ȘI AL TRAUMELOR**

---

---

- Hemoragia severă reprezintă una dintre principalele cauze prevenibile de deces în traumă.    Controlul sângerării se realizează prin:  • aplicarea pansamentului compresiv;  • presiune directă asupra rănii;  • utilizarea garoului atunci când sângerarea nu poate fi controlată altfel.    În cazul fracturilor:  • se evită mișcările inutile;  • se stabilizează segmentul afectat;  • se aplică atele corespunzătoare;  • se monitorizează circulația distală.    Pacienții cu traumatisme severe trebuie transportați fără întârziere către unități medicale adecvate.

 -

- **ARSURI ȘI EXPUNERI TERMICE**

---

---

- Arsurile pot varia de la leziuni superficiale la traumatisme severe cu risc vital.    Principii generale:  • îndepărtarea pacientului din sursa de căldură;  • răcirea controlată a zonei afectate;  • protejarea plăgii cu pansamente sterile;  • prevenirea hipotermiei.    Arsurile extinse sau cele la nivelul căilor respiratorii necesită transport rapid și monitorizare continuă.

 -

- **SUPORT CARDIO-RESPIRATOR**

---

---

- În cazul stopului cardio-respirator, intervenția rapidă este esențială.    Se inițiază imediat:  • evaluarea respirației și pulsului;  • compresiile toracice;  • utilizarea defibrilatorului extern automat (AED);  • administrarea oxigenului.    Coordonarea echipei trebuie să fie clară, iar resuscitarea continuă până la predarea pacientului către personal medical avansat.

 -

- **ADMINISTRAREA OXIGENULUI**

---

---

- Administrarea oxigenului este indicată în:  • dificultăți respiratorii;  • traumatisme majore;  • stop cardiac;  • arsuri severe;  • pacienți inconștienți.    Echipamente utilizate:  • canulă nazală;  • mască cu rezervor;  • balon de ventilație manuală.    Alegerea metodei depinde de starea pacientului și de nivelul de conștiență.

 -

- **COORDONAREA CU ECHIPELE DE INTERVENȚIE**

---

---

- Intervențiile medicale se desfășoară în strânsă coordonare cu echipele de stingere și salvare.    Comunicarea eficientă între echipaje este esențială pentru:  • stabilirea zonelor de tratament;  • prioritizarea evacuării;  • transferul pacienților;  • menținerea siguranței generale a scenei.    Toate acțiunile medicale trebuie integrate în planul general al incidentului stabilit de comandantul intervenției.

---

---

 **CAPITOLUL IV**
 **PERIOADA DE PROBĂ ȘI PROGRAMUL DE INSTRUIRE ÎN TEREN (FTO)**

---

---

- **STATUTUL DE POMPIER/EMT ÎN PERIOADĂ DE PROBĂ**

---

---

- Absolvirea Academiei conferă statutul de Pompier/EMT aflat în perioadă de probă. Această etapă reprezintă tranziția de la mediu controlat de instruire la mediul operațional real.    Perioada de probă are rolul de a confirma că membrul:  • aplică corect procedurile în condiții reale;  • menține disciplina și siguranța operațională;  • funcționează eficient în echipă;  • demonstrează maturitate profesională.    Durata standard a perioadei de probă este stabilită de departament și poate fi prelungită dacă performanța nu atinge nivelul cerut.

 -

- **PRINCIPIILE PERIOADEI DE PROBĂ**

---

---

- În perioada de probă, pompierul nu operează independent în situații critice fără supraveghere adecvată.    Se aplică următoarele restricții operaționale:  • nu conduce operațiuni interioare;  • nu preia comanda unei echipe;  • nu coordonează zone de triaj fără supraveghere;  • execută sarcini sub îndrumarea unui membru experimentat.    Scopul nu este limitarea dezvoltării, ci consolidarea competențelor în condiții reale.

 -

- **PROGRAMUL FIELD TRAINING OFFICER (FTO)**

---

---

- Programul FTO este etapa formală de instruire în teren și este coordonat de un Ofițer de Instruire desemnat.    FTO are responsabilitatea de a:  • observa performanța zilnică;  • corecta deficiențele;  • evalua nivelul de autonomie;  • recomanda confirmarea sau prelungirea perioadei de probă.    Programul FTO este structurat în trei faze progresive:    **Faza I – Observare activă**  Membrul asistă la intervenții și execută sarcini simple sub supraveghere directă.    **Faza II – Implicare operațională controlată**  Membrul execută sarcini tehnice (furtun, ventilare, evaluare pacient) cu autonomie parțială.    **Faza III – Conducere supervizată**  Membrul poate coordona o activitate limitată sub monitorizare atentă.    Trecerea între faze este condiționată de performanță și recomandarea FTO.

 -

- **EVALUAREA ÎN CADRUL FTO**

---

---

- Evaluarea zilnică se bazează pe următoarele criterii:    • Siguranță personală și a echipei;  • Aplicarea procedurilor standard;  • Capacitatea de comunicare radio și directă;  • Integrarea în echipaj;  • Inițiativă controlată și judecată operațională.    Observațiile sunt documentate în rapoarte de instruire. Deficiențele identificate sunt discutate imediat, iar corectarea lor este urmărită în intervențiile următoare.    Abaterile grave sau repetate privind siguranța pot conduce la:  • reluarea fazei curente;  • prelungirea programului FTO;  • reevaluare formală de către Biroul de Instruire.

 -

- **INTEGRAREA ÎN ECHIPAJ**

---

---

- Integrarea într-un echipaj operațional presupune adaptare la ritmul stației și la cultura organizațională.    Membrul aflat în probă trebuie să demonstreze:  • respectarea ierarhiei;  • capacitatea de a primi și aplica feedback;  • responsabilitate față de echipamente și autospeciale;  • participare activă la întreținerea și verificarea zilnică a materialelor.    Comportamentul profesional în cadrul stației este la fel de important ca performanța în intervenție.

 -

- **CONFIRMAREA ÎN FUNCȚIE**

---

---

- La finalul perioadei de probă și al programului FTO, Biroul de Instruire analizează:    • rapoartele zilnice;  • progresul operațional;  • comportamentul profesional;  • capacitatea de a opera în siguranță fără supraveghere directă.    Confirmarea în funcție se acordă atunci când membrul demonstrează competență constantă și respectarea standardelor departamentale.    În cazul în care standardele nu sunt îndeplinite, perioada de probă poate fi:  • prelungită pentru consolidarea competențelor;  • reevaluată într-o sesiune formală;  • încheiată conform regulamentelor interne.

 -

- **CONCLUZIE**

---

---

- Programul Academiei și perioada de probă constituie fundamentul dezvoltării profesionale a fiecărui membru al departamentului.    Prin aplicarea consecventă a standardelor de siguranță, disciplină și competență tehnică, departamentul asigură un nivel ridicat de pregătire operațională și protecție a comunității deservite.    Formarea nu se încheie odată cu confirmarea în funcție; instruirea continuă reprezintă o responsabilitate permanentă a fiecărui pompier și EMT.

Cu stima,

**Battalion Chief Kellan Dunley**

---

---

 **RESURSE SUPLIMENTARE**

 Pentru proceduri, protocoale și documentație medicală actualizată, personalul operațional poate accesa pagina dedicată EMS:

 [**Link către pagina OPERATIONALA a departamentului**](https://lsfd.ro-rp.mp/viewforum.php?f=15&sid=7410f36c32254652482330006f4d9757)
 [**Link către pagina EMS a departamentului**](https://lsfd.ro-rp.mp/viewforum.php?f=19&sid=7410f36c32254652482330006f4d9757)
 [**Link către pagina FIREFIGHTER a departamentului**](https://lsfd.ro-rp.mp/viewforum.php?f=20&sid=7410f36c32254652482330006f4d9757)
---

---

---

---

---
