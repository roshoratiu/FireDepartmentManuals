# PROCESUL DE ADMITERE

- **Topic ID:** 4
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=4
- **Posts:** 1

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

ADMISSION BOARD

---

 PROCESUL DE ADMITERE
---

---

- Procesul de admitere în cadrul **Los Santos Fire Department** este unul riguros, conceput pentru a testa abilitățile fizice, capacitățile psihice și atitudinea profesională a aplicanților în situații de stres ridicat. Conduita și performanța candidaților sunt atent monitorizate de către ofițerii de recrutare și instructorii din cadrul **Training & Professional Development**. Toți pașii acestui proces sunt obligatorii, iar respectarea cu strictețe a procedurilor și a lanțului de comandă (Chain of Command) este esențială pentru a putea promova.    **I. APLICAȚIA** - Reprezintă prima etapă a procesului. Cererea de înscriere trebuie completată conform modelului impus și este analizată în detaliu de către un **Recruitment Coordinator** din cadrul **Administration & Human Resources**. Decizia de acceptare sau respingere se ia pe baza profilului, a istoricului și a eligibilității candidatului.    **II. INTERVIUL** - Candidații ale căror aplicații au fost acceptate vor fi programați pentru susținerea unui interviu oficial. Această evaluare are loc în fața unui panel de recrutare format din ofițeri ai departamentului. Prestanța, motivația, etica și capacitatea de reacție vor fi evaluate pentru a determina dacă aplicantul este potrivit pentru o carieră în LSFD.    **III. EXAMENUL MEDICAL** - Reprezintă evaluarea stării de sănătate a candidatului. Constă în analize complete de sânge, test de urină, evaluare fizică generală și un test anti-drog obligatoriu, pentru a certifica aptitudinea medicală pentru efort intens și operarea echipamentelor speciale.    **IV. RECRUIT TRAINING ACADEMY** - Odată admiși, recruții încep programul oficial al academiei (desfășurat de regulă pe o perioadă de 3-4 săptămâni). Programul este structurat în module progresive ce îmbină pregătirea teoretică și cea practică, acoperind siguranța operațională, stingerea incendiilor, proceduri de salvare și obținerea certificării medicale **Basic Life Support (BLS)**.    **V. EXAMENUL FINAL ȘI EVALUAREA TACTICĂ** - Pentru a absolvi Academia, recruții trebuie să promoveze o serie de testări riguroase sub supravegherea **Academy Instructors**. Acestea includ teste scrise din materia parcursă, verificări practice pe nivelul de competență, precum și evaluări tactice desfășurate în scenarii simulate cu foc viu (Live Fire) sau urgențe medicale.    **VI. STATUTUL DE PROBAȚIUNE (FIELD TRAINING PROGRAM)** - Absolvirea Academiei **nu** conferă independență pe teren. Absolvenții primesc rang-ul de **Probationary Firefighter** (Pompier/EMT aflat în perioadă de probă) și intră direct în **Field Training Program**. În această etapă, ei vor opera pe autospeciale exclusiv sub directa supraveghere și îndrumare a unui **Field Training Officer (FTO)**. Doar în urma evaluărilor zilnice (DOR) și a confirmării competențelor în intervenții reale, membrul va finaliza perioada de probă și va fi avansat la rang-ul de **Firefighter** deplin.    Orice întrebare, nelămurire sau problemă cu privire la procesul de admitere și pașii pe care aplicanții trebuie să îi parcurgă poate fi adresată prin mesaj către membrii **Human Resources** sau departamentului de **Recruitment**. Orice modificări ulterioare vor fi anunțate în acest topic.

---
