# [MODEL] Patient Care Report

- **Topic ID:** 10
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=10
- **Posts:** 2

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

 Administrative & Support

---

 **PATIENT CARE REPORT**
 Los Santos Fire Department · Emergency Medical Services

**I — INFORMAȚII GENERALE**

- **PERSONAL:** Rank Prenume Nume, Rank Prenume Nume  **UNITATE:** Numărul unității  **DISPECERAT:** 911 / Departamental / Găsit  **ORA SOSIRII:** DD/LLL/YYYY HH:MM  **ORA ÎNCHEIERII:** DD/LLL/YYYY HH:MM  **REZULTAT:** Refuz / Tratat - Lansat / Transfer / Apel anulat / Decedat

**II — DATE PACIENT**

- **NUME:** Prenume Nume  **VÂRSTĂ:** X ani  **SEX:** Bărbat / Femeie  **RASĂ:** Afro-american / American Indian / Asiatic / Caucazian / Hispanic / Altele  **ALERGII:** NKDA / Listă alergii

**DECES — completați numai dacă este cazul**

- **ORA DECESULUI:** HH:MM · Raportul continuă la secțiunea Prejudiciu, iar la final se trimite la Coroners.

**III — PREJUDICIU & EVALUARE**

- **PREJUDICIU:** Tipul și descrierea rănii / rănilor  **LOCAȚIA RĂNII:** Localizare anatomică  **MECANISMUL PREJUDICIULUI:** Chimic / Fizic / Biologic — descriere

**IV — SEMNE VITALE**

- **ORA:** HH:MM | **PULS:** XX bpm | **RESP:** XX/min | **T.A.:** XXX/XX mmHg | **LOC-AVPU:** A / V / P / U  **ORA:** HH:MM | **PULS:** XX bpm | **RESP:** XX/min | **T.A.:** XXX/XX mmHg | **LOC-AVPU:** A / V / P / U

**V — MEDICAȚIE ADMINISTRATĂ**

- **MEDICAMENT:** —  **DOZĂ:** —  **METODĂ:** IV / IM / Oral / Inhalator / Sublingual

**VI — NARAȚIUNE**

- Introduceți narațiunea aici. Descrieți circumstanțele apelului, evaluarea inițială, intervențiile efectuate și evoluția stării pacientului pe parcursul intervenției.

 Semnat,
 Nume Prenume

---

## #2 — Aisha Dubois

Titlu:
```
[DDMMHHMM]Nume Prenume
```

 Format:
```
[birou= Administrative & Support Bureau]
[center][size=130][b]PATIENT CARE REPORT[/b][/size]
[size=85][color=#888888]Los Santos Fire Department  ·  Emergency Medical Services[/color][/size][/center]

[divbox=#1B2A4A][center][color=white][size=92][b]I — INFORMAȚII GENERALE[/b][/size][/color][/center][/divbox]
[list=none][size=88]
[b]PERSONAL:[/b]          Rank Prenume Nume,  Rank Prenume Nume
[b]UNITATE:[/b]            Numărul unității
[b]DISPECERAT:[/b]      911 / Departamental / Găsit
[b]ORA SOSIRII:[/b]      DD/LLL/YYYY  HH:MM
[b]ORA ÎNCHEIERII:[/b]  DD/LLL/YYYY  HH:MM
[b]REZULTAT:[/b]          Refuz / Tratat - Lansat / Transfer / Apel anulat / Decedat
[/size][/list]

[divbox=#1B2A4A][center][color=white][size=92][b]II — DATE PACIENT[/b][/size][/color][/center][/divbox]
[list=none][size=88]
[b]NUME:[/b]      Prenume Nume
[b]VÂRSTĂ:[/b]   X ani
[b]SEX:[/b]        Bărbat / Femeie
[b]RASĂ:[/b]      Afro-american / American Indian / Asiatic / Caucazian / Hispanic / Altele
[b]ALERGII:[/b]   NKDA / Listă alergii
[/size][/list]

[divbox=#6B1A1A][center][color=white][size=88][b]DECES — completați numai dacă este cazul[/b][/size][/color][/center][/divbox]
[list=none][size=88]
[b]ORA DECESULUI:[/b]  HH:MM  ·  Raportul continuă la secțiunea Prejudiciu, iar la final se trimite la Coroners.
[/size][/list]

[divbox=#1B2A4A][center][color=white][size=92][b]III — PREJUDICIU & EVALUARE[/b][/size][/color][/center][/divbox]
[list=none][size=88]
[b]PREJUDICIU:[/b]                    Tipul și descrierea rănii / rănilor
[b]LOCAȚIA RĂNII:[/b]                Localizare anatomică
[b]MECANISMUL PREJUDICIULUI:[/b]  Chimic / Fizic / Biologic — descriere
[/size][/list]

[divbox=#1B2A4A][center][color=white][size=92][b]IV — SEMNE VITALE[/b][/size][/color][/center][/divbox]
[list=none][size=88]
[b]ORA:[/b] HH:MM  |  [b]PULS:[/b] XX bpm  |  [b]RESP:[/b] XX/min  |  [b]T.A.:[/b] XXX/XX mmHg  |  [b]LOC-AVPU:[/b] A / V / P / U
[b]ORA:[/b] HH:MM  |  [b]PULS:[/b] XX bpm  |  [b]RESP:[/b] XX/min  |  [b]T.A.:[/b] XXX/XX mmHg  |  [b]LOC-AVPU:[/b] A / V / P / U
[/size][/list]

[divbox=#1B2A4A][center][color=white][size=92][b]V — MEDICAȚIE ADMINISTRATĂ[/b][/size][/color][/center][/divbox]
[list=none][size=88]
[b]MEDICAMENT:[/b]  —
[b]DOZĂ:[/b]            —
[b]METODĂ:[/b]       IV / IM / Oral / Inhalator / Sublingual
[/size][/list]

[divbox=#1B2A4A][center][color=white][size=92][b]VI — NARAȚIUNE[/b][/size][/color][/center][/divbox]
[list=none][size=88]
Introduceți narațiunea aici. Descrieți circumstanțele apelului, evaluarea inițială, intervențiile efectuate și evoluția stării pacientului pe parcursul intervenției.
[/list]

Semnat,
Nume Prenume

[/birou]
```

---
