# FORMULAR DE REINTEGRARE

- **Topic ID:** 7
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=7
- **Posts:** 2

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

OFFICE OF THE FIRE CHIEF

---

 FORMULAR DE REINTEGRARE
---

---

- **(1.0)** INFORMAȚII CU CARACTER PERSONAL

---

---

- **(1.1) Nume:** Răspunde aici.  **(1.2) Prenume:** Răspunde aici.  **(1.3) Adresă:** Răspunde aici.  **(1.4) Număr de telefon:** Răspunde aici.

 -
---

---

- **(2.0)** INFORMAȚII DESPRE DEMITERE

---

---

- **(2.1) Rang precedent:** Răspunde aici.  **(2.2) Tipul demiterii:** Răspunde aici.  **(2.3) Motivul demiterii:** Răspunde aici.  **(2.4) Data demiterii:** ZZ.LL.AAAA  **(2.5) Legătură către demitere:** [ACCES](https://lsfd.ro-rp.mp/LinkDeAcces)

 -
---

---

- **(3.0)** MOTIVAȚIE

---

---

- **(3.1) Ce ocupații ați avut din momentul demiterii până în prezent?:**     **(3.2) Dacă ați fost demis(ă) neonorabil, specificați motivul sau motivele pentru care Office of the Fire Chief ar lua în considerare cererea dumneavoastră de reintegrare:** (minim 50 de cuvinte)    Răspunde aici.    **(3.3) De ce doriți să vă reintegrați în Los Santos Fire Department?** (minim 50 de cuvinte)    Răspunde aici.

 -
---

---

- (( **(4.0)** INFORMAȚII OUT OF CHARACTER ))

---

---

- **(4.1) Pe plan Out Of Character, de ce dorești să te reintegrezi în Los Santos Fire Department?:** (minim 50 de cuvinte)    Răspunde aici.    **(4.2) Dacă ai fost demis(ă) neonorabil din motive Out Of Character, specifică motivul sau motivele pentru care ar trebui să luăm în considerare cererea ta de reintegrare:** (minim 50 de cuvinte)    Răspunde aici.    **(4.3) Acces către contul de forum:** [ACCES](https://lsfd.ro-rp.mp/LinkDeAcces)  **(4.4) În prezent, ești membru al unei alte facțiuni? Dacă da, specifică:** Răspunde aici.  **(4.5) Prezintă poze needitate cu Admin Record-ul de pe toate caracterele** (album): [ACCES](https://lsfd.ro-rp.mp/LinkDeAcces)  **(4.6) Prezintă o poză needitată cu /stats de pe caracterul cu care aplici:** [ACCES](https://lsfd.ro-rp.mp/LinkDeAcces)

 -

---

## #2 — Aisha Dubois

Titlu:
```
[REINTEGRARE] Nume Prenume
```

 Cod:
```
[birou=OFFICE OF THE FIRE CHIEF white]

[size=150][center]FORMULAR DE REINTEGRARE[/center][/size]
[hr][/hr]
[list=none][size=120][b](1.0)[/b] INFORMAȚII CU CARACTER PERSONAL[/size][/list]
[hr][/hr]
[list=none]
[b](1.1) Nume:[/b] Răspunde aici.
[b](1.2) Prenume:[/b] Răspunde aici.
[b](1.3) Adresă:[/b] Răspunde aici.
[b](1.4) Număr de telefon:[/b] Răspunde aici.
[/list]
[color=#FFFFFF]-[/color]
[hr][/hr]
[list=none][size=120][b](2.0)[/b] INFORMAȚII DESPRE DEMITERE[/size][/list]
[hr][/hr]
[list=none]
[b](2.1) Rang precedent:[/b] Răspunde aici.
[b](2.2) Tipul demiterii:[/b] Răspunde aici.
[b](2.3) Motivul demiterii:[/b] Răspunde aici.
[b](2.4) Data demiterii:[/b] ZZ.LL.AAAA
[b](2.5) Legătură către demitere:[/b] [url=LinkDeAcces]ACCES[/url]
[/list]
[color=#FFFFFF]-[/color]
[hr][/hr]
[list=none][size=120][b](3.0)[/b] MOTIVAȚIE[/size][/list]
[hr][/hr]
[list=none]
[b](3.1) Ce ocupații ați avut din momentul demiterii până în prezent?:[/b]

[b](3.2) Dacă ați fost demis(ă) neonorabil, specificați motivul sau motivele pentru care Office of the Fire Chief ar lua în considerare cererea dumneavoastră de reintegrare:[/b] (minim 50 de cuvinte)

Răspunde aici.

[b](3.3) De ce doriți să vă reintegrați în Los Santos Fire Department?[/b] (minim 50 de cuvinte)

Răspunde aici.

[/list]
[color=#FFFFFF]-[/color]
[hr][/hr]
[list=none][size=120](( [b](4.0)[/b] INFORMAȚII OUT OF CHARACTER ))[/size][/list]
[hr][/hr]
[list=none]
[b](4.1) Pe plan Out Of Character, de ce dorești să te reintegrezi în Los Santos Fire Department?:[/b] (minim 50 de cuvinte)

Răspunde aici.

[b](4.2) Dacă ai fost demis(ă) neonorabil din motive Out Of Character, specifică motivul sau motivele pentru care ar trebui să luăm în considerare cererea ta de reintegrare:[/b] (minim 50 de cuvinte)

Răspunde aici.

[b](4.3) Acces către contul de forum:[/b] [url=LinkDeAcces]ACCES[/url]
[b](4.4) În prezent, ești membru al unei alte facțiuni? Dacă da, specifică:[/b]  Răspunde aici.
[b](4.5) Prezintă poze needitate cu Admin Record-ul de pe toate caracterele[/b] (album): [url=LinkDeAcces]ACCES[/url]
[b](4.6) Prezintă o poză needitată cu /stats de pe caracterul cu care aplici:[/b] [url=LinkDeAcces]ACCES[/url]
[/list]
[color=#FFFFFF]-[/color]

[/birou]
```

---
