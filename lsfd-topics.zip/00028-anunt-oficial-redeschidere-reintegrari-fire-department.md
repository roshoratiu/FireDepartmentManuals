# (( Anunț Oficial: Redeschidere Reintegrări Fire Department ))

- **Topic ID:** 28
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=28
- **Posts:** 1

---

## #1 — Aisha Dubois

![Antet Scrisoare](https://i.imgur.com/2jlMxHe.png)
**Duminica 12, 2025**

 Los Santos Fire Department
 Sherling Road 234, Los Santos
 San Andreas

 **Către: Dragi Jucători ai Comunității noastre,**

 Suntem extrem de încântați să vă anunțăm că suntem în **toiul pregătirilor** pentru **Fire Department** și că ne apropiem de finalizare cu pași rapizi!

 Odată cu această veste, anunțăm **DESCHISE CERERILE DE REINTEGRARE!**

- **Cine poate aplica?** Membrii vechi ai facțiunii care doresc să revină, membrii cu experiență în Fire Department.
- **Unde se aplică?** Puteți posta cererea de reintegrare începând de acum pe **categoria dedicată**.
- **Atenție!** Deoarece serverul nu este încă deschis, iar anumite câmpuri nu pot fi completate (din lipsă de informații actuale din joc, sau lipsa de Character Development), le puteți lăsa **goale** sau menționați **N/A**.
- **Durata de răspuns:** Vă rugăm să aveți **răbdare**. Procesul de evaluare va dura mai mult, estimând un interval de **2-3 săptămâni**.
- **Pasul următor:** Ne așteptăm să vă contactăm **direct** pentru întrebări suplimentare. Vă rugăm să fiți pregătiți!

 Vă mulțumim pentru interes și așteptăm cu nerăbdare să ne revedem!

 Cu stimă,
 din partea Fire Office și Command Unit,
 **Aisha Dubois,**
 **Fire Chief**

Los Santos Fire Department — "City's **Bravest**, City's **Best**"

**To report an emergency call 9-1-1**

---
