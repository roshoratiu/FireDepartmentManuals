# RIDE ALONG PROGRAM

- **Topic ID:** 6
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=6
- **Posts:** 1

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

RIDE-ALONG PROGRAM

---

 Dacă sunteți interesat să aderați în cadrul Los Santos Fire Department sau pur și simplu doriți să aflați mai multe despre îndatoririle medicilor de zi cu zi, puteți solicita să fiți luat într-un ride-along alături de un paramedic.

 **CONDIŢII DE BAZĂ**
---

---

 1) Aplicantul trebuie să deţină un document valid de legitimare.
 2) Aplicantul trebuie să aibă vârstă minimă de șaisprezece (16) ani.
 3) Aplicantul trebuie să aibă un cazier curat (excepție contravențiile și suspendările de licență).

 4) Dacă este minor, aplicantul trebuie să aibă un părinte sau un tutore legal care să fie de acord cu reglementările impuse și care să semneze pentru acest lucru.

 5) Aplicantul trebuie să fie pregătit psihic, mental și emoțional pe toată perioada ride-along-ului.
 6) Aplicantul trebuie să respecte şi să facă tot ce spune medicul care îl înoţeşte.
 7) Aplicantul nu trebuie să fie restricţionat din cadrul departamentului sau din cadrul procesului de recrutare. (( Această regulă se aplică şi pe plan OOC.))

 (( Aplicantul nu trebuie să folosească programul de ride-along cu scopul de a publica informaţii clasificate, care nu ar putea fi cunoscute de către public prin alte căi, printre care se numără coduri radio, politici, proceduri şi regulamente interne, ori alte informaţii considerate clasificate. ))

 (( Aplicantul nu poate folosi programul de ride-along pentru a obţine un avantaj, fie acesta In-Character sau Out of Character. Aici intră, dar nu se limitează doar la, comiterea infracţiunilor, furtul de proprietate guvernamentală, folosirea de proprietate guvernamentală, ori acte de terorism, răpire sau alte încălcări ale Codului Penal asupra unui civil sau asupra unui angajat guvernamental. ))
---

---

 **PREVEDERI ESENTIALE**
---

---

 1) Aplicantul trebuie să urmeze cu stricteţe toate instrucţiunile oferite de către medicul cu care realizează patrula de observaţie sau, după caz, de către orice alt medic sau supervizor aflat la scenă. Se aşteaptă din partea fiecărui aplicant să menţină o atitudine serioasă şi respectuoasă faţă de medici şi public pe toată durata desfăşurării programului de ride-along.

 2) Aplicantul poate fi expus informaţiilor clasificate ca şi confidenţiale, printre care se numără numele anumitor dosare sau acte, adrese, etc. Orice informaţie considerată clasificată nu trebuie dezvăluită persoanelor neautorizate, mai exact persoane din afara Los Santos Fire Department.

 3) Indiferent de experienţa anterioară deţinută, poziţia aplicantului este una de observare. În unele cazuri, aplicantul poate fi solicitat să ofere asistenţă; totuşi, în cazul în care aplicantul nu doreşte să ofere asistenţa cerută, este responsabilitatea acestuia să informeze medicul de faptul că nu se simte competent, apt sau că nu doreşte să ofere asistenţă.

 4) În momentul în care medicul răspunde unui apel sau se află într-o situaţie, aplicantul nu trebuie să îi vorbească sau să îl distragă în vreun anumit fel, decât în cazul în care doreşte să îl avertizeze de posibile pericole pe care acesta nu le-a identificat încă.

 5) Se aşteaptă de la fiecare aplicant să rămână în permanenţă în interiorul vehiculului de patrulă. Excepţie fac cazurile în care un medic solicită aplicantului părăsirea vehiculului. A se nota faptul că aplicantul nu trebuie să ceară permisiunea să părăsească vehiculul decât în situaţii de urgenţă.

 6) Aplicantul nu trebuie să folosească telefonul sau orice alt aparat electronic decât pentru a comunica lucruri importante şi esenţiale. Totuşi, aplicantul poate folosi astfel de aparate electronice în cazul unei urgenţe. A se nota faptul că telefonul sau aparatele eletronice trebuie oprite sau puse pe modul silenţios pe toată durata desfăşurării programului de ride-along.

 7) Fiecare solicitare survenită din partea unui civil trebuie înaintată către medicul cu care desfăşuraţi programul de ride-along.

 8) Aplicantul trebuie să înţeleagă faptul că o patrulă de observare poate fi încheiată în orice moment fără înştiinţarea acestuia anterioară, în special în cazurile în care ofiţerul trebuie să răspundă unei situaţii de mare risc care ar putea să vă pună viaţa în pericol. Din aceste motive, vă este recomandat să purtaţi asupra voastră o sumă de bani şi un telefon mobil.

 9) Paramedicul va acorda sfaturi privind anumite aspecte referitoare la protecţia personală în funcţie de situaţiile la care aplicantul participă. Totuşi, odată cu întocmirea aplicaţiei de participare în cadrul programului de ride-along, aplicantul îşi asumă propria protecţie. All Saints General Hospital nu îşi asumă nici o responsabilitate privind accidentarea, rănirea sau chiar moartea aplicantului survenită în urma desfăşurării programului de ride-along. Excepţie fac cazurile în care cele de mai sus au dus la neglijenţa intenţionată a medicului.

 10) Aplicantul nu trebuie să deţină obiecte ilegale, printre care se numără, dar nu se limitează doar la, armament, explozibil, droguri sau arme albe, asupra sa, indiferent dacă deţine sau nu documente care să ateste dreptul de purtare şi păstrare a respectivelor bunuri.
---

---

 **ÎNTOCMIREA CERERII**
---

---

 Conform noului regulament, cererile se depun la receptia statiei de pompieri. (( Va puteti prezenta la statia de pompieri si sa spuneti ca aveti o cerere activa la receptie, fara a completa un format anume. ))

---
