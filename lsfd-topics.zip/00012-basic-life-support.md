# BASIC LIFE SUPPORT

- **Topic ID:** 12
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=12
- **Posts:** 3

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

BASIC LIFE SUPPORT

---

---

---

**1. PROCEDURĂ GENERALĂ**
---

---

 1.1 **La sosire**
- Toate situațiile la care răspundeți sau la care sunteți trimis sunt entități dinamice - sunt în continuă schimbare și, prin urmare, trebuie să vă adaptați. Atunci când vă apropiați de locul faptei cu o ambulanță, fiți atenți la locul unde parcați - NU vă rulați lângă pacient. Dacă forțele de ordine se află la fața locului, acestea vor defini granițele/perimetrele și vă vor sfătui unde este cel mai bine să staționați.    1.1.1 **Izolarea substanțelor corporale (BSI)**  ``` [SHOW] Purtați întotdeauna mănuși medicale. În cazul în care există posibilitatea ca lichide precum sângele să ajungă la ochi, purtați ochelari de protecție. Mască chirurgicală ca măsură de precauție în cazul diferitelor boli cunoscute. ```     1.1.2 **Securitatea scenei**  ``` [SHOW] Nu intrați la locul unui accident instabil până la sosirea pompierilor. Limitarea traficului prin utilizarea conurilor sau a altor mijloace de control al traficului. Parcați corect, nu parcați în mijlocul drumului dacă scena nu este în mijlocul drumului, parcați drept și nu blocați benzile care nu au nevoie de blocare. Siguranța dumneavoastră este pe primul loc, nu intrați la locul crimei decât dacă vi se spune altfel de către PD/SD. Fiți prudenți atunci când ajungeți la locul unde se află un consumator de droguri (seringi, etc.). Controlați scena cerând o cameră, cereți PD/SD dacă cererea este ignorată. Mențineți o cale de scăpare, dacă o scenă devine periculoasă, atunci plecați. ```     1.1.3 **Mecanismul de rănire**  ``` [SHOW] Indicele de suspiciune, cât de grav este prejudiciul. Indicele ridicat de suspiciune include: căderi, accidente/coliziuni, explozii, violență, arsuri. Verificați semnele și simptomele, privind și vorbind cu pacientul. ```     1.1.4 **Numărul de pacienți**  ``` [SHOW] La sosire, estimați numărul de pacienți implicați. Dacă numărul este mai mare decât poate face față unitatea, solicitați întăriri (majoritatea vehiculelor pot transporta doi pacienți) și treceți la triaj. Dacă numărul este mai mare de patru, apelați codul zero, iar dispeceratul va trimite o MCU la fața locului. ```     1.1.5 **Triage**  ``` [SHOW]Triajul este un proces important la orice scenă care are mai mult de trei victime și ar trebui să fie folosit pentru a se asigura că personalul medical este alocat corect. Există patru culori/categorii diferite atunci când vine vorba de triaj:   CATEGORIILE DE TRIAJ ÎN ORDINE DE PRIORITATE:   ROȘU[/b] - IMEDIAT Pacientul necesită îngrijiri imediate pentru tratarea leziunilor care îi pun viața în pericol dacă oricare dintre următoarele este adevărat:   Frecvența respiratorie a pacientului este peste 30. Pacientul nu respira la început, dar a început să respire după o ridicare a capului în jos și a bărbiei. Pacientul are un puls radial (pulsul la încheietura mâinii) foarte slab sau inexistent. Acest lucru se datorează adesea unei tensiuni arteriale scăzute din cauza pierderii de sânge. Pacientul este confuz sau nu poate înțelege comenzi simple.   YELLOW[/b] - ÎNTARZIAT Pacientul nu îndeplinește niciunul dintre criteriile pentru o etichetă neagră sau roșie, dar nu poate merge.   GREEN[/b] - MINOR Când i se cere, pacientul este capabil să meargă.   NEGRU - decedat Pacientul nu are respirație, chiar și după o înclinare a capului și ridicarea bărbiei. Pacientul este mort sau pe cale să moară, iar eforturile de salvare vor fi folosite mai bine pe alți pacienți..   Este o procedură foarte simplă de realizat, iar o unitate ALS care ajunge la locul unui accident în masă trebuie să desemneze orice alt EMT aflat la fața locului să se pregătească pentru tratament în timp ce începe triajul. Paramedicii vor putea astfel să se asigure că se ocupă mai întâi de incidentele care pun în pericol cel mai mult viața.   Cum să:  1. Evaluați și diagnosticați pacientul folosind procedura DR CAB pentru a determina prioritatea pacientului. 2. Etichetați pacientul prin agățarea unui card de etichetă pe un membru adecvat (gât, braț) asigurându-vă că îl liniștițiți cu privire la ceea ce se întâmplă în prezent. Dacă a fost amenajată o zonă de triaj, asigurați-vă că îi direcționați către această zonă. 3. Treceți la următoarea victimă și repetați procesul. [SHOW] ```   1.1.6 **Additional Resources**  ``` [SHOW] Cereți întăriri de la o altă ambulanță dacă nu puteți face față numărului de pacienți de la fața locului. Anunțați PD/SD în caz de trafic/violență/alte pericole. Solicitați Hazmat pentru materiale periculoase, Engine/Ladder pentru incendii sau victime prinse. ```

1.2**Evaluarea inițială, DR ABC / DR CAB Schema**
- După ce ați finalizat evaluarea dimensiunii, sunteți gata să vă ocupați complet de pacient. Evaluarea inițială este modalitatea prin care puteți stabili necesitatea resuscitării cardio-respiratorii și, de asemenea, cum să începeți să acordați ajutor. "DR CAB" și "DR ABC" sunt ambele un mijloc de bază, practicat pe scară largă și eficient de a determina rapid cum să acordați primul ajutor, în special pentru pacienții inconștienți/nereactivi, sub forma unui mnemonic util. În Los Santos, ambele metode sunt aprobate pentru utilizare și este la latitudinea medicilor să decidă care dintre ele să o folosească. În cadrul acestui ghid, ordinea este prezentată ca DR ABC, ceea ce nu înseamnă că aceasta este metoda preferată, ambele sunt la fel de preferate.    **NOTĂ: În cazul în care există o hemoragie majoră, odată ce s-au stabilit semnele vitale, treceți la secțiunea 2 pentru tratarea hemoragiilor înainte de a continua cu restul evaluării inițiale. De exemplu, dacă**    1.2.1 **Dfurie** ``` [SHOW]Reasigurați siguranța locului - verificați dacă există pericole, cum ar fi seringi, trafic activ și expunere la trafic, scene de crimă, zone aglomerate. Asigurați-vă că anunțați PD/SD pentru asistență, solicitând acest lucru de la dispecerat sau contactându-i direct prin radioul departamentului. ```     1.2.2 **Respuns** ``` [SHOW]Verificați dacă pacientul este receptiv, încercați să-l strigați pe nume dacă îl cunoașteți, iar dacă nu, spuneți pur și simplu "Domnule, mă auziți?". Dacă nu există niciun răspuns verbal prezent, ciupiți mușchiul trapez sau efectuați un masaj al sternului. Nivelul de conștiență (LOC) se măsoară cu ajutorul scalei AVPU.    A - Alertă (pacientul este complet receptiv) V - Stimuli verbali (Pacientul răspunde la stimuli verbali) P - Stimulii durerii (Pacientul este sensibil la durere) U - Fără răspuns (Pacientul nu răspunde)    NOTĂ: Dacă pacientul este ALERT, NU trebuie să continuați cu evaluarea inițială a ABC sau CAB. Vorbiți cu pacientul pentru a determina un diagnostic corect și tratamentul necesar. Dacă considerați că este necesar să verificați semnele vitale din cauza diagnosticului, procedați în acest sens. ```   1.2.3 **Airway** ``` [SHOW]Un pacient inconștient înseamnă că nu-și controlează mușchii, inclusiv limba. Atunci când un pacient este așezat pe spate, șansa ca limba să blocheze căile respiratorii crește semnificativ. În plus, căile respiratorii ale unui pacient ar putea fi blocate de alte materiale, cum ar fi sângele, voma și mâncarea. Pentru a verifica căile respiratorii există două tehnici, înclinarea capului și împingerea maxilarului, una dintre acestea trebuind să fie întotdeauna efectuată pe un pacient inconștient. Ambele sunt explicate mai jos:   Înclinarea capului Aceasta este principala metodă de deschidere a căilor respiratorii și ar trebui utilizată în majoritatea cazurilor, cu excepția cazului în care se suspectează sau sunt prezente leziuni ale coloanei vertebrale/capului. Pentru a efectua o înclinare a capului, puneți mai întâi o mână pe fruntea pacientului și una sub bărbie. Aplicați ușor o presiune pentru a-i înclina capul pe spate pentru a permite deschiderea căilor respiratorii, astfel încât să le puteți vedea clar.   Jaw-Thrust Aceasta este o alternativă la înclinarea capului și ar trebui să fie utilizată atunci când se suspectează leziuni ale coloanei vertebrale/capului. Pentru a efectua un Jaw-Thrust, poziționați-vă în genunchi în spatele capului pacientului. Așezați-vă degetele în spatele unghiurilor maxilarului inferior al pacienților și apoi deplasați maxilarul în sus în timp ce vă folosiți degetul mare pentru a deschide ușor gura. Acest lucru va deschide maxilarul fără a extinde gâtul.   Poziția de recuperare Dacă o persoană este inconștientă, dar respiră și nu are alte afecțiuni care să-i pună viața în pericol, trebuie să fie așezată în poziția de recuperare. Punerea unei persoane în poziția de recuperare îi va menține căile respiratorii libere și deschise. De asemenea, se asigură că orice voma sau lichid nu le va provoca sufocarea. Pentru a efectua corect poziția de recuperare, trebuie să se facă următoarele;   1. Îngenuncheați pe podea lângă pacienți. 2. Așezați brațul cel mai apropiat de dumneavoastră în unghi drept față de corpul lor, cu mâna în sus, spre cap. 3. Bagă cealaltă mână sub partea laterală a capului, astfel încât spatele mâinii să le atingă obrazul. 4. Îndoiți genunchiul cel mai îndepărtat de voi în unghi drept. 5. Rostogoliți cu grijă persoana pe o parte, trăgând de genunchiul îndoit. 6. Brațul de sus ar trebui să susțină capul, iar brațul de jos vă va împiedica să le rostogoliți prea mult. 7. Deschideți-le căile respiratorii înclinându-le ușor capul pe spate și ridicându-le bărbia și verificați dacă nimic nu le blochează căile respiratorii. [altspoiler=HOW TO PERFORM RECOVERY POSITION.]https://youtu.be/Py6i884c9JE[/altspoiler]   În cazul în care căile respiratorii ale pacientului nu sunt libere sau dacă pacientul se străduiește să-și mențină singur căile respiratorii, luați în considerare posibilitatea de a contacta suportul ALS pentru a putea ajuta cu tehnici suplimentare pentru a stabili o cale respiratorie. Dacă nu este disponibil un ALS, transportați-l cât mai curând posibil. ```     1.2.4 **Breathing** ``` [SHOW]Privește, ascultă și simte respirația. Cum sunt sunetele respirației lor? Respirația lor este dificilă, superficială, profundă? Luați în considerare nevoia de oxigen. Acest lucru poate fi verificat prin coborârea obrazului la gura pacientului în timp ce ascultați, auziți și urmăriți pieptul pentru respirație. De asemenea, puteți folosi stetoscopul găsit în trusa BLS. Ritmul normal de respirație este între 12-18 respirații pe minut la un adult, dacă auziți respirație șuierătoare sau pieptul nu se mișcă simetric, luați în considerare posibilitatea ca căile respiratorii să fie blocate de ceva. ```     1.2.5 **Circulație** ``` [SHOW]Mai întâi localizați și controlați orice sângerare, palpați și evaluați pulsul (găsiți pulsul central și periferic, apoi comparați-le) și evaluați pielea pacientului pentru culoare (palidă, cianotică, roșie, normală) temperatură (rece, caldă, fierbinte, normală) și stare (uscată, umedă, diaforetică, normală). Pulsul poate fi găsit la nivelul arterei radiale (partea din spate a încheieturii mâinii), arterei brahiale (un centimetru și jumătate deasupra pliului de pe partea interioară a cotului) sau arterei carotide (partea laterală a traheei) prin plasarea degetului mijlociu și a celui arătător deasupra arterei.   Valorile normale pentru puls: Newborn 100-150  Sugari 80-120 Adulți 60-100 Athletic Adults 40-60 ```

 1.3 **Palpation**
```
[SHOW]Palparea este cea mai de bază tehnică de diagnosticare care este folosită pentru examinarea fizică pentru a evalua textura țesutului pacientului, pentru a localiza anumite repere anatomice (găsirea unei anumite coaste) și pentru a primi în general informații folosind tehnica prin observarea răspunsului pacientului, cum ar fi durerea sau iritarea.

Așezați degetele unul peste altul pe partea corpului.
Palpați ușor în zonă până când găsiți informațiile necesare (umflătură, răspuns la durere, etc'.)
```

---

---

**2. TRATAMENTUL RĂNILOR**
---

---

 2.1 **Sângerare**
```
[SHOW]Este imperativ să oprești sângerarea cât mai repede posibil. Rănile mai mari, cum ar fi rănile provocate de focuri de armă și tăieturile de cuțit, sângerează adesea foarte mult. Atunci când tratați sângerarea sau hemoragia, nu îndepărtați niciodată obiecte precum sticla, gloanțe sau alte fragmente, etc. Bandajați-le ÎNCONJURUL acestora, deoarece acestea ar putea prinde un vas de sânge și s-ar putea produce mai multe daune atunci când le îndepărtați sau încercați să le îndepărtați.

Când se controlează sângerarea, există trei etape principale prezentate mai jos ca DPT (pansament, presiune, garou).

Dressing
1. Luați pansamentul pentru traumatisme din trusa BLS.
2. Folosiți o foarfecă de traume pentru a tăia orice îmbrăcăminte din jurul rănii și a o expune.
3. Aplicați pansamentul direct pe rană.

Pressure

4. Aplicați o presiune directă pe pansamentul care acoperă rana timp de câteva momente.
5. Dacă sângerarea continuă și se infiltrează prin pansament, aplicați un nou pansament peste ultimul și continuați să aplicați presiune directă.

Tourniquet
6. Dacă sângerarea severă încă persistă, utilizați un garou, plasându-l chiar deasupra locului leziunii și strângându-l după cum este necesar.

Odată ce sângerarea a încetinit sau s-a oprit, aplicați orice alte proceduri medicale care ar putea fi necesare (alte leziuni, ajutor pentru respirație etc.). Apoi procedați la utilizarea aparatului corect pentru a transporta pacientul la cel mai apropiat spital. Dacă este în parte, asigurați-vă că un medic din cadrul unității dumneavoastră aplică în permanență presiune pe rană.

[altspoiler=TRAUMA DRESSING][/altspoiler][/altspoiler]

[altspoiler=TOURNIQUET][/altspoiler]
```

 2.2 **Curățarea rănilor**
```
[SHOW]Curățarea unei răni deschise ar trebui să aibă loc la toate rănile minore la fața locului și înainte de a pansa rana. Cu toate acestea, rănile majore ar trebui să fie curățate doar dacă riscul de infecție este ridicat din cauza urgenței necesare pentru a trata sângerarea. Pentru a curăța o rană deschisă, urmați pașii de mai jos:

1. Scoateți o sticlă mică de soluție salină din geanta BLS, golind conținutul acesteia pe un tampon de bumbac.
2. Ștergeți încet și cu grijă rana, dacă pacientul este conștient avertizați-l că s-ar putea să îl usture sau să îi provoace un mare disconfort.
3. După ce ai curățat rana, treci la pansarea corectă a acesteia.
```

---

---

**3. FRACTURILE OSULUI**
---

---

 Fractura osoasă apare atunci când există o ruptură în secvența osului. De obicei, o fractură este însoțită de dureri medii sau severe în zona fracturii. O fractură osoasă este cauzată, de obicei, de un impact sau de un stres ridicat asupra osului.

 **Există două tipuri de fracturi osoase:**
 **Fractură închisă/simplă**[/color] - Pielea este intactă, iar osul se află sub piele.
 **Fractura deschisă/compusă**[/color] - Osul este rupt prin piele și expus unei posibile infecții.

 3.1 **Fracturi compuse**
```
[SHOW]Dacă pacientul are o fractură compusă, trebuie să controlați imediat sângerarea ca prioritate maximă înainte de a vă îndrepta atenția către osul în sine. Pentru a controla sângerarea unei fracturi compuse, puneți două role de tifon pe fiecare parte a osului proeminent. După aceea, înfășurați tifon sau bandaj peste cele două role de tifon, aplicând presiune pe ambele părți ale osului, în loc să o faceți direct pe os. Asigurați-vă că transportați pacienții cu fracturi compuse cât mai repede posibil, deoarece șansele de infecție sunt foarte mari.

[altspoiler=COMPOUND FRACTURE][/altspoiler]
```

 3.2 **Scheletul de vid**
```
[SHOW]S-a demonstrat că atelia cu vacuum este o metodă simplă, sigură și eficientă de ateliere de urgență pentru membrele fracturate. Există 3 atele unice separate (atelă pentru gleznă/picior, atelă pentru membrele inferioare și atelă pentru braț) disponibile într-o trusă de transport în cadrul ambulanței. Este important să tratați orice sângerare la nivelul extremității înainte de a aplica atelă, precum și să o readuceți în poziția inițială, dacă este posibil. Nu aplicați niciodată atelă cu brațul complet drept, asigurați-vă că există o îndoire a brațului.
[altspoiler=VACUUM SPLINT][/altspoiler][/altspoiler]

Folosit pentru: Fracturi de gleznă, picior, braț și picior.

Cum să:

1. Colectați atelia din suportul care se află în interiorul ambulanței dumneavoastră.
2. Deschideți supapa trăgând de tub.
3. Distribuiți manual mărgelele pe toată atelia.
4. Glisați atelia sub zona fracturată și fixați curelele astfel încât o curea să fie deasupra locului fracturii, iar cealaltă să fie sub ea.
5.5. Pur și simplu manipulați mărgelele și ajustați aerul în atelă cu o pompă dacă nu este montată corect.
```

 3.3 **Atela de tracțiune**
```
[SHOW]Dacă bănuiți că o persoană și-a fracturat femurul (osul de deasupra genunchiului), trebuie folosită imediat o atelă de tracțiune pentru a imobiliza piciorul și a preveni alte leziuni. În cazul unei fracturi la partea inferioară a piciorului (tibie/fibulă), atunci ar trebui folosită în schimb o atelă de vacuum.
[altspoiler=TRACTION SPLINT][/altspoiler]
```

 3.4 **Triangular Bandage**
```
[SHOW]Un bandaj triunghiular este folosit pentru a susține brațul în diagonală și pentru a preveni alte răni. Motivul pentru care brațul este ridicat în diagonală este acela de a controla sângerarea, în cazul în care există și de a preveni o eventuală umflătură. Bandajele triunghiulare pot fi găsite în trusa BLS.
[altspoiler=TRIANGULAR BANDAGE][/altspoiler][/altspoiler]

Folosit pentru: Suspiciune de fractură de braț

Cum să:

1. Luați brațul pacientului, mișcându-l într-o poziție diagonală.
2. Mutați bandajul triunghiular sub brațul lor și în jurul cefei.
3.3. Leagă ambele capete ale bandajului triunghiular împreună în spatele gâtului lor.
```

 3.5 **Atela cervicală: X-Collar**
```
[SHOW]Dacă se suspectează că pacientul are leziuni cervicale (la nivelul gâtului) sau ale coloanei vertebrale (implicarea într-un accident de mașină este cea mai frecventă cauză), nu trebuie să îl mișcați decât dacă este vital. Înainte de a continua cu tratamentul ulterior al oricăror leziuni, trebuie să vă asigurați că în jurul gâtului pacientului este plasat un guler X-Collar.
[altspoiler=X-COLLAR][/altspoiler]

Folosit pentru: Suspiciuni de leziuni ale gâtului și ale coloanei vertebrale.

Cum să:

1. Întindeți gulerul pe lungime.
2. Desfășurați suportul pentru spate și blocați-l în poziție.
3. Așezați X-COLLAR-ul în spatele pacientului, înconjurându-l, și conectați catarama.
4. X-COLLAR trebuie plasat cât mai aproape posibil de piele. În cazul în care pacientul este întins și hainele nu sunt scoase, salvatorul trebuie să ciupească și să strângă hainele aproape de dispozitiv, astfel încât X-COLLAR să alunece în zona spatelui între omoplați.
5.5. Așezați căptușeala de susținere a bărbiei direct sub bărbia pacientului și asigurați-vă că cureaua pentru bărbie este plasată în fața bărbiei, sub buza inferioară. Mențineți această poziție pentru a vă asigura că gulerul este plasat drept pe bărbie.
6. Reglați ambele curele laterale.
7. Atașați STRAP-uri.
```

---

---

**4. BURNS**
---

---

 4.1 **Grade de ardere**
```
[SHOW]Arsurile sunt leziuni cauzate la nivelul pielii de orice tip de căldură, electricitate, radiații, frecare, lumină sau substanțe chimice. Există numeroase tipuri de grade care descriu gravitatea arsurii. Unele arsuri necesită tratament spitalicesc, în timp ce altele nu. Acest lucru se face de la caz la caz, în funcție de gravitatea arsurii și de mărimea acesteia.

Arsură de gradul I: Epidermă afectată, aspect de roșeață și textură uscată a pielii, durere ușoară.
Arsură de gradul II: Derma afectată, aspect roșu și alb, textură umedă, durere severă.
Arsură de gradul trei: Se extinde până la hipodermă, textură rigidă și albă, uscată și coroiată, fără durere.
Arsură de gradul patru: Țesut subcontanat afectat, aspect negru, textură uscată, fără durere.

[altspoiler=BURN DEGREES][/altspoiler]
```

 4.2 **Tratamentul arsurilor**
```
[SHOW]Tratamentul pentru orice arsură depinde de tipul de arsură, precum și de gradul de acoperire. Dacă o arsură acoperă mai mult de 20%, este necesar un tratament intravenos, iar transportul sau suportul ILS ar trebui să fie primul obiectiv al medicilor.

Înainte de începerea oricărui tratament trebuie să se efectueze/considerate următoarele etape:

1. Îndepărtați sursa de căldură de la pacient (stingeți focul sau îndepărtați contactul cu lichide fierbinți, aburi sau alte materiale).
2. Scoateți bijuteriile, curelele sau orice îmbrăcăminte strâmtă, deoarece arsurile se pot umfla rapid.
3.3. Fiți atenți dacă pacientul intră în șoc, dacă acest lucru se întâmplă, tratați rapid arsura și oferiți-i oxigen.

Procedura pentru arsuri de gradul I și II

1. Dacă este posibil și pentru arsuri mici, treceți zona arsă sub apă rece timp de 10-15 minute.
2. Acoperiți-l lejer cu un bandaj uscat, neaderent, fixându-l cu bandă adezivă medicală.
3. Dacă arsura este mai mare decât dimensiunea mâinii pacientului sau de gradul 2, va fi nevoie de transport.
4. Furnizați Ibuprofen pacientului pentru a ajuta la ameliorarea durerii.

Procedura pentru arsuri de gradul III și IV

1. Acoperiți-l lejer cu un bandaj steril, neaderent, fixându-l la locul lui cu bandă adezivă medicală.
2.2. Degetele de la picioare și de la mâini arse cu pansamente uscate și sterile. (Acest lucru este necesar pentru picioare și mâini).
3.3. Preveniți șocul prin așezarea pacientului pe plan întins, păstrând pacientul cald (pătură) și, dacă este posibil, ridicând arsura deasupra nivelului inimii.
```

---

---

**5. SUPORT CARDIAC**
---

---

 Va veni un moment în care cineva va suferi un stop cardiac, care poate fi diagnosticat dacă pacientul îndeplinește următoarele criterii:
- Inconștient
- Fără respirație
- Fără puls

 Stopul cardiac este diferit de un atac de cord prin faptul că, în cazul unui atac de cord, sângele continuă să circule către inimă, dar într-o stare întreruptă. Cu toate acestea, un atac de cord poate duce la stop cardiac dacă nu este tratat la timp. Pentru a trata stopul cardiac, se va folosi resuscitarea cardio-respiratorie (CPR) în combinație cu DEA.

 5.1 **Resuscitare cardiopulmonară (CPR)**
```
[SHOW]CPR este folosită pentru a simula acțiunea inimii și pentru a menține unele funcții cerebrale. Scopul inimii este de a menține fluxul de oxigen către varietatea de organe din corpul nostru, în cazul în care aceasta încetează să mai funcționeze, trebuie să continuăm fluxul de oxigen către părțile corpului nostru, prin simularea acțiunii inimii. Acest lucru trebuie făcut doar pe un pacient fără puls.

1. Asigurați siguranța locului și verificați răspunsul (verbal+durere). Cereți cuiva să aducă DEA.
2. Verificați pulsul în artera carotidă care se află în gât.
3. Dacă nu există puls, efectuați compresii rapide și profunde în stern, la un ritm de cel puțin 100 de compresii pe minut, 30 de compresii.
4. Verificați dacă există ceva care ar putea bloca căile respiratorii, dacă există, rostogoliți pacientul înainte la 90 de grade și îndepărtați tot ceea ce blochează căile respiratorii (voma, de exemplu). Deschideți căile respiratorii folosind manevra de înclinare a capului și ridicare a bărbiei.
5. Ventilați de două ori cu ajutorul unui BVM.
6. Continuați compresiile la un ritm de 30:2 (30 de compresii, 2 ventilații) - asigurați-vă că verificați pulsul din când în când (ex.: după fiecare 2 seturi).
7. Dacă pacientul vomită în timpul resuscitării, curățați voma, verificați pulsul și numai apoi reluați compresiile dacă nu există puls.
8. Dacă există puls, dar nu respiră, ventilați o dată la 5 secunde.

* Poți să faci doar mâini (fără BVM) dacă nu ai un partener.[/b]
* "Omul respiră, inima bate". - Dacă cineva respiră, inima lui bate.[/b]
* Aducerea unui DEA nu vine în locul compresiilor, conectarea acestuia, DOAR.[/b]

NOTĂ: Fără puls = Efectuați resuscitarea cardio-respiratorie | Puls = NU efectuați resuscitarea cardio-respiratorie.

[altspoiler=Demonstrație CPR][/altspoiler]
```

 5.2 **Defibrilator extern automat (DEA)**
```
[SHOW]DEA este un aparat avansat folosit ca principal procedeu medical în tratarea stopului cardiac brusc. Aparatul DEA poate fi utilizat în felul următor:

1. Colectați DEA din partea din spate a ambulanței și puneți-l lângă pacient.
2. Porniți DEA.
3. Așezați tampoanele pe pieptul pacientului.
4. Apăsați ANALYZE.
5. Electrocardiograma (ECG) de pe DEA va produce o ieșire digitală a ritmului cardiac al pacientului.
6. DEA vă va spune dacă se recomandă șocul. În caz afirmativ, strigați '"CLEAR" și apăsați SHOCK.
7. Verificați ritmul cardiac al pacientului cu ajutorul DEA.
8. Dacă DEA nu restabilește un ritm cardiac normal, atunci efectuați resuscitarea cardio-respiratorie timp de 2 minute, repetând pașii de la 3 la 8.
9. Dacă se restabilește un ritm cardiac normal, susțineți căile respiratorii ale pacientului și supliniți respirația și transportați-l cât mai repede!

[altspoiler=CARDIAC SUPPORT][/altspoiler]
```

---

---

**6. ADMINISTRAREA OXIGENULUI**
---

---

 Administrarea de oxigen este necesară atunci când frecvența respiratorie a unui pacient a scăzut sau a crescut din cauza unui traumatism sau din motive medicale. Oxigenul trebuie administrat la:
- Un adult care respiră mai puțin de 12 sau mai mult de 20 de respirații pe minut.
- Un copil care respiră mai puțin de 15 sau mai mult de 30 de respirații pe minut.
- Un sugar care respiră mai puțin de 25 sau mai mult de 50 de respirații pe minut.

 Masca de oxigen are aproximativ 2,5 m de tuburi de alimentare, deci trebuie să fie ținută în apropierea sursei de alimentare, fie că este în interiorul ambulanței, pe targă sau că o transportați dumneavoastră, și poate fi furnizată prin intermediul mai multor dispozitive:

 6.1 **Canulă nazală (N.C)**
```
[SHOW]Canula nazală este un tub de plastic îngust cu două duze mici, care se introduce în nările pacientului. Aceasta poate furniza în mod confortabil un debit maxim de 1-6 L/min. Aceasta ar trebui să fie utilizată atunci când un pacient are dificultăți minore de respirație sau nu poate tolera o mască.

Modul corect de utilizare a canulei nazale este următorul:

1. Alegeți canula nazală de dimensiunea potrivită.
2. Setați debitul corect de oxigen.
3. Asigurați-vă că oxigenul circulă corect.
4.4. Introduceți capătul cu două vârfuri în nări și plasați tubul în spatele urechilor lor.
[altspoiler=NASAL CANNULA][/altspoiler]
```

 6.2 **Non-Rebreather Mask**
```
[SHOW]Masca de oxigen fără respirator are orificii laterale care sunt supape unidirecționale, ceea ce înseamnă că aerul din cameră nu poate intra în mască, dar aerul expirat poate părăsi masca.  Aceasta poate asigura un debit de 10-15 L./min și trebuie utilizată dacă pacientul este inconștient sau major deoxigenat.

Modul corect de utilizare a măștii fără respirator este următorul:
1. Scoateți masca de oxigen și conectați-o la tubulatura de alimentare cu oxigen.
2. Umpleți sacul rezervorului cu oxigen.
3. Așezați masca peste gura și nasul pacientului, fixând-o cu ajutorul elasticului.
4.4. Porniți butelia cu ajutorul supapei, permițând să treacă cantitatea corectă de oxigen.

[altspoiler=NON-REBREATHER MASK][/altspoiler][/altspoiler]
```

 6.3 **Masca cu valvă cu sac**
```
[SHOW]O mască cu valvă cu sac sau adesea denumită BVM este un dispozitiv portabil utilizat pentru a stoarce oxigenul în plămânii pacientului. Se utilizează atunci când pacientul nu respiră sau respiră atât de insuficient încât nu mai poate fi menținută viața.

Modul corect de utilizare a unui BVM este următorul:
1. Scoateți BVM-ul din geantă.
2. Deschideți căile respiratorii ale pacientului (înclinarea capului).
3. Așezați masca peste gura și nasul pacientului, ținând-o pe loc
4. Strângeți sacul la un ritm de 10-12 respirații pe minut. (Pentru resuscitare cardio-respiratorie 2 respirații după 30 de compresii).

[altspoiler=BAG VALVE MASK][/altspoiler]
```

---

---

**7. APARATURI**
---

---

 7.1 **Stretcher/Gurney**
```
[SHOW]Un Gurney este o targă pliabilă care este folosită pentru a încărca și descărca cu ușurință pacienții în și din ambulanță. În comparație cu alte targă simple, această targă include o siguranță sporită a pacientului, a operatorului și o calitate superioară. Modelul pe care îl folosim noi este un sistem hidraulic alimentat de o baterie care ridică și coboară pacientul cu ușurință. Sistemul inovator de pătuț reduce dramatic riscurile, cum ar fi rănirea spatelui, atât a operatorului, cât și a pacientului.

Descărcarea targului:

1. Apăsați în jos maneta roșie de eliberare situată la capătul piciorului sistemului.
2. Mențineți o prindere sigură a targăi în permanență după ce ați apăsat maneta.
3. Căruciorul se va mișca, ceea ce vă va indica faptul că sistemul de încărcare cu energie susține drumul căruciorului și al pacientului.
4. Începeți să trageți targa până când lumina de pe încărcătorul de energie se transformă în verde solid.
5. Folosiți butoanele de control pentru a controla picioarele (+ înseamnă să le extindeți, - înseamnă să le ridicați).
6. Odată ce picioarele sunt pe sol, apăsați butonul roșu de eliberare pentru a dezactiva targa de la sistemul de încărcare electrică.
7. Ridicați brațele de încărcare ale încărcătorului și împingeți-l înapoi în ambulanță.

Încărcarea targăi:

1. Duceți targa înapoi la ambulanță.
2. Ridicați mânerele încărcăturii electrice și trageți căruciorul afară, apoi lăsați mânerele.
3. Țintiți căruciorul spre mânerele de ridicare a căruciorului sistemului de încărcare electrică și împingeți înainte până când acesta este în poziție.
4. Controlați roțile cu ajutorul panoului de la capătul piciorului targăi, în acest caz va trebui să le ridicați (apăsați - butonul).
5.5. Împingeți targa în ambulanță până când aceasta este fixată în sistemul de încărcare electrică și asigurați-vă că a fost fixată..
[altspoiler=HOW TO LOAD THE GURNEY][/altspoiler]
```

 7.2 **Tablă de fund**
```
[SHOW]O scândură (sau o scândură pentru coloană vertebrală) ar trebui să fie folosită în fiecare caz în care cineva este imobilizat (de exemplu, inconștient, incapabil, incapabil fizic să se miște) și apoi ridicat de cel puțin două persoane pe o targă. Targa în sine este o targă cu o "saltea" din piele de grosime medie (acoperită cu cearșafuri albastre) deasupra, de unde și termenul de pat-targă. Pentru a așeza victima deasupra scândurii, asigurați-vă că aceasta este mai întâi întinsă, cu brațele în lateral și picioarele drepte (cu excepția cazului în care rănile nu permit altfel).

După aceasta, trebuie efectuată o tehnică numită 'log roll'[/b], în care persoana accidentată este rostogolită ușor pe o parte și ridicată în diagonală, iar placa de susținere este glisată sub ea. Curelele de pe fiecare parte sunt catarate pentru a le fixa , iar apoi două persoane ridică victima pe patul de targă.
[altspoiler=BACKBOARD][/altspoiler]
```

---

---

**8. MEDICAMENTE PERMISE**
---

---

 Există câteva medicamente diferite în trusa BLS și fiecare dintre ele se administrează pe cale orală. Adică sunt sub formă de lichid, pastilă, tabletă sau capsulă și trebuie să puneți la dispoziția pacientului o sticlă cu apă pentru ca acesta să poată înghiți corect medicamentul.

 8.1  **Calmarea durerii**
```
[SHOW]
Aspirină
Utilizare: Tratamentul precoce în cazul atacurilor de cord, ajută la reducerea dimensiunii cheagurilor. Folosit ca analgezic pentru a ameliora durerile minore sau pentru a reduce febra.
Doza: Maxim 400mg la fiecare patru ore.
Forma: Orală

Ibuprofen
Utilizare: Pentru a ameliora durerea ușoară până la severă.
Doza: 800mg (vine în pastile de 200mg sau 400mg)
Forma: Oral
```

 8.2 **Intoxicații și supradoze**
```
[SHOW]
Cărbune activat
Utilizare: Folosit în caz de otrăvire/ supradoză datorită capacității sale de a absorbi otrava. (Lichid negru). Poate fi folosit și pentru consumul foarte intoxicat, dar este mai mult ca sigur capabil să îi facă să vomite. (Puneți o găleată lângă ei).
Doza: 8 oz sub formă lichidă sau 250mg sub formă de tablete.
Forma: Orală (lichid sau tabletă)

Naloxone/Narcan
Utilizare: Inversează efectele supradozajului de narcotice, cum ar fi supradoza de heroină sau morfină. Folosit pentru a contracara depresia care pune în pericol viața sistemului nervos central și a sistemului respirator.
Dozaj: 0,4-2mg IV/IM/intranazal la fiecare 2-3 minute
Forma: IV, IM, Intranazal
```

---

## #2 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

BASIC LIFE SUPPORT

---

---

---

**1. ECHIPAMENTE EXTERIOARE**
---

---

 Pompierii-EMT vor răspunde la o multitudine de apeluri și vor trebui să fie pregătiți pentru mai multe tipuri de leziuni și situații. Personalul care operează ambulanțele noastre de salvare se poate trezi deseori răspunzând la scene de incendiu alături de mașini, așa că va trebui să aibă echipament special și pentru asta.

 1.1 **Compartimentul din stânga față, în spatele portierei șoferului**
- În acest compartiment veți găsi suficient echipament de protecție pentru doi pompieri. Acesta este depozitat în fiecare ambulanță în cazul în care trebuie să ajute la locul unui incendiu ``` [SHOW] ```

 1.2 **Compartimentul din stânga spate, în spatele anvelopei din spate**
- În acest compartiment veți găsi plăci pentru spate, atele de tracțiune și coliere C suplimentare. ``` [SHOW] ```

---

---

**2. ECHIPAMENTE INTERIOARE**
---

---

 2.1 **Echipament de acces rapid**
- În partea din spate a fiecărei ambulanțe, veți găsi echipament de acces rapid. Ceea ce înseamnă că acestea sunt disponibile imediat și nu sunt depozitate într-un compartiment încuiat. Acest lucru vă asigură că scenele se desfășoară fără probleme și eficient.  ``` [SHOW]- Gurney - DAE - Atele de vid - Pături - Sticle de apă ```

 2.2 **Echipament de izolare a substanței corporale**
- Partea din spate a fiecărei ambulanțe are mai multe compartimente mai mici, toate acestea conținând echipamente și provizii suplimentare. Iată ce veți găsi în compartimentul BSI:  ``` [SHOW]- Ochelari de protecție din plastic suplimentar - Măști chirurgicale suplimentare - Mănuși de nitril fără latex suplimentare ```

 2.3 **Echipament de gestionare a rănilor**
- ``` [SHOW] - Foarfecă de traumă suplimentară - Pansamente suplimentare pentru traume - Rulouri suplimentare de tifon - Soluție salină suplimentară  - Tampoane de bumbac suplimentare - Bandaje extra sterile, neaderente - Bandă medicală suplimentară - Turnichete suplimentare - Pachete de gheață suplimentare - Bandaje triunghiulare suplimentare/banderole pentru brațe ```

 2.4 **Oxygen Equipment**
- ``` [SHOW]- Canistre de oxigen suplimentare. - Măști suplimentare care nu se refulează - Canule nazale suplimentare - Măști suplimentare pentru sacul cu valțuri ```

 2.5 **Medicamente**
- În plus față de rezerva mică pe care o aveți în gențile BLS, fiecare ambulanță are o rezervă de medicamente suplimentare, care este blocată.  ``` [SHOW]- Aspirină - Ibuprofen - Cărbune activat - Naloxone/Narcan ```

---

## #3 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

BASIC LIFE SUPPORT

---

---

---

**1. BLS JUMPBAG EQUIPMENT**
---

---

 Pompierii-EMT vor răspunde la o multitudine de apeluri și vor trebui să fie pregătiți pentru mai multe tipuri de leziuni și situații. Geanta de salt, denumită și "trusă", trebuie să fie cu dumneavoastră în permanență. În interiorul fiecărei genți se află instrumente și medicamente care nu trebuie să cadă în mâini greșite, așa că trebuie să fiți foarte atenți la locul în care se află geanta dumneavoastră. Țineți-o agățată în jurul umărului (umerilor) atunci când nu o folosiți și nu o lăsați niciodată nesupravegheată, cu excepția cazului în care este încuiată în interiorul ambulanței.

 1.1 **Echipament de izolare a substanței corporale**
- ``` [SHOW]- Ochelari de plastic - Măști chirurgicale - Mănuși de nitril non-Latex ```

 1.2 **Vital-Checking Equipment**
- ``` [SHOW] - Tensiometru - Stetoscop ```

 1.3 **Echipament de gestionare a rănilor**
- ``` [SHOW]- Foarfecele de traumă - Pansamente pentru traume - Rulouri de tifon - Soluție salină - Tampoane de bumbac - Bandaje sterile, neaderente - Bandă medicală - Turechetele - Pachete de gheață - Bandaje triunghiulare/banderole de braț ```

 1.4 **Oxygen Equipment**
- ``` [SHOW] - Canistră de oxigen - Mască non-rebreather - Canulă nazală - Masca cu sac și valvă ```

 1.5 **Medicamente**
- Fiecare geantă de salt are o mică rezervă de medicamente, motiv pentru care siguranța în geantă este foarte importantă.  ``` [SHOW]- Aspirină - Ibuprofen - Cărbune activat ```

---
