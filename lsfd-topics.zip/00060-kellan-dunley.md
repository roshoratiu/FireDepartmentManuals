# Kellan Dunley

- **Topic ID:** 60
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=60
- **Posts:** 1

---

## #1 — Kellan Dunley

![](https://i.imgur.com/2jlMxHe.png)

 Administrative & Support

---

 **PERSONNEL RECORD**
 Los Santos Fire Department · Administrative & Support Bureau

**I — DATE PERSONALE**

- **NUME COMPLET:** Kellan Dunley  **NUMĂR INSIGNĂ:** #0002  **DATA ANGAJĂRII:** 18/05/2026  **STATUS:** Activ

**II — RANG & POZIȚIE**

- **RANG CURENT:** Deputy Chief   **TIP CONTRACT:** Permanent  **PROMOVAT DE:** Fire Chief · 16/05/2026

**III — DIVIZII & BIROURI**

- **DIVIZIE PRIMARĂ:** Primary Operations Bureau  **SPECIALIZARE:** Suppression / EMS / HazMat / Technical Rescue   **STAȚIE:** Station 72    **— BIROURI SECUNDARE —**  · Administrative & Support Bureau  · Training & Professional Development · Director · Din: 16/05/2026  · Union & Labour Relations · Director · Din: 12/MAR/2021

**IV — CALIFICĂRI & CERTIFICĂRI**

- **— CORE OPERATIONS (obligatoriu — toți membrii) —**    ✓ Basic Life Support (BLS)    ✓ Fire Suppression (Fire 1)    ✓ Interior Operations    ✓ Vehicle Extrication    ✓ Rope Rescue    ✓ Fire 2     ✓ Fire 3     ✓ Apparatus Driver     ✓ Pump Operations      **— EMERGENCY MEDICAL —**    ✓ Emergency Medical Technician (EMT)    x Field Medic    ✓ Advanced Life Support (ALS) — Critical Care Provider / Paramedic     **— PRIMARY OPERATIONS — SPECIALIZĂRI —**    ✓ Fire Attack Specialist    ✓ Engine Operator    ✓ Ventilation Specialist    ✓ Heavy Rescue Technician    ✓ Rope Rescue Operator    ✓ Crash Response Specialist    ✓ Apparatus Engineer    ✓ Incident Safety Officer    ✓ Operations Coordinator     **— DIV. 2: HAZMAT, SPECIAL OPERATIONS & DISASTER RESPONSE —**    ✓ Hazmat Operations · Tier I    ✓ Decontamination Specialist · Tier I    ✓ Hazmat Technician · Tier II    ✓ Hazmat Entry Technician · Tier II    ✓ Hazmat Equipment Officer    ✓ CBRN Response Officer · Tier III    ✓ HSOD Coordinator · Tier IV — Division Lead     **— DIV. 3: WILDLAND & ENVIRONMENTAL OPERATIONS —**    ✗ Wildland Firefighter — Type 2 · Tier I    ✗ Wildland Firefighter — Type 1 · Tier II    ✗ Wildland Engine Operator · Tier III    ✗ Wildland Helitack · Tier III    ✗ Environmental Response Specialist    ✗ Wildland Incident Commander · Tier IV    ✗ Wildland Operations Coordinator · Tier IV — Division Lead     **— DIV. 4: WATER RESCUE OPERATIONS —**    ✗ Water Rescue Awareness · Tier I    ✗ Swift Water Rescue Technician · Tier II    ✗ Marine Operations Specialist · Tier II    ✗ Ice Rescue Technician · Tier II    ✗ Flood Response Operator · Tier II    ✗ Dive Rescue Technician · Tier III    ✗ Water Rescue Coordinator · Tier IV — Division Lead     **— DIV. 5: FIRE INVESTIGATION & PREVENTION —**    ✓ Fire Safety Officer · Tier I    ✓ Public Education Officer    ✓ Fire Inspector · Tier II    ✓ Fire Investigator · Tier III    ✓ Arson Investigator · Tier III    ✓ Fire Marshal    ✓ Fire Prevention Chief · Tier IV — Division Lead     **— DIV. 6: TRAINING & PROFESSIONAL DEVELOPMENT —**    ✓ Field Training Officer (FTO) · Tier I    ✓ Fire Instructor · Tier II    ✓ Academy Instructor · Tier II    ✓ Certification Officer · Tier II    ✓ Scenario Designer    ✓ FTO Coordinator · Tier III    ✓ Senior Academy Instructor · Tier III    ✓ Curriculum Developer · Tier III    ✓ Academy Director · Tier III    ✓ Training Division Chief · Tier IV — Division Lead     **— DIV. 7: FLEET, LOGISTICS & COMMUNICATIONS —**    ✓ Fleet Technician / Dispatcher · Tier I    ✓ Senior Fleet Technician · Tier II    ✓ Supply Officer · Tier II    ✓ Facilities Coordinator · Tier II    ✓ Lead Dispatcher · Tier III    ✓ Fleet Manager · Tier III    ✓ Communications Manager · Tier III    ✓ Support Services Chief · Tier IV — Division Lead     **— DIV. 8: ADMINISTRATION & HUMAN RESOURCES —**    ✓ HR Assistant / Records Assistant · Tier I    ✓ Human Resources Officer · Tier II    ✓ Recruitment Coordinator · Tier II    ✓ Employee Relations Officer · Tier II    ✓ Records Management Officer · Tier II    ✓ Internal Affairs Officer · Tier III    ✓ Public Information Officer (PIO) · Tier III    ✓ Administrative Services Chief · Tier IV — Division Lead

**V — ISTORIC PROMOVĂRI**

- **15/MAR/2018** · Recruit · Angajare inițială — Recruit Academy Cohort #7  **22/APR/2018** · Probationary Firefighter · Promovat de Battalion Chief James Harlow  **08/NOV/2019** · Firefighter · Promovat de Captain Diana Mercer  **14/MAY/2021** · Engineer · Promovat de Captain Diana Mercer  **07/FEB/2022** · Lieutenant · Promovat de Deputy Chief Marcus Vane · Vacancy Promotion  **03/OCT/2022** · Captain · Promovat de Deputy Chief Marcus Vane · Promotional Exam — Scor 89/100  **21/JUN/2023** · Battalion Chief · Promovat de Fire Chief Elias Drummond  **09/FEB/2025** · Deputy Chief · Promovat de Fire Chief Elias Drummond · Bureau Commander — Operations

**VI — DISTINCȚII & MENȚIUNI**

- **30/JUL/2018** · Life Saving Award · Acordat de Captain Diana Mercer · Resuscitare reușită la accident rutier pe Great Ocean Highway — pacient stabilizat pe teren și transportat cu succes  **17/APR/2020** · Commendation Letter · Acordat de Battalion Chief James Harlow · Gestionare exemplară a unui incendiu structural în Mission Row — evacuare completă fără victime civile  **11/DEC/2021** · Perfect Attendance Citation · Acordat de Captain Diana Mercer · Zero absențe nemotivate pe parcursul anului fiscal 2020–2021  **25/AUG/2022** · Medal of Bravery · Acordat de Deputy Chief Marcus Vane · Intrare în structură parțial prăbușită pentru extragerea unui civil blocat — Rockford Hills House Fire  **14/MAR/2023** · Employee of the Month · Acordat de Deputy Chief Marcus Vane · Coordonare exemplară a Field Training Program și reducerea semnificativă a timpilor de răspuns la Station 3  **08/NOV/2023** · Medal of Valor · Acordat de Fire Chief Elias Drummond · Comandă tactică la incendiul industrial din La Mesa — prevenirea exploziei rezervoarelor de propan și evacuarea a 28 de civili  **09/FEB/2025** · Distinguished Service Medal · Acordat de Fire Chief Elias Drummond · Recunoașterea conducerii exemplare și a contribuțiilor la restructurarea operațională a LSFD — acordat la ceremonia de numire ca Deputy Chief

**VII — SANCȚIUNI & SUSPENDĂRI**

- **03/JUN/2019** · Avertisment Verbal · Emis de: Captain Diana Mercer Arhivat

**VIII — EVALUĂRI & RECOMANDĂRI**

- **09/FEB/2025** · Fire Chief Elias Drummond:  Dunley este numit Deputy Chief ca rezultat direct al unui parcurs profesional fără compromisuri. A demonstrat în mod repetat că poate conduce oameni în condiții de presiune extremă, menținând disciplina operațională și claritatea decizională. Capacitatea sa de a echilibra exigențele tactice cu managementul instituțional îl plasează printre cei mai complecși ofițeri pe care i-am evaluat pentru o poziție de Bureau Commander. Numirea ca Deputy Chief — Operations reprezintă o consecință logică, nu o recompensă.    **21/JUN/2023** · Fire Chief Elias Drummond:  Dunley a gestionat incidentul din La Mesa cu o maturitate tactică rară pentru un Captain. Promovarea la Battalion Chief vine după o perioadă în care a restructurat vizibil eficiența Station 3 și a mentorat mai mulți ofițeri care au promovat ulterior. Recomand fără rezerve pentru orice poziție de comandă; este genul de ofițer pe care îl vrei în față, nu în spate.    **03/OCT/2022** · Deputy Chief Marcus Vane:  Promovat la Captain în urma celui de-al treilea cel mai mare scor la Promotional Exam din ultimii patru ani. Dunley nu este remarcabil doar prin cunoștințe tehnice, ci prin instinctul cu care citește o scenă și prin autoritatea naturală cu care coordonează echipa sub stres. Îl recomand cu fermitate pentru orice rol de field command și anticipez că va depăși rapid acest grad.

---
