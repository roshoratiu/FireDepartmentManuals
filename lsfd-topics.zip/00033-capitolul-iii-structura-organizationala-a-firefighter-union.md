# CAPITOLUL III – STRUCTURA ORGANIZAȚIONALĂ A FIREFIGHTER UNION

- **Topic ID:** 33
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=33
- **Posts:** 1

---

## #1 — Kellan Dunley

![](https://i.imgur.com/2jlMxHe.png)

FIREFIGHTER UNION MANUAL

---

 CAPITOLUL 3 – STRUCTURA IERARHICĂ ȘI ORGANIZATORICĂ A FIREFIGHTER UNION
---

---

- **(3.0)** Introducere Generală

---

---

- Organizarea ierarhică a Firefighter Union reprezintă fundamentul funcționării eficiente și transparente a unei instituții care are în centru protejarea drepturilor și intereselor personalului operativ. Într-un domeniu caracterizat prin stres profesional ridicat, riscuri semnificative și expunere constantă la factori psihologici și fizici agresivi, o structură sindicală clară și profesionist administrată devine esențială pentru echilibrul organizațional al întregului departament.    Această structură este construită deliberat pentru a acoperi toate dimensiunile vieții profesionale ale unui pompier: condiții de muncă, sănătate, siguranță, beneficii, negociere contractuală, suport emoțional, protecție împotriva abuzurilor și reprezentare juridică sau administrativă. Fiecare rol are atribuții distincte, dar complementare, contribuind la un sistem unitar care funcționează ca liant între Fire Department Leadership și corpul de pompieri.    Ierarhia este împărțită pe nivele (TIER-uri), reflectând gradul de responsabilitate și nivelul de expertiză necesar. Fiecărui nivel îi corespund funcții precise, centrate pe management, negociere, investigare, protecția drepturilor, consiliere sau suport operațional.

 -
---

---

- **(3.1)** TIER 4 – Leadership Level

---

---

- **Union & Labor Relations Chief (Division Lead)**    Acesta este cel mai înalt rang din cadrul Firefighter Union și figura centrală în toate procesele decizionale, administrative și de reprezentare. Chief-ul servește drept principal punct de contact între Union și Fire Department Command Staff, reprezentând interesele membrilor în discuțiile cruciale: salarizare, politici interne, condiții de lucru, sancțiuni, conflicte organizaționale și modificări strategice.    Union & Labor Relations Chief nu este doar un administrator, ci un lider executiv capabil să gestioneze situații delicate, conflicte interne, sesizări complexe și negocieri critice. El aprobă sau respinge inițiativele departamentelor sindicale, stabilește direcția generală a organizației și asigură conformitatea cu legislația muncii și standardele etice ale profesiei.

 -
---

---

- **(3.2)** TIER 3 – Senior Administrative Level

---

---

- **Benefits Coordinator**    Rol esențial pentru bunăstarea pompierilor, Benefits Coordinator administrează programele de beneficii ce includ sănătate, siguranță psihologică, compensații, facilități pentru familii și alte elemente de sprijin instituțional.    Acesta asigură legătura dintre politicile departamentului și nevoile reale ale membrilor, analizând constant oportunități pentru îmbunătățirea pachetelor de beneficii. Documentează solicitările, gestionează accesul la programe și propune ajustări atunci când condițiile operaționale sau bugetare o permit.

 -
---

---

- **(3.3)** TIER 2 – Operational & Case Management Level

---

---

- TIER 2 cuprinde roluri care au impact direct asupra vieții profesionale a membrilor și asupra modului în care Union gestionează problemele de zi cu zi. Aceste poziții asigură protecție, investigație, negociere, reprezentare și suport operațional.    **Union Representative**   Reprezentantul oficial al membrilor în relația cu departamentul. Participă la ședințe, consultări și discuții administrative, aduce în atenția Union Chief probleme operaționale, conflicte interne, situații de moral scăzut sau îngrijorări legate de condițiile de lucru. Menține comunicarea transparentă între conducerea Union și personal.    **Labor Contract Negotiator**   Specialist în legislația muncii și negocieri colective, responsabil pentru redactarea, analizarea și negocierea contractelor sindicale. Evaluează impactul financiar al propunerilor, colaborează cu Union Chief și asigură adoptarea unor soluții optime pentru personal.    **Grievance Officer**   Ofițerul responsabil cu gestionarea plângerilor și sesizărilor, având un rol crucial în protejarea membrilor împotriva abuzurilor și nedreptăților administrative. Investighează cazurile, colectează informații, redactează rapoarte și recomandă soluții. Participă la proceduri disciplinare în calitate de observator sau apărător al drepturilor angajaților.    **Workplace Advocate**   Specialist axat pe monitorizarea condițiilor de lucru și protejarea drepturilor profesionale ale pompierilor. Intervine în cazurile în care există conflict între proceduri și realitatea operațională, asistă membrii în ședințe sau interviuri și colaborează frecvent cu Grievance Officer.    **Health & Safety Officer**   Responsabil de sănătatea ocupațională și siguranța membrilor Union. Evaluează riscurile la locul de muncă, investighează accidentele, propune măsuri de prevenție și colaborează cu Benefits Coordinator pentru accesarea programelor de recuperare, tratamente și concedii medicale. Este o figură-cheie în menținerea unui mediu de lucru sigur și funcțional.

 -
---

---

- **(3.4)** TIER 1 – Support & Wellness Level

---

---

- **Peer Support Specialist**    Primul nivel al structurii Union, TIER 1 reprezintă suportul emoțional și psihologic al organizației. Peer Support Specialist oferă consiliere de bază, suport moral și asistență pentru membrii care trec prin traume, stres operațional, burnout, pierderi sau dificultăți personale.    Aceștia ascultă, oferă încurajare, monitorizează starea psihologică a colegilor și trimit cazurile grave către profesioniști. Mențin confidențialitatea și contribuie esențial la moralul colectiv și stabilitatea psihologică a pompierilor.

 -
---

---

- **(3.5)** Coeziunea între niveluri și funcționarea integrată a Union

---

---

- Structura organizată pe TIER-uri funcționează într-un sistem colaborativ dinamic. Fiecare rol sprijină celelalte poziții, iar fiecare nivel contribuie la protejarea membrilor și la menținerea unui climat profesional sănătos.    Union Chief stabilește direcția strategică; structura de nivel mediu gestionează negocieri, reprezentare și investigații; iar TIER 1 asigură suportul moral necesar într-o profesie definită de riscuri. Prin această organizare, Firefighter Union devine o forță de echilibru în departament — capabilă să prevină abuzurile, să susțină interesele membrilor și să construiască o cultură profesională bazată pe respect, protecție și solidaritate.

 -

---
