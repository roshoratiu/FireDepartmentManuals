# TRUCK - TR

- **Topic ID:** 74
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=74
- **Posts:** 1

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

TRUCK

---

---

---

**1. TOOLS & EQUIPMENT (UNELTE ȘI ECHIPAMENTE)**
---

---

- Truck Company este unitatea specializată pentru ladder operations (operațiuni cu scara), ventilation (ventilație), forcible entry (intrare forțată), exterior attack (atac exterior), salvări de la înălțime și suport tehnic la incidente complexe.

 1.1 **Primary Equipment (echipament principal)**
- **[Cut-off saw (fierăstrău circular de intervenție)](http://www.northsidetoolrental.com/wp-content/uploads/2010/12/cut-off-saw.jpg):** taie materiale de construcție, metal, acoperișuri și obstacole dure.
- **[Reciprocating saw (fierăstrău alternativ)](http://cdn0.blocksassests.com/assets/ozito/ozito-clean-pics/gSib6qHKBsXwpI0/RECIP-SAW-RSR-850.jpeg):** folosit pentru sticlă, tablă, țevi și materiale ușoare.
- **[Ground ladder - 4m (scară de sol 4m)](https://embed.widencdn.net/img/wernerco/txwocfirfk/1200x1200px/514-1_PI.jpeg?crop=no&u=qlpvmu):** acces rapid la niveluri joase sau ferestre.
- **[Extension ladder - 7m (scară extensibilă 7m)](http://www.homedepot.com/catalog/productImages/1000/0f/0f9bb948-6ad7-4e6d-b9c7-0334c5d17be9_1000.jpg):** acces la etaje superioare când scara scurtă nu ajunge.
- **[Fire axe (topor de pompieri)](http://i.imgur.com/GQGbqDl.jpg):** spargere, forțare și îndepărtarea obstacolelor.
- **[Mallet (ciocan de intervenție)](http://i.imgur.com/qCVwzM2.jpg):** lovire controlată pentru materiale ușoare.
- **[Sledgehammer (baros)](http://asrentall.com/wp-content/uploads/2013/03/sledge-hammer.jpg):** forțare prin uși, pereți ușori și obstacole rezistente.
- **[Pike pole (cange)](https://4.bp.blogspot.com/-PTvAo3OAKTU/TzGyyfrIBBZI/AAAAAAF7E/JgFQEgeW4Hc/s640/pike+pole.jpg):** verificarea tavanului, pereților, podelei și a materialelor mocnite.
- **[Portable fan (ventilator portabil)](http://i.imgur.com/Gsua1aM.jpg):** positive pressure ventilation - PPV (ventilație cu presiune pozitivă) sau evacuarea fumului.
- **[Halligan/pry bar (rangă/Halligan)](http://i.imgur.com/kQDBTVjh.gif):** forcible entry, deschiderea ușilor și crearea accesului.
- **[Lifting airbag (pernă pneumatică de ridicare)](http://i.imgur.com/UJKAuE1.jpg):** ridicarea obiectelor grele, vehiculelor sau obstacolelor.
- **[Jump pad (saltea pneumatică de salvare)](http://i.imgur.com/QU6CFdG.jpg):** protecție pentru persoane aflate la înălțime, când situația o permite.
- **[Stabilization struts (tije de stabilizare)](http://i.imgur.com/JJrWEew.jpg):** stabilizarea vehiculelor răsturnate sau instabile.
- **[Backboard (placă spinală)](http://www.savelives.com/media/images/j1p_full.jpg):** transfer și imobilizare în extrication (extragere).

---

---

**2. FIRE TRIANGLE (TRIUNGHIUL DE FOC)**
---

---

- Fire Triangle (triunghiul de foc) explică cele trei elemente necesare arderii: fuel (combustibil), oxygen (oxigen) și heat (căldură). Pentru extinguishment (stingere), echipajul trebuie să elimine sau să controleze cel puțin unul dintre aceste elemente.

 2.1 **Fuel (combustibil)**
- Fuel reprezintă materialul care arde: lemn, hârtie, textile, combustibil lichid, gaz, grăsimi sau alte materiale inflamabile. Eliminarea combustibilului poate însemna închiderea unei supape de gaz, îndepărtarea materialului combustibil sau izolarea zonei afectate.

 2.2 **Oxygen (oxigen)**
- Focul se stinge dacă oxygen-ul nu mai ajunge la combustibil. Firefighting foam (spuma de stingere) funcționează prin acoperirea combustibilului și separarea lui de aer. În spații închise, ventilația trebuie coordonată cu fire attack (atacul asupra focului), deoarece introducerea oxigenului fără control poate intensifica incendiul.

 2.3 **Heat (căldură)**
- Heat se reduce în principal prin apă, răcire și expunerea materialelor fierbinți. Nu folosiți apă pe ulei încins, echipamente electrice active sau substanțe reactive cu apă. În aceste cazuri se folosesc agenți potriviți, foam sau CO2, conform clasei de incendiu.

---

---

**3. SUICIDAL CALLS (APELURI CU RISC SUICIDAL)**
---

---

- La suicidal calls (apeluri cu risc suicidal), Truck/Ladder este trimis pentru ladder operations, jump pad deployment și suport tehnic. Scena trebuie tratată ca o intervenție multi-agency (multi-agenție), coordonată cu PD/SD și EMS.

- **1.** Stabiliți staging (poziționare de așteptare) într-o zonă sigură, fără a agita persoana.  **2.** Solicitați PD/SD pentru perimeter (perimetru), crowd control și negociere.  **3.** IC stabilește dacă se folosește jump pad, ladder sau alt sistem de acces.  **4.** Dacă se folosește jump pad, poziționați-l sub zona de risc, conectați portable fan-ul și umflați complet salteaua.  **5.** Anunțați toate agențiile când sistemul este pregătit.  **6.** Nu forțați contactul fizic decât dacă există o oportunitate clară, sigură și coordonată cu IC/PD.

---

---

**4. HIGH-ANGLE / STRANDED PERSONS (PERSOANE BLOCATE LA ÎNĂLȚIME)**
---

---

- Pentru persoane blocate la înălțime, prioritatea este stabilizarea scenei, alegerea accesului potrivit și coborârea controlată. Ladder placement (poziționarea scării) trebuie făcută cu atenție la vânt, suprafață, cabluri și unghi.

- **1.** Parcați Truck-ul astfel încât să aveți acces la victimă, dar fără să blocați complet alte unități.  **2.** Solicitați PD/SD pentru perimeter și controlul traficului.  **3.** Faceți scene size-up (evaluarea scenei): înălțime, acces, stabilitate, riscuri electrice și starea victimei.  **4.** Alegeți ladder-ul potrivit și verificați suprafața de sprijin.  **5.** Extindeți ladder-ul sub punctul de acces, nu direct peste victimă.  **6.** Asigurați contact verbal cu victima și coborâți-o controlat.  **7.** După coborâre, predați pacientul către EMS pentru assessment (evaluare).

---

---

**5. EXTERIOR ATTACK & VENTILATION (ATAC EXTERIOR ȘI VENTILAȚIE)**
---

---

- La un structure fire (incendiu de structură), IC decide dacă strategia este offensive (ofensivă) sau defensive (defensivă). Dacă structura este fully involved (implicată complet în flăcări) sau intrarea este nesigură, Truck Company sprijină exterior attack, aerial operations și ventilation.

 5.1 **Exterior Attack (atac exterior)**
- **1.** Poziționați echipa în afara collapse zone (zonei de prăbușire).  **2.** Folosiți hose line, master stream sau aerial stream doar conform ordinului IC.  **3.** Pulverizați dintr-un unghi sigur și țineți cont de vânt.  **4.** Protejați căile de evacuare și reduceți extinderea focului.  **5.** Direcționați civilii evacuați către EMS și raportați numărul lor către IC.

 5.2 **Ventilation (ventilație)**
- Ventilation elimină smoke (fum), heat (căldură) și fire gases (gaze de incendiu), dar trebuie coordonată cu fire attack. Ventilația necoordonată poate alimenta incendiul.

 5.2.1 **Vertical Ventilation (ventilație verticală)**
- Vertical ventilation se face prin deschideri în acoperiș. Înainte de tăiere, verificați roof stability (stabilitatea acoperișului), identificați punctele solide și lucrați cu minimum două persoane, în contact radio cu IC.

 5.2.2 **Horizontal Ventilation (ventilație orizontală)**
- Horizontal ventilation se face prin ferestre, uși sau deschideri laterale. Deschideți ferestrele când este posibil; spargerea lor trebuie făcută doar când este necesar și coordonat.

 5.2.3 **Positive Pressure Ventilation - PPV (ventilație cu presiune pozitivă)**
- PPV folosește portable fan-ul pentru a împinge fumul spre o ieșire controlată. Asigurați-vă că există exhaust opening (deschidere de evacuare) și că interior attack știe când începe ventilația.

---
