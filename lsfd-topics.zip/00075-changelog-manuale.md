# CHANGELOG Manuale

- **Topic ID:** 75
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=75
- **Posts:** 1

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

CHANGELOG

---

---

---

**CHANGELOG - JURNAL DE MODIFICARI**
---

---

- Acest document inregistreaza toate modificarile aduse manualelor din repository, in ordine cronologica inversa (cele mai recente primele). Fiecare intrare specifica fisierul, sectiunea si natura modificarii.

---

---

 **2026-05-25 — Sesiunea 5**

 **Verificare gramaticala romana — toate documentele scanate:**
- Fisiere verificate: EMS/ALS.md, EMS/BLS.md, FIRE/ENGINE.md, FIRE/TRUCK.md, FIRE/SQUAD.md, FIRE/RESCUE.md, MOP.md, MOP-PARTII.md, CALIFICARI.md, CHANGELOG.md, Letter.md, agent.md.
- Nicio eroare sistematica identificata in afara de cea de mai jos.
- Toate cuvintele engleze cu sufixe romanesti corectate in sesiunile anterioare (kinkuit, tuckeaza, ratiourile, antebratt, immobilizeaza, comfortabila, incommod, calcanul palmei, semikonştient) sunt absente in versiunile curente.

 **EMS/BLS.md** — Corectie tipografica
- **Sectiunea 3.5 (X-Collar) — corectata:** `loviturae la cap` → `lovituri la cap` (exces de litere la finalul substantivului plural).

---

---

 **2026-05-24 — Sesiunea 4**

 **Cross-check EMS (ALS + BLS) — nicio contradictie identificata:**
- Dozele de Aspirin, Activated Charcoal si Naloxone sunt consistente intre BLS.md si ALS.md.
- Tintele SpO2 sunt consistente: 94-99% general (BLS) si 94-98% post-ROSC (ALS).
- Rata CPR (100-120/min) si raportul compresii:ventilatii (30:2 adult) sunt identice in ambele manuale.
- Terminologia tehnica (sniffing position, antecubital fossa, ICS/MCL/AAL, tibial tuberosity, flashback) este definita in ALS 1.1 si aplicata consistent in procedurile ALS.

 **EMS/ALS.md** — Dezvoltare masiva a sectiunilor procedurale

 **Sectiunea 1.1 (Terminologie) — extinsa semnificativ:**
- Adaugati termeni noi: SpO2, ROSC, VF, VT, PEA, RSI, GCS, MAP, STEMI, NPA, SCA, Antecubital fossa, Cephalic/Basilic vein, Cricothyroid membrane, Tibial tuberosity, ICS, MCL, AAL, Tidal volume, Tension pneumothorax, Sniffing position, Flashback, Mallampati score.
- Completate definitiile pentru SL si IN cu detalii de administrare.

 **Sectiunea 2.1 (OPA) — rescrisa cu detaliu complet:**
- Tehnica de dimensionare (de la coltul gurii la tragus).
- Procedura detaliata: insertie inversata + rotire la adult, insertie directa (fara rotire) la copil.
- Greselile comune cu consecinte explicate.
- Adaugata sectiunea NPA: dimensionare, tehnica de insertie (perpendicular pe fata, nu inclinat), lubrifiant obligatoriu, greselile comune, contraindicatie la fractura baza craniu.

 **Sectiunea 2.2 (Airway Suction) — extinsa:**
- Tipuri de catetere: Yankauer (orofaringe) vs cateter moale/French (ET tube, NPA).
- Limitele de timp (maxim 10-15 secunde per aspirare), preoxigenare obligatorie.
- Presiunile de aspirare (adult 80-120 mmHg, copil 60-80 mmHg).
- Greselile comune: aspirare prelungita, avansare cu aspirare activa, Yankauer prea adânc.

 **Sectiunea 2.3 (ETI) — rescrisa complet:**
- Lista completa de echipament (laryngoscop cu lame Mac/Miller, dimensiuni, ET tube dimensionat pe gen, stilet, syringe 10 mL, BVM, suction, capnography).
- Sniffing position: explicata cu ridicarea occiputului 7-10 cm, exceptia traumatizatilor (in-line stabilization).
- Procedura detaliata in 12 pasi (de la cross-finger, BURP, plasarea tubului prin coltul drept, confirmarea EtCO2).
- Confirmarea plasarii: EtCO2 (gold standard), auscultatia (la axile), chest rise, condensare, SpO2.
- Greselile comune cu consecinte: intubare esofagiana (semne, solutie), intubare in bronhia dreapta, parghie pe dinti, avansare fara vizualizare, hiperventilatia post-intubare.
- Limita: maxim 3 tentative, apoi plan B (LMA/King LT sau cricotirotomie).

 **Sectiunea 2.5 (Needle Cricothyrotomy) — extinsa cu anatomie:**
- Reper anatomic detaliat: localizarea membranei cricotiroidiene intre cartilajul tiroid si cricoid, tehnica de palpare pas cu pas.
- Procedura completa in 8 pasi cu confirmare prin aspirare aer.
- Greselile comune: identificare anatomica gresita, punctionare laterala (risc arterial), avansare fara confirmare.

 **Sectiunea 2.6 (Needle Decompression) — extinsa cu repere anatomice:**
- Doua locatii acceptate: ICS 2 MCL (clasic) si ICS 4-5 AAL (alternativa la obezi).
- Regula critica: punctionati pe MARGINEA SUPERIOARA a coastei inferioare (nu dedesubt — evitati pachetul vasculo-nervos).
- Procedura in 9 pasi, cateter 14G minim 8 cm (10-14 cm la obezi).
- Greselile comune: locatie gresita, cateter prea scurt, partea gresita, cateter indoit.

 **Sectiunea 4.1 (IV Access) — rescrisa complet:**
- Locatii preferate in ordine: fosa antecubitala (vena mediana cubitala), antebratul, dosul mainii, jugulara externa.
- Selectia calibrului (14G-22G) cu indicatii pentru fiecare.
- Locatii de evitat (mastectomie, fistula AV, fractura distala, celulita).
- Procedura in 11 pasi cu unghi de insertie (15-30° fosa antecubitala, 10-15° dorsal), tehnica de avansare a cateterului, eliberarea garoului inainte de deconectarea acului.
- Confirmarea patentei: flashback, flush 10 mL fara rezistenta sau umflatura.
- Greselile comune cu consecinte: avansare excesiva, neavansarea cateterului, reintroducerea acului (sectionarea cateterului), fara flush test, unghi gresit.

 **Sectiunea 4.2 (IO Access) — rescrisa complet:**
- Indicatii clare: 2-3 tentative IV esuate sau 60-90 sec fara succes la pacient critic.
- Toate locatiile de insertie cu repere anatomice exacte: tibia proximala (2-3 cm sub tuberozitate, fata mediala), tibia distala (2-3 cm deasupra maleolei mediale), humerus proximal (tuberculul mai mare, brat rotit intern), sternum (dispozitiv specializat FAST-1).
- Procedura completa cu EZ-IO in 10 pasi.
- Lidocaina IO obligatorie la pacient constient (2 mg/kg, max 40 mg) inainte de flush.
- Confirmarea pozitiei: acul sta drept, flush fara rezistenta/extravasare, aspiratie maduva/sange.
- Greselile comune: locatie gresita, nu perpendicular, oprire prematura/avansare excesiva, fara lidocaina la constient.

 **Sectiunea 5.1 (ECG) — extinsa:**
- Plasarea derivatiilor pentru monitorizare 3-4 lead si 12-lead.
- Plasarea electrozilor precordiali V1-V6 cu repere intercostale exacte.
- Tehnica de identificare ICS 4 prin unghiul lui Louis.
- Ritmuri uzuale de recunoscut in prespital cu tratamentul asociat.
- Greselile comune: electrozi pe zone musculare (artefact), V1-V2 puse prea sus, confundarea artefactelor cu VF.

 **Sectiunea 6.1 (Routes) — rescrisa cu detalii complete:**
- IV: flush 20 mL NS obligatoriu dupa medicamente bolus.
- IO: lidocaina flush la pacient constient.
- IM: site-uri detaliate (deltoid max 3 mL, vastus lateralis max 5 mL preferat, ventrogluteal) cu repere anatomice si volume maxime.
- IN: MAD obligatoriu, max 1 mL per nara, tehnica de impartire a dozei.
- SL: tehnica corecta de mentinere sub limba.
- Inhaled: nebulizer continuu preferat in bronhospasm sever, respiratie adanca si lenta.
- Ce NU trebuie facut: reguli de incompatibilitate, flush obligatoriu.

---

---

 **EMS/BLS.md** — Rescriere completa cu nivel de detaliu major

 **Toate sectiunile au fost rescrise/extinse semnificativ. Modificari principale:**
- **Sectiunea 1.1 (Arrival):** Adaugata procedura de parcare la accidente rutiere (15-30 m, unghi de protectie).
- **Sectiunea 1.1.1 (BSI):** Tipuri de echipament (nitrile, eye protection, mask, N95, halat), tehnica de scoatere a manusilor, greselile comune.
- **Sectiunea 1.1.2 (Scene Safety):** Lista exhaustiva de pericole specifice, reguli detaliate de pozitionare si escape route.
- **Sectiunea 1.1.3 (MOI):** Criterii de high index of suspicion pentru fiecare mecanism (auto, cadere, penetrant, explozie, electrocutare, inec), ce se observa la fata locului.
- **Sectiunea 1.1.5 (Triage):** START Triage complet cu cele 4 categorii si procedura de executie pas cu pas.
- **Sectiunea 1.2.2 (Response):** Tehnica stimulului dureros (trapezius pinch, sternum rub) cu durata si interpretare.
- **Sectiunea 1.2.3 (Airway):** Tehnica detaliata head tilt (mana pe os mandibulei, nu pe tesuturi moi), jaw-thrust cu pozitionare corecta, sunete anormale cu semnificatia lor (snoring, gurgling, stridor, wheeze).
- **Sectiunea 1.2.4 (Breathing):** Semne de insuficienta respiratorie inclusiv gasping agonic (NU este respiratie normala), valori FR pentru adult/copil/sugar.
- **Sectiunea 1.2.5 (Circulation):** Locatii de palpare (radial, brahial, carotidian, femural) cu conditii de utilizare, interpretarea skin signs, CRT cu limitele sale.
- **Sectiunea 1.3 (Palpare):** Tehnica completa, ce se cauta (crepitatie, instabilitate, guarding, rebound, subcutaneous emphysema).
- **Sectiunea 2.1 (Bleeding Control):** Cantitati de pierdere de sange si Clasele I-IV, wound packing pentru zone non-extremitate (inghinal, axilar, gat), tourniquet: 5-8 cm proximal de rana, locatii corecte (treimea superioara brat/coapsa, nu pe articulatii), consecintele unui tourniquet prea slab.
- **Sectiunea 2.2 (Wound Cleaning):** Irigare cu volum minim 100-200 mL, interzicerea apei oxigenate/betadinei intraranic, rani ce NU se curata in prespital.
- **Sectiunea 3 (Fracturi):** PMS explicat (Pulse, Motor, Sensation) cu locatiile de palpare distala pentru fiecare membru.
- **Sectiunea 3.1 (Open Fracture):** Dressing umed pe os expus, procedura in 9 pasi, greselile comune.
- **Sectiunea 3.2 (Vacuum Splint):** Dimensionare, verificarea PMS pre si post, greselile comune.
- **Sectiunea 3.3 (Traction Splint):** Procedura completa in 9 pasi (inclusiv tractiunea manuala continua), contraindicatii absolute.
- **Sectiunea 3.4 (Triangular Bandage):** Swathe (legarea brațului de trunchi) adaugata pentru imobilizare suplimentara.
- **Sectiunea 3.5 (X-Collar):** Dimensionare (distanta umar-barbie), contraindicatii, tehnica in 7 pasi cu doi salvatori.
- **Sectiunea 4.1 (Burn Degrees):** Rule of Nines (Regula lui 9) cu procentele pe fiecare zona corporala, criteriile pentru arsuri majore.
- **Sectiunea 4.2 (Burn Treatment):** Arsuri chimice (irigare 15-30 min, NU neutralizare cu substanta opusa), arsuri electrice (deconectare sursa, monitorizare EKG), greselile comune (gheata, flictene sparte, hipotermia la arsuri mari).
- **Sectiunea 5.1 (CPR):** Pozitia mainilor (treimea inferioara a sternului, podul palmei, degetele ridicate), adancimea 5-6 cm, revenire completa, rotatia la 2 minute, CPR la copil/sugar, greselile comune extinse.
- **Sectiunea 5.2 (AED):** Pozitionarea exacta a pads-urilor (sub clavicula dreapta, ICS 4-5 stang), situatii speciale (pacemaker implantat, pacient umed, peri excesiv, copii sub 8 ani), greselile comune.
- **Sectiunile 6.1-6.3 (O2):** Debitele cu FiO2 estimat (NC), pre-umplerea obligatorie a saculetului NRB, tinta SpO2 diferentiata (general vs BPOC vs post-ROSC), tehnica C-E BVM, greselile comune (hiperventilatia, volumul excesiv, apasarea pe tesuturi moi).
- **Sectiunile 7.1-7.2 (Echipament):** Log roll detaliat cu 4 salvatori si atribuirea pozitiilor, regulile de blocare a targii.
- **Sectiunea 8 (Medicamente) — profiluri complete adaugate:**  - **Aspirin:** Indicatii, Contraindicatii, Doza (162-325 mg masticata), tehnica de administrare, ce NU se face. - **Ibuprofen:** Indicatii, Contraindicatii (renala, sarcina, AINS), Doza (400-600 mg PO), interactiune cu Aspirina. - **Activated Charcoal:** Indicatii (sub 60 min), Contraindicatii extinse (corozivi, hidrocarburi, alcooli, metale grele, litiu, voma activa), Doza (25-50 g adult), tehnica de administrare. - **Naloxone/Narcan:** Triada clasica a supradozei opioid, doze BLS IN (2 mg / 1 mg per nara) si IM (0.4-2 mg), durata de actiune vs durata opioidului (re-sedare posibila), tehnica de administrare la dependent (titrat 0.4 mg), ce NU se face. - **Sectiune noua 8.3 — Oral Glucose:** Indicatii (hipoglicemie <70 mg/dL la pacient constient), contraindicatii, doza (15-20 g glucoza), repetare la 15 min cu glucometrie, transport obligatoriu.

---

---

 **2026-05-24 — Sesiunea 3**

 **Cross-check general — probleme identificate si rezolvate:**
- **FIRE/RESCUE.md, Sectiunea 9.2 — CORECTATA:** Calificarea minima pentru intrarea in hot zone era gresit specificata ca "Hazmat Operations (TIER I)". Conform MOP.md cap. 11.03, TIER I (Decontamination Specialist) opereaza in Warm Zone; cel care intra in Hot Zone este Hazmat Entry Technician (TIER II). Corectat la "Hazmat Technician (TIER II)" cu clarificarea explicita a diferentei TIER I vs hot zone.
- **Technical Rescue Specialist — notata, nemodificata:** Calificarea exista in MOP 5.07 dar lipseste din CALIFICARI.md. User a autorizat folosirea ei anterior.
- **Apparatus Engineer — notata, nemodificata:** Clasificat diferit in MOP 5.07 (Technical Specializations) fata de CALIFICARI (Primary Operations Specializari). Nu creeaza contradictie operationala.

 **EMS/ALS.md** - Capitol 6.2 (Medication Groups) — medicamente noi adaugate
- **Cardiac/Pulse:** Adaugat **Vasopressin** (vasopresor alternativ epinefrinei in cardiac arrest, 40 UI IV/IO doza unica).
- **Cardiac Specific:** Adaugat **Procainamide** (antiaritmic pentru VT cu puls stabil si FA cu durere scurta, alternativa amiodaronei).
- **Pain Relief:** Adaugat **Acetaminophen / Paracetamol (Tylenol)** in forma IV pentru pacienti care nu pot lua oral sau cu contraindicatii la AINS.
- **Poisoning & Overdose:** Adaugat **Hydroxocobalamin / Cyanokit** (antidot cianuri, indicat la victime incendii cu inhalare fum) si **Pralidoxime / 2-PAM** (reactivator colinesteraza pentru intoxicatii cu organofosforice, administrat cu Atropine).
- **Respiratory:** Adaugat **Dexamethasone** (corticosteroid cu durata lunga, pentru COPD/astm sever, anaphylaxis, edem laringian, crup); specificata combinatia Atrovent + Salbutamol pentru bronhospasm sever.
- **Diabetic:** Adaugat **Thiamine / Vitamin B1** (administrata inaintea Dextrose la pacienti cu suspiciune etilism cronic, pentru preventie Wernicke).
- **Nausea:** Adaugat **Ondansetron / Zofran** (antiemetic de electie in prespital, blocant 5-HT3, administrare IV/IM/SL).
- **Allergies:** Adaugat **Dexamethasone** (complement corticosteroid pentru anaphylaxis).
- **Seizures — grupa noua:** Adaugata grupa separata pentru crize epileptice cu Diazepam, Midazolam, Lorazepam si **Levetiracetam / Keppra** (antiepileptic de linia a doua pentru status epilepticus refractar la benzodiazepine, IV fara sedare semnificativa).

---

---

 **2026-05-24 — Sesiunea 2**

 **MOP.md** - Capitol 10 (Primary Operations Bureau)
- **Sectiune noua - 10.04 Incident Commander — Desemnare si Autoritate:** Adaugata dupa sectiunea 10.03 (Pozitii si Calificari). Include trei sub-sectiuni: 10.04.01 (regula generala IC = cel mai mare rank, exceptia pentru incidente specializate, procedura de Transfer of Command cu fraza standardizata), 10.04.02 (autoritatea si prioritatea IC pe canal, sectorizarea comunicatiilor pe Statia 713/714, subordonarea TAC channels fata de 712, procedura de revenire pe canal principal) si 10.04.03 (responsabilitatile IC la scena, cu fraze standardizate de anunt si raportare).

 **MOP-PARTII.md** - Capitol 19 (Politici de Comunicare)
- **Sectiunea 19.06.02 Frecvente — reescrisa complet:** Adaugate canalele specifice cu descrieri: Statia 712 (Dispatch / Canal Principal), Statia 713 (IC1/TAC1), Statia 714 (IC2/TAC2). Fiecare canal are rolul, conditiile de utilizare si relatia cu canalul principal.
- **Sectiune noua - 19.06.03 Format de Comunicare Radio:** Adaugata intre 19.06.02 si 19.07. Explica cele doua formate: transmisie generala (Rank Prenume Nume, mesaj) si transmisie cu destinatar (Rank Prenume Nume towards Rank Prenume Nume, mesaj). Include exemple concrete pentru fiecare format si procedura de confirmare a receptiei.
- **Sectiunea 19.08 Terminologie — extinsa semnificativ:** Redenumita "Terminologie si Coduri de Raspuns". Adaugate si reformulate codurile: Code 0 (Emergency Traffic / Canal Liber, cu fraza de anunt de trei ori), Code 1 (non-urgent), Code 2 (urgent, lumini doar), Code 3 (urgenta, lumini + sirene), Code 4 (scena securizata). Adaugati termeni noi: Mayday, PAR (Personnel Accountability Report).

---

---

 **2026-05-24 — Sesiunea 1**

 **FIRE/RESCUE.md** - Rescrierea completa a manualului
- **Modificare generala:** Manualul a fost transformat din concept manual (draft) intr-un manual operational complet, similar ca structura si nivel de detaliu cu ENGINE.md, TRUCK.md si SQUAD.md.
- **Sectiuni noi adaugate:** 1. PPE (echipament standard + echipament specific Rescue), 2. Tools & Equipment (Extrication / Stabilizare / Rope & Confined Space / Scene Support), 3. Division Assignment (actualizat), 4. Vehicle Extrication (cu sub-proceduri detaliate), 5. Structural Collapse (collapse patterns, shoring, victim removal), 6. Confined Space Rescue (atmospheric testing, entry protocol, non-entry rescue, emergency egress), 7. Rope Rescue / High-Angle (anchor system, patient packaging, lower vs raise cu comenzi standardizate), 8. Mayday Support / RIT Assist, 9. Hazmat Support.
- **Calificari invalide inlocuite:** "Structural Collapse Awareness" si "Confined Space Rescue" nu existau in MOP sau CALIFICARI - au fost inlocuite cu "Technical Rescue Specialist" (existent in MOP 5.07).
- **Referinte divizii corectate:** "Division 2 HSOD" → "Division 2: HSOD - Hazmat, Special Operations & Disaster Response"; "Division 3 Wildland & Environmental Operations" → "Division 3: Wildland & Environmental Operations". Toate referintele la divizii verifica acum contra MOP.md si CALIFICARI.md.

 **agent.md** - Adaugare reguli noi
- **Sectiune noua - Validarea Referintelor (Divizii, Rankuri, Calificari):** Regula ca orice divizie, rank sau calificare trebuie verificata in MOP.md SI CALIFICARI.md inainte de a fi folosita. Daca exista in ambele → se foloseste; daca nu → se opreste si se intreaba utilizatorul.
- **Sectiune noua - Cross-Check:** Explicatia completa a ce trebuie verificat intr-un cross-check (divizii, rankuri, calificari, contradictii procedurale, consistenta TIER, chain of command) si ce trebuie sa contina un raport de cross-check.

 **MOP.md** - Capitol 5
- **Sectiune noua - 5.11 Cum se Obtin Calificarile:** Adaugata dupa sectiunea 5.10 (Administration). Explica procesul in 4 pasi: contactarea Division 6, verificarea eligibilitatii, parcurgerea instruirii si inregistrarea oficiala de catre Certification Officer.

 **MOP-PARTII.md** - Capitol 15 (Division 6)
- **Sectiune noua - 15.05 Cum se Solicita o Calificare:** Adaugata dupa sectiunea 15.04 (Programe de Training). Acelasi proces in 4 pasi, cu nota suplimentara despre recertificari periodice.

 **CALIFICARI.md**
- **Sectiune noua - Cum se Obtine o Calificare:** Adaugata ca divbox inaintea primei sectiuni de calificari. Rezuma procesul de 4 pasi direct in registrul de calificari, pentru acces rapid.

---

---

- Changelog generat automat. Orice modificare ulterioara trebuie adaugata manual la inceputul acestui document, dupa linia . ---   ---

---
