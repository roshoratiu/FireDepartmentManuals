# Advanced Life Support - ALS

- **Topic ID:** 65
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=65
- **Posts:** 2

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

ADVANCED LIFE SUPPORT

---

---

---

**1. INTRODUCTION (INTRODUCERE)**
---

---

- Advanced Life Support - ALS (suport vital avansat) reprezintă nivelul medical peste BLS. Un ALS provider / Paramedic poate efectua proceduri avansate precum airway management (managementul căilor respiratorii), IV/IO access (acces intravenos/intraosos), cardiac monitoring (monitorizare cardiacă), medication administration (administrare de medicamente), needle decompression (decompresie cu ac) și advanced trauma care (îngrijire traumatică avansată).    ALS nu înlocuiește BLS. Procedurile BLS - scene safety, BSI, airway basic, bleeding control, CPR și transport rapid - rămân fundația oricărei intervenții.

 1.1 **Medical Terminology (terminologie medicală)**
```
[SHOW]
End-tidal capnography - EtCO2 (capnografie la final de expirație): monitorizarea CO2 expirat, utilă în stop cardiac, intubation confirmation (confirmarea intubației) și evaluarea ventilației.

Gastric suction (aspirație gastrică): îndepărtarea conținutului gastric prin tub, în contexte specifice și controlate.

IO infusion (perfuzie intraosoasă): administrarea de fluide sau medicamente în măduva osoasă când IV access nu poate fi obținut rapid.

Mechanical ventilator (ventilator mecanic): dispozitiv care ventilează pacientul cu presiune pozitivă controlată.

Synchronized cardioversion (cardioversie sincronizată): șoc electric sincronizat cu ritmul cardiac, folosit pentru anumite tahiaritmii instabile.

TCP - Transcutaneous Pacing (stimulare transcutanată): stimulare electrică externă pentru bradicardie severă simptomatică.

Therapeutic hypothermia (hipotermie terapeutică): răcire controlată după ROSC, conform protocolului.

Thrombolysis (tromboliză): administrarea de medicamente care dizolvă cheaguri, conform indicațiilor medicale.

Pharynx (faringe): zona gâtului care leagă cavitatea nazală/orală de laringe și esofag.

Nasopharynx (nazofaringe): porțiunea din spatele cavității nazale.

Oropharynx (orofaringe): porțiunea vizibilă în spatele gurii.

Laryngopharynx (laringofaringe): zona inferioară a faringelui, spre laringe și esofag.

Pneumonia (pneumonie): inflamație/infecție pulmonară cu acumulare de fluid sau secreții.

Hypoventilation (hipoventilație): ventilație insuficientă.

Hyperventilation (hiperventilație): respirație prea rapidă sau prea profundă, cu scăderea CO2.

IV - Intravenous (intravenos): administrare într-o venă.

IM - Intramuscular (intramuscular): administrare într-un mușchi.

SL - Sublingual (sublingual): administrare sub limbă, prin mucoasa sublinguală; absorbție rapidă fără primul pasaj hepatic (ex. nitroglicerină, ondansetron dispersibil).

IN - Intranasal (intranazal): administrare prin spray sau atomizor nazal; util la pacienți fără acces IV (ex. naloxone, midazolam); maxim 1 mL per nară.

SpO2 (saturatia periferica a oxigenului): procentul hemoglobinei saturate cu oxigen, masurat noninvaziv prin pulsoximetru. Normal: 94-100%. Sub 90% = hipoxie; sub 85% = hipoxie severa, interventie imediata.

ROSC - Return of Spontaneous Circulation (revenirea circulatiei spontane): reapariția pulsului spontan dupa stopul cardiac; ghideaza tratamentul post-resuscitare: oxigenare controlata (SpO2 94-98%), TA, temperatura, monitorizare continua.

VF - Ventricular Fibrillation (fibrilatie ventriculara): ritm cardiac haotic si dezorganizat, fara contractie coordonata a ventriculilor; principalul ritm soc-abil in stop cardiac. Tratament: CPR + defibrilare + epinefrina + antiaritmic.

VT - Ventricular Tachycardia (tahicardie ventriculara): ritm rapid (>100/min) cu origine in ventricul. Cu puls si stabil: antiaritmice (amiodarona, lidocaina, procainamida). Fara puls: tratata ca VF.

PEA - Pulseless Electrical Activity (activitate electrica fara puls): activitate EKG prezenta, dar fara puls palpabil. Cauze reversibile: Hipovolemie, Hipoxie, Hipotermie, H+ (acidoza), Hipo/Hiperpotasemie, Tensiune pneumotorax, Tamponada cardiaca, Toxine, Tromboza (coronariana/pulmonara).

RSI - Rapid Sequence Intubation (intubare cu secventa rapida): tehnica de intubare ce combina un agent de inductie (ex. Ketamine) cu un relaxant muscular (ex. Succinylcholine), administrate simultan, pentru a paraliza rapid pacientul si a reduce riscul de aspiratie.

GCS - Glasgow Coma Scale (scala coma Glasgow): evaluarea nivelului de constienta. Deschidere ochi (E 1-4) + Raspuns verbal (V 1-5) + Raspuns motor (M 1-6). Total 3-15. GCS ≤8 = coma; considerati intubarea pentru protectia cailor respiratorii.

MAP - Mean Arterial Pressure (presiunea arteriala medie): presiunea medie de perfuzie tisulara. Formula: MAP = TAd + (TAs − TAd) / 3. Tinta in soc: MAP >65 mmHg pentru perfuzie adecvata a organelor.

STEMI - ST-Elevation Myocardial Infarction (infarct miocardic cu supradenivelare ST): ocluzie coronariana totala evidentiata prin supradenivelare ST ≥1 mm in ≥2 derivatii adiacente pe EKG. Urgenta maxima: notificati spitalul imediat pentru PCI (angioplastie) primara — fiecare minut conteaza.

NPA - Nasopharyngeal Airway (cale aeriena nazofaringiana): dispozitiv flexibil introdus printr-o nara, mentinand un canal aerian pana in nazofaringe. Tolerat de pacienti semiconstienți cu gag reflex usor prezent. Masurare: de la varful nasului la tragus.

SCA - Sudden Cardiac Arrest (stop cardiac subit): oprirea brusca si neasteptata a activitatii cardiace eficiente, cu pierderea pulsului si constiintei. Necesita CPR imediata si defibrilare cat mai rapida.

Antecubital fossa (fosa antecubitala): zona de la plica cotului, pe fata anterioara. Contine vena mediana cubitala — locatia preferata pentru acces IV rapid in urgenta, deoarece vena este larga si relativ fixa.

Cephalic vein / Basilic vein (vena cefalica / vena bazilica): vene superficiale ale antebratului; utilizate ca alternativa la fosa antecubitala pentru acces IV.

Cricothyroid membrane (membrana cricotiroidiana): membrana fibroelastica intre cartilajul tiroid (marul lui Adam) si cartilajul cricoid inferior; locul de electie pentru cricotirotomie de urgenta.

Tibial tuberosity (tuberozitatea tibiei): proeminenta osoasa palpabila pe fata anterioara a tibiei, imediat sub rotula; punct de reper pentru insertia IO in tibia proximala — punctia se face 2-3 cm inferior si medial de aceasta.

ICS - Intercostal Space (spatiu intercostal): spatiul dintre doua coaste. ICS 2 (linia medioclaviculara) si ICS 4-5 (linia axilara anterioara) sunt repere pentru decompresie cu ac in pneumotorax sub tensiune.

MCL - Midclavicular Line (linia medioclaviculara): linie verticala imaginara ce trece prin mijlocul claviculei; reper principal pentru decompresie cu ac (ICS 2).

AAL - Anterior Axillary Line (linia axilara anterioara): linie verticala imaginara de-a lungul marginii anterioare a axilei; reper alternativ pentru decompresie cu ac (ICS 4-5), preferat la pacientii obezi.

Tidal volume (volum curent): volumul de aer per respiratie normala. Adult: ~500 mL. Hipoventilatie <300 mL. In ventilatie cu BVM: suficient cat sa vedeti chest rise — nu mai mult (risc de barotrauma si distensie gastrica).

Tension pneumothorax (pneumotorax sub tensiune): acumulare progresiva de aer sub presiune in spatiul pleural, cu colapsul plamanului ipsilateral si devierea mediastinului spre partea opusa; urgenta vitala ce necesita decompresie imediata.

Sniffing position (pozitia de mirosit): pozitia optima pentru intubare — extensia usoara a capului cu flexia usoara a gâtului la baza, ca si cum pacientul miroase ceva. Aliniaza axele orofaringiana, faringiana si traheala, maximizand vizualizarea corzilor vocale.

Flashback (reflux de sange): aparitia sangelui in camera de vizualizare a cateterului IV imediat dupa punctionarea venei; confirma pozitia intravasculara a acului.

Mallampati score (scorul Mallampati): evaluare vizuala a dimensiunii cailor aeriene orofaringiene (structuri vizibile la gura larg deschisa, fara fonatie). Scor crescut (III-IV) sugereaza intubare dificila.
```

---

---

**2. AIRWAY MANAGEMENT (MANAGEMENTUL CĂILOR RESPIRATORII)**
---

---

- Airway management are prioritate la orice pacient inconștient, cu respirație ineficientă sau cu risc de aspirație. O respirație zgomotoasă este tratată ca airway obstruction (obstrucție de cale respiratorie) până la proba contrarie.

 2.1 **OPA - Oropharyngeal Airway (cale aeriană orofaringiană)**
```
[SHOW]
OPA menține limba departe de posterior pharynx la pacienți inconștienți fără gag reflex (reflex de vomă). Nu se folosește la pacient conștient sau semiconștient cu reflex prezent — riscul de vomă și aspirație este major.

Dimensionare: Masurați de la colțul gurii la unghiul mandibulei SAU de la centrul gurii la tragus (lobul urechii). Un OPA prea mic nu susține airway-ul; unul prea mare poate impinge epiglota și bloca corzile vocale.

Cum se aplică:

1. Alegeți dimensiunea corectă — masurați pe fata pacientului inainte de insertie.
2. Deschideți gura pacientului prin chin lift sau cross-finger technique și verificați absența obstrucțiilor vizibile.
3. La adult: introduceți OPA cu concavitatea spre palat (inversat / cu deschiderea spre sus), avansați până la valul palatin, apoi rotiți 180° astfel încât concavitatea urmărește limba în jos spre faringe. Flansa rămâne la nivelul buzelor.
4. La copil (sub 8 ani): NU rotiti — folosiți abatator de limbă și introduceți OPA direct cu concavitatea în jos.
5. Confirmați că flansa este la buze și că airway-ul este patent: ascultați aerul care trece, evaluați chest rise.
6. Monitorizați continuu: respirație, toleranță, eventuale vome. Dacă pacientul încearcă să-l expectoreze sau apare gag reflex, scoateți OPA și considerați NPA.

Greșeli comune:

OPA prea mare: poate impinge epiglota in trahee blocând airway-ul în loc să-l deschidă — verificați dimensiunea.
OPA prea mic: nu are efect, limba cade oricum posterior.
Inserție la pacient cu gag reflex: provoacă vomă activă și risc imediat de aspirație.
Rotire incorectă la copii: mucoasa laringiană este mai fragilă; nu rotiti niciodata OPA la copii.
Netestarea poziției: OPA corect inserat nu garantează un airway liber dacă există secreții, sânge sau corp străin — verificați și aspirați dacă este nevoie.

Ce NU trebuie să faceți: Nu introduceți OPA forțat dacă simțiți rezistență. Nu lăsați OPA la pacient care devine agitat sau revine la conștiință fără a evalua din nou toleranța.

---

NPA - Nasopharyngeal Airway (cale aeriena nazofaringiana) — alternativa la OPA

NPA este un tub moale de cauciuc sau silicon introdus printr-o nara, care menține un canal aerian până în nazofaringe. Este tolerat de pacienți semiconstienți cu gag reflex prezent, unde OPA este contraindicat.

Dimensionare: De la vârful nasului la tragus (lobul urechii). Calibru ales în funcție de diametrul nării: de obicei 6-7 mm la adulți (verificați că alunecă fără rezistență).

Cum se aplică:

1. Lubrifiați NPA cu gel hidro-solubil (NU vaselina/ulei — degradează cauciucul).
2. Alegeți nara mai liberă — de regulă dreapta, cu bizoul orientat spre septul nazal.
3. Introduceți NPA perpendicular pe față (NU înclinat în sus spre frunte), urmând podeaua nazală.
4. Avansați ușor, fără forță, cu o ușoară mișcare de rotire. Flansa rămâne la intrarea nării.
5. Dacă simțiți rezistență puternică, NU forțați — încercați cealaltă nară sau calibru mai mic.
6. Confirmați airway-ul patent prin flux aerian audibil sau vizibil.

Greșeli comune NPA:

Orientare greșita: inserție înclinată în sus traumatizează turbinele nazale — întotdeauna perpendicular pe față.
Fără lubrifiant: traumatizează mucoasa, provoacă epistaxis, face inserția dureroasă.
Forțare: poate produce epistaxis sever, hematom septal sau traumă adenoidiană.
Dimensiune incorectă: NPA prea lung poate stimula gag reflex sau laringe; prea scurt nu deschide airway-ul.

Contraindicație NPA: Fractură de bază de craniu suspectată (semne: ochi de raton bilateral, semnul Battle, licoree/hemotimpanom). Riscul de inserție intracraniană este teoretic, dar această contraindicatie este respectată în prespital.

[SHOW]
```

 2.2 **Airway Suction (aspirația căilor respiratorii)**
```
[SHOW]
Airway suction îndepărtează sânge, vomă, secreții sau lichide care pot provoca aspiration (aspirație în plămâni). Aspirația unui volum mic de conținut gastric poate cauza pneumonie de aspirație severă — acționați rapid la primul semn de secreții.

Tipuri de catetere:

Yankauer (rigid): pentru orofaringe — cel mai des folosit; aspiră eficient volume mari de sânge sau vomă. NU introduceți mai adânc decât faringele posterior — risc de stimulare vagală (bradicardie) sau laringospasm.
Catheter moale / French: pentru nazofaringe, prin ET tube sau NPA. Dimensiunea Fr 12-14 pentru adulti.

Cum se execută:

1. Pregătiți suction unit (verificați presiunea: 80-120 mmHg pentru adulti, 60-80 mmHg pentru copii) și Yankauer catheter.
2. Pre-oxigenați pacientul cu BVM 100% O2 timp de 30-60 secunde dacă starea permite.
3. Deschideți gura pacientului și introduceți Yankauer lateral, sub control vizual — NU avansați orbit.
4. Aplicați aspirarea NUMAI în timp ce retrageți cateterul, nu în timp ce avansați (avansarea cu aspirare activă poate traumatiza mucoasa și hipoxia creierul).
5. Durata maxima a fiecărei aspirari: 10-15 secunde la adult (timpul cât puteți ține respirația confortabil). Nu depașiți limita.
6. Reoxigenați cu BVM sau mașca de O2 între episoade de aspirare.
7. Repetați dacă sunt secreții restante, dar prioritizați întotdeauna oxigenarea.

Greșeli comune:

Aspirare prelungita: >15 secunde = hipoxie; SpO2 poate scadea dramatic în 10-15 secunde la un pacient compromis.
Avansarea cu aspirare activa: traumatizeaza mucoasa faringiana si poate produce laringospasm.
Yankauer prea adânc: poate stimula nervul vag și produce bradicardie sau laringospasm reflex.
Presiune de aspirare prea mare: la copii poate produce atelectazie; verificati presiunea dupa fiecare pacient.
Nepreoxigenarea: nu aspirați un pacient hipoxic fără a-l oxigena mai intai.

Ce NU trebuie să faceți: Nu aspirați blind (fără vizualizare). Nu avansați cu aspirarea activă. Nu înlocuiți aspirarea cu ventilarea unui pacient cu vomă în airway — aspirați mai întâi, ventilați după.

[SHOW]
```

 2.3 **Endotracheal Intubation - ETI (intubație endotraheală)**
```
[SHOW]
Endotracheal intubation plasează un ET tube (tub endotraheal) în trachea pentru ventilare controlată și protecția airway-ului. Este indicată când BLS airway și BVM nu asigură oxigenare adecvată, în stop cardiac, traumă majoră, GCS ≤8 sau pacient incapabil să-și protejeze airway-ul (vomă, sângerare, secreții).

Echipament necesar:

Laryngoscope: mâner + lama (blade). Lama Macintosh (Mac) curbă, mărimea 3 sau 4 la adulti — vârful lamei se plasează în vallecula (spațiul dintre baza limbii și epiglotă). Lama Miller dreaptă, mărimea 2 sau 3 — vârful ridică direct epiglota.
ET tube: 7.5-8.0 mm (barbati adulti), 7.0-7.5 mm (femei adulte). Taiați la 26-28 cm la barbati, 22-24 cm la femei.
Syringe 10 mL: pentru umflarea cuff-ului (inject 5-10 mL aer, presiune ideala 20-30 cmH2O).
Stilet (stylet): pentru a da forma de baton de hochei ET tube-ului; retrageți-l inainte de trecerea tubului prin corzi.
BVM + O2 100%: pentru preoxigenare si ventilare dupa intubare.
Suction activ: gata de utilizare pe tot parcursul procedurii.
Capnography (EtCO2): gold standard pentru confirmarea pozitiei tubului.

Pozitionarea pacientului — Sniffing Position:

Ridicati occiput 7-10 cm (o paturica sau prosop) si extindeți ușor capul — aceasta aliniaza axele oral, faringian si traheal. La traumatizat cu imobilizare cervicala: intubati in pozitie neutra, fara extensia capului (in-line stabilization cu un coleg).

Cum se execută:

1. Pregătiți și verificați echipamentul: bec laryngoscop functional, cuff ET tube intact (gonflati si deflati), suction pornit.
2. Preoxigenați pacientul: BVM 100% O2, 3-5 minute dacă situatia permite, sau 8-12 ventilații profunde. Tinta SpO2 >95% inainte de tentativa de intubare.
3. Pozitionati pacientul in sniffing position.
4. Deschideti gura cu mana dreapta (cross-finger technique: police pe dinti superiori, index pe inferior).
5. Tineti laringoscopul cu mana stanga, introduceti lama pe dreapta limbii, avansati spre dreapta deplasand limba spre stanga.
6. Avansati pana la vallecula (Mac) sau sub epiglota (Miller), ridicati lama in sus si anterior (spre unghiul tavanului) — NU faceti parghie pe dinti (cel mai frecvent gresit).
7. Vizualizati corzile vocale (structuri alb-sidefii, triunghiulare). Daca nu le vedeti: cereti BURP (Backward-Upward-Right Pressure pe cartilajul tiroid) sau reajustati pozitia capului.
8. Cu mana dreapta, introduceti ET tube prin coltul drept al gurii (nu prin laringoscop), urmarind traiectoria vizuala. Treceti cuff-ul la 2-3 cm distal de corzile vocale.
9. Mentineti tubul cu mana dreapta, scoateti laringoscopul si stiletul.
10. Gonflati cuff-ul cu 5-10 mL aer pana nu mai simtiti scurgere la ventilatie.
11. Conectati BVM si ventilati — confirmati pozitia (vezi mai jos).
12. Fixati tubul cu leucoplast sau dispozitiv de fixare comercial. Notati adancimea la dinti.

Confirmarea pozitiei (obligatorie — nu negociabila):

EtCO2 (capnografie): gold standard. Prezenta CO2 la expiratie confirma pozitia traheala. Lipsa CO2 = intubare esofagiana pana la proba contrarie — scoateti tubul imediat.
Auscultatia: sunete respiratorii bilaterale (la ambele axile, nu doar la piept — pieptul conduce sunetele). Lipsa sunetelor pe stanga = intubare in bronhia dreapta (retrageti 1-2 cm si reascultati). Sunete gastrice la epigastru = intubare esofagiana — scoateti tubul.
Chest rise bilateral: toracele se ridica simetric la ventilatie.
Condensare in tub: aburi la expiratie in tub — semn de confirmare secundar, nu suficient singur.
SpO2: trebuie sa creasca sau sa ramana stabila dupa intubare; scaderea SpO2 dupa intubare sugereaza esec.

Greșeli comune și ce NU trebuie să faceți:

Intubare esofagiana: CEA MAI PERICULOASA greseala. Semne: nu apare EtCO2, sunet gastric la ventilatie, SpO2 scade, abdomenul se umfla. Solutie: scoateti tubul imediat, reoxigenati, reincercati.
Intubare in bronhia dreapta (mainstem): ET tube introdus prea adânc; sunet respirator prezent doar pe dreapta. Solutie: deflati cuff, retrageti 1-2 cm, reconfirmati.
Pârghie pe dinti: laringoscopul trebuie ridicat, nu tras ca o bara pe dinti — fractura dentara si vizualizare slaba.
Avansare fara vizualizare: NU avansati tubul daca nu vedeti corzile vocale. Daca nu vizualizati — retrageți, reoxigenati, reîncercati cu ajustari (pozitia capului, BURP, aspirare, alt operator).
Omisiunea confirmarii: NU considerati intubarea confirmata fara EtCO2 si auscultatia. Orice miscare a pacientului (transfer, transport) necesita reconfirmare.
Prea multe tentative: maxim 3 tentative de intubare per operator; dupa 3 esecuri, mergeti la plan B: supraglottic airway (LMA/King LT) sau cricotirotomie.
Hiperventilatia post-intubare: ventilati 10-12/min la adult, 1 ventilatie la 5-6 sec. Hiperventilatia scade CO2, produce vasoconstrictie cerebrala si agraveza outcome-ul neurologic.

[SHOW]
```

 2.4 **Magill Forceps (pense Magill)**
```
[SHOW]
Magill forceps se folosesc pentru îndepărtarea obiectelor străine vizibile din airway, de obicei împreună cu laryngoscope. Nu se folosește blind sweep (măturare oarbă).

Cum se folosesc:

1. Vizualizați obiectul cu laryngoscope.
2. Introduceți Magill forceps fără a împinge obiectul mai adânc.
3. Prindeți obiectul și extrageți-l lent.
4. Reevaluați airway și breathing.

[SHOW]
```

 2.5 **Needle Cricothyrotomy (cricotiroidotomie cu ac)**
```
[SHOW]
Needle cricothyrotomy este o procedură de ultimă instanță — situatia "can't intubate, can't ventilate" (CICV): nu se poate intuba, nu se poate ventila cu BVM sau dispozitiv supralarindian. Se executa doar atunci când toate metodele anterioare au eșuat și pacientul este in pericol iminent.

Indicații posibile:

edem sever al gâtului (anafilaxie, edem angioneurotic, arsuri inhalatorii);
traumă facială majoră cu distrugerea anatomiei orofaringiene;
corp străin imposibil de îndepărtat prin manevre de bază sau Magill forceps;
eșec repetat al intubației orotraheale cu imposibilitatea ventilarii eficiente.

Reper anatomic — cricothyroid membrane:

Membrana cricotiroidiana se afla pe linia mediana a gâtului, intre cartilajul tiroid (marul lui Adam — proeminenta superioara) si cartilajul cricoid (primul inel traheal — proeminenta inferioara, mai mica). Palpati cu indexul pe linia mediana de sus in jos: simtiti mai intai marul lui Adam, apoi o depresiune moale (aceasta este membrana cricotiroidiana, aproximativ 1-1.5 cm sub marginea inferioara a tiroidului), apoi cartilajul cricoid mai dur sub ea. In urgenta, puteti identifica zona si prin glisarea degetului de la cartilajul tiroid in jos pana la prima depresiune moale.

Pași de execuție:

1. Extindeti gatul pacientului daca nu exista suspiciune de trauma cervicala.
2. Stabilizati laringele cu mana non-dominanta: policele si degetul mijlociu pe cartilajele tiroid, indexul palpeaza membrana.
3. Dezinfectati rapid zona cu compresa alcoolizata.
4. Cu o seringa de 10 mL partial umpluta cu ser fiziologic, conectata la un ac sau cateter de 14G, punctionati membrana pe linia mediana, orientand acul caudal (spre picioare) la 45° fata de piele.
5. Aspirati in timp ce avansati — aparitia bulelor de aer in seringa confirma pozitia intratraheala.
6. Avansati cateterul pe ac, scoateti acul (retineti cateterul), fixati-l cu degetele.
7. Conectati sistemul de ventilare (jet ventilation sau BVM cu adaptator) si ventilati.
8. Monitorizati EtCO2, chest rise si SpO2. Aceast metoda asigura oxigenare temporara (~30-45 min) — pregatiti un airway definitiv cat mai rapid.

Greșeli comune:

Identificare anatomica gresita: punctionarea cartilajului tiroid sau cricoid in loc de membrana — nu aspirati aer, reajustati.
Punctionare laterala (nu pe linia mediana): risc de lezare a arterei cricotiroidiene (care trece pe marginea superioara a membranei — punctionati intotdeauna in treimea mijlocie-inferioara a membranei).
Avansare fara confirmare aerului: asigurati-va ca aspirati aer liber inainte de a avansa cateterul.
Fixare insuficienta: cateterul se poate disloca la miscarea pacientului — mentineti manual pana la fixare ferma.

[SHOW]
```

 2.6 **Needle Thoracostomy / Needle Decompression (toracostomie cu ac / decompresie cu ac)**
```
[SHOW]
Needle decompression (toracostomie cu ac) tratează tension pneumothorax — acumularea progresivă de aer sub presiune în spațiul pleural, care colabează plămânul ipsilateral și deviază mediastinul, compromițând întoarcerea venoasă și producând stop cardiac dacă nu este tratată.

Semne clinice (nu toate trebuie să fie prezente):

distress respirator sever, rapid progresiv;
sunete respiratorii absente sau marcant reduse pe o parte (de regulă pe aceeași parte cu pneumotoraxul);
hipotensiune și tahicardie (semne de șoc);
turgescența venelor jugulare (JVD) — poate lipsi în hipovolemie;
deviatia traheei spre partea opusa (semn tardiv, de multe ori absent clinicb);
deteriorare rapida dupa traumă toracica sau la pacient ventilat mecanic.

Repere anatomice — doua locatii acceptate:

Locatia 1 (clasica) — ICS 2, MCL: Al 2-lea spatiu intercostal, pe linia medioclaviculara. Numarati coastele de la clavicule in jos — prima coasta e sub clavicule, spatiul al doilea e imediat sub coasta a 2-a. Punctionati pe MARGINEA SUPERIOARA a coastei a 3-a (NU pe marginea inferioara a coastei a 2-a — vasele si nervul intercostal trec pe fata inferioara a fiecarei coaste).

Locatia 2 (alternativa, recomandata la obezi) — ICS 4-5, AAL: Al 4-lea sau al 5-lea spatiu intercostal pe linia axilara anterioara (marginea anterioara a axilei). Permite cateter mai lung, acces mai bun la stratul pleural la pacienti cu perete toracic gros. Aceeasi regula: punctionati pe marginea superioara a coastei inferioare din spatiu.

Pași de execuție:

1. Identificati partea cu semne clinice de tension pneumothorax (sunete respiratorii absente, deteriorare).
2. Dezinfectati rapid zona cu compresa alcoolizata.
3. Folositi cateter-over-needle 14G (sau 16G), lungime ≥8 cm (preferabil 10-14 cm la pacienti cu perete gros).
4. Punctionati perpendicular pe suprafata toracica, avansand pe MARGINEA SUPERIOARA a coastei (nu dedesubt).
5. La penetrarea pleurei, simtiti o scadere a rezistentei si/sau auziti un rush de aer.
6. Avansati cateterul de plastic pana la baza pe ac, scoateti acul, lasati cateterul in loc.
7. Fixati cateterul cu leucoplast.
8. Reevaluati imediat: sunete respiratorii, SpO2, tensiunea arteriala, starea de constiinta. Imbunatatirea rapida confirma diagnosticul.
9. Aceasta este o masura temporara — pacientul necesita toracostomie sau dren pleural la spital.

Greșeli comune:

Locatie gresita (dedesubtul coastei): lezarea pachetului vasculo-nervos intercostal — sangerare intercostala. Intotdeauna punctionati pe marginea superioara a coastei inferioare.
Cateter prea scurt la pacienti obezi: cateterul de 4.5 cm (standard) nu ajunge la pleura — folositi 10-14 cm.
Partea gresita: decomprimati intotdeauna partea cu sunete absente sau diminuate. Decomprimarea partii gresite agraveza situatia.
Cateter indoit: cateterul moale se poate indoi la peretele toracic — verificati patenta dupa insertie (aerul trebuie sa iasa liber).
Omisiunea reevaluarii: daca starea nu se imbunatateste dupa decompresie, considerati decomprimare si pe partea opusa sau alta cauza de deteriorare.

[SHOW]
```

---

---

**3. ADVANCED WOUND CARE (TRATAMENT AVANSAT AL RĂNILOR)**
---

---

 3.1 **Steri-Strips (benzi adezive de închidere)**
```
[SHOW]
Steri-Strips pot închide lacerații mici, curate, cu margini apropiate. Nu se folosesc pe răni contaminate, mușcături, sângerări active sau lacerații adânci.

Cum se aplică:

1. Curățați și uscați zona.
2. Apropiați marginile rănii.
3. Aplicați benzile perpendicular pe lacerație, fără tensiune excesivă.

[SHOW]
```

 3.2 **Gunshot Wounds - GSW (răni prin împușcare)**
```
[SHOW]
GSW necesită control rapid al bleeding-ului, evaluarea airway/breathing și transport prioritar.

Chest GSW (rană toracică):

Folosiți occlusive dressing / chest seal (pansament ocluziv) pentru sucking chest wound.
Monitorizați tension pneumothorax și pregătiți needle decompression dacă protocolul indică.
Folosiți backboard doar dacă mecanismul sau starea pacientului o cere.

Abdominal GSW (rană abdominală):

Controlați bleeding-ul extern.
Dacă există evisceration (eviscerație), acoperiți cu sterile moist dressing (pansament steril umed).
Nu împingeți organele înapoi.

Extremity GSW (rană la membre):

Aplicați trauma dressing și direct pressure.
Folosiți tourniquet pentru hemoragie severă necontrolată.
Evaluați PMS distal și imobilizați dacă suspectați fractură.

Head/Neck GSW (rană la cap/gât):

Controlați bleeding-ul fără a compromite airway-ul.
Pregătiți airway management avansat.
Transport rapid și notificare medicală.
```

---

---

**4. IV / IO THERAPY (TERAPIE IV / IO)**
---

---

 4.1 **IV Access (acces intravenos)**
```
[SHOW]
IV access permite administrarea de fluide, medicamente și produse de sânge rapid și eficient. Este prima alegere pentru orice pacient ALS — stabiliți linia cât mai devreme, chiar dacă nu este necesară imediat.

Locatii preferate (in ordine de preferinta):

Fosa antecubitala (plica cotului): vena mediana cubitala — larga, fixa, vizibila. Prima alegere in urgenta. Dezavantaj: bratul trebuie mentinut relativ drept dupa insertie.
Antebratul: vena cefalica (lateral) si vena bazilica (medial) — accesibile, bune pentru perfuzii.
Dosul mainii: reteaua venoasa dorsala — accesibila dar mai dureroasa si mai fragila; folosita ca alternativa.
Vena jugulara externa: vizibila si accesibila la pacienti hipovolemici; necesita experienta; cateter 14-16G, directia spre umarul ipsilateral.

Selectia cateterului (gauge):

14G (portocaliu): resuscitare masiva, transfuzii rapide, traumă severa.
16G (gri): traumă, hemoragie, resuscitare fluidica.
18G (verde): standard pentru urgente — compatibil cu medicamente si fluide.
20G (roz): pacienți cu vene mici, vârstnici, copii; pentru medicamente (nu pentru transfuzii rapide).
22G (albastru): copii mici, vene extrem de fragile.

Locatii de evitat:

Brat cu mastectomie ipsilaterala (risc limfedem, infectie).
Brat cu fistula arteriovenoasa (dializa).
Membre cu fractura sau traumă severa distal de locatia propusa.
Zone cu celulita, flebita, hematom activ sau infectie locala.
Vezicula la articulatii mari fara stabilizare adecvata (genunchi, glezna — risc de indoire a cateterului la miscare).

Pași detaliati de execuție:

1. Alegeti vena, aplicati garoul (tourniquet) la 10-15 cm proximal de locatia de punctionare. Nu lasati garoul mai mult de 2 minute — vena se comprima si colabeza.
2. Cresteti umplerea venoasa: rugati pacientul sa stranga pumnul, tapotati blând vena, coboritii bratul sub nivelul inimii.
3. Dezinfectati zona cu tampon alcoolizat 70% — miscati circular dinspre centru spre exterior. Lasati sa se usuce 10-15 secunde (alcoolul umed iritatia si nu dezinfecteaza complet).
4. Intindeti pielea sub vena cu police-ul mainii non-dominante (tractiune distala).
5. Introduceti cateterul la unghi de 15-30° pentru vene profunde (fosa antecubitala), 10-15° pentru vene superficiale (dosul mainii), biseoul orientat in sus. Avansati pana apare flashback (sânge în camera de vizualizare).
6. Dupa aparitia flashback-ului: avansati inca 2-3 mm (pentru a fi sigur ca si bizoul cateterului este in vena), apoi avansati cateterul de plastic pana la flansa, concomitent retrăgând acul.
7. Eliberati garoul INAINTE de a scoate complet acul sau de a conecta perfuzia.
8. Aplicati presiune digitala pe vena proximal de vârful cateterului pentru a preveni sangele sa iasa.
9. Scoateti complet acul, conectati saline lock sau IV tubing. NU reintroduceti acul in cateter — riscul de sectionare a cateterului este real si poate produce embolie cu fragment de plastic.
10. Testati cu flush de 10 mL ser fiziologic: sa nu existe rezistenta, umflare locala (infiltratie) sau durere.
11. Fixati cateterul cu leucoplast sau dispozitiv comercial; documentati ora, locatia, calibrul.

Confirmarea pozitiei IV:

Sange in camera de flashback la insertie.
Flush de 10 mL NS fara rezistenta si fara infiltratie (umflatura locala = cateterul e in tesuturi, nu in vena).
Aspiratia usoara de sange prin saline lock dupa montare.
Fluidul curge liber la gravitatie sau pompa.

Greșeli comune:

Avansarea acului prea mult dupa flashback: strapungeti peretele posterior al venei — infiltratie imediata.
Neavansarea cateterului destul: cateterul ramane partial in afara venei; la miscare iese complet.
Reintroducerea acului in cateter: sectioneaza cateterul — categoric interzis.
Garoul lasat prea mult: vena se prabuseste si nu mai poti punctioneaza — eliberati dupa maxim 2 minute.
Fara testul de flush: medicamentele administrate pe o linie infiltrata pot cauza necroza tisulara (calciul, dopamina, noradrenalina sunt extrem de iritante extravasal).
Unghi prea mare: strapungeti vena direct; unghi prea mic: cateterul ramane sub piele.

Ce NU trebuie să faceți: Nu administrati niciun medicament inainte de a testa linia cu ser fiziologic. Nu fortati garoul pe un brat slabit sau cu fractura. Nu punctionati acelasi loc de mai mult de doua ori — mutati-va pe alt loc sau alta vena.
```

 4.2 **IO Access (acces intraosos)**
```
[SHOW]
IO access permite administrarea de medicamente, fluide si produse de sange direct in maduva osoasa, care comunica cu sistemul venos central. Onsetul medicamentelor este comparabil cu IV. Se utilizeaza cand IV nu poate fi obtinut in 2-3 tentative sau 60-90 secunde la pacientul critic.

Indicații: cardiac arrest, soc sever, traumă majoră, arsuri extinse, pediatrie in urgenta — orice situatie in care IV nu poate fi stabilit rapid si pacientul se deterioreaza.

Dispozitive uzuale: EZ-IO (drill electric — cel mai folosit in prespital), BIG (bone injection gun), Storm IO, ac manual Jamshidi.

Locatii de insertie (in ordine de preferinta):

Tibia proximala: CEA MAI FRECVENTA locatie. Reper: tuberozitatea tibiei (proeminenta osoasa sub rotula) — punctionati 2-3 cm inferior si medial de tuberozitate, pe fata plana mediala a tibiei. Fata sa va orientati, nu pe fata anterioara ascutita.
Tibia distala: 2-3 cm proximal de maleola mediala (glezna interna), pe fata mediala. Alternativa buna.
Humerus proximal: tuberculul mai mare al humerusului — locul cel mai rapid pentru sistemic absorption; bratul trebuie rotit intern (mana pe abdomen). Reper: 1-2 cm deasupra liniei chirurgicale a gâtului humeral. Necesita mai multa experienta.
Stern (manubriu sternal): dispozitiv specializat (FAST-1); rar folosit in prespital.
Calcaneu: alternativa rara; viteza de flux mai scazuta.

Contraindicatii pentru o locatie specifica:

Fractura recenta a osului tinta — trece in alt os.
Infectie sau arsura la locul de insertie.
IO anterior in acelasi os in ultimele 24-48h (site compromis).
Osteogeneza imperfecta sau alte boli osoase fragilitare.

Procedura cu EZ-IO:

1. Alegeti locatia si palpatiti reperele anatomice. Pozitionati membrul: pentru tibia proximala — genunchi flectat usor cu un suport sub el.
2. Dezinfectati zona.
3. Selectati acul EZ-IO: roz 15mm (copii 3-39 kg), albastru 25mm (adulti standard), galben 45mm (adulti obezi sau tibia distala/humerus).
4. Introduceti acul perpendicular pe suprafata osoasa (90° fata de os — NU in unghi). Avansati cu drillul la presiune usoara, fara a impinge prea tare.
5. La penetrarea cortexului osos simtiti o scadere brusca a rezistentei ("pop" sau "give") — opriti imediat drillul. Sondati nu mai adanc.
6. Scoateti mandrenul (trocar-ul), pastrati cateterul.
7. Confirmati pozitia: acul sta drept fara suport, aspirati: maduva osoasa sau sange confirma pozitia intraosara (nota: nu intotdeauna aspira — nu e obligatoriu daca restul criteriilor sunt ok).
8. Flush 10-20 mL NS pentru a cura cavitatea medulara. ATENTIE: dureaza mult (pacientul constient simte durere intensa). La pacient constient/semiconstient: injectati 2% lidocaina 20-40 mg IO lent inainte de flush sau medicatie.
9. Conectati tubulatura IV la cateterul IO si fixati.
10. Documentati ora si locatia. Acul trebuie inlocuit cu IV dupa maxim 24h (sau cat mai rapid).

Confirmarea pozitiei IO:

Acul sta drept fara suport extern.
Flush cu NS fara rezistenta semnificativa si fara infiltratie (umflatura in tesuturi moi adiacente).
Fluidele/medicamentele ruleaza la gravitatie sau cu pompa.
Aspiratie de maduva/sange (nu obligatorie dar confirmatorie).

Greșeli comune:

Locatie anatomica gresita: pe fata anterioara a tibiei in loc de cea mediala — osul e mai subtire acolo si mai dificil de accesat.
Nu perpendicular pe os: cateterul se indoaie sau nu penetreaza cortexul — asigurati-va ca drillul e 90° fata de os.
Oprire prematura: cateterul ramane in cortex, nu in cavitatea medulara; flush nu merge, aspirat nu merge.
Avansare excesiva: strapungeti cortexul posterior; cateterul e in tesuturile moi de cealalta parte — medicamentele se administreaza perimuscular.
Fara flush initial cu lidocaina la pacient constient: durere extrem de severa care poate cauza agitatie si compromiterea tehnicii.
Lasat acul IO la transfer sau in spital fara a informa echipa: IO trebuie inlocuit cu IV cat mai repede si raportat la predarea pacientului.
```

 4.3 **IV Fluids (fluide intravenoase)**
```
[SHOW]
Normal Saline (soluție salină): hidratare, flush, hipovolemie selectată.

Lactated Ringer's (Ringer lactat): pierdere de sânge, arsuri, traumă sau resuscitare fluidică, conform protocolului.

Reguli generale:

Nu administrați fluide inutil la pacienți stabili.
Monitorizați semnele de overload (supraîncărcare): dificultate respiratorie, edem, crackles.
Documentați tipul fluidului, volumul și răspunsul pacientului.
```

---

---

**5. CARDIAC MONITORING (MONITORIZARE CARDIACĂ)**
---

---

 5.1 **ECG/EKG (electrocardiogramă)**
```
[SHOW]
ECG monitorizează activitatea electrică a inimii și ajută la identificarea rhythm disturbances (tulburări de ritm), ischemiei sau stopului cardiac. EKG-ul 12 derivatii este obligatoriu in orice suspiciune de SCA (sindrom coronarian acut) si trebuie transmis spitalului cat mai devreme.

Indicații:

chest pain (durere toracică) — orice durere toracica de natura necunoscuta;
shortness of breath (dispnee) inexplicata;
syncope (lesin) sau pre-sincopa;
palpitations (palpitatii) sau ritm neregulat;
altered mental status la varstnic fara cauza clara;
post-ROSC monitoring — obligatoriu;
supradoza, intoxicatie cu medicamente cardiotoxice;
hiperkaliemie suspectata;
traumă toracica severa.

Plasarea derivatiilor pentru monitorizare (3-lead sau 4-lead):

RA — Right Arm (brat drept): sub clavicola dreapta sau pe bratul drept. Culoare: alb (ALBS mnemonic: Alb/Rosu/Galben/Verde = Alb-dr, Rosu-st, Galben-picior-st, Verde-picior-dr — sau conform codificarii locale).
LA — Left Arm (brat stang): sub clavicola stanga sau pe bratul stang.
LL — Left Leg (picior stang): sub costul stang, sau pe piciorul stang.
RL — Right Leg (picior drept): referinta/pamant — sub costul drept sau pe piciorul drept.
Derivatia II: cea mai utila pentru monitorizare de baza — vizualizeaza cel mai bine undele P si complexele QRS.

Plasarea electrozilor precordiali pentru EKG 12 derivatii:

V1: marginea dreapta a sternului, spatiul intercostal 4 (ICS 4R).
V2: marginea stanga a sternului, ICS 4 (ICS 4L).
V3: intre V2 si V4 (jumatate de drum).
V4: ICS 5, linia medioclaviculara stanga (apex cardiac).
V5: ICS 5, linia axilara anterioara stanga.
V6: ICS 5, linia axilara medie stanga (la nivelul V4 si V5).

Identificarea ICS 4 (reper cheie): Palpati unghiul lui Louis (junctiunea manubrio-sternala, aproximativ 5 cm sub incizura sternala superioara — simtiti o proeminenta orizontala pe mijlocul sternului). La nivelul acestui unghi se ataseaza coasta a 2-a. Numărati in jos: ICS 2, coasta 3, ICS 3, coasta 4, ICS 4.

Ritmuri uzuale de recunoscut in prespital:

NSR (ritm sinusal normal): ritm regulat 60-100/min, unda P inainte de fiecare QRS.
VF (fibrilatie ventriculara): aspect haotic, fara complexe recunoscute — soc imediat.
VT fara puls: complexe largi, regulate, >100/min, fara puls — soc imediat.
Asistola: linie dreapta sau cu activitate minimala — CPR, epinefrina.
PEA: orice ritm pe monitor fara puls palpabil — CPR, tratati cauza.
SVT/TPSV: ritm rapid regulat, ingust, 150-250/min — vagal maneuvers, adenozina.
AFib: ritm neregulat, lipsa undelor P, linie de baza iregulara — controlul frecventei.
Bradicardie sinusala: <60/min cu simptome — atropina, dopamina, TCP.
STEMI: supradenivelare ST ≥1 mm in ≥2 derivatii adiacente — notificare spital imediat.

Greșeli comune:

Electrozi pusi pe zone musculare sau articulatii: tremorul muscular produce artefacte care mimeaza VF sau alte ritmuri — puneti pe suprafete osoase (clavicola, stern, coaste).
Electrozi pusi pe rani sau haine: contact slab, artef act.
V1 si V2 puse prea sus (ICS 2 in loc de ICS 4): modifica morfologia QRS si poate masca STEMI posterior.
Lipsa interpretarii active: nu lasati monitorita sa ruleze fara sa verificati ritmul — schimbarile pot aparea brusc.
Confundarea artefactelor cu VF: verificati intotdeauna clinic (palpati pulsul, verificati pacientul) inainte de a soca un "ritm" de pe monitor.

[SHOW]
[SHOW]
```

 5.2 **Defibrillation / Cardioversion / Pacing (defibrilare / cardioversie / pacing)**
```
[SHOW]
Defibrillation (defibrilare): șoc nesincronizat pentru VF/pulseless VT în cardiac arrest.

Synchronized cardioversion (cardioversie sincronizată): șoc sincronizat pentru tahiaritmii instabile cu puls.

Transcutaneous pacing - TCP (stimulare transcutanată): pacing extern pentru bradicardie severă simptomatică.

Aceste proceduri se fac conform protocolului, cu monitorizare continuă, pregătire pentru airway management și comunicare clară cu echipajul.
```

---

## #2 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

 ADVANCED LIFE SUPPORT

---

---

---

**6. MEDICATION ADMINISTRATION (ADMINISTRAREA MEDICAMENTELOR)**
---

---

- Medicamentele ALS se administrează doar conform protocolului departamental și nivelului de certificare. Verificați alergii, contraindicații, doză, cale de administrare, ora administrării și efectul. Documentați fiecare administrare.

 6.1 **Routes (căi de administrare)**

```
[SHOW]
IV - Intravenous (intravenos): direct în venă. Onset rapid (30-60 sec pentru cele mai multe medicamente). Verificati intotdeauna patenta liniei cu 10 mL NS inainte de medicament. Dupa medicamentele bolus, urmariti cu 20 mL NS flush pentru a impinge medicamentul in circulatie.

IO - Intraosseous (intraosos): in maduva osoasa. Onset similar cu IV. Pot fi administrate toate medicamentele IV. Lidocaina IO (2 mg/kg, max 40 mg) inainte de flush la pacientul constient, pentru a reduce durerea severa a expansiunii medulare.

IM - Intramuscular (intramuscular): injectie in muschi. Onset mai lent (5-20 min). Volumul maxim per locatie:

Deltoid (umăr): max 2-3 mL. Reper: 2-3 cm sub procesul acromion, pe fetele laterala sau antero-laterala. Evitati zona posterioara (nervul radial).
Vastus lateralis (fata laterala a coapsei): preferata — max 5 mL. Reper: treimea medie a fetei anterioro-laterale a coapsei, intre genunchi si sold. Optima la sugari si pentru volume mari.
Ventrogluteal: max 5 mL; localizare mai precisa, evita nervul sciatic; reper: plaseaza palma pe trohanterul mare, indexul spre SIAS, degetul mijlociu spre creasta iliaca — injecteaza in V-ul format.

Aspiratia inainte de injectie nu este obligatorie la locatiile IM standard (dovezi actuale), dar ramane practica la unele protocoale.

IN - Intranasal (intranazal): prin mucoasa nazala cu MAD (Mucosal Atomization Device). Onset: 2-5 min. Volum maxim: 1 mL per nara (mai mult se scurge in faringe fara absorbtie). Daca doza necesita >2 mL total, impartiti intre ambele nari, asteptand 30-60 sec intre administrari. Util pentru: naloxone, midazolam, fentanyl (la copii mai ales).

SL - Sublingual (sublingual): sub limbă, absorbtie rapida (vasculatura bogata). Pacientul trebuie sa tina medicamentul sub limba — nu inghita, nu bea. Ex.: nitroglicerina 0.4 mg, ondansetron 4 mg (comprimat dispersibil).

PO - Oral (oral): inghitit. Onset lent (20-60 min). Numai la pacient constient, alert, cu reflex de inghitire intact si fara risc de varsatura. Ex.: aspirina mestecata (absorbtie mai rapida), ibuprofen, glucoza orala.

Inhaled (inhalator): prin nebulizer (atomizare in flux de O2 6-8 L/min) sau MDI cu spacer (4-8 puff-uri). Onset: 3-10 min. Medicamentul trebuie sa ajunga in caile respiratorii distale — pacientul respira adanc si lent prin masca nebulizatorului. Nebulizatorul continuu este preferat in bronhospasm sever.

Topical (topic): pe piele sau mucoasa. Ex.: paste de nitroglicerină (aplicata pe piele intacta, la piept sau brat), anestezice locale topice.

Ce NU trebuie să faceți:

Nu administrati medicamente IV pe o linie infiltrata (extravasal — necroza tisulara).
Nu amestecati medicamentele incompatibile in aceeasi seringa sau aceeasi linie (ex. calciu + bicarbonat = precipitat alb).
Nu administrati pe cale IM medicamente care necesita IV pentru onset rapid sau titration (ex. epinefrina in cardiac arrest).
Nu omiteti flush-ul de 20 mL NS dupa medicamentele bolus IV — medicamentul ramane in tubulatura altfel.
```

 6.2 **Medication Groups (grupe de medicamente)**

 **IV FLUIDS (fluide IV)**
```
[SHOW]
Normal Saline - 0.9% NaCl (soluție salină izotona)
Indicatii: hipovolemie, deshidratare, flush IV/IO intre medicamente, carrier pentru perfuzii.
Contraindicatii: edem pulmonar acut (cu precautie), hipernatremie, ICC decompensata (limitati volumul).
Doza: 250-1000 mL bolus; ajustati dupa raspunsul clinic si tensiunea arteriala.
Cai: IV, IO.

Lactated Ringer's (Ringer lactat)
Indicatii: traumă cu pierdere mare de sange, arsuri extinse, resuscitare fluidica; preferat fata de NS in traumă severa.
Contraindicatii: hiperkaliemie (contine K+); insuficienta renala severa; TBI sever (solutia e usor hipotona - cu precautie).
Doza: 1-2 L bolus in traumă; ajustati dupa raspuns.
Cai: IV, IO.
```

 **CARDIAC ARREST & VASOPRESORI**
```
[SHOW]
Epinephrine / Adrenaline (epinefrina/adrenalina)
Indicatii: cardiac arrest (VF, pVT, PEA, asistola); anafilaxie severa; bronhospasm sever; bradicardie simptomatica refractara la atropina.
Contraindicatii: nu exista contraindicatii absolute in cardiac arrest. In anafilaxie: cu precautie la HTA severa cunoscuta, dar beneficiul depaseste riscul.
Doza: cardiac arrest: 1 mg IV/IO la fiecare 3-5 min; anafilaxie: 0.3-0.5 mg IM (coapsă - vastus lateralis); bronhospasm sever: 0.3 mg SC/IM.
Cai: IV, IO, IM, SC.

Vasopressin (vasopresina)
Indicatii: cardiac arrest - alternativa la prima sau a doua doza de epinefrina; soc vasodilatator (septic, neurogen) refractar.
Contraindicatii: nu exista contraindicatii absolute in cardiac arrest. Precautie la boli coronariene cunoscute in afara stopului.
Doza: 40 UI IV/IO doza unica (inlocuieste prima sau a doua doza de epinefrina; nu se repeta).
Cai: IV, IO.

Norepinephrine / Noradrenaline (noradrenalina)
Indicatii: soc septic, soc distributiv, hipotensiune severa refractara la volum.
Contraindicatii: hipovolemie necompensata (trateati intai volumul); cu precautie la aritmii.
Doza: 0.01-3 mcg/kg/min IV, titrat; incepeti cu 0.1 mcg/kg/min si cresteti pana la TA tinta (MAP >65 mmHg).
Cai: IV perfuzie continua (ideal linie centrala; linie periferica acceptabila pe termen scurt in prespital).

Dopamine (dopamina)
Indicatii: soc cardiogen cu TA sistolica <70-80 mmHg; bradicardie simptomatica refractara la atropina.
Contraindicatii: feocromocitom; FV/TV necontrolata; hipovolemie necompensata.
Doza: 2-5 mcg/kg/min (efect renal/dopaminergic); 5-10 mcg/kg/min (efect cardiac); >10 mcg/kg/min (vasoconstrictie). Titrati dupa raspuns.
Cai: IV perfuzie continua.
```

 **ANTIARITMICE & CARDIAC**
```
[SHOW]
Amiodarone (amiodarona)
Indicatii: VF/pVT refractare la defibrilare (cardiac arrest); VT cu puls stabil; FA cu raspuns ventricular rapid.
Contraindicatii: bradicardie severa; BAV grad II/III (fara pacemaker); soc cardiogen sever; hipotensiune severa; hipersensibilitate la iod.
Doza: cardiac arrest: 300 mg IV/IO bolus, a doua doza 150 mg; VT cu puls: 150 mg IV in 10 min.
Cai: IV, IO.

Lidocaine (lidocaina)
Indicatii: VT cu puls stabil; VF refractara (alternativa amiodaronei daca aceasta nu e disponibila); analgezie locala la proceduri.
Contraindicatii: BAV grad II/III; bradicardie severa; soc cardiogen; hipersensibilitate la anestezice locale de tip amida.
Doza: 1-1.5 mg/kg IV/IO bolus; a doua doza 0.5-0.75 mg/kg la 5-10 min; max 3 mg/kg total.
Cai: IV, IO.

Adenosine (adenozina)
Indicatii: TPSV (tahicardie paroxistica supraventriculara) - conversie la ritm sinusal si diagnostic diferential.
Contraindicatii: BAV grad II/III; WPW cu FA/flutter (poate precipita FV); astm sever (bronhospasm); hipersensibilitate.
Doza: 6 mg IV rapid bolus (3 sec) urmat imediat de flush 20 mL NS; daca nu raspunde in 1-2 min: 12 mg IV rapid (repetabil o data).
Cai: IV rapid (preferabil vena antecubitala sau centrala; linie periferica distala necesita doza mai mare).

Procainamide (procainamida)
Indicatii: VT cu puls stabil la pacient hemodinamic stabil; FA cu durata sub 48h (fara WPW, fara ICC severa).
Contraindicatii: QT prelungit preexistent; torsada de varf; bloc de ramura larg; soc cardiogen; insuficienta cardiaca severa; miastenia gravis; hipersensibilitate.
Doza: 20-50 mg/min IV pana la max 17 mg/kg total; opriti la conversie la ritm sinusal, largire QRS >50% din valoarea initiala sau hipotensiune.
Cai: IV perfuzie lenta (NU bolus).

Atropine (atropina)
Indicatii: bradicardie simptomatica (simptome: hipotensiune, sincopa, alterare constienta, angina); intoxicatii cu organofosforice (cu 2-PAM); asistola (doza unica, mai putin eficienta).
Contraindicatii: tahicardie (>100/min) - contraindicatie relativa; glaucom unghi inchis; tachiaritmii.
Doza: bradicardie: 0.5-1 mg IV/IO la 3-5 min, max 3 mg total; organofosforice: 2-4 mg IV, repetat la 5-10 min pana la uscarea secretiilor bronhice.
Cai: IV, IO, IM (mai putin predictibil).

Verapamil
Indicatii: TPSV refractara la adenozina; FA/flutter cu raspuns ventricular rapid la pacienti stabili hemodinamic (fara ICC, fara WPW).
Contraindicatii: WPW sau sindrom de preexcitatie; soc cardiogen; BAV grad II/III; hipotensiune; VT; beta-blocante IV administrate recent (risc stop cardiac).
Doza: 2.5-5 mg IV in 2-3 min; se poate repeta 5-10 mg la 15-30 min, max 20 mg.
Cai: IV lent.

Metoprolol
Indicatii: FA/flutter cu raspuns ventricular rapid; tahicardie sinusala simptomatica; angina; urgente hipertensive cu tahicardie.
Contraindicatii: bradicardie (<50/min); BAV grad II/III; bronhospasm activ/astm sever; soc cardiogen; ICC decompensata acuta.
Doza: 5 mg IV in 2 min la fiecare 5 min, max 3 doze (15 mg total).
Cai: IV.

Labetalol
Indicatii: urgente hipertensive cu tahicardie; disectie de aorta; eclampsie (cu precautie).
Contraindicatii: astm/BPOC sever; bradicardie; BAV; ICC decompensata; hipotensiune.
Doza: 20 mg IV in 2 min; se poate repeta 40-80 mg la 10 min, max 300 mg total.
Cai: IV.

Nitroglycerin (nitroglicerina)
Indicatii: durere toracica de tip anginos; STEMI (cu TA adecvata); edem pulmonar acut.
Contraindicatii: TA sistolica <90 mmHg; infarct de ventricul drept (VD); consum de inhibitori PDE-5 (sildenafil/Viagra) in ultimele 24h (vardenafil 48h, tadalafil 72h); bradicardie <50/min; tahicardie >100/min fara ICC.
Doza: 0.4 mg SL (tableta sau spray); repetati la 5 min daca TA permite; max 3 doze fara supraveghere medicala avansata.
Cai: SL.

Furosemide / Lasix
Indicatii: edem pulmonar acut; retentie hidrica severa; insuficienta cardiaca decompensata cu supravolumizare.
Contraindicatii: anurie; hipovolemie; hipokaliemie severa; hipersensibilitate la sulfonamide; deshidratare.
Doza: 20-80 mg IV lent (1-2 min); la pacienti cu tratament cronic cu furosemide, doza poate fi egala sau dubla fata de doza uzuala orala.
Cai: IV.

Calcium Chloride (clorura de calciu)
Indicatii: hipocalcemie simptomatica; hiperkaliemie cu modificari EKG (stabilizare membranara); supradoza de blocante de canale de calciu sau beta-blocante; hipermagnezemie.
Contraindicatii: hipercalcemie; intoxicatie cu digitalice (creste toxicitatea); FV activa; nu amestecati cu bicarbonat in acelasi linie (precipita).
Doza: 500-1000 mg IV lent (1 g in 3-5 min).
Cai: IV lent (iritant venos sever; evitati infiltratia; administrati in vena larga).

Sodium Bicarbonate (bicarbonat de sodiu)
Indicatii: acidoza metabolica severa (pH <7.1); hiperkaliemie cu instabilitate hemodinamica; supradoza de antidepresive triciclice (ATC); cardiac arrest prelungit (dupa 10+ min de RCP).
Contraindicatii: alcaloza metabolica sau respiratorie existenta; edem pulmonar (sodiu suplimentar); nu administrati in aceeasi linie cu calciu (precipita) sau cu catecolamine.
Doza: 1 mEq/kg IV/IO; se poate repeta 0.5 mEq/kg la 10 min ghidat de gazometrie.
Cai: IV, IO (administrat lent; nu amestecati cu alte medicamente in aceeasi linie).

Aspirin (acid acetilsalicilic)
Indicatii: suspiciune de STEMI sau SCA (sindrom coronarian acut) - inhibitie plachetara precoce.
Contraindicatii: alergie confirmata la aspirina/AINS; ulcer peptic activ cu hemoragie; copii sub 16 ani (sindrom Reye); coagulopatie severa.
Doza: 162-325 mg PO masticata (mestecata pentru absorbtie rapida, nu inghitita intreaga).
Cai: PO (masticata).
```

 **HEMORAGIE & COAGULARE**
```
[SHOW]
Tranexamic Acid - TXA (acid tranexamic)
Indicatii: traumă cu hemoragie severa; hemoragie postpartum; epistaxis sever necontrolat; orice hemoragie masiva. Eficient administrat in primele 3 ore de la traumă (ideal sub 1 ora).
Contraindicatii: tromboembolism activ (TEP, TVP); coagulare intravasculara diseminata (CID) activa; alergie.
Doza: 1 g IV in 10 min (prima doza prespital); a doua doza 1 g IV in 8h se administreaza la spital.
Cai: IV (perfuzie lenta; NU bolus rapid - risc hipotensiune si crize).
```

 **ANALGEZIE (CONTROLUL DURERII)**
```
[SHOW]
Fentanyl (fentanil)
Indicatii: durere severa (traumă, arsuri, fracturi); analgezie pre-intubatie; sedare procedurala; preferabil morfina cand hipotensiunea este o preocupare.
Contraindicatii: hipotensiune severa necontrolata; depresie respiratorie activa fara suport; hipersensibilitate la opioide.
Doza: 1-2 mcg/kg IV/IO lent (2-3 min; onset rapid); 2 mcg/kg IM; 2-3 mcg/kg IN. Se poate titrat cu doze suplimentare de 25-50 mcg IV la 5-10 min.
Cai: IV, IO, IM, IN.

Morphine (morfina)
Indicatii: durere severa; edem pulmonar acut (vasodilatatie venoasa + anxioliza).
Contraindicatii: hipotensiune (<90 mmHg sistolica); depresie respiratorie activa; astm activ sever; hipersensibilitate; disfunctie renala severa (acumulare metaboliti activi).
Doza: 2-4 mg IV la 5-15 min titrat; 5-10 mg IM.
Cai: IV, IM.

Ketorolac / Toradol
Indicatii: durere moderata spre severa (colica renala, fracturi, migrena); alternativa non-opioid la fentanil/morfina.
Contraindicatii: insuficienta renala (chiar si moderata); ulcer peptic activ sau hemoragie GI; alergie la AINS; sarcina (al treilea trimestru); coagulopatie; varsta inaintata (reduceti doza).
Doza: 30 mg IV/IM (15 mg la varstnici sau cu functie renala redusa); 10 mg PO. Maxim 5 zile total.
Cai: IV, IM, PO.

Acetaminophen / Paracetamol / Tylenol
Indicatii: durere moderata; febra; adjuvant in analgezie multimodala; preferat cand AINS sunt contraindicate (renali, ulcer, sarcina, varstnici).
Contraindicatii: insuficienta hepatica severa; alergie; doza zilnica existenta apropiata de limita (atentie la supradoza; maxim 4 g/zi adult sau 3 g/zi la alcoolici).
Doza: 1000 mg IV in 15 min (forma IV); 650-1000 mg PO.
Cai: IV (perfuzie 15 min), PO.

Meperidine / Demerol
Indicatii: durere moderata spre severa; rigori post-anestezie (doza mica).
Contraindicatii: IMAO in ultimele 14 zile (interactiune letala - hipertermie, crize, coma); insuficienta renala (acumulare normeperidina - neurotoxica si proconvulsivanta); epilepsie; hipersensibilitate.
Doza: 25-100 mg IV lent sau IM.
Cai: IV lent, IM.

Entonox (50% N2O + 50% O2)
Indicatii: durere moderata; anxietate la proceduri; accidente cu traumă minora-moderata; nastere.
Contraindicatii: traumă toracica/pneumotorax (N2O difuzeaza in spatii inchise si creste presiunea); alterare constienta; sarcina in primul trimestru; deficienta de vitamina B12; embolie gazoasa; obstructie intestinala.
Doza: autoadministrat prin masca sau piesa bucala la cerere (pacientul controleaza singur inhalarea).
Cai: Inhaled (masca etansa auto-administrata).

Ibuprofen
Indicatii: durere usoara spre moderata; febra; inflamatie; fracturi minore.
Contraindicatii: insuficienta renala; ulcer peptic activ; sarcina (al treilea trimestru); coagulopatie; hipersensibilitate la AINS; insuficienta cardiaca severa.
Doza: 400-600 mg PO la 6-8h; max 2400 mg/zi.
Cai: PO.
```

 **INTOXICATII & SUPRADOZE**
```
[SHOW]
Naloxone / Narcan
Indicatii: supradoza cu opioide (depresie respiratorie, mioza, alterare constienta, istoric de consum); opioid-induced respiratory depression post-ALS.
Contraindicatii: fara contraindicatii absolute. Precautie la pacienți dependenti - poate precipita sevraj violent, agitatie si convulsii.
Doza: 0.4-2 mg IV/IM/IN; repetati la 2-3 min pana la imbunatatire respiratorie (FR >12/min, SpO2 adecvata); opioid cu durata lunga (metadona, fentanil patch) poate necesita perfuzie continua.
Cai: IV, IO, IM, IN.

Hydroxocobalamin / Cyanokit (hidroxocobalamina)
Indicatii: intoxicatie cu cianuri; victime ale incendiilor cu inhalare de fum in spatii inchise + acidoza lactica severa + alterare constienta inexplicabila + instabilitate cardiovasculara. Leaga direct ionul de cianura, formand cianocobalamina eliminata urinar.
Contraindicatii: fara contraindicatii absolute in urgenta. Nota: decoloreaza temporar pielea, mucoasele si urina in rosu-roz (interferenta cu pulsoximetria si unele analize de laborator).
Doza: 5 g IV in 15 min (prima doza adult); se poate repeta 5 g (pana la max 15 g) in functie de raspuns.
Cai: IV perfuzie (solutie de 5 g/200 mL).

Pralidoxime / 2-PAM (pralidoxim)
Indicatii: intoxicatii cu organofosforice (pesticide, agenti nervoasi) - reactivator de acetilcolinesteraza; administrat INTOTDEAUNA impreuna cu Atropine.
Contraindicatii: intoxicatii cu carbamate (poate agrava toxicitatea); insuficienta renala severa (ajustare doza); hipersensibilitate.
Doza: 1-2 g IV in 15-30 min (perfuzie lenta; bolus rapid cauzeaza tahicardie, rigiditate musculara, stop respirator); perfuzie de intretinere 200-400 mg/h.
Cai: IV perfuzie lenta.

Activated Charcoal (carbune activat)
Indicatii: ingestii toxice recente (sub 1h, ideal sub 30 min) la pacient constient si cooperant; reduce absorbtia multor medicamente si toxine.
Contraindicatii: alterare constienta sau risc de aspiratie; ingestie de corozivi (acizi, baze), hidrocarburi, alcooli, metale grele, fier, litiu (nu adsorb la carbune); obstructie intestinala; voma activa.
Doza: 25-50 g PO (adult); 1 g/kg la copii (max 50 g).
Cai: PO (suspendat in apa; servit cu pai).

Diazepam / Valium
Indicatii: crize epileptice active; sevraj alcoolic sever; anxietate severa; sedare procedurala (adjuvant).
Contraindicatii: depresie respiratorie severa fara suport; glaucom unghi inchis; hipotensiune severa; hipersensibilitate la benzodiazepine.
Doza: crize: 5-10 mg IV/IO (2 mg/min); repetati la 5-10 min, max 30 mg. IM - absorbtie impredictibila (preferati midazolam IM). Rectal: 0.2-0.5 mg/kg (gel rectal).
Cai: IV, IO, rectal.
```

 **RESPIRATOR**
```
[SHOW]
Salbutamol / Ventolin / Albuterol
Indicatii: bronhospasm (astm, BPOC exacerbat, anafilaxie cu bronhospasm); hiperkaliemie (adjuvant temporar - redistribuie K+ intracelular).
Contraindicatii: tahicardie severa simptomatica (relativa; beneficiul depaseste riscul in bronhospasm sever); hipersensibilitate.
Doza: 2.5 mg nebulizat in 3 mL NS (nebulizator continuu 10-15 min); 4-8 puff MDI cu spacer; repetabil la 20 min in criza severa.
Cai: Inhaled (nebulizer, MDI).

Ipratropium Bromide / Atrovent
Indicatii: bronhospasm sever/status asthmaticus; BPOC exacerbat; combinat cu Salbutamol pentru efect sinergic (bronhodilatatie duala).
Contraindicatii: hipersensibilitate la atropina sau bromura de ipratropiu; evitati contactul cu ochii (precipita glaucom acut).
Doza: 0.5 mg nebulizat (combinat cu Salbutamol in acelasi nebulizator); repetabil la 30 min (max 3 doze).
Cai: Inhaled (nebulizer).

Magnesium Sulfate (sulfat de magneziu)
Indicatii: status asthmaticus sever refractar la bronhodilatatoare; torsada de varf (VT polimorf cu QT lung); preeclampsia/eclampsia (previne convulsii); hipomagnezemie simptomatica.
Contraindicatii: hipotensiune severa; insuficienta renala severa (acumulare - toxica); bloc neuromuscular; bradicardie severa.
Doza: astm sever: 2 g IV in 20 min; torsada de varf: 1-2 g IV rapid (1-2 min); eclampsia: 4 g IV in 10 min, apoi perfuzie 1-2 g/h.
Cai: IV (perfuzie; NU bolus rapid in afara torsadei).

Methylprednisolone (metilprednisolon)
Indicatii: astm/BPOC exacerbat sever; anafilaxie (adjuvant - efectul apare in 4-6h); exacerbari inflamatorii severe.
Contraindicatii: infectie sistemica activa necontrolata (relativa in urgenta acuta); hipersensibilitate. Fara contraindicatii absolute in urgenta.
Doza: 1-2 mg/kg IV (max 125 mg doza initiala); se poate repeta la 6h conform protocol.
Cai: IV, IO.

Dexamethasone (dexametazona)
Indicatii: exacerbari COPD/astm; anafilaxie (adjuvant); edem laringian post-extubatie; crup laringian; varsaturi severe (profilaxie).
Contraindicatii: infectie activa necontrolata (relativa); diabet necontrolat (creste glicemia semnificativ); hipersensibilitate.
Doza: urgente respiratorii/alergice: 8-10 mg IV/IM; crup: 0.6 mg/kg IM/PO (max 16 mg).
Cai: IV, IM, PO.
```

 **DIABET & METABOLIC**
```
[SHOW]
Dextrose - D50W / D10W (dextroza)
Indicatii: hipoglicemie documentata (glicemie <60 mg/dL) sau simptomatica cu glicemie <70 mg/dL.
Contraindicatii: fara contraindicatii absolute. Precautie in AVC ischemic acut (hiperglicemia agraveaza leziunea cerebrala - preferati D10W in loc de D50W).
Doza: D50W: 25 g (50 mL) IV/IO; D10W: 250 mL IV (preferata in AVC sau copii). Repetati glucometria la 5-10 min si repetati doza daca hipoglicemia persista.
Cai: IV, IO.

Glucagon
Indicatii: hipoglicemie la pacient fara acces IV; supradoza de beta-blocante (creste contractilitatea independenta de receptorii beta); supradoza de blocante de canale de calciu.
Contraindicatii: feocromocitom (precipita criza hipertensiva); insulinom; alergie la glucagon sau la proteinele din ou.
Doza: hipoglicemie: 1 mg IM/SC; supradoza beta-blocker/calciu-blocant: 3-10 mg IV bolus lent, apoi perfuzie 3-5 mg/h.
Cai: IM, SC, IV.

Oral Glucose (glucoza orala)
Indicatii: hipoglicemie usoara la pacient constient, alert si capabil sa inghita in siguranta.
Contraindicatii: alterare constienta; incapacitate de a inghiti; voma activa; hipoglicemie severa (necesita IV).
Doza: 15-20 g PO (gel glucoza, comprimate sau 150 mL suc de fructe). Repetati glucometria la 15 min.
Cai: PO.

Thiamine / Vitamin B1 (tiamina)
Indicatii: administrata INAINTEA sau concomitent cu Dextrose la pacienti cu etilism cronic, malnutritie severa sau coma cu etiologie necunoscuta - previne encefalopatia Wernicke (leziune cerebrala ireversibila precipitata de glucoza in absenta tiaminei).
Contraindicatii: hipersensibilitate (rara).
Doza: 100 mg IV lent (diluat in 100 mL NS in 10 min) sau IM.
Cai: IV (diluat, lent), IM.
```

 **GREATA & VOMA**
```
[SHOW]
Ondansetron / Zofran (ondansetron)
Indicatii: greata si voma din orice cauza - traumă, ALS, AVC, migrena, post-procedura, efecte secundare medicamentoase; antiemetic de electie in prespital.
Contraindicatii: QT prelungit preexistent (creste usor intervalul QT - monitorizati EKG); hipersensibilitate.
Doza: 4 mg IV/IM/SL; repetabil o data la 4-6h.
Cai: IV, IM, SL (comprimate dispersibile sublinguale - util fara acces IV).

Metoclopramide / Maxeran
Indicatii: greata/voma; procinetic gastric; migrena (adjuvant).
Contraindicatii: obstructie mecanica GI; feocromocitom (criza hipertensiva); epilepsie (scade pragul convulsiv); boala Parkinson; hipersensibilitate; NU administrati IV rapid (anxietate, akatizie, crampe abdominale severe).
Doza: 10-20 mg IV in 5-10 min (perfuzie lenta); 10 mg IM.
Cai: IV lent, IM.

Dimenhydrinate / Gravol
Indicatii: greata/voma; rau de miscare; labirintita acuta (vertij periferic).
Contraindicatii: glaucom unghi inchis; hipertrofie de prostata; epilepsie; alterare constienta; conducere auto (sedativ); hipersensibilitate.
Doza: 50 mg IV/IM; 50-100 mg PO.
Cai: IV, IM, PO.
```

 **ALERGII & ANAFILAXIE**
```
[SHOW]
Epinephrine (anafilaxie) — vezi sectiunea Cardiac Arrest & Vasopresori.

Diphenhydramine / Benadryl
Indicatii: anafilaxie (adjuvant la Epinefrina - NU inlocuitor); reactii alergice usoare-moderate; urticarie; reactii la transfuzii. ATENTIE: nu administrati niciodata in locul Epinefrinei in anafilaxie severa.
Contraindicatii: glaucom unghi inchis; hipertrofie de prostata severa; alterare constienta avansata (potentiaza sedarea); hipersensibilitate.
Doza: 25-50 mg IV lent / IM; 25-50 mg PO (forme usoare).
Cai: IV lent, IM, PO.

Methylprednisolone / Dexamethasone — vezi sectiunea Respirator.
```

 **SEDATIVE & RSI (RAPID SEQUENCE INTUBATION)**
```
[SHOW]
Midazolam / Versed
Indicatii: sedare procedurala; pre-medicatie RSI; crize epileptice (preferabil IM daca fara acces IV); anxietate acuta severa; amnezie pre-procedura.
Contraindicatii: hipotensiune severa; depresie respiratorie fara suport; hipersensibilitate la benzodiazepine.
Doza: sedare procedurala: 0.05-0.1 mg/kg IV (2-5 mg adult); RSI (cu Ketamine): 0.1 mg/kg IV; crize IM: 5-10 mg IM (onset 5-10 min).
Cai: IV, IM, IN, SL, rectal.

Ketamine
Indicatii: anestezie disociativa pentru proceduri dureroase (reductii, plagi); agent de inductie RSI (mai ales in traumă si hipotensiune); analgezie sub-anestezica la doze mici; bronhospasm sever (bronhodilatator direct).
Contraindicatii: HTA severa necontrolata (creste TA si FC - relativa); psihoza activa; hipersensibilitate; sarcina (precautie). NOTA: contraindicatia in TBI este depasita de ghidurile actuale - Ketamine este sigura in TBI.
Doza: inductie/proceduri: 1-2 mg/kg IV (onset 30-60 sec) sau 4-6 mg/kg IM (onset 3-5 min); analgezie sub-disociativa: 0.1-0.3 mg/kg IV in 15 min.
Cai: IV, IM.

Succinylcholine
Indicatii: relaxant muscular depolarizant pentru RSI; onset ultra-rapid (30-60 sec), durata scurta (8-12 min) - ideal cand se anticipeaza intubatie dificila.
Contraindicatii: hiperkaliemie severa sau risc crescut (arsuri >24-48h, sectiune medulara, crush syndrome, imobilizare prelungita >72h, miopatie); susceptibilitate la hipertermie maligna; pseudocolinesteraza deficienta (durata prelungita); mioglobinurie; fasciculatii la copii mici (preferati Rocuronium).
Doza: 1-2 mg/kg IV (doza uzuala 1.5 mg/kg); 3-4 mg/kg IM daca nu exista acces IV.
Cai: IV, IM.

Rocuronium / Zemuron
Indicatii: relaxant muscular nedepolarizant pentru RSI - ales cand Succinylcholine este contraindicata; durata mai lunga (30-60 min).
Contraindicatii: hipersensibilitate; miastenia gravis (efect extrem de prelungit - precautie majora).
Doza: RSI: 1.2 mg/kg IV (doza mare pentru onset rapid de 60-90 sec, comparabil cu Succinylcholine); intubatie facilitata non-urgenta: 0.6 mg/kg IV.
Cai: IV.

Lorazepam / Ativan
Indicatii: anxietate severa; crize epileptice/status epilepticus (IV - eficienta ridicata); sedare; amnezie procedurala.
Contraindicatii: depresie respiratorie severa; glaucom unghi inchis; hipotensiune severa; hipersensibilitate la benzodiazepine.
Doza: anxietate/sedare: 0.05-0.1 mg/kg IV/IM (2-4 mg adult); crize: 4 mg IV lent (2 mg/min), repetabil o data dupa 5 min.
Cai: IV, IM.

Haloperidol
Indicatii: agitatie severa si psihoza acuta; delir hiperactiv; excitatie extrema fara componenta anxioasa majora.
Contraindicatii: QT prelungit (risc torsada de varf - monitorizati EKG); sindrom parkinsonian (agraveaza rigiditatea); epilepsie (scade pragul convulsiv); hipotensiune severa; hipersensibilitate.
Doza: 5-10 mg IM (debut 20-40 min); 2-5 mg IV lent (debut rapid, risc QT mai mare).
Cai: IM (preferat in prespital), IV lent.
```

 **CRIZE EPILEPTICE (STATUS EPILEPTICUS)**
```
[SHOW]
Ordinea terapeutica in status epilepticus: Benzodiazepina (prima linie) → Levetiracetam sau alt antiepileptic IV (linia a doua) → Anestezie generala (linia a treia, spital).

Diazepam / Valium — prima linie
Indicatii: crize epileptice active; sevraj alcoolic.
Doza: 5-10 mg IV (2 mg/min); repetati la 5-10 min, max 30 mg. Rectal: 0.2-0.5 mg/kg (gel).
Cai: IV, IO, rectal. (IM - absorbtie impredictibila, evitati in favoarea Midazolam IM.)

Midazolam / Versed — prima linie (preferabil IM fara acces IV)
Indicatii: crize epileptice active; ales atunci cand nu exista acces IV (IM sau IN cu absorbtie rapida si predictibila).
Doza: 5-10 mg IM; 5 mg IN; 5-10 mg IV.
Cai: IM, IN, IV.

Lorazepam / Ativan — prima linie (IV)
Indicatii: status epilepticus activ; durată de actiune mai lunga decat diazepam IV.
Doza: 4 mg IV lent (2 mg/min); repetabil o data dupa 5 min.
Cai: IV.

Levetiracetam / Keppra — linia a doua
Indicatii: status epilepticus refractar la benzodiazepine; crize in sarcina (alternativa mai sigura decat fenitoina pentru fat); crize repetitive fara status.
Contraindicatii: insuficienta renala severa (ajustare doza); hipersensibilitate. Nu produce sedare semnificativa - avantaj major in monitorizarea neurologica.
Doza: 20-60 mg/kg IV (uzual 1000-3000 mg adult) in 15 min; rata maxima 500 mg/min.
Cai: IV perfuzie.
```

 **ANESTEZICE**
```
[SHOW]
Methohexital
Indicatii: inductie anestezie pentru proceduri scurte (cardioversie electiva, reduceri ortopedice, sutura extinsa); barbituric ultra-scurt.
Contraindicatii: porfirie acuta (absoluta - precipita criza); hipotensiune; obstructie acuta a cailor respiratorii; hipersensibilitate la barbiturice; istoric de convulsii (scade pragul).
Doza: 1-1.5 mg/kg IV (onset 30 sec, durata 5-7 min).
Cai: IV.
```

 **ANTIBIOTICE**
```
[SHOW]
Clarithromycin (claritromicina)
Indicatii: infectii respiratorii (pneumonie comunitara, bronsita bacteriana, sinuzita); rar indicata in prespital - conform protocol.
Contraindicatii: prelungire QT preexistenta; interactiuni medicamentoase semnificative (statine, warfarina, carbamazepina - creste nivelul plasmatic); insuficienta hepatica severa; hipersensibilitate la macrolide.
Doza: 500 mg PO la 12h; forma IV 500 mg la 12h (mediu spitalicesc).
Cai: PO (primar in prespital).
```

 **SARCINA & NASTERE**
```
[SHOW]
Oxytocin (oxitocina)
Indicatii: hemoragie postpartum (dupa expulzia placentei, pentru contractia uterina); nastere prelungita cu contractii insuficiente (augmentare - doar in mediu controlat).
Contraindicatii: fetal distress cand nasterea nu este iminenta; prezentatie anormala (transversa, podalie); cicatrice uterina anterioara (relativa - risc ruptura); NU administrati IV bolus direct (hipotensiune severa, colaps).
Doza: hemoragie postpartum: 10 UI IM (metoda de electie prespital) sau 10-20 UI in 500-1000 mL NS IV perfuzie (titrat); NU bolus IV direct.
Cai: IM (preferat prespital), IV perfuzie.
```

---

---

**7. ALS HANDOFF (PREDARE ALS)**
---

---

- Predarea către spital sau alt echipaj trebuie să fie scurtă și clară:  - chief complaint (plângerea principală); - MOI/NOI (mecanismul de rănire/natura bolii); - vitals și trend; - proceduri efectuate; - medicamente, doze, ore și răspuns; - schimbări în starea pacientului; - orice risc special: airway dificil, bleeding, shock, overdose, cardiac rhythm.

---
