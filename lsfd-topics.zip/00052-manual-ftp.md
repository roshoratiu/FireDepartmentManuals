# Manual FTP

- **Topic ID:** 52
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=52
- **Posts:** 1

---

## #1 — Kellan Dunley

![](https://i.imgur.com/2jlMxHe.png)

OFFICE OF THE FIRE CHIEF

---

 **PROGRAMUL DE FORMARE PE TEREN (FTP)**
 **MANUAL OFICIAL**
 Departamentul de Pompieri din Los Santos
 *Biroul de Instruire și Dezvoltare Profesională*

 *„Excelența nu este un act, ci un obicei. Fiecare zi petrecută în FTP este o oportunitate de a deveni pompierul sau paramedicul pe care comunitatea din Los Santos îl merită."*
 — Training & Professional Development Bureau, LSFD

 **RESURSE DEPARTAMENTALE**

 [**➤ Valorile SPIRIT & Misiunea LSFD**](https://lsfd.ro-rp.mp/viewforum.php?f=15&sid=54c02def7c3abb77ea67c3f84462a0af) [**➤ Ierarhia Rankurilor & Jurământul**](https://lsfd.ro-rp.mp/viewtopic.php?t=45&sid=54c02def7c3abb77ea67c3f84462a0af) [**➤ Standarde Uniforme (Class A/B/C/D)**](https://lsfd.ro-rp.mp/viewtopic.php?t=45&sid=54c02def7c3abb77ea67c3f84462a0af) [**➤ Regulament Faction — Reguli OOC**](https://lsfd.ro-rp.mp/URL)

 **CUPRINS**

1. Introducere
2. Scopul Programului FTP
3. Structura Programului
4. Fazele FTP
5. Ofițerul de Instruire pe Teren (FTO)
6. Responsabilitățile Cursantului
7. Sistemul de Evaluare Zilnică (DOR)
8. Sistemul de Sancțiuni Disciplinare
9. Instruirea Remedială
10. Absolvirea și Standardele de Finalizare
11. Excluderea din Program
12. Standarde Profesionale
13. Standarde de Comunicare Radio
14. Proceduri de Siguranță la Fața Locului
15. Așteptări Operaționale
16. Documentație și Raportare
17. Proceduri Medicale de Bază (BLS)
18. Dispoziții Finale

 **1. INTRODUCERE**

 **1.1 Definiție și Context**

 Programul de Formare pe Teren (**Field Training Program — FTP**) reprezintă etapa obligatorie de instruire practică prin care orice nou absolvit al Academiei LSFD trebuie să treacă înainte de a dobândi statut operațional complet în cadrul Departamentului de Pompieri din Los Santos.

 FTP-ul nu este o simplă formalitate administrativă, ci un proces riguros și structurat de evaluare, formare și integrare operațională. Acesta reprezintă tranziția critică dintre mediul controlat al Academiei și realitatea unui serviciu de urgență activ. În cadrul acestui program, cursanții sunt expuși la intervenții reale, medii operaționale dinamice, scenarii de stres ridicat și situații care solicită luarea de decizii rapide și corecte — totul sub supravegherea directă a unui Ofițer de Instruire pe Teren certificat.

 **1.2 Importanța FTP-ului în LSFD**

 Departamentul de Pompieri din Los Santos deservește o comunitate complexă și solicitantă. Fiecare intervenție poate face diferența dintre viață și moarte — atât pentru victimele unui incident, cât și pentru membrii echipajului. Din acest motiv, LSFD nu poate permite ca un membru nepregătit să opereze independent pe teren fără să fi demonstrat în prealabil că deține cunoștințele, abilitățile și temperamentul necesare unui pompier sau paramedic eficient.

 FTP-ul asigură că fiecare nouă recrut care poartă uniforma LSFD a fost evaluat, instruit și validat conform standardelor înalte pe care departamentul le impune.

 **1.3 Statut Obligatoriu**

 **Niciun membru al LSFD nu poate obține statut operațional deplin fără finalizarea cu succes a Programului de Formare pe Teren.**

 Această regulă nu admite excepții. Indiferent de experiența anterioară a unui cursant în alte departamente, de cunoștințele teoretice demonstrate în Academie sau de alte circumstanțe personale, FTP-ul rămâne obligatoriu și trebuie parcurs în întregime.

 **1.4 Legătura cu Avansarea în Grad**

 Finalizarea cu succes a FTP-ului este condiția obligatorie pentru avansarea de la **Probationary Firefighter** la **Firefighter**. Niciun Probationary Firefighter nu poate obține statut operațional independent sau avansa în ierarhia departamentului fără absolvirea completă a acestui program.

 **2. SCOPUL PROGRAMULUI FTP**

 **2.1 Obiective Principale**

 Programul de Formare pe Teren a fost instituit cu scopul de a îndeplini o serie de obiective esențiale pentru funcționarea eficientă a LSFD:

 **a) Standardizarea procedurilor de instruire operațională**
 Toți cursanții urmează același proces structurat de formare, indiferent de FTO-ul care îi supervizează. Aceasta garantează că fiecare pompier sau paramedic care absolvă FTP-ul a fost evaluat în baza acelorași criterii și standarde uniforme.

 **b) Asigurarea conformității cu standardele operaționale LSFD**
 Fiecare cursant este evaluat în raport cu procedurile standard de operare (SOP) ale departamentului. Cunoașterea și aplicarea corectă a SOP-urilor nu este opțională — este fundamentală pentru siguranța tuturor.

 **c) Evaluarea capacității de luare a deciziilor sub presiune**
 Urgențele reale nu oferă luxul timpului îndelungat de gândire. FTP-ul testează și dezvoltă abilitatea cursanților de a analiza rapid situațiile și de a acționa corect chiar și în condiții de stres, presiune temporală și informații incomplete.

 **d) Îmbunătățirea comunicării și a lucrului în echipă**
 Intervențiile de urgență sunt, prin natura lor, acțiuni de echipă. Un pompier sau paramedic care nu poate comunica eficient sau care nu știe să lucreze în coordonare cu colegii săi reprezintă un risc atât pentru misiune, cât și pentru siguranța echipajului.

 **e) Dezvoltarea abilităților de management al scenei**
 Fiecare incident are o dinamică proprie. Cursanții trebuie să învețe să citească scena, să identifice pericolele, să prioritizeze acțiunile și să gestioneze resursele disponibile.

 **f) Consolidarea disciplinei și profesionalismului**
 LSFD este o instituție cu o cultură organizațională puternică, bazată pe respect, disciplină și profesionalism. FTP-ul evaluează nu doar competența tehnică, ci și conduita, atitudinea și integritatea morală a fiecărui cursant.

 **g) Pregătirea pentru operațiuni independente pe teren**
 Scopul final al FTP-ului este acela de a forma pompieri și paramedici capabili să funcționeze eficient și în deplină siguranță fără supravegherea constantă a unui FTO.

 **h) Garantarea siguranței publicului și a echipajului**
 Aceasta este, în ultimă instanță, rațiunea de existență a întregului program. Nicio altă considerație nu primează față de siguranța civililor și a personalului LSFD.

 **2.2 FTP ca Instrument de Selecție**

 Este important de înțeles că FTP-ul nu este exclusiv un proces educațional. El reprezintă, de asemenea, un instrument de selecție și evaluare. Dacă un cursant demonstrează pe parcursul programului că nu posedă aptitudinile, atitudinea sau potențialul necesar pentru serviciul în LSFD, departamentul are responsabilitatea față de comunitate și față de colegii săi de a lua decizia corespunzătoare — inclusiv, dacă este cazul, de a exclude acel cursant din program.

 **3. STRUCTURA PROGRAMULUI**

 **3.1 Organizare Generală**

 Programul de Formare pe Teren este structurat în **patru faze operaționale progresive**, fiecare construindu-se pe fundația celei anterioare. Complexitatea sarcinilor, nivelul de independență al cursantului și rigorile evaluării cresc gradual de la o fază la alta.

 Această structură progresivă reflectă principiul pedagogic fundamental conform căruia formarea eficientă trebuie să pornească de la observație și înțelegere, să treacă prin practică asistată și să culmineze cu demonstrarea independenței operaționale.

 **3.2 Criterii de Progresie între Faze**

 Avansarea dintr-o fază în alta **nu este automată** și nu se bazează exclusiv pe numărul de zile petrecute în program. Progresia este condiționată de:

- **Performanță operațională** — Cursantul demonstrează nivelul de competență așteptat pentru faza respectivă
- **Profesionalism** — Conduita, atitudinea și disciplina cursantului sunt conforme cu standardele LSFD
- **Activitate** — Cursantul participă activ și consistent la intervențiile și activitățile departamentului
- **Competență operațională** — Cursantul aplică corect procedurile și protocoalele specifice fazei
- **Recomandarea FTO-ului** — Ofițerul de instruire confirmă că cursantul este pregătit să avanseze

 **Toți acești factori trebuie să fie îndepliniți simultan.** Un cursant cu performanță tehnică excelentă, dar cu probleme de profesionalism, nu va fi promovat automat în faza următoare.

 **3.3 Autoritatea Biroului de Instruire**

 Biroul de Instruire și Dezvoltare Profesională (**Training & Professional Development Bureau**) deține autoritatea supremă în ceea ce privește administrarea FTP-ului. Acesta își rezervă dreptul de a:

- **Extinde** durata oricărei faze dacă cursantul nu îndeplinește criteriile de progresie
- **Repeta** o fază dacă performanța cursantului s-a deteriorat sau nu a atins nivelul minim acceptabil
- **Plasa cursanți în instruire remedială** atunci când sunt identificate deficiențe specifice
- **Suspenda temporar** participarea unui cursant în așteptarea unei investigații disciplinare
- **Termina participarea** în FTP a oricărui cursant care nu îndeplinește standardele minime

 Deciziile Biroului de Instruire sunt **definitive** în absența unui apel formal adresat Comandamentului de Instruire.

 **4. FAZELE FTP**

 **━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
 **FAZA I — INTRODUCTION (OBSERVARE)**
 **━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**

 **Durată minimă:** 1 săptămână operațională

 **4.1.1 Descriere și Scop**

 Prima fază a FTP-ului reprezintă punctul de intrare al cursantului în mediul operațional real al LSFD. Această etapă este concepută deliberat ca una de observare și asimilare, nu de participare activă sau demonstrare de competențe tehnice.

 Cursantul însoțește FTO-ul atribuit și observă modul în care un pompier/paramedic cu experiență gestionează situațiile de urgență, comunică pe radio, coordonează cu echipajul și aplică protocoalele departamentale. Totul ceea ce cursantul vede în această fază reprezintă un model de conduită profesională pe care trebuie să îl internalizeze.

 Faza I nu trebuie considerată o perioadă „ușoară". Deși cursantul nu conduce intervenții și nu execută proceduri complexe în mod independent, el este permanent evaluat în ceea ce privește atitudinea, disciplina, curiozitatea profesională și capacitatea de a asimila informații. **Cursantul este obligat să mențină un FTP Journal** în care documentează observațiile, cunoștințele dobândite și evoluția proprie pe durata întregului program.

 **4.1.2 Activitățile Cursantului în Faza I**

 Pe parcursul Fazei I, cursantul:

- **Observă intervențiile de urgență** — urmărind cu atenție modul în care FTO-ul gestionează fiecare tip de incident, de la sosirea la fața locului până la finalizarea raportului
- **Studiază eticheta radio a departamentului** — asistând la comunicările radio ale FTO-ului și familiarizându-se cu formatele, codurile și protocolul de comunicare specific LSFD
- **Studiază operațiunile de la gară** — înțelegând rutinele zilnice, verificările de echipament, procedurile de mentenanță și cultura organizațională specifică stației
- **Se familiarizează cu vehiculele și aparatura** — identificând componentele principale ale autovehiculelor de intervenție, locația echipamentelor și modul lor de operare de bază
- **Învață utilizarea MDT/MDC** — observând cum FTO-ul utilizează terminalul de date mobil pentru a recepționa și gestiona misiunile
- **Participă la briefinguri de scenă** — asistând la modul în care FTO-ul evaluează situația la sosire și comunicând informațiile relevante echipajului
- **Completează FTP Journal zilnic** — documentând observații, întrebări și cunoștințe acumulate
- **Asistă cu sarcini operaționale de bază** — contribuind la activitățile elementare care nu implică riscuri sau responsabilitate operațională independentă

 **4.1.3 Restricții în Faza I**

 Cursantul în Faza I **nu are voie să**:

- Conducă sau să coordoneze independent niciun incident
- Inițieze comunicări radio complexe fără îndrumare directă din partea FTO-ului
- Execute proceduri medicale avansate sau manevre de stingere fără supraveghere directă
- Ia decizii operaționale autonome care pot afecta siguranța scenei sau a echipajului
- Răspundă la apeluri singur sau fără însoțirea unui FTO
- Opereze orice Apparatus (vehicul de intervenție) în răspuns la urgențe

 Aceste restricții nu sunt arbitrare. Ele există pentru a proteja atât cursantul, cât și victimele și echipajul, asigurând că niciun cursant nepregătit nu este pus într-o poziție care depășește nivelul său de pregătire demonstrat.

 **4.1.4 Obiectivele Fazei I**

- **Adaptarea la mediul operațional** — să nu mai fie intimidat sau dezorientat de ritmul și complexitatea serviciului de urgență
- **Înțelegerea fluxului de lucru LSFD** — cunoașterea modului în care se desfășoară o intervenție de la alertare până la debriefing
- **Dezvoltarea disciplinei și a conștiinței situaționale** — atenție permanentă la tot ceea ce se petrece în jur
- **Familiarizarea cu structurile SOP** — înțelegerea logicii și importanței procedurilor standard de operare

 **━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
 **FAZA II — OPERAȚIUNI ASISTATE**
 **━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**

 **Durată minimă:** 2–3 săptămâni operaționale

 **4.2.1 Descriere și Scop**

 Faza II marchează tranziția cursantului de la rolul de observator pasiv la cel de participant activ în intervențiile de urgență. Aceasta este etapa în care teoria Academiei și observațiile din Faza I încep să fie puse în practică în condiții reale, dar cu suportul permanent al FTO-ului.

 Fiecare greșeală din această fază reprezintă o oportunitate de învățare — dar și un criteriu de evaluare. FTO-ul furnizează corecții în timp real, oferă explicații și ghidează cursantul spre adoptarea comportamentelor operaționale corecte.

 **4.2.2 Activitățile Cursantului în Faza II**

 Pe parcursul Fazei II, cursantul:

- **Comunică activ pe radio** — inițiind și răspunzând la traficul radio conform protocoalelor LSFD, sub monitorizarea FTO-ului
- **Asistă la îngrijirea pacienților** — participând direct la evaluările medicale primare și secundare și la administrarea primului ajutor
- **Execută sarcini de bază în stingerea incendiilor** — poziționarea corectă a furtunurilor, utilizarea echipamentului de protecție, participarea la operațiunile de control al focului
- **Efectuează evaluări simple** — realizând triajul pacienților și evaluările inițiale ale situației sub supravegherea FTO-ului
- **Exersează comunicarea operațională** — dezvoltând abilitatea de a transmite informații clare, concise și relevante
- **Completează documentația incidentelor sub supraveghere** — înțelegând structura și cerințele rapoartelor oficiale LSFD
- **Actualizează FTP Journal** — cu observații privind propria evoluție și domeniile ce necesită îmbunătățire

 **4.2.3 Responsabilitățile FTO-ului în Faza II**

- **Furnizează corecții constante și constructive** — intervenind imediat la greșeli, explicând ce nu a fost corect și cum trebuie procedat
- **Evaluează cunoștințele procedurale** — verificând că cursantul înțelege nu doar CE trebuie făcut, ci și DE CE
- **Monitorizează răspunsul la stres** — observând cum reacționează cursantul în situații de presiune
- **Consolidează conformitatea cu SOP-urile** — asigurând că fiecare acțiune a cursantului respectă procedurile departamentale

 **4.2.4 Obiectivele Fazei II**

- **Îmbunătățirea încrederii operaționale** — capacitatea de a acționa fără ezitare exagerată în situații pentru care este pregătit
- **Aplicarea cunoștințelor Academiei în situații reale** — transferul efectiv al teoriei în practică
- **Îmbunătățirea capacității de lucru în echipă** — coordonarea eficientă cu FTO-ul și cu ceilalți membri ai echipajului
- **Demonstrarea conștiinței de scenă** — înțelegerea dinamicii locului intervenției și adaptarea comportamentului la aceasta

 **━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
 **FAZA III — CONDUCERE CONTROLATĂ**
 **━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**

 **Durată minimă:** 3–4 săptămâni operaționale

 **4.3.1 Descriere și Scop**

 Faza III reprezintă cel mai exigent și mai revelator stadiu al FTP-ului. Cursantul este acum așteptat să demonstreze independență operațională reală, conducând intervenții și luând decizii sub evaluarea continuă a FTO-ului.

 Această fază testează dacă cursantul poate funcționa ca un pompier/paramedic autonom și eficient — nu perfect, dar capabil să gestioneze situațiile cu competență și profesionalism. FTO-ul adoptă un rol mai retras, intervenind pentru corectare sau siguranță, dar lăsând cursantul să conducă.

 **4.3.2 Activitățile Cursantului în Faza III**

 Pe parcursul Fazei III, cursantul:

- **Gestionează incidentele minore** — conducând intervenții de complexitate redusă sau medie de la sosire până la finalizare
- **Efectuează evaluări primare ale pacienților** — realizând independent evaluări medicale complete și luând decizii de tratament adecvate
- **Gestionează traficul radio** — coordonând comunicările operaționale pentru incidentele pe care le conduce
- **Demonstrează abilități de lider** — organizând activitățile echipajului și comunicând clar sarcinile și prioritățile
- **Se coordonează cu alte servicii de urgență** — interacționând profesional cu LSPD, LSEMS și alte agenții prezente la fața locului
- **Aplică SOP-urile independent** — demonstrând că a internalizat procedurile departamentale și le poate aplica fără îndrumare activă

 **4.3.3 Responsabilitățile FTO-ului în Faza III**

- **Monitorizează procesul decizional** — observând calitatea judecăților operaționale ale cursantului, intervenind doar dacă siguranța este compromisă
- **Evaluează potențialul de leadership** — apreciind capacitatea cursantului de a conduce, motiva și coordona
- **Identifică slăbiciunile operaționale** — documentând domeniile în care cursantul necesită îmbunătățiri înainte de evaluarea finală
- **Pregătește recomandările finale** — elaborând o analiză detaliată a performanței cursantului pentru Faza IV

 **4.3.4 Obiectivele Fazei III**

- **Gândire operațională independentă** — capacitatea de a analiza situații noi și de a formula răspunsuri adecvate fără ghidaj constant
- **Dezvoltarea abilităților de leadership** — capacitatea de a conduce eficient în situații de urgență
- **Luarea de decizii sub presiune** — menținerea clarității judecăților în condiții de stres
- **Managementul scenei** — controlul și coordonarea eficientă a resurselor și personalului la fața locului

 [hr]

 **━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
 **FAZA IV — EVALUAREA FINALĂ**
 **━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**

 **Durată:** 1 zi operațională

 **4.4.1 Descriere și Scop**

 Faza IV constituie evaluarea culminantă a întregului parcurs din FTP. Aceasta este o evaluare formală, completă și structurată, condusă de evaluatori certificați ai Biroului de Instruire și Dezvoltare Profesională.

 Spre deosebire de fazele anterioare, Faza IV nu este o sesiune de instruire. Evaluatorul nu furnizează corecții în timp real. Cursantul trebuie să demonstreze, **fără asistență**, că a atins standardele operaționale complete ale LSFD. La intrarea în Faza IV, cursantul predă **FTP Journal-ul** complet completat, care face parte din documentația de evaluare finală.

 **4.4.2 Categoriile de Evaluare**

- **Scenarii Medicale** — Triaj, evaluare primară/secundară, protocoale de tratament, prioritizare
- **Operațiuni de Stingere** — Utilizarea echipamentului, poziționarea, coordonarea, respectarea protocoalelor
- **Siguranța la Fața Locului** — Identificarea pericolelor, utilizarea EIP, conștiința situațională
- **Cunoașterea SOP-urilor** — Aplicarea corectă a procedurilor standard de operare
- **Comunicare Radio** — Claritate, format corect, disciplină radio, calitatea traficului
- **Redactarea Rapoartelor** — Acuratețe, detalii, profesionalism, respectarea termenelor
- **Managementul Stresului** — Menținerea eficienței operaționale în condiții de presiune
- **Profesionalism** — Conduită, atitudine, respect, reprezentarea LSFD
- **Noțiuni de Comandă a Incidentului** — Aplicarea principiilor ICS, coordonarea cu structura de comandă

 **4.4.3 Rezultatele Posibile ale Evaluării Finale**

 **PROMOVAT (PASS)**
 Cursantul a demonstrat competența în toate categoriile evaluate la un nivel egal sau superior standardului minim acceptabil. Este eligibil pentru finalizarea FTP-ului și acordarea statutului operațional.

 **INSTRUIRE REMEDIALĂ (REMEDIAL TRAINING)**
 Cursantul prezintă deficiențe specifice în unul sau mai multe domenii. Va fi supus unui program de instruire remedială înainte de a putea repeta evaluarea finală.

 **RESPINS (FAIL)**
 Cursantul nu a îndeplinit standardele minime în mai multe categorii critice. Eșecul la evaluarea finală poate atrage:
- Repetarea uneia sau mai multor faze
- Includerea în program remedial extins
- Excluderea din FTP și, implicit, din LSFD

 [hr]

 **5. OFIȚERUL DE INSTRUIRE PE TEREN (FTO)**

 **5.1 Definiție și Statut**

 Un Ofițer de Instruire pe Teren (**Field Training Officer — FTO**) este un membru certificat al LSFD autorizat de Biroul de Instruire și Dezvoltare Profesională să supravegheze, instruiască și evalueze cursanții în cadrul Programului de Formare pe Teren.

 Certificarea FTO se obține după atingerea rank-ului minim de **Firefighter III** și finalizarea calificării **Field Training Officer** din cadrul Division 6 — Training & Professional Development. Certificarea nu reprezintă un simplu titlu onorific — este o responsabilitate majoră care implică standarde de conduită, competență și profesionalism ridicate.

 **5.2 Responsabilitățile FTO-ului**

- **Supravegheze cursanții** — monitorizarea permanentă a cursantului atribuit, asigurând că acesta acționează conform standardelor fazei în care se află
- **Asigure siguranța la fața locului** — FTO-ul poartă responsabilitatea operațională finală pentru siguranța cursantului și a scenei
- **Evalueze competența operațională** — aprecierea obiectivă a performanței cursantului, pe baza standardelor documentate
- **Corecteze greșelile** — furnizarea de feedback corectiv clar, specific și constructiv imediat după identificarea unei erori
- **Documenteze performanța** — completarea riguroasă și promptă a Rapoartelor de Observare Zilnică (DOR) și a Task Book-ului cursantului
- **Mențină standardele LSFD** — servirea ca model de conduită profesională și operațională
- **Aplice disciplina** — identificarea și abordarea promptă a oricăror abateri disciplinare sau comportamente neprofesionale

 **5.3 FTO ca Model de Rol**

 Dincolo de responsabilitățile formale, FTO-ul are un rol esențial: acela de a servi ca **model de rol** pentru cursant. Cursanții nu învață doar din ceea ce FTO-ul le spune — învață din ceea ce FTO-ul *face*. Un FTO care tolerează scurtături, adoptă comportamente neprofesionale sau ignoră SOP-uri când consideră că nimeni nu privește transmite cursantului exact acele standarde negative.

 Prin urmare, **FTO-ul este evaluat permanent** — nu formal de cursant, ci de supervizorii săi și de Biroul de Instruire — inclusiv în ceea ce privește propriul comportament operațional și profesional.

 **5.4 Interdicțiile FTO-ului**

 FTO-ul **nu are voie** să:

- **Falsifice evaluările** — subminează scopul FTP-ului și pune în pericol comunitatea și colegii
- **Favorizeze cursanții** — compromite obiectivitatea procesului de evaluare
- **Ignore violările SOP** — validează comportamente periculoase și ineficiente
- **Tolereze conduita neprofesională** — perpetuează standarde negative în departament
- **Saboteze deliberat progresul cursantului** — constituie abuz de autoritate
- **Utilizeze abuziv autoritatea** — hărțuirea sau intimidarea cursanților este inacceptabilă

 **5.5 Consecințele Încălcării Responsabilităților FTO**

 Un FTO care încalcă responsabilitățile menționate se supune:

- **Suspendării** din activitatea de instruire pe durata investigației
- **Decertificării** ca FTO cu interzicerea temporară sau permanentă de a mai superviza cursanți
- **Anchetei disciplinare** conform Regulamentului de Conduită al LSFD

 [hr]

 **6. RESPONSABILITĂȚILE CURSANTULUI**

 **6.1 Angajamentul față de Program**

 Participarea la FTP nu este o obligație pasivă. Cursantul trebuie să abordeze fiecare zi din program cu maximă seriozitate, angajament și dorință de a se îmbunătăți. LSFD investește timp și resurse semnificative în formarea fiecărui cursant — această investiție merită un răspuns pe măsură.

 **6.2 Restricțiile Specifice ale Probationary Firefighter**

 Pe durata FTP-ului, statusul de Probationary Firefighter implică restricții operaționale stricte:

- **Nu poate răspunde la apeluri singur** — prezența FTO-ului sau a unui pompier cu experiență este obligatorie la orice intervenție
- **Nu poate opera Apparatus** în răspuns la urgențe (Engine, Truck, Squad, Rescue Ambulance)
- **Nu poate acționa ca echipaj principal** — rolul este de suport și asistență, nu de conducere
- **Nu poate lua decizii de comandă** — nu poate prelua rolul de Incident Commander sau Company Officer
- **Trebuie să fie sub supraveghere permanentă** a unui FTO sau ofițer superior în orice moment de serviciu

 Aceste restricții se ridică **exclusiv** după absolvirea cu succes a FTP-ului și obținerea statutului de Firefighter.

 **6.3 Obligațiile Operaționale și Profesionale**

 Toți cursanții sunt obligați să:

- **Respecte lanțul de comandă** — ierarhia LSFD există din motive operaționale concrete; ordinele FTO-ului și ale superiorilor trebuie respectate fără contestare publică
- **Mențină profesionalismul** — conduita adecvată se aplică atât în fața publicului, cât și față de colegi, superiori și în stație
- **Accepte criticile constructive** — feedback-ul negativ este o parte esențială a formării; defensivitatea sau argumentativitatea în fața corecțiilor demonstrează imaturitate profesională
- **Studieze manualele SOP și MOP** — cunoașterea procedurilor standard de operare este obligatorie și se face inclusiv în timpul liber
- **Mențină FTP Journal-ul actualizat** — documentând zilnic activitățile, observațiile și progresul personal
- **Rămână activi și atenți** — serviciul de urgență nu tolerează pasivitatea; cursanții trebuie să fie permanent alertă și pregătiți să acționeze
- **Mențină disciplina operațională** — respectarea regulilor și protocoalelor chiar și atunci când nimeni nu privește
- **Participe la instruirile programate** — sesiunile de instruire suplimentare, exercițiile și briefingurile sunt obligatorii
- **Respecte membrii departamentului** — toți membrii LSFD merită respect, indiferent de grad sau vechime

 **6.4 Reprezentarea LSFD**

 Cursanții reprezintă LSFD **atât în timpul serviciului, cât și în afara acestuia**. Comportamentul unui cursant în medii publice poate reflecta pozitiv sau negativ asupra departamentului. Conduita neprofesională sau comportamentele care aduc prejudicii imaginii LSFD pot constitui motiv de sancționare disciplinară chiar și în afara serviciului.

 [hr]

 **7. SISTEMUL DE EVALUARE ZILNICĂ (DOR)**

 **7.1 Raportul de Observare Zilnică**

 La sfîrșitul fiecărui schimb operațional, FTO-ul atribuit trebuie să completeze un **Raport de Observare Zilnică** (**Daily Observation Report — DOR**). Acesta constituie documentul oficial de evaluare al cursantului pentru ziua respectivă și instrumentul esențial de urmărire a progresului în timp.

 DOR-ul nu este o formalitate birocratică — este instrumentul prin care Biroul de Instruire urmărește traiectoria de dezvoltare a fiecărui cursant, identificând zonele de progres, stagnare sau regres. DOR-urile completate sunt corelate cu intrările din FTP Journal-ul cursantului pentru o imagine completă a evoluției sale.

 **7.2 Categoriile de Evaluare**

1. **Comunicare Radio** — Claritatea transmisiilor, respectarea formatelor, disciplina radio
2. **Siguranța la Fața Locului** — Identificarea pericolelor, utilizarea EIP, conștiința situațională
3. **Cunoștințe Medicale** — Triaj, evaluare, protocoale de tratament, prioritizare
4. **Proceduri de Stingere** — Tehnici, poziționare, utilizarea echipamentului, coordonare
5. **Luarea Deciziilor** — Calitatea judecăților, prioritizarea, răspunsul la situații neprevăzute
6. **Managementul Stresului** — Funcționarea eficientă sub presiune, menținerea clarității mentale
7. **Profesionalism** — Conduită, atitudine, prezentare, respectul față de colegi și public
8. **Lucrul în Echipă** — Colaborarea cu echipajul, coordonarea, comunicarea interpersonală
9. **Redactarea Rapoartelor** — Acuratețea, detaliile, structura și promptitudinea documentației
10. **Conformitatea cu SOP-urile** — Aplicarea corectă și consistentă a procedurilor standard

 **7.3 Scala de Evaluare**

 **DOES NOT MEET EXPECTATIONS — NU ÎNDEPLINEȘTE AȘTEPTĂRILE**
 Performanța nu atinge standardele minime LSFD. Erori grave care compromit siguranța, eficiența operațională sau imaginea departamentului. Această evaluare impune un plan de remediere imediat și poate declanșa revizuirea continuării în program. FTO-ul trebuie să documenteze specific natura deficienței și acțiunile corective recomandate.

 **MEETS EXPECTATIONS — ÎNDEPLINEȘTE AȘTEPTĂRILE**
 Performanța îndeplinește standardele minime operaționale. Cursantul demonstrează competența de bază în domeniu, cu greșeli minore care nu afectează în mod semnificativ operațiunile. Aceasta este **evaluarea minimă necesară pentru progresie**. Cursantul funcționează conform așteptărilor pentru stadiul de formare în care se află.

 **EXCEEDS EXPECTATIONS — DEPĂȘEȘTE AȘTEPTĂRILE**
 Performanță peste medie. Cursantul demonstrează o înțelegere solidă a domeniului, execuție competentă și inițiativă proprie. Acționează adesea fără a fi nevoie de îndrumare, anticipează nevoile scenei și contribuie activ la eficiența echipajului. Evaluare semnificativă care reflectă un cursant cu potențial ridicat.

 **OUTSTANDING — EXCEPȚIONAL**
 Performanță excepțională, rar acordată. Cursantul depășește în mod constant așteptările pentru stadiul de formare în care se află, demonstrează leadership natural și potențial clar pentru roluri de responsabilitate crescută. Această evaluare trebuie să reprezinte o realizare reală și nu trebuie acordată cu ușurință — este rezervată performanțelor cu adevărat remarcabile.

 **7.4 Interpretarea Rezultatelor DOR**

- O evaluare generală de **MEETS EXPECTATIONS sau mai mare** este necesară la toate categoriile pentru considerarea progresiei de fază
- Nicio categorie nu poate primi **DOES NOT MEET EXPECTATIONS** fără un plan de remediere imediat documentat
- Evaluări consistente de **EXCEEDS / OUTSTANDING** pot accelera progresia între faze
- Un tipar de scădere a evaluărilor semnalează posibile probleme care necesită investigație și, potențial, instruire remedială

 [hr]

 **8. SISTEMUL DE SANCȚIUNI DISCIPLINARE**

 **8.1 Scopul Sistemului de Sancțiuni**

 Sistemul de sancțiuni disciplinare al FTP-ului (**Strike System**) a fost instituit pentru a menține nivelul de disciplină și profesionalism necesar unui serviciu de urgențe. El nu este un instrument de pedepsire, ci un mecanism de responsabilizare care asigură că toți cursanții respectă standardele fundamentale ale LSFD.

 O sancțiune disciplinară nu înseamnă neapărat că un cursant va fi exclus din program — înseamnă că comportamentul respectiv a fost identificat, documentat și că cursantul are oportunitatea de a se corecta.

 [hr]

 **NIVEL I — SANCȚIUNE MINORĂ**

 **Se aplică pentru:**
- Greșeli procedurale minore din neglijență, nu din ignoranță deliberată
- Lipsă de atenție sau concentrare inadecvată la activitățile operaționale
- Activitate scăzută sau participare insuficientă la intervențiile zilnice
- Violări minore ale SOP-urilor care nu au afectat siguranța sau eficiența operațională
- Erori de formatare sau protocol în comunicările radio
- Necompletarea FTP Journal-ului în termenele stabilite

 **Consecințe:**
 O sancțiune de Nivel I constituie un avertisment documentat. Cursantul este informat formal despre comportamentul problematic. Acumularea mai multor sancțiuni de Nivel I poate escalada la măsuri disciplinare mai severe.

 [hr]

 **NIVEL II — SANCȚIUNE MEDIE**

 **Se aplică pentru:**
- Insubordonare față de FTO sau alți superiori
- Comportament neprofesional care afectează imaginea departamentului sau relațiile cu colegii
- Neglijență operațională care poate sau ar fi putut crea riscuri
- Violări repetate ale SOP-urilor care demonstrează o atitudine de neconformare deliberată
- Perturbarea scenei sau a activității de urgență

 **Consecințe:**
- **Repetarea fazei** în curs — cursantul trebuie să demonstreze din nou că îndeplinește cerințele fazei
- **Suspendarea temporară** din activitatea de instruire activă
- **Repartizarea pentru instruire remedială** în domeniile specifice problematice

 [hr]

 **NIVEL III — SANCȚIUNE SEVERĂ**

 **Se aplică pentru:**
- Conduită gravă incompatibilă cu valorile și standardele LSFD
- Trolism, fail roleplay sau acțiuni care subminează calitatea simulărilor operaționale
- Neglijență gravă cu potențial de vătămare a unor persoane sau de compromitere a unei misiuni
- Acțiuni care periclitează siguranța la fața locului, a victimelor sau a echipajului
- Comportament toxic care afectează moralul, coeziunea sau bunăstarea echipei
- Violări intenționate și grave ale SOP-urilor

 **Consecințe:**
 O sancțiune de Nivel III poate **duce imediat la excluderea din FTP**.

 [hr]

 **8.3 Procesul de Documentare a Sancțiunilor**

 Orice sancțiune disciplinară trebuie:
1. Documentată în formular oficial cu descrierea detaliată a incidentului
2. Comunicată cursantului în mod direct și clar, cu explicarea motivelor
3. Transmisă Biroului de Instruire și Dezvoltare Profesională
4. Păstrată în dosarul cursantului pe toată durata FTP-ului

 [hr]

 **9. INSTRUIREA REMEDIALĂ**

 **9.1 Scopul Instruirii Remediale**

 Instruirea remedială nu reprezintă o penalizare, ci o oportunitate suplimentară de formare pentru cursanții care au demonstrat deficiențe specifice ce pot fi adresate prin îndrumare și practică țintită. Scopul este de a aduce cursantul la nivelul de competență cerut, nu de a-l penaliza pentru neajunsuri.

 **9.2 Circumstanțele care Pot Atrage Instruire Remedială**

 Instruirea remedială poate fi dispusă atunci când:

- DOR-urile arată evaluări de **DOES NOT MEET EXPECTATIONS** constant în una sau mai multe categorii
- Cursantul nu îndeplinește standardele de progresie la finalizarea unei faze
- Evaluarea finală (Faza IV) se încheie cu rezultatul „INSTRUIRE REMEDIALĂ"
- FTO-ul identifică deficiențe specifice care necesită atenție suplimentară
- Un incident operațional semnificativ relevă o lacună de cunoaștere sau de abilitate

 **9.3 Tipurile de Instruire Remedială**

- **Ride-along-uri suplimentare** — ore suplimentare însoțind un FTO experimentat, cu accent pe domeniile problematice
- **Scenarii operaționale extra** — simulări controlate ale situațiilor specifice în care cursantul a demonstrat deficiențe
- **Examene scrise** — testarea cunoștințelor teoretice în domeniile de slăbiciune identificate
- **Sesiuni practice de comunicare radio** — exerciții structurate cu corectare în timp real a erorilor
- **Schimburi operaționale supravegheate** — schimburi cu nivel ridicat de supraveghere FTO, dedicate exersării practice
- **Reevaluări de fază** — repetarea evaluării pentru faza relevantă după finalizarea programului remedial

 **9.4 Autoritatea de Dispunere a Instruirii Remediale**

 Dispunerea instruirii remediale poate fi autorizată exclusiv de:

- **FTO-ul Principal** al cursantului — pentru recomandări inițiale
- **Supervizorul de Instruire** — pentru aprobarea planului formal
- **Directorul Biroului de Instruire și Dezvoltare Profesională** — pentru cazurile complexe sau repetate

 [hr]

 **10. ABSOLVIREA ȘI STANDARDELE DE FINALIZARE**

 **10.1 Condiții de Absolvire**

 Pentru a finaliza cu succes FTP-ul, cursantul trebuie să îndeplinească **simultan** toate condițiile următoare:

- **Finalizarea tuturor fazelor FTP** — parcurgerea și finalizarea cu succes a tuturor celor patru faze
- **Promovarea evaluării finale** — Faza IV trebuie să se fi încheiat cu rezultatul PASS
- **Menținerea evaluărilor acceptabile** — DOR-urile nu trebuie să prezinte tiparuri de evaluări DOES NOT MEET persistente
- **Predarea FTP Journal-ului completat** — documentul trebuie să reflecte implicarea și evoluția reală a cursantului
- **Demonstrarea profesionalismului** — dosarul disciplinar trebuie să confirme conduita adecvată
- **Aprobarea finală a Comandamentului de Instruire** — nicio absolvire nu este oficializată fără confirmare formală

 **10.2 Statutul Acordat la Absolvire**

 La finalizarea cu succes a FTP-ului, cursantul avansează de la **Probationary Firefighter** la **Firefighter** și poate primi, în funcție de specializarea urmată și de performanța demonstrată, unul dintre următoarele statute:

- **Firefighter** — statut operațional complet, poate răspunde independent la apeluri, poate opera Apparatus
- **Firefighter / Paramedic track** — statut operațional complet cu cale de specializare medicală confirmată
- **Autorizare Probatorie extinsă** — statut temporar în așteptarea unor cerințe administrative sau de documentare

 [hr]

 **11. EXCLUDEREA DIN PROGRAM**

 **11.1 Motive de Excludere**

 Un cursant poate fi exclus din FTP pentru oricare dintre motivele următoare:

- **Inactivitate** — absență prelungită sau participare insuficientă care face imposibilă evaluarea obiectivă
- **Probleme disciplinare repetate** — acumularea de sancțiuni care demonstrează o atitudine incompatibilă cu serviciul
- **Incompetență operațională** — incapacitatea de a îndeplini standardele minime după instruire remedială repetată
- **Eșec în îmbunătățire** — niciun progres demonstrabil în ciuda feedback-ului și oportunităților suplimentare
- **Conduită gravă** — comportament care periclitează siguranța, integritatea sau reputația LSFD
- **Comportament toxic** — acțiuni care dăunează moralului, coeziunii sau bunăstării echipei
- **Nerespectarea standardelor LSFD** — refuzul persistent de a respecta valorile și regulile departamentului

 **11.2 Procedura de Excludere**

 Decizia de excludere este luată de Biroul de Instruire și Dezvoltare Profesională după:

1. Revizuirea completă a dosarului cursantului (DOR-uri, sancțiuni, rapoarte FTO, FTP Journal)
2. Audierea cursantului, cu posibilitatea de a prezenta punctul său de vedere
3. Consultarea FTO-ului principal al cursantului
4. Emiterea unui document oficial de excludere cu motivele detaliate

 **11.3 Dreptul la Apel**

 Deciziile de excludere sunt **definitive**, cu excepția cazului în care cursantul formulează un apel formal adresat direct Comandamentului de Instruire. Apelul trebuie depus **în scris, în termen de 72 de ore** de la comunicarea deciziei, și trebuie să conțină argumente clare și dovezi relevante. Decizia Comandamentului de Instruire este finală și nu mai poate fi contestată.

 [hr]

 **12. STANDARDE PROFESIONALE**

 **12.1 Cultura Organizațională LSFD**

 LSFD este o organizație bazată pe valori fundamentale: **integritate, profesionalism, curaj, respect și responsabilitate**. Participanții la FTP sunt ambasadori ai acestei culturi. Aceste valori sunt reflectate în acronimul departamental **SPIRIT** — *Service, Professionalism, Integrity, Respect, Innovation, Trust* — și reprezintă busola morală care ghidează fiecare decizie și acțiune.

 **12.2 Așteptări de Conduită**

 Toți membrii LSFD implicați în FTP sunt așteptați să:

- **Mențină maturitatea** — mediul operațional nu este locul pentru glume nepotrivite sau comportamente infantile
- **Evite conflictele interne** — dezacordurile trebuie adresate prin canale adecvate, nu prin confruntări publice sau zvonuri
- **Demonstreze lucrul în echipă** — eficiența unui serviciu de urgență depinde de capacitatea membrilor de a colabora și acționa coordonat
- **Mențină realismul în operațiuni** — simulările sunt eficiente doar dacă toți participanții se angajează pe deplin față de autenticitatea scenariilor
- **Respecte superiorii și colegii** — respectul este o normă fundamentală de conduită profesională, nu o opțiune
- **Reprezinte LSFD pozitiv în orice context** — fiecare interacțiune cu publicul sau alte departamente este o ocazie de a consolida imaginea departamentului

 [hr]

 **13. STANDARDE DE COMUNICARE RADIO**

 **13.1 Importanța Comunicării Radio**

 Comunicarea radio este coloana vertebrală a coordonării operaționale. Un mesaj clar și concis poate face diferența dintre o intervenție eficientă și haos. Comunicarea deficitară — mesaje neclare, trafic radio excesiv, formatare incorectă — poate întârzia intervenția, crea confuzie și, în cel mai grav caz, periclita siguranța echipajului.

 **13.2 Principiul „Plain English"**

 LSFD utilizează **„Plain English"** (limbaj clar, fără coduri 10 sau argou) pentru toate comunicările radio. Acest standard asigură claritatea mesajelor indiferent de cine le recepționează. Utilizarea codurilor 10 (10-4, 10-20 etc.) este **interzisă**, cu excepția cazurilor extrem de specifice aprobate de Bureau Commander.

 Locațiile trebuie întotdeauna referențiate prin **numele străzii**, nu prin repere informale sau denumiri locale.

 **13.3 Cerințele de Bază**

 Toți cursanții trebuie să:

- **Utilizeze disciplina radio adecvată** — radioul este un canal profesional și operațional, nu o rețea socială; conversațiile personale sunt strict interzise
- **Evite traficul radio inutil** — fiecare transmisie trebuie să aibă un scop clar și o valoare operațională
- **Utilizeze semnele de apel corecte** — fiecare unitate și fiecare membru are un semn de apel specific care trebuie respectat
- **Rămână calmi în comunicări** — tonul trebuie să rămână calm și profesional indiferent de gravitatea situației
- **Prioritizeze claritatea și concizia** — formatele standard de comunicare LSFD trebuie respectate cu strictețe

 **13.4 Asignări Radio (Call Signs)**

- **Command 1 (CM1)** — Rezervat pentru Incident Commander la scene majore
- **Battalion 11 (B11)** — Battalion Chief
- **Engine (E##)** — Unitățile Engine Company (E11, E12 etc.) — stingere incendii, water supply
- **Truck (T##)** — Unitățile Truck Company — ventilație, forcible entry, operațiuni aeriene
- **Squad (S##)** — Unitățile Squad Company — technical rescue, suport manpower
- **Rescue Ambulance (RA##)** — Unitățile medicale ALS (RA11, RA12 etc.)

 **13.5 Coduri Operaționale**

- **Code 1** — Răspuns non-emergent (fără lumini/sirene). Utilizat pentru apeluri de prioritate scăzută
- **Code 2** — Răspuns urgent cu lumini doar, fără sirene (utilizat rar)
- **Code 3** — Răspuns urgent cu lumini și sirene. Standard pentru urgențe
- **Priority Traffic** — Mesaj urgent care necesită liniște imediată pe frecvență. Toți utilizatorii opresc transmisiile
- **MCI (Mass Casualty Incident)** — Incident cu victime multiple care depășesc capacitatea unităților prezente

 **13.6 Fraze Standard de Comunicare**

 Cursanții trebuie să memoreze și să utilizeze exclusiv frazele standard aprobate de LSFD:

- **La plecare din stație:** „[Callsign] responding Code 3/Code 1 to [Locație]."
- **La sosirea pe scenă:** „[Callsign] on scene at [Locație]. [Size-up scurt dacă este relevant]."
- **La transport medical:** „[Callsign] transporting to [Spital] with [Număr] patient(s) on board."
- **La eliberarea de pe scenă:** „[Callsign] clear from last, back in service."
- **Solicitare resurse:** „[Callsign] requesting [resursă] at [Locație]."
- **Mesaj urgent:** „Priority Traffic — [Callsign] — [mesaj scurt]."

 **13.7 Frecvențe Radio**

- **Metropolitan Fire Communications (Dispatch)** — Canalul principal, monitorizat permanent
- **TAC Channels (Tactical)** — Canale secundare pentru coordonare la fața locului la incidente complexe; alocate de Dispatch la activarea unui incident major

 **13.8 Consecințele Comunicării Radio Deficitare**

 Eșecul în menținerea disciplinei radio va afecta negativ evaluările DOR și poate constitui motiv de sancțiuni disciplinare, mai ales dacă este vorba de o problemă recurentă sau dacă a afectat desfășurarea unei intervenții.

 [hr]

 **14. PROCEDURI DE SIGURANȚĂ LA FAȚA LOCULUI**

 **14.1 Siguranța ca Prioritate Supremă**

 **Siguranța la fața locului este prioritatea operațională absolută a LSFD.**

 Nicio urgență nu justifică punerea în pericol a vieților echipajului sau ale victimelor prin ignorarea procedurilor de siguranță.

 **14.2 Obligațiile de Siguranță ale Cursanților**

 Cursanții trebuie să:

- **Identifice pericolele** — la orice sosire pe scenă, prima acțiune este evaluarea pericolelor prezente: incendiu, substanțe periculoase, pericole structurale, trafic rutier, pericole de securitate
- **Mențină conștiința situațională** — să știe în orice moment ce se petrece în jur și cum evoluează situația
- **Respecte cerințele EIP** — Echipamentul Individual de Protecție (cască, costum ignifug, mănuși, bocanci de protecție, SCBA) trebuie utilizat conform protocoalelor LSFD; ignorarea EIP nu este curaj, ci imprudență
- **Respecte structura de comandă** — ierarhia operațională la fața locului există pentru a asigura coordonarea eficientă și siguranța tuturor
- **Evite freelancingul** — acțiunea fără coordonare sau autorizare este unul dintre cei mai periculoși factori de risc la fața locului
- **Prioritizeze siguranța civililor și a echipajului** — un pompier rănit nu mai poate ajuta pe nimeni

 **14.3 Consecințele Ignorării Siguranței**

 Acțiunile nesigure vor fi supuse **imediat revizuirii disciplinare**, indiferent de context sau de explicațiile oferite. Siguranța nu este negociabilă și nu admite justificări retrospective.

 [hr]

 **15. AȘTEPTĂRI OPERAȚIONALE**

 **15.1 Conduita Operațională**

 Cursanții sunt așteptați să demonstreze standarde operaționale ridicate în fiecare aspect al activității lor zilnice:

- **Să răspundă rapid și profesional la urgențe** — pregătirea vehiculelor, echipamentului și a cursantului însuși pentru intervenție promptă este o responsabilitate permanentă
- **Să înțeleagă misiunile de aparatură** — fiecare vehicul de intervenție are o misiune specifică: Engine (water supply/fire attack), Truck (ventilație/forcible entry), Squad (technical rescue), Rescue Ambulance (transport medical ALS/BLS)
- **Să demonstreze lucrul în echipă** — comunicarea activă cu colegii, anticiparea nevoilor echipei și contribuția la succesul misiunii în ansamblu
- **Să mențină starea de pregătire operațională** — echipamentul personal și vehiculele trebuie verificate regulat; pregătirea este un proces continuu
- **Să se adapteze la situații stresante** — menținerea eficienței operaționale chiar și atunci când situația este haotică și presiunea este maximă
- **Să respecte toate SOP-urile LSFD** — procedurile standard de operare nu sunt sugestii; sunt instrucțiuni obligatorii

 [hr]

 **16. DOCUMENTAȚIE ȘI RAPORTARE**

 **16.1 Importanța Documentației**

 Documentația operațională este fundamentul responsabilității instituționale. Rapoartele de intervenție constituie înregistrarea oficială a acțiunilor departamentului — ele pot fi utilizate în investigații, proceduri juridice, evaluări de calitate și decizii administrative. O documentație deficitară poate expune atât individul, cât și departamentul la consecințe grave.

 **16.2 Standardele de Documentare**

 Toate rapoartele completate în cadrul FTP trebuie să fie:

- **Precise** — informațiile incluse trebuie să fie corecte și verificabile
- **Profesionale** — tonul, limbajul și formatul trebuie să respecte standardele documentației oficiale
- **Detaliate** — un raport complet include toate informațiile relevante: timp, locație, persoane implicate, acțiuni întreprinse, resurse utilizate
- **Corecte gramatical** — erorile gramaticale evidente compromit credibilitatea documentului
- **Depuse în termenele departamentale** — rapoartele tardive pot afecta deciziile operaționale și administrative

 **Falsificarea rapoartelor constituie conduită gravă** și va fi tratată cu cea mai mare severitate, inclusiv cu excluderea imediată din FTP.

 [hr]

 **17. PROCEDURI MEDICALE DE BAZĂ (BLS)**

 **17.1 Scopul Acestui Capitol**

 Acest capitol oferă cursanților un cadru de referință pentru procedurile medicale de bază (Basic Life Support — BLS) pe care trebuie să le cunoască și să le aplice în teren. Certificarea BLS este **obligatorie** pentru toți membrii LSFD operaționali. Procedurile detaliate avansate sunt acoperite în manualele specifice BLS și ALS ale departamentului.

 **17.2 Procedura Generală la Sosire**

 **17.2.1 Izolarea Substanțelor Corporale (BSI)**
 Înainte de orice contact cu pacientul:
- Purtați întotdeauna **mănuși medicale**
- Dacă există risc de expunere la lichide biologice (sânge, vomă), purtați **ochelari de protecție**
- Utilizați **mască chirurgicală** în cazul bolilor infecțioase cunoscute sau suspectate

 **17.2.2 Securitatea Scenei**
- **Nu intrați** pe o scenă instabilă fără confirmarea că este sigură (ex: incendiu activ, scenă de crimă — așteptați LSPD)
- **Parcați corect** — nu blocați benzi de circulație fără necesitate; asigurați o zonă de lucru sigură
- **Controlați accesul** la scenă; solicitați sprijinul LSPD/SD dacă sunt martori sau persoane agresive
- **Siguranța personală primează** — dacă scena devine periculoasă, evacuați imediat și chemați suport
- **Fiți atenți la pericole specifice**: seringi, substanțe toxice, trafic activ, structuri instabile

 **17.2.3 Estimarea Numărului de Pacienți**
- La sosire, estimați imediat numărul de victime
- Dacă depășesc capacitatea unităților prezente — solicitați **resurse suplimentare**
- Dacă sunt peste 4 victime — activați **MCI Protocol**; Dispatch va aloca o unitate MCU la fața locului

 **17.3 Schema de Evaluare DR ABC / DR CAB**

 Schema de evaluare primară a pacientului se desfășoară conform protocolului **DR ABC** sau **DR CAB** (ambele aprobate în LSFD):

 **D — Danger (Pericol)**
 Reevaluați siguranța scenei. Verificați pericolele active: trafic, seringi, zone de crimă. Notificați PD/SD dacă este necesar.

 **R — Response (Răspuns)**
 Verificați dacă pacientul este conștient. Strigați-l pe nume sau spuneți „Vă auziți?". Dacă nu răspunde verbal, aplicați un stimul dureros minor (ciupire mușchi trapez). Evaluați nivelul de conștiență cu scala **AVPU**:
- **A — Alert**: Pacientul este complet conștient și receptiv
- **V — Verbal**: Răspunde la stimuli verbali
- **P — Pain**: Răspunde doar la durere
- **U — Unresponsive**: Nu răspunde la niciun stimul

 *Notă: Dacă pacientul este Alert (A), treceți direct la evaluarea prin dialog — nu este necesară continuarea cu ABC.*

 **A — Airway (Căile Respiratorii)**
 Verificați și asigurați permeabilitatea căilor respiratorii. Tehnici:
- **Head-Tilt Chin-Lift (Înclinarea capului)** — metodă principală, utilizată când nu există suspiciune de leziune spinală
- **Jaw-Thrust (Tracțiunea mandibulei)** — utilizat când se suspectează leziuni ale coloanei cervicale
- **Recovery Position** — dacă pacientul este inconștient dar respiră, cu căi respiratorii libere

 **B — Breathing (Respirație)**
 Evaluați respirația: privind mișcările toracelui, ascultând sunetele respiratorii, simțind fluxul de aer. Frecvența normală la adulți: 12–18 respirații/minut. Respirație anormală (absentă, superficială, șuierătoare) — considerați suport respirator și/sau chemare ALS.

 **C — Circulation (Circulație)**
 Localizați și controlați sângerările. Evaluați pulsul (radial, brahial sau carotidian). Valorile normale ale pulsului:
- Adulți: 60–100 bpm
- Adulți sportivi: 40–60 bpm

 Evaluați culoarea, temperatura și starea pielii (palidă/cianotică/roșie, rece/caldă, uscată/diaforetică).

 **17.4 Triajul — Sistemul de Prioritizare START**

 Triajul se aplică obligatoriu când există **3 sau mai multe victime**. Scopul este alocarea eficientă a resurselor medicale:

 **ROȘU — IMEDIAT**
 Pacientul necesită îngrijiri imediate — leziuni cu risc vital. Criterii: frecvență respiratorie > 30/min, puls radial absent sau foarte slab, stare de conștiență alterată (confuz, nu urmează comenzi simple).

 **GALBEN — ÎNTÂRZIAT**
 Pacientul nu îndeplinește criterii ROȘU sau NEGRU, dar nu poate merge. Necesită tratament, dar poate aștepta.

 **VERDE — MINOR**
 Pacientul poate merge la solicitare. Leziuni minore ce pot fi tratate după prioritățile superioare.

 **NEGRU — DECEDAT / EXPECTANT**
 Pacientul nu respiră nici după deschiderea căilor aeriene. Resursele sunt mai eficient utilizate pe alte victime.

 **17.5 Tratamentul Sângerărilor**

 La orice sângerare semnificativă, aplicați protocolul **DPT**:

 **D — Dressing (Pansament)**
 Expuneți rana (tăiați îmbrăcămintea). Aplicați pansamentul pentru traumatisme direct pe rană. **Nu îndepărtați** niciodată obiecte înfipte (sticlă, gloanțe) — bandajați în jurul lor.

 **P — Pressure (Presiune)**
 Aplicați presiune directă fermă și continuă pe pansament. Mențineți cel puțin 5–10 minute fără întrerupere.

 **T — Tourniquet (Garou)**
 Utilizat pentru sângerări severe la membre care nu răspund la presiune directă. Aplicați proximal față de rană. Documentați **ora exactă a aplicării** pe pansament sau pe garoul propriu-zis.

 **17.6 Solicitarea Resurselor Suplimentare**

- Solicitați **a doua ambulanță** dacă numărul de pacienți depășește capacitatea
- Notificați **LSPD/SD** pentru pericole de securitate, trafic sau violență la scenă
- Solicitați **Hazmat** pentru materiale periculoase
- Solicitați **Engine/Truck** pentru victime prinse sau incendii asociate
- Activați **ALS support** (paramedic) pentru proceduri avansate (intubație, medicamente IV/IO, EKG)

 [hr]

 **18. DISPOZIȚII FINALE**

 **18.1 Autoritatea Biroului de Instruire**

 Biroul de Instruire și Dezvoltare Profesională deține autoritatea deplină de a administra, modifica și aplica FTP-ul. Acesta își rezervă dreptul de a:

- **Modifica procedurile FTP** — actualizând protocolul în funcție de experiența acumulată sau de cerințele departamentale
- **Revizui standardele operaționale** — ajustând criteriile de evaluare pentru a reflecta evoluția cerințelor serviciului
- **Suspenda cursanți** — până la clarificarea unor situații disciplinare sau administrative
- **Revoca certificările FTO** — retragând dreptul de instruire al ofițerilor care nu respectă standardele impuse
- **Implementa sisteme noi de evaluare** — introducând metode îmbunătățite de măsurare a performanței

 **18.2 Amendamentele la Manual**

 Orice modificare a prezentului manual va fi comunicată tuturor membrilor LSFD implicați în FTP prin canalele oficiale de comunicare ale departamentului. Versiunea curentă a manualului va fi disponibilă permanent pe platformele interne ale LSFD.

 **18.3 Interpretarea Prevederilor**

 În cazul oricărei ambiguități în interpretarea prevederilor prezentului manual, autoritatea de interpretare aparține Directorului Biroului de Instruire și Dezvoltare Profesională. Interpretarea sa este obligatorie și definitivă.

 **18.4 Conformitatea cu Manualul**

 Participarea la Programul de Formare pe Teren implică acceptarea și conformarea cu toate prevederile prezentului manual. **Ignoranța față de o regulă nu constituie o scuză valabilă pentru nerespectarea acesteia.**

 [hr]

 **DECLARAȚIE DE ANGAJAMENT**

 *Prin participarea la Programul de Formare pe Teren al LSFD, mă angajez să respect în totalitate prevederile prezentului manual, să urmăresc excelența operațională și profesională, să reprezint valorile Departamentului de Pompieri din Los Santos cu demnitate și integritate, și să contribui la misiunea departamentului de a proteja viața și proprietatea comunității pe care o deservim.*

 [hr]

 **Biroul de Instruire și Dezvoltare Profesională**
 **Departamentul de Pompieri din Los Santos**
 *Training & Professional Development Bureau — LSFD*

 *Manualul FTP este un document oficial al LSFD. Orice reproducere sau distribuire neautorizată este interzisă.
 Versiunea curentă înlocuiește toate versiunile anterioare.*
---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---
