# CAPITOLUL VI – PROCEDURI DISCIPLINARE ALE FIREFIGHTER UNION

- **Topic ID:** 36
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=36
- **Posts:** 1

---

## #1 — Kellan Dunley

![](https://i.imgur.com/2jlMxHe.png)

FIREFIGHTER UNION MANUAL

---

 CAPITOLUL VI – PROCEDURI DISCIPLINARE ALE FIREFIGHTER UNION
---

---

- **(6.1)** Scopul și principiile fundamentale ale procedurii disciplinare

---

---

- Procedura disciplinară reprezintă mecanismul formal prin care Departamentul de Pompieri analizează comportamentul unui membru atunci când există suspiciuni privind încălcarea regulilor, procedurilor operaționale sau a standardelor profesionale.    Rolul Firefighter Union este de a garanta că acest proces este:    • corect;   • transparent;   • echilibrat;   • lipsit de prejudecăți;   • bazat pe dovezi;   • respectuos cu drepturile membrului.    Pompierii iau decizii în condiții de stres extrem; orice analiză ulterioară trebuie să țină cont de contextul real al intervenției. O procedură disciplinară corectă este fundamentală pentru protejarea integrității profesionale.

 -
---

---

- **(6.2)** Categorii de abateri disciplinare

---

---

- Pentru a menține consistența deciziilor, abaterile sunt clasificate în patru categorii:    **A. Abateri minore**   • întârzieri repetate;   • nerespectarea uniformei;   • comportament neprofesionist fără consecințe operaționale;   • neexecutarea unor sarcini administrative minore.    **B. Abateri moderate**   • conflicte interne între membri;   • nerespectarea ordinelor non-critice;   • încălcări ale regulamentelor interne;   • lipsa echipamentului necesar.    **C. Abateri majore**   • neglijență operațională cu potențial de risc;   • comportament agresiv;   • refuzul unui ordin operațional;   • afectarea imaginii publice a Departamentului.    **D. Abateri critice**   • consum de alcool sau droguri în timpul serviciului;   • abandonarea postului;   • fapte penale;   • comportament care pune în pericol viața colegilor sau a civililor.

 -
---

---

- **(6.3)** Declanșarea procedurii disciplinare

---

---

- Procedura disciplinară poate fi declanșată în urma:    • unui raport al superiorului direct;   • unei sesizări interne din partea unui membru;   • unei plângeri externe (cetățeni, poliție, alte instituții);   • unui incident operațional major;   • unei investigații interne periodice.    **(6.3.1) Termenul de raportare**   Toate incidentele care ar putea conduce la o procedură disciplinară trebuie raportate în maximum 72 de ore.   Raportarea tardivă fără justificare poate invalida procedura.

 -
---

---

- **(6.4)** Notificarea membrului și a Firefighter Union

---

---

- Odată declanșată procedura, membrul:    • este notificat în scris cu detalierea acuzațiilor;   • primește lista drepturilor procedurale;   • este informat despre data audierii;   • are dreptul să consulte toate documentele oficiale.    Firefighter Union trebuie notificat în maximum 24 de ore de la deschiderea procedurii.   Prezența unui reprezentant sindical este obligatorie la orice discuție oficială.

 -
---

---

- **(6.5)** Faza de investigație

---

---

- Investigația reprezintă etapa critică a procesului disciplinar. Aceasta trebuie să fie obiectivă, documentată și realizată profesionist.    **(6.5.1) Investigatorul desemnat**   Investigația este condusă de:    • un ofițer superior imparțial;   • o comisie mixtă FD Command + Legal;   • un observator sindical (drept de intervenție procedurală, fără drept de decizie).    **(6.5.2) Colectarea probelor**   Investigația poate include:    • rapoarte operaționale;   • înregistrări radio;   • imagini CCTV / bodycam;   • declarații ale martorilor;   • analiza echipamentului;   • documente medicale.    **(6.5.3) Interviurile**   • fără întrebări-capcană;   • fără presiuni psihologice;   • membrul poate cere pauză pentru consultare;   • toate discuțiile sunt înregistrate;   • Union poate contesta întrebările improprii.    **(6.5.4) Raportul final**   La final, investigatorul redactează un raport care include:    • faptele stabilite;   • evaluarea probelor;   • concluziile privind responsabilitatea;   • recomandările privind sancțiunile.    Union primește raportul simultan cu conducerea.

 -
---

---

- **(6.6)** Audierea disciplinară

---

---

- Audierea este momentul oficial în care comisia disciplinară analizează concluziile investigației.    **(6.6.1) Componența comisiei**   • Deputy Chief sau delegat;   • ofițer juridic;   • reprezentant administrativ;   • reprezentant sindical (drept de veto procedural, dar nu decizional).    **(6.6.2) Drepturile membrului**   Membrul are dreptul:    • să fie asistat de reprezentant sindical și/sau avocat;   • să conteste probele;   • să aducă martori;   • să solicite reevaluarea probelor;   • să adreseze întrebări investigatorului;   • să ofere o declarație finală.    **(6.6.3) Standardul decizional**   Decizia trebuie să se bazeze pe:    • dovezi clare;   • imparțialitate totală;   • proporționalitatea sancțiunii;   • istoricul profesional;   • contextul operațional din momentul incidentului.

 -
---

---

- **(6.7)** Măsurile disciplinare

---

---

- Sancțiunile trebuie să fie proporționale cu abaterea:    **A. Avertisment verbal** – pentru abateri minore.   **B. Avertisment scris** – document oficial inclus în dosar.   **C. Suspendare (cu sau fără plată)** – pentru abateri moderate/majore. Union poate contesta suspendările fără plată.   **D. Retrogradare** – se poate contesta prin apel sau arbitraj extern.   **E. Concediere** – sancțiune extremă, aplicată doar după:    • investigație completă;   • audiere oficială;   • opinie juridică;   • consultarea Union;   • garantarea dreptului la apel.    Union poate bloca concedierea prin arbitraj extern.

 -
---

---

- **(6.8)** Procedura de apel

---

---

- Orice membru poate depune apel în 10 zile lucrătoare.    **(6.8.1) Arbitraj intern**   Comisie formată din:    • trei membri seniori ai Union;   • consilier juridic;   • un pompier neutru.    **(6.8.2) Arbitraj extern**   Dacă Union consideră că FD a încălcat procedurile, cazul este transmis unui arbitru independent.    Decizia arbitrului este finală și obligatorie pentru ambele părți.

 -
---

---

- **(6.9)** Situații speciale în procedurile disciplinare

---

---

- **(6.9.1) Incidente cu victime civile**   Union oferă avocat și suport psihologic imediat.    **(6.9.2) Utilizarea forței**   Investigată împreună cu poliția. Union asigură protecția membrului.    **(6.9.3) Probleme psihologice**   În caz de burnout, PTSD sau stres extrem, Union poate solicita înlocuirea sancțiunii cu programe de recuperare.

 -
---

---

- **(6.10)** Protecția membrilor împotriva procedurilor abuzive

---

---

- Firefighter Union poate bloca sau anula proceduri disciplinare dacă ele:    • nu respectă regulile interne;   • sunt disproporționate;   • au fost declanșate fără dovezi;   • sunt influențate politic;   • reprezintă abuzuri de autoritate.    Union poate solicita:    • reluarea investigației;   • schimbarea investigatorului;   • anularea deciziei;   • arbitraj extern.

 -

---
