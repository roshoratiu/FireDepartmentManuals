# Manual Oficial

- **Topic ID:** 17
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=17
- **Posts:** 10

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

Manual Oficial

---

 1. Introducere
- .01.00 Scop  .02.00 Preambul  .03.00 Declarație de misiune  .04.00 Valori fundamentale  .05.00 Principiul de funcționare  .06.00 Organigrama  .07.00 Birouri și funcții ale departamentului .07.01 Birouri și funcții ale departamentului: Biroul șefului pompierilor  .07.02 Birouri și funcții ale departamentului: operațiuni administrative  .07.03 Birouri și funcții ale departamentului: operațiuni de urgență  ---   ---   08.00 Jurământul de mandat

 2. Codul de etică
- .01.00 Scop  .02.00 Așteptări și standarde ale departamentului  .03.00 **((**Așteptările facțiunii **))**

 3. Descrierea poziției
- .01.00 Scop  .02.00 Şeful pompierilor  .03.00 Adjunctul șefului pompierilor  .04.00 Asistent șef pompier  .05.00 Şeful Batalionului de Pompieri  .06.00 Căpitanul de pompieri II  .07.00 Căpitanul de pompieri I  .08.00 Inginer de pompieri  .09.00 Pompier III  .10.00 Pompier II  .11.00 Pompier I  .12.00 Rezerva pentru pompieri  .13.00 Recrute de pompieri

 4. Regulamente privind uniforma și aspectul
- .01.00 Scop  .02.00 Uniforma clasa A  .03.00 Uniforma clasa B  .04.00 Uniforma clasa C  .05.00 Uniforma clasa D  .06.00 Uniforma de exercițiu  .07.00 Utilizarea uniformei  .08.00 Mutilarea corpului  .09.00 Păr  .10.00 Bijuterii  .11.00 Piercinguri pentru corp  .12.00 Tatuaje  .13.00 **((**Articole de îmbrăcăminte**))**

 5. Comportament
- .01.00 Scop  .02.00 Conduita generală  .03.00 Reguli și regulamente  .04.00 Limbajul și comunicarea verbală  .05.00 Respectul pentru colegii angajați ai departamentului și contactele profesionale  .06.00 Angajare în afara serviciului  .07.00 Absența  .08.00 **((**Corupție**))**  .09.00 **((**Permisiunea dublei facțiuni**))**  .10.00 **((**Reguli facțiunii**))**  .11.00 **((**Absență în afara caracterului**))**  .12.00 **((**Schimbarea numelui caracterului**))**

 6. Beneficii de angajare
- .01.00 Scop  .02.00 Beneficii de bază  .03.00 Planuri de acoperire  .04.00 Concediu medical  .05.00 Concediu de vacanta

 7. Politici administrative
- .01.00 Scop  .02.00 Certificari  .03.00 Sistem de promovare .03.01 Sistem de promovare: Cerințe de progres  .03.02 Sistem de promovare: Promoții de ofițer  .03.03 **((**Sistem de promovare: cerințe de activitate**))**  ---   ---   .04.00 Proceduri disciplinare  .05.00 Contestații disciplinare și Consiliul pentru Drepturi  .06.00 Relație sau părtinire rezonabilă  .07.00 Alocarea unității  .08.00 Premii și calificări .08.01 Premii și calificări: laude  .08.02 Premii și calificări: Calificări  ---   ---   .09.00 Centru de Solicitari Personal  .10.00 Service Stripes  .11.00 Program de instruire pe teren .11.01 Program de instruire pe teren: Scala de evaluare  ---   ---   .13.00 **((**Rapoarte de absență**))**  .14.00 **((**Pedepsele administrative**))**  .15.00 **((**Demisia**))**  .16.00 **((**Sugestii**))**

 8. Politici operaționale
- .01.00 Scop  .02.00 Utilizarea asistenței civile  .03.00 Călătorie .03.01 Ride Alongs: Comportamentul unui Ride Along  .03.02 Ride Alongs: Terminarea unui Ride Along  ---   ---   .04.00 Găsirea obiectelor de valoare  .05.00 Personal în afara serviciului  .06.00 Descoperirea unui incident în timpul răspunsului  .07.00 Găsirea unui cadavru  .08.00 Alarma de panică și conștientizarea primejdiei  .09.00 Imagini de la Dash Camera  .10.00 **((**Comenzi ale facțiunii**))**

 9. Politici de comunicare
- .01.00 Scop  .02.00 Telefoane  .03.00 Telefoane mobile  .04.00 Paginare  .05.00 Calculatoare și MDT-uri  .06.00 Comunicaţii radio .06.01 Comunicații radio: utilizarea expresiei  .06.02 Comunicaţii radio: frecvenţe  ---   ---   .07.00 Teme radio  .08.00 Terminologie  .09.00 E-mailuri și scrisori ale departamentului  .10.00 Comunicații Metropolitan Fire  .11.00 Partajarea informațiilor .11.01 Partajarea informațiilor: informații despre pacient  .11.02 Partajarea informațiilor: Documente departamentale  ---   ---   .12.00 **((**Discord**))**  .13.00 **((**TeamSpeak 3**))**

 10. Politici flote/facilități
- .01.00 Scop  .02.00 Responsabilitate  .03.00 Open House Concept  .04.00 Vizitatori  .05.00 Înregistrări și comenzi  .06.00 Atribuții de stații și poziții de aparate atribuite  .07.00 Îndatoririle staţiei  .08.00 Reparatii  .09.00 Pregătirea aparatului  .10.00 Arme de foc și alte arme  .11.00 Vehicule personale  .12.00 Desfăşurarea aparatului  .13.00 Implementări de răspuns .13.01 Implementări de răspuns: Implementarea incidentelor  ---   ---

---

## #2 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

 1. Introducere

---

 Acest capitol stabilește baza standardelor etice, morale și profesionale ale Departamentului. Aceste informații sunt considerate a fi de cunoștință publică și reprezintă un set de directive pe care toți angajații trebuie să le respecte.

 02.00 Preambul

 Manualul de operațiuni, abreviat MOPS, este o colecție de documente care dictează politica, procedura și standardele Departamentului. Manualul de operațiuni este destinat angajaților actuali ai acestui Departament și trebuie citit cu atenție de către angajații nou instalați înainte de a se angaja în orice activitate relevantă pentru Departament.

 Se recomandă o citire periodică a acestor documente pentru a asigura păstrarea cunoștințelor. Orice modificări aduse Manualului de operațiuni care vă afectează ca angajat al acestui Departament vor fi transmise printr-un memorandum sau altă notificare oficială. Dacă sunteți confuz sau aveți întrebări cu privire la orice parte a Manualului de operațiuni, vă rugăm să contactați supervizorul dvs. direct.

 03.00 Declarație de misiune

 O declarație de misiune este definită ca ceva care afirmă scopul sau scopul unei afaceri sau organizații. În centrul acestei definiții, declarația de misiune a Departamentului este următoarea:

 Departamentul de Pompieri Los Santos păstrează viața și proprietatea, promovează siguranța publică și încurajează creșterea economică printr-un angajament de prevenire, pregătire, răspuns și recuperare ca furnizor de răspuns pentru siguranța vieții cu toate riscurile.

 04.00 Valori de bază

 Similar cu o declarație de misiune, valorile de bază sunt un set de ideologii care definesc o afacere sau o organizație. Valorile de bază (sau chiriașii) Departamentului sunt cunoscute prin schema SPIRIT și sunt după cum urmează:

- Serviciu — Dedicare comunității noastre;
- Profesionalism — Onorarea jurământului pompierilor;
- Integritate — Susținerea comportamentului moral și etic în orice moment;
- Respect — Îmbrățișarea diversității și recunoașterea valorii individuale;
- Inovație — Asumarea riscurilor creative pentru a se adapta și îmbunătăți; și
- Încredere — Încrederea pe integritatea, puterea și capacitatea membrilor noștri.

 05.00 Principii de funcționare

 Un principiu de funcționare este un ghid de bază care ar trebui să reprezinte munca pe care o desfășoară un angajat în cadrul Departamentului. Departamentul menține următoarele principii de funcționare, după cum urmează:

- Operați prin munca în echipă;
- Funcționează pentru a poziționa Departamentul pentru viitor; și
- Operați în mod etic și cu integritate.

 06.00 Organigrama

 ![Image](https://i.imgur.com/VqLUGVG.png)

 07.00 Birouri și funcții ale departamentelor

 Departamentul este împărțit în două Operațiuni, care conțin Birouri, Secțiuni și Unități. Departamentul mai conține și Biroul șefului pompierilor, care găzduiește un singur Birou (Biroul Administrativ). Acest sistem organizează diferitele zone ale Departamentului în zone specifice pentru a produce o funcționare zilnică mai eficientă.

 Prima parte a acestui lanț sunt cele două Operațiuni, după cum urmează:

- Operațiuni administrative; și
- Operațiuni de urgență.

 Fiecare operațiune este condusă de un comandant, de obicei un șef asistent de pompieri. Comandanții operațiunilor sunt responsabili pentru supravegherea operațiunii respective, lucrând alături de ofițerii de departament alocați în cadrul operațiunii respective. În cadrul unei operațiuni, există birouri, care se preling fie în unități, fie în divizii. Un birou este condus de un comandant de birou, care este de obicei un căpitan de stație sau un alt ofițer de departament. Comandantul Biroului este responsabil pentru funcționarea acelui Birou și este văzut asistând zilnic. În cadrul unui Birou, există fie unități, fie divizii. Unitățile și diviziile nu se amestecă în cadrul birourilor. Unitățile sunt conduse de un comandant de unitate numit de către comandantul biroului și/sau comandantul operațiunilor. Comandantul unității este responsabil să lucreze alături de comandantul biroului și asistenții săi în conducerea acelei unități. De asemenea,

 07.01 Birouri și funcții ale departamentului: Biroul șefului pompierilor

 Biroul Șefului Pompierilor este o parte specializată a Departamentului, care conține un singur Birou și alcătuind Ofițerii șefi de departament.

 Biroul de administrare este compus din trei Divizii: Divizia Standarde Profesionale, Divizia Relații cu Angajații și Divizia Resurse Umane. Acest birou lucrează îndeaproape cu Biroul șefului pompierilor și alți administratori de pompieri datorită naturii acestor divizii.

 Sarcina Diviziei Standarde Profesionale este de a menține standardele în cadrul Departamentului, de a gestiona plângerile disciplinare și de a asista Administrația de Pompieri cu alte sarcini legale. Divizia Standarde Profesionale este separată în continuare în două unități: Unitatea de investigații pe teren și Unitatea de investigații interne.

 Sarcina Direcției Relații cu Angajații este de a comunica atât cu publicul, cât și cu angajații, oferind acces facil la informațiile referitoare la Departament.

 Sarcina Diviziei de Relații Umane este de a revizui personalul activ și care revine. Unele dintre sarcinile acestei divizii includ revizuirea cererilor de rezervă pentru pompieri, revizuirea angajaților de upgrade și promovare, examinarea statutului și alte sarcini delegate de Biroul șefului pompierilor. Divizia de Relații Umane nu se ocupă de selecția de pompieri la nivel de intrare, de care se ocupă Biroul de Formare și Suport al Operațiunilor Administrative.

 07.02 Birouri și funcții departamentale: operațiuni administrative

 Operațiuni administrative este însărcinată cu partea administrativă a Departamentului. Operațiunile administrative lucrează frecvent alături de Biroul șefului de pompieri și Administrația de pompieri, datorită naturii Birourilor implicate.

 Operațiunile administrative este alcătuită din două birouri care sunt după cum urmează:

- Biroul pentru prevenirea incendiilor și siguranța publică (FPB)
- Biroul de Formare și Suport (TSB)

 Obiectivul principal al Biroului de Prevenire a Incendiilor și Siguranță Publică este investigarea incendiilor, determinând cauza fiecărui incendiu la care participă Departamentul, prevenind în mod proactiv apariția mai multor incendii prin creșterea gradului de conștientizare a publicului cu privire la problemă, inspectând întreprinderile și asigurându-se că respectă legea.

 Biroul de Formare și Suport este compus din două unități principale: Unitatea de Recrutare și Academia de Formare a Recruților. Biroul de Instruire și Suport are sarcina de a pregăti atât recruții, cât și personalul, managementul flotei și Programul de instruire pe teren.

 07.03 Birouri și funcții departamentale: operațiuni de urgență

 Operațiunile de Urgență este însărcinată cu funcționarea zilnică a Departamentului. Operațiunile de Urgență angajează majoritatea angajaților Departamentului.

 Operațiunile de Urgență este alcătuită din două Birouri care sunt după cum urmează:

- Biroul de operațiuni (OB)
- Biroul Servicii Medicale de Urgență (EMB)

 Biroul de operațiuni conține două unități operaționale suplimentare:

- Unitatea de operațiuni aeriene (AOU)
- Unitatea de căutare și salvare urbană (USAR)

 Biroul de operațiuni conține, de asemenea, Stația de pompieri 11. Stația de pompieri 11 este însărcinată cu răspunsul zilnic medical și de incendiu în combinație cu alte stații și agenții private și guvernamentale.

 Biroul de operațiuni este alcătuit din pompieri din prima linie care lucrează la o stație și servesc atât ca pompieri, cât și ca agenți medicali. Unitățile interioare sunt formate din pompieri cu calificare și pregătire avansată.

 Unitatea de Operațiuni Aeriene are sarcina de a oferi suport aerian, fie sub formă de stingere a incendiilor, fie de urgență medicală. Această unitate este formată din piloți de elicopter cu înaltă pregătire care operează în jurul jurisdicției Los Santos și în jurisdicțiile învecinate.

 Unitatea de Căutare și Salvare Urbană are sarcina de a oferi sprijin avansat de salvare pompierilor obișnuiți. Această unitate execută o varietate de salvări diferite și foarte specializate, de la marine la spațiu închis până la salvari montane. Unitatea de Căutare și Salvare Urbană este, de asemenea, responsabilă pentru răspunsul de urgență la incidentele cu materiale periculoase. Angajații Unității de Căutare și Salvare Urbană sunt instruiți în decontaminarea în masă și de urgență, extracția rapidă (salvare într-un mediu periculos) și gestionarea armelor de distrugere în masă.

 Biroul Servicii Medicale de Urgență cuprinde Unitatea de Sănătate Publică. Unitatea de Sănătate Publică și Directorul EMS (medic șef) sunt responsabile pentru toate răspunsurile medicale zilnice care sunt gestionate de Departament. Biroul găzduiește, de asemenea, Unitatea avansată de răspuns a furnizorilor (APRU), care se ocupă de îngrijirea medicală non-urgentă.

 08.00 Jurământul în funcție

 Jurământul de oficiu („Jurământul pompierilor”) este un jurământ care a fost depus de fiecare angajat al departamentului care a depus un jurământ de foc. Scopul Jurământului în funcție („Jurământul Pompierului”) este acela de a insufla angajatului un simț al responsabilității și de a-l trage la răspundere atunci când acesta încalcă Jurământul de Funcție („Jurământul de Pompier”).

 Jurământul în funcție („Jurământul pompierului”) este următorul:
 Jur (sau afirm) atât de solemn că voi sprijini și apăra Constituția Statelor Unite și Constituția statului San Andreas împotriva tuturor dușmanilor, străini și interni, încât voi avea adevărată credință și loialitate față de Constituția Statele Unite ale Americii și Constituția statului San Andreas, că îmi asum această obligație în mod liber, fără nicio rezervă mentală sau scop de evaziune și că îmi voi îndeplini bine și cu fidelitate îndatoririle în care sunt pe cale să intru.
---

---

---

## #3 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

2. Codul de etică

---

 01.00 Scop

 Acest capitol stabilește baza standardelor de etică profesională pe care angajații Departamentului trebuie să le respecte.

 02.00 Așteptări și standarde ale departamentului

 Departamentul folosește standarde riguroase pentru toți angajații și operațiunile pentru a oferi cea mai înaltă calitate a serviciilor. Așteptările de bază sunt următoarele:

- Angajații departamentului trebuie să respecte toate legile și actele stabilite de statul San Andreas și de organele legale locale;
- Angajații departamentului trebuie să trateze ceilalți angajați și persoane cu respect, indiferent de orice certuri; și
- Angajații departamentului trebuie să se reprezinte în mod profesionist în orice moment.

 **((**03.00 Așteptările facțiunii**))**

 În calitate de membru al unei facțiuni, menții așteptări în afara caracterului cu privire la modul în care acționezi și te comporți. Acest lucru se aplică **toate** personajelor din joc, precum și conturilor de pe alte platforme Los Santos Roleplay. Așteptările de bază sunt următoarele:

- Membrii facțiunii trebuie să respecte toate regulile LS-RP pe toate platformele legate de LS-RP;
- Membrii facțiunii trebuie să urmeze toate procedurile enumerate în Manualul de operațiuni;
- Membrii facțiunii trebuie să joace de rol într-un mod realist, fidel caracterului și dezvoltării caracterului lor;
- Membrii facțiunii trebuie să joace rol într-o manieră corectă, absenți de orice mentalitate de joc pentru a câștiga; și
- Membrii facțiunii trebuie să trateze cu respect pe ceilalți membri ai facțiunii și comunității, indiferent de orice certuri.

![](https://i.imgur.com/2jlMxHe.png)

3. Descrieri de poziție

---

 01.00 Scop

 Acest capitol stabilește bazele informațiilor relevante pentru anumite ranguri și poziții din cadrul Departamentului.

 02.00 Șeful pompierilor

 **Tipul de poziție**:
 Administrativ, jurat de foc

 **Categoria de plată**:
 241.310,16 USD - 260.000,11 USD

 **Așteptările săptămânii de lucru**:
 Scuti.

 **Raportează către:**
 Consiliul Comisarilor de Pompieri, orașul Los Santos.

 **Rezumat:**
 Șeful pompierilor este considerat director general al departamentului și este responsabil pentru supravegherea dezvoltării și a funcționării generale.

 **Datorii și responsabilități principale**:
- Să servească drept magistrală al Departamentului la mass-media sau alte evenimente;
- Managementul general al personalului Departamentului până la adjunctul șefului pompierilor în conformitate cu politica Departamentului și reglementările serviciului public; și
- Dezvoltarea și supravegherea politicii, procedurii și așteptărilor Departamentului.

 **Calificări și/sau certificări obligatorii**:
- Tehnician medical de urgență — Avansat
- INCENDIU 3

 **Poziții potențiale**:
 Șeful Pompierilor este considerat Director General al Departamentului și poate prelua orice funcție suplimentară în cadrul Departamentului, acolo unde se consideră necesar.

 **Limita pozițională**:
 Departamentului i se permite să angajeze un (1) șef de pompieri.

---

---

 03.00 Adjunctul șefului pompierilor

 **Tipul de poziție**:
 Administrativ, jurat de foc

 **Categoria de plată**:
 165.139,92 USD - 232.999,92 USD

 **Așteptările săptămânii de lucru**:
 Scuti.

 **Raportează către:**
 Pompier sef.

 **Rezumat:**
 Adjunctul șefului pompierilor este considerat director general adjunct al Departamentului, în principal responsabil pentru asistarea șefului pompierilor în administrarea Departamentului.

 **Datorii și responsabilități principale**:
- Asistență șefului pompierilor în administrarea Departamentului;
- Supraveghează personalul Departamentului până la Asistent șef al pompierilor;
- Asigurați-vă că politica, procedura și așteptările Departamentului, precum și reglementările serviciului public sunt respectate; și
- Preluați comanda Departamentului de Pompieri cu autoritate deplină în absența șefului pompierilor.

 **Calificări și/sau certificări obligatorii**:
- Tehnician medical de urgență — Avansat
- INCENDIU 3

 **Poziții potențiale**:
 Adjunctul șefului de pompieri poate ocupa orice funcție suplimentară în cadrul Departamentului, acolo unde consideră necesar.

 **Limita pozițională**:
 Departamentului i se permite să angajeze un (1) șef adjunct al pompierilor.

---

---

 04.00 Asistent șef pompier

 **Tipul de poziție**:
 Administrativ, jurat de foc

 **Categoria de plată**:
 116.689,37 USD - 158.750,64 USD

 **Așteptările săptămânii de lucru**:
 saptamana de 40 de ore.

 **Raportează către:**
 Adjunctul șefului pompierilor.

 **Rezumat:**
 Asistentul șef de pompieri joacă un rol important în administrarea Departamentului, supraveghend toate Posturile, șefii batalioanelor de pompieri și conducând una dintre operațiuni.

 **Datorii și responsabilități principale**:
- Supraveghează personalul Departamentului până la Șeful Batalionului de Pompieri;
- Asigurați-vă că politica, procedura și așteptările Departamentului, precum și reglementările serviciului public sunt respectate;
- Gestionează toate cererile în cadrul Operațiunii lor;
- Finalizați promoțiile atunci când este necesar; și
- Asigurați legătura cu alte departamente și echipe în situații care justifică o astfel de legătură.

 **Calificări și/sau certificări obligatorii**:
- Tehnician medical de urgență — Avansat
- INCENDIU 3

 **Poziții potențiale**:
 Asistentul șef al pompierilor poate fi responsabil de una dintre operațiuni: comandant al operațiunilor administrative, comandant al operațiunilor de urgență sau comandant al operațiunilor speciale.

 **Limita pozițională**:
 Departamentului i se permite să angajeze trei (3) șefi asistenți de pompieri.

---

---

 05.00 Șeful batalionului de pompieri

 **Tipul de poziție**:
 Jurat de foc

 **Categoria de plată**:
 94.839,94 USD - 113.065,20 USD

 **Așteptările săptămânii de lucru**:
 Săptămâna de 56 de ore.

 **Raportează către:**
 Asistent șef de pompieri.

 **Rezumat:**
 Șefii batalionului de pompieri au o linie de comunicare mai directă cu angajații Departamentului, care supraveghează stațiile din cadrul batalionului său. Șefii batalionului de pompieri sunt responsabili pentru gestionarea personalului și alte afaceri administrative. Șefii batalionului de pompieri au un contact mai direct cu membrii Departamentului, deoarece sunt localizați la propria stație din cadrul batalionului lor. Aceștia sunt în principal responsabili pentru afacerile administrative legate de personal.

 **Datorii și responsabilități principale**:
- Supraveghează personalul Departamentului până la Fire Captain II;
- Să-și conducă stația cu deplină autoritate;
- Autorizează promoții în cadrul stației lor;
- Participați la apeluri cu personalul lor atunci când este necesar și asigurați-vă că toate procedurile sunt respectate corect și reglementările respectate;
- Asumați comanda de incident atunci când este prezent la fața locului, cu excepția cazului în care nu este favorabil din motive justificate;
- Asigurați legătura cu Biroul șefului pompierilor, după caz;
- Să-și supravegheze (asistentul) căpitanilor de stație și să mențină un grad de responsabilitate pentru fiecare încălcare a politicii; și
- Funcționează în limitele bugetului stațiilor sale și autorizează achizițiile de echipamente.

 **Calificări și/sau certificări obligatorii**:
- Tehnician medical de urgență — Avansat
- INCENDIU 3

 **Poziții potențiale**:
 Șefii batalionului de pompieri pot ocupa o poziție de batalion de stație la oricare dintre stații.

 **Limita pozițională**:
 Departamentului i se permite să angajeze șase (6) șefi de batalioane de pompieri.

---

---

 06.00 Fire Captain II

 **Tipul de poziție**:
 Jurat de foc

 **Categoria de plată**:
 90.999,51 USD - 94.347,77 USD

 **Așteptările săptămânii de lucru**:
 Săptămâna de 56 de ore.

 **Raportează către:**
 Șeful batalionului de pompieri desemnat de el.

 **Rezumat:**
 Căpitanul de pompieri II este în principal responsabil pentru interacțiunea cu personalul rudei de stație pe teren, informându-i cu privire la progresul său, monitorizând cât de bine se descurcă. Pompierii căpitanilor II au, de asemenea, sarcina de a gestiona problemele administrative legate de personal în cadrul stației sale, alături de batalionul stației.

 **Datorii și responsabilități principale**:
- Supraveghează personalul Departamentului până la Căpitanul Pompierii I;
- Asigurați-vă că toate sarcinile asistenților căpitanilor de stație sunt îndeplinite în mod corespunzător în orice moment;
- Ajută batalionul de stație să se asigure că stația lor funcționează fără probleme;
- Sugerează promoții pentru personalul merituos din cadrul stației sale;
- Acționează ca un supervizor pe teren, participând activ la fiecare apel de stingere a incendiilor cu Stația lor, atunci când este posibil;
- Asigurați-vă că toate procedurile sunt respectate corect și reglementările sunt respectate;
- Asumați comanda de incident în absența unui șef de batalion de pompieri, cu excepția cazului în care nu este capabil pentru instruire și/sau în scopuri practice; și
- Trimiteți problemele și întrebările în sus pe lanțul de comandă, după cum este necesar.

 **Calificări și/sau certificări obligatorii**:
- Tehnician medical de urgență — Avansat
- INCENDIU 3

 **Poziții potențiale**:
 Căpitanul de pompieri II poate ocupa o poziție de căpitan de stație la oricare dintre stații.

 **Limita pozițională**:
 Departamentului i se permite să angajeze douăsprezece (12) căpitan-uri de pompieri II.

---

---

 07.00 Căpitanul de pompieri I

 **Tipul de poziție**:
 Jurat de foc

 **Categoria de plată**:
 51.092,61 USD - 68.035,24 USD

 **Așteptările săptămânii de lucru**:
 Săptămâna de 56 de ore.

 **Raportează către:**
 Șeful batalionului de pompieri și căpitanul stației.

 **Rezumat:**
 Căpitanul pompierilor este cel mai responsabil pentru interacțiunea cu personalul rudă al stației pe teren, să răspundă la apelurile cu aceștia, să-i informeze despre progresul său și să monitorizeze cât de bine se performanță. Căpitanul de pompieri este, de asemenea, însărcinat cu gestionarea afacerilor administrative legate de personal în cadrul stației lor, alături de batalionul de stație și de căpitanul de stație.

 **Datorii și responsabilități principale**:
- Supraveghează personalul Departamentului până la Pompier III;
- Ajută batalionul și căpitanul stației lor să se asigure că stația lor funcționează fără probleme;
- Sugerează promoții pentru personalul merituos din cadrul stației lor și participă la procesul de vot;
- Acționează ca un supervizor pe teren, participând activ la fiecare apel de stingere a incendiilor cu Stația lor, atunci când este posibil;
- Asigurați-vă că toate procedurile sunt respectate corect și reglementările sunt respectate;
- Asumarea Comandamentului de incident în absența unui șef de batalion de pompieri și a unui căpitan de stație, cu excepția cazului în care nu este capabil pentru instruire și/sau în scopuri practice; și
- Trimiteți problemele și întrebările în sus pe lanțul de comandă, după cum este necesar.

 **Calificări și/sau certificări obligatorii**:
- Tehnician medical de urgență — Avansat
- INCENDIU 3

 **Poziții potențiale**:
 Căpitanul de pompieri I poate prelua o funcție de Asistent căpitan de stație la oricare dintre stații.

 **Limita pozițională**:
 Departamentului i se permite să angajeze doisprezece (12) căpitan de pompieri.

---

---

 08.00 Inginer de pompieri

 **Tipul poziției:**
 Jurat de foc

 **Class de plată:**
 50.276,06 USD - 51.092,61 USD

 **Așteptări pentru săptămâna de lucru:**
 Săptămâna de 56 de ore.

 **Raportează către:**
 Căpitanul său de stație.

 **Rezumat:**
 Inginerii de pompieri sunt în mare parte responsabili pentru interacțiunea cu personalul rudă al stației pe teren și pentru a răspunde apelurilor cu aceștia. Acesta este cel mai înalt nivel de vechime pe care îl poate atinge înaintea Căpitanului.

 **Datorii și responsabilități principale:**
- Ajută batalionul și căpitanul stației lor să se asigure că stația lor funcționează fără probleme;
- Acționați ca supervizor pe teren atunci când un căpitan de stație sau mai mare este indisponibil;
- Asigurați-vă că toate procedurile sunt respectate corect și reglementările sunt respectate;
- Asumați comanda de incident în absența unui șef de batalion de pompieri și a unui căpitan de stație, cu excepția cazului în care nu este capabil pentru instruire și/sau în scopuri practice;
- Redirecționați problemele și anchetele în sus pe lanțul de comandă, după cum este necesar;
- Asistați, instruiți și observați în mod activ angajații mai noi ai Departamentului, inclusiv răspunzând la orice întrebări pe care le-ar putea avea;
- Demonstrați o poziție proactivă atât în ​​ceea ce privește stingerea incendiilor, cât și apelurile medicale în mod egal;
- Asigurați-vă că toți membrii de rang inferior sunt alocați și își îndeplinesc corespunzător rolurile atribuite pe fiecare scenă;
- Se ocupă de documentele legate de Programul de instruire pe teren; și
- Arătați un nivel ridicat de activitate în cadrul Programului de instruire pe teren.

 **Calificări și/sau certificări obligatorii:**
- Tehnician medical de urgență — Avansat
- FOC 3

 **Poziții potențiale:**
 Ofițer de pregătire pe teren II.

 **Limita pozițională:**
 Nici unul.

---

---

 09.00 Pompierul III

 **Tipul de poziție**:
 Jurat de foc

 **Categoria de plată**:
 45.678,73 USD - 50.276,06 USD

 **Așteptările săptămânii de lucru**:
 Săptămâna de 56 de ore.

 **Raportează către:**
 Căpitan de stație (asistent) desemnat.

 **Rezumat:**
 Pompierul III (Field Training Officer) este cea mai înaltă funcție de subofițer pe care o poate atinge un membru în cadrul Departamentului, axarea sa principală fiind către formarea și testarea de noi membri.

 **Datorii și responsabilități principale**:
- Acționează ca prim punct de contact pentru angajații departamentului de rang inferior;
- Asistați, instruiți și observați în mod activ angajații departamentului mai noi, inclusiv răspunzând la orice întrebări pe care le-ar putea avea;
- Asumați comanda incidentului în cazul absenței unei persoane de rang superior;
- Demonstrați o poziție proactivă atât în ​​ceea ce privește stingerea incendiilor, cât și apelurile medicale în mod egal;
- Asigurați-vă că toți membrii de rang inferior sunt alocați și își îndeplinesc corespunzător rolurile atribuite pe fiecare scenă;
- Se ocupă de documentele legate de Programul de instruire pe teren; și
- Arătați un nivel ridicat de activitate în cadrul Programului de instruire pe teren.

 **Calificări și/sau certificări obligatorii**:
- Tehnician medical de urgență — Avansat
- INCENDIU 3

 **Poziții potențiale**:
 Ofițer de pregătire pe teren I, Ofițer de pregătire pe teren II.

 **Limita pozițională**:
 Nici unul.

---

---

 10.00 Pompierul II

 **Tipul de poziție**:
 Jurat de foc

 **Categoria de plată**:
 40.736,88 USD - 44.396,10 USD

 **Așteptările săptămânii de lucru**:
 48 de ore pe săptămână.

 **Raportează către:**
 Căpitan de stație (asistent) desemnat.

 **Rezumat:**
 Pompierul II este cea mai obișnuită și esențială poziție a Departamentului, cu un nivel ridicat de concentrare pe munca de teren, deținută de tot personalul cu jurământ de pompieri care a promovat Programul de pregătire pe teren, cu excepția unui ofițer de pregătire pe teren și mai sus.

 **Datorii și responsabilități principale**:
- Participați atât la apelurile medicale, cât și la cele de stingere a incendiilor, după cum este necesar, după expediere;
- Să-și asume un rol adecvat care le-a fost atribuit de Comandamentul de incident;
- Asumați comanda incidentului pe scenele de suprimare a incendiilor până când este prezent un individ de rang superior;
- Acționează ca un model pentru membrii mai puțin experimentați ai Departamentului;
- Urmați orice ordine de la personalul aflat într-o poziție de autoritate;
- Completează toate documentele necesare legate de atribuțiile lor; și
- Participați la treburile casnice în jurul stației desemnate, care pot include gătit și curățare.

 **Calificări și/sau certificări obligatorii**:
- Tehnician medical de urgență — Avansat
- INCENDIU 2

 **Poziții potențiale**:
 Nici unul.

 **Limita pozițională**:
 Nici unul.

---

---

 11.00 Pompier I

 **Tipul de poziție**:
 Jurat de foc

 **Categoria de plată**:
 38.060,00 USD - 40.010,00 USD

 **Așteptările săptămânii de lucru**:
 48 de ore pe săptămână.

 **Raportează către:**
 Pompier III (Ofițer de pregătire pe teren).

 **Rezumat:**
 Pompierul I este postul de cel mai jos grad al Departamentului, cu scopul principal de a dobândi cunoștințe și experiență prin sarcini practice alături de pompieri experimentați.

 **Datorii și responsabilități principale**:
- Lucrări pentru finalizarea Programului de instruire pe teren;
- Obține și demonstrează cunoștințe și îmbunătățiri prin acțiuni în practică; și
- Răspundeți la scene cu alți pompieri.

 **Calificări și/sau certificări obligatorii**:
- Tehnician medical de urgență — Bază
- FOC 1

 **Poziții potențiale**:
 Nici unul.

 **Limita pozițională**:
 Nici unul.

---

---

 12.00 Rezervă pentru pompieri

 **Tipul de poziție**:
 Jurat de foc

 **Categoria de plată**:
 38.060,00 USD - 40.010,00 USD

 **Așteptările săptămânii de lucru**:
 Săptămâna de 32 de ore.

 **Raportează către:**
 Căpitan de stație, Asistent căpitan de stație

 **Rezumat:**
 Rezerva de pompieri este un post de pompieri part-time în cadrul Departamentului.

 **Datorii și responsabilități principale**:
- Participați la ture de cel puțin 32 de ore;
-
- Răspunde la scene cu alți pompieri.

 **Calificări și/sau certificări obligatorii**:
- Tehnician medical de urgență — Bază
- FOC 1

 **Poziții potențiale**:
 Nici unul.

 **Limita pozițională**:
 Nici unul.

---

---

 13.00 Recrut de pompieri

 **Tipul de poziție**:
 Academic

 **Categoria de plată**:
 38.060,00 USD - 40.010,00 USD

 **Așteptările săptămânii de lucru**:
 48 de ore pe săptămână.

 **Raportează către:**
 Secția Servicii Recrutare, Biroul de Formare și Suport

 **Rezumat:**
 Fire Recruit este postul pre-entry-level din cadrul Departamentului, cu scopul de a dobândi cunoștințe pentru a deveni angajat al Departamentului cu jurământ.

 **Datorii și responsabilități principale**:
- Participați la sesiunile de pregătire necesare și primiți certificările necesare pentru postul de Pompier;
- Participați la curse cu angajații Departamentului; și
- Revizuiți materialul dat în pregătire pentru sesiunile de instruire.

 **Calificări și/sau certificări obligatorii**:
 Nici unul.

 **Poziții potențiale**:
 Nici unul.

 **Limita pozițională**:
 Nici unul.

---

---

---

## #4 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

4. Regulamente privind uniforma și aspectul

---

 01.00 Scop

 Acest capitol stabilește fundamentul reglementărilor relevante pentru aspectul vizual al angajaților Departamentului.

 02.00 Uniformă clasa A

 PĂLĂRIE: pălărie rochie **((** „Pălărie de pilot” **))**
 Cămașă: cămașă rochie de culoare bleumarin, mânecă lungă, cravată de culoare bleumarin, bandă de nume albă pe dreapta, plasture LSFD pe umăr pe umărul drept, o clapă de plasture pe fiecare sân, insigna argintie pe sânul drept
 PANTALONI: Pantaloni de rochie de culoare bleumarin, două buzunare pe fiecare parte din spate
 MODIFICĂRI PENTRU POMPIERII: Cămașă de culoare neagră, pantaloni de culoare neagră, culoare argintie, insignă de culoare cu decorațiuni aurii
 MODIFICĂRI PENTRU POMPIERII ȘEFI: cămașă albă, pantaloni negru, insignă de culoare aurie

 UTILIZARE: Departamentul Evenimente
 AUTORIZAT PENTRU: TOȚI ANGAJATII

 **((** /uniform 0 **))**

 03.00 Uniformă clasa B

 PĂLĂRIE: Ball Cap LSFD (OPȚIONAL)
 Cămașă: tricou, de culoare bleumarin, mânecă scurtă, bandă de nume albă pe sânul drept, plasture LSFD pentru umăr pe umărul drept, o clapă de plasture pe fiecare sân, insignă argintie pe sânul stâng
 PANTALONI: casual, de culoare bleumarin, două buzunare pe fiecare șold/lateral, două buzunare pe fiecare parte din spate
 MODIFICĂRI PENTRU POMPIERI: cămașă neagră, pantaloni negru, insignă de culoare argintie cu decorațiuni aurii
 MODIFICĂRI PENTRU POMPIERII ȘEFI: cămașă albă, pantaloni negru, insignă de culoare aurie

 UTILIZARE: Datorie
 AUTORIZAT PENTRU: Pompier I, Pompier II, Pompier III, Pompieri, Pompieri-șefi

 **((** Masculin (caucazian) /uniformă 69
 Bărbat (afro-american) /uniformă 66
 Femeie (caucaziană) /uniformă 67**))**

 04.00 Uniformă clasa C

 PĂLĂRIE: Ball Cap LSFD (OPȚIONAL)
 Cămașă: tricou, bleumarin de culoare, mânecă scurtă, text alb „LOS SANTOS CITY FIRE DEPARTMENT” pe sânul drept
 PANTALONI: Pantaloni scurți, de culoare bleumarin, două buzunare pe fiecare șold/lateral, text „LOS SANTOS CITY FIRE DEPARTMENT” pe spate.

 UTILIZARE: Exerciții, activități de antrenament pe teren
 AUTORIZAT PENTRU: Pompier I, Pompier II, Pompier III, Pompieri, Pompieri-șefi

 05.00 Uniformă clasa D

 CAP: Glugă de protecție, culoare bej, cască galbenă, număr de stație în față, etichetă pompier deasupra, etichetă LAFD dedesubt
 Cămașă: tricou, de culoare bleumarin, mânecă scurtă, bandă de nume albă pe sânul drept, plasture LSFD pentru umăr pe umărul drept, o clapă de plasture pe fiecare sân, insignă argintie pe sânul drept
 PALACĂ: Pregătire de protecție, rezistentă la foc, de culoare bej, dungi reflexive în jurul încheieturilor/gleznelor/taliei/pieptului, un buzunar pe fiecare parte/șold, lanternă pe sânul stâng
 Mănuși: de protecție, rezistente la foc, de culoare bej
 PANTALONI: Două straturi, casual pe partea de jos, de culoare bleumarin, două buzunare pe fiecare șold/lateral, două buzunare pe fiecare parte din spate, pantaloni bunker deasupra, bretele pentru sprijin, un buzunar pe fiecare coapsă/lateral
 CIZME: de protecție, rezistente la foc, de culoare neagră, față de culoare bej
 APARAT DE RESPIRATIE: aparat de respirat autonom (SCBA), cadru de transport pe spate cu rezervor de oxigen, regulator de presiune, mască de oxigen pe față, ham cu dispozitiv PASS

 UTILIZARE: Sarcini de incendiu
 AUTORIZAT PENTRU: Pompier I, Pompier II, Pompier III, Pompieri, Pompieri-șefi

 **((** **Echipament de jumătate de participare la vot:**
 Bărbat (caucazian) /uniformă 79
 Bărbat (afro-american) /uniformă 75
 Femeie (caucaziană) /uniformă 76

 **Echipament complet de participare la vot:**
 Bărbat (caucazian) /uniformă 78
 Bărbat (afro-american) /uniformă 74
 Femeie (caucaziană) /uniformă 77**))**

 06.00 Utilizarea uniformei

 Uniformele sunt purtate pe toată perioada în care angajatul este considerat a fi în tură. Angajații departamentului pot purta uniforme în afara serviciului, cu condiția să se desfășoare o activitate autorizată care servește o capacitate oficială în cadrul sau pentru Departament. Angajații care poartă orice articol uniform sunt considerați a fi reprezentați exclusiv Departamentul în mod oficial în orice moment.

 Cu excepția cazului în care se prevede altfel în acest capitol, articolele uniforme care nu sunt specificate alături de uniforma specifică nu pot fi purtate fără autorizarea ofițerilor șef de pompieri. Niciun articol uniform care aparține unui anumit angajat nu poate fi dat oricărei alte persoane, indiferent de apartenența acesteia la Departament.

 07.00 Mutilarea corpului

 Mutilarea corpului este definită ca altercare majoră intenționată a corpului, capului, feței sau pielii, în scopul îmbunătățirii aspectului. Mutilarea corpului este interzisă tuturor angajaților Departamentului. Câteva exemple de mutilare a corpului includ (dar nu se limitează la):

- Limbă despicată sau „furculiță”;
- Obiecte străine sub sau în piele;
- Speriare sau arsură intenționată a gâtului, feței și scalpului; și
- Găuri neregulate în corp.

 08.00 păr

 Părul este de așteptat să fie îngrijit, curat și prezentabil pentru scopul Departamentului. Părul nu trebuie să depășească gulerul sau peste urechi. Următoarele stiluri de păr enumerate mai jos nu sunt permise pentru utilizare:

- Spike;
- Mohawks;
- Dreadlocks; și
- Multicolor.

 De asemenea, se impun următoarele:
- Percoanele trebuie să fie bine tăiate și nu trebuie să se extindă sub partea inferioară a lobului urechii;
- Mustațile trebuie să fie îngrijite/tuiate frumos și nu trebuie să se extindă în lungime dincolo de partea superioară a sigiliului unei măști SCBA;
- Bărba și caprele nu sunt permise sub nicio formă; și
- Femeile pompieri (în uniformă) nu pot avea părul care să se extindă dincolo de partea de jos a gulerului cămășii din spate: pot avea o singură coadă de cal care să nu depășească partea de jos a gulerului cămășii din spate.

 În plus, sunt permise utilizarea următoarelor accesorii de păr, cu condiția ca articolul să fie de culoare bleumarin sau negru:
- Panglici sau benzi de cauciuc acoperite cu terry;
- Agrafe sau agrafe de păr; și
- Bentite.

 În plus, pompierilor (în uniformă) li se permite să poarte o cantitate moderată de machiaj, care nu are ca rezultat un aspect exterior extrem sau nepotrivit. De asemenea, sunt impuse următoarele reglementări:
- Crema de ochi nu trebuie să se extindă dincolo de conturul ochiului;
- Rujul nu trebuie să se extindă dincolo de linia buzelor sau de colțurile gurii; și
- Lacul de unghii trebuie să fie transparent la culoare.

 09.00 Bijuterii

 Următoarele articole sunt autorizate pentru utilizare în timp ce purtați uniforme:

- Ceas de mână sau brățară; și
- Inel non-invaziv

 Orice articole care sunt considerate a fi „bijuterii” care nu sunt enumerate mai sus nu sunt autorizate pentru utilizare. Ofițerii șefi de pompieri au dreptul de a interzice unui angajat să folosească bijuterii aprobate altfel, cu condiția să existe o convingere rezonabilă că purtarea unor astfel de bijuterii poate avea ca rezultat un risc de siguranță sau o productivitate redusă.

 10.00 Piercinguri corporale

 Orice piercing pe corp trebuie acoperit în timp ce purtați articole uniforme.

 11.00 Tatuaje

 Tatuajele nu trebuie să conțină vulgaritate, să fie indecente, sexiste sau rasiste sau ușor considerate ca nepotrivite. Tatuajele sunt interzise pe cap, față, gât, jumătatea mânecilor brațelor inferioare, mânecile întregi, încheietura mâinii și mâinile. Angajații care au un tatuaj într-o zonă interzisă trebuie să aibă tatuajul corespunzător acoperit în timp ce sunt în uniformă. Acoperirea potențială include un articol uniform cu mânecă lungă. Tatuajele care nu sunt interzise și care nu pot fi acoperite trebuie îndepărtate.

 **((**12.00 Articole de îmbrăcăminte**))**

 Membrii facțiunii au acces la o comandă fracționată /cumpărare la spawn-ul principal al facțiunii. Acest lucru permite achiziționarea de articole restricționate, cu toate acestea, majoritatea articolelor nu sunt permise pentru cumpărare sau utilizare în cadrul acestei facțiuni. Articolele sunt după cum urmează:

- Black Law Glasses (1500 USD) — Permis pentru utilizare la serviciu;
- Red Law Glasses (1500 USD) — Nu sunt permise pentru utilizare;
- Ochelari Blue Law (1500 USD) — Nu sunt permise pentru utilizare;
- Police Cap ($1350) — Nu este permisă pentru utilizare;
- Cască de poliție maro deschis (1350 USD) — Nu este permisă pentru utilizare;
- Blue Police Cap ($1350) — Nu este permisă pentru utilizare;
- Pălărie maro închis pentru gazon (2350 USD) — Nu este permisă pentru utilizare;
- Pălărie maro (2350 USD) — Nu este permisă pentru utilizare;
- Cască de lege (5350 USD) — Nu este permisă pentru utilizare;
- Cască Swat (7000 USD) — Nu este permisă pentru utilizare;
- Police Shield (5000 USD) — Nu este permis pentru utilizare;
- Police Armor (5000 USD) — Nu este permisă pentru utilizare;
- Pălărie galbenă de foc (8000 USD) — Permis pentru utilizare la serviciu;
- Pălărie neagră de foc (8000 USD) — Nu este permisă utilizarea, cu excepția cazului în care se specifică altfel;
- Lanternă (3500 USD) — Permis pentru utilizare în timpul serviciului. Rol jucat ca o lanternă;
- Insigna (stea) (700 USD) — Nu este permisă pentru utilizare;
- Insigna (aur) (700 USD) — Nu este permisă pentru utilizare;
- Insigna (argint) (700 USD) — Nu este permisă pentru utilizare;
- Police Hat (( PD SO // SD ES )) ($700) — Nu este permisă pentru utilizare;
- Pălărie de pilot (700 USD) — Permis pentru evenimentele departamentului sau utilizarea ofițerilor șef de pompieri;
- Toc (1000 USD) — Nu este permis pentru utilizare;
- Trusă medicală (3000 USD) — Permis pentru utilizare în timpul serviciului. Rolplayed as a Basic/Advanced Life Support Kit; și
- Mască de gaz (( NUMAI UTILIZARE LA SERVICE )) (0 USD) — Permisă pentru utilizare în timpul serviciului. Jucat ca o mască SCBA.

---

## #5 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

5. Comportament

---

 01.00 Scop

 Acest capitol stabilește fundamentul comportamentului și comportamentului așteptat de la angajații Departamentului.

 02.00 Conduita generală

 Se așteaptă ca angajații departamentului să se comporte într-o manieră care să nu perturbe liniștea și liniștea zonei în care se află. Angajații departamentului nu pot servi drept pacoste pentru niciun angajat activ în tură, indiferent de statutul lor în schimb.

 Angajații departamentului sunt guvernați de regulile obișnuite și rezonabile de bună conduită și comportament ale cetățenilor care respectă legea, indiferent de statutul în schimb. Angajații nu trebuie să acționeze într-un mod care să se discrediteze ca individ sau Departamentul ca colectiv.

 03.00 Reguli și regulamente

 Se așteaptă ca angajații departamentului să fie familiarizați cu regulile și/sau reglementările impuse în manualul de operațiuni. Se așteaptă ca angajații departamentului să fie familiarizați cu Codul de incendiu al statului San Andreas, cu reglementările angajaților din Serviciul Public, precum și cu orice buletine sau memorandumuri suplimentare postate de Departament.

 Toate ordonanțele la nivel de oraș și stat sunt aplicate angajaților Departamentului ca reglementări normale (dacă nu se specifică altfel). Ignorarea oricărei politici, reguli sau proceduri nu este acceptată ca scuză, cu excepția cazului în care este susținută o greșeală recunoscută în informațiile furnizate angajatului.

 Se așteaptă ca angajații departamentului să se mențină la curent cu politica. Ofițerii șefi de pompieri trebuie să notifice în mod rezonabil modificarea politicii cu cel puțin douăzeci și patru (24) de ore înainte de modificarea politicii.

 04.00 Limbă și comunicare verbală

 Angajații departamentului trebuie să se asigure că comunică verbal într-un mod pozitiv, lipsit de vulgaritate, limbaj lipsit de respect sau sugestiv. Administratorii departamentului nu trebuie să folosească comunicare verbală excesiv de dur atunci când comunică cu angajații Departamentului în mod privat și nu trebuie să folosească comunicarea verbală dură în întregime atunci când sunt la îndemâna publicului.

 05.00 Respect pentru colegii angajați ai departamentului și contactele profesionale

 Niciun angajat al Departamentului nu trebuie să critice sau să cheme public acțiunile sau comportamentul unui coleg sau contact profesional. Se așteaptă ca angajații departamentului să acționeze într-o manieră profesională atunci când au de-a face cu colegii angajați și contactele profesionale și trebuie să facă o încercare rezonabilă de a evita provocarea de conflicte sau fricțiuni între părți.

 Se așteaptă ca angajații departamentului să urmeze lanțul de comandă în consecință și trebuie să respecte ordinele date de o cifră de rang superior (cu excepția comenzilor în care există o convingere rezonabilă că ordinul contravine legii orașului, statului sau federal).

 06.00 Angajare în afara serviciului

 Angajații departamentului pot participa la angajare secundară în timp ce nu sunt în tură. Angajații departamentului trebuie să obțină autorizație înainte de a accepta orice ofertă de angajare prin Centrul de solicitare a personalului.

 Angajații departamentului nu sunt eligibili pentru a ocupa un loc de muncă secundar atunci când sunt absenți dintr-o tură preconizată sau în concediu pe termen lung.

 Angajații Departamentului nu pot participa la nicio angajare secundară care creează un conflict de interese rezonabil în ceea ce privește poziția sa în cadrul Departamentului.

 07.00 Absență

 Angajații departamentului care au o boală personală care îi împiedică să participe în mod rezonabil la serviciu (de exemplu: contagiune) trebuie să-și notifice căpitanul de stație relevant înainte de începerea turei afectate. Căpitanul stației transmite aceste informații șefului batalionului atunci când este disponibil. Angajații departamentului trebuie să repete acest proces pentru fiecare tură care va fi ratată, cu excepția cazului în care o absență pe termen lung este autorizată de către ofițerii șef de pompieri.

 Angajații departamentului care nu pot să se prezinte în tură la ora stabilită trebuie să aranjeze ca un angajat al departamentului în afara serviciului să stea în timpul perioadei pierdute. Căpitanul stației trebuie, de asemenea, să fie anunțat înainte de începerea turei afectate și poate ajuta la găsirea unui loc de muncă. Căpitanul stației transmite aceste informații șefului batalionului atunci când este disponibil.

 **((**08.00 Corupție**))**

 Pentru a menține un sentiment de realism și joc corect, nivelul de corupție pe care membrii facțiunii îl pot angaja este limitat. Există două niveluri principale de corupție care sunt recunoscute de facțiune: minor și major. Corupția minoră poate fi efectuată de membrii facțiunii fără autorizație, în timp ce corupția majoră necesită autorizare pentru fiecare act corupt. Acesta poate fi un singur act de corupție sau un act specific de corupție care are loc pe termen lung. Corupția majoră nu este autorizată într-un mod general; Ofițerii șefi de pompieri trebuie să fie conștienți de intențiile dumneavoastră.

 Corupția majoră se acordă prin Centrul de Solicitari de Personal, formatul cererii fiind disponibil în subiect. Formatul este completat de membrul facțiunii și este trimis ofițerilor șefi de pompieri prin mesaje private pentru revizuire. Această solicitare este o comunicare între ofițerii șefi de pompieri, cu toate acestea, cererea poate fi partajată cu administrația serverului în circumstanțe rezonabile și necesare. Autorizarea se acordă printr-un mesaj privat returnat, nu este automată la trimiterea cererii.

 Actele de corupție enumerate mai jos sunt considerate a fi minore. Toate actele criminale de corupție menționate mai jos, chiar dacă sunt considerate majore la nivel de server, sunt tratate ca fiind minore doar în anumite situații care au impus astfel de acțiuni pentru a-ți portretiza personajul în mod realist. Dacă aceste acțiuni sunt planificate, nu au loc în căldura momentului și nu sunt necesare, ele sunt clasificate drept corupție majoră și, prin urmare, necesită depunerea unei cereri. Orice lucru care nu este listt este automat considerat major. Actele minore de corupție, având în vedere cele menționate mai sus, sunt următoarele:

- Infracțiune contravențională împotriva statului San Andreas Cod penal 2018;

 În plus, nu este permisă nicio corupție în afara caracterului. Câteva exemple de corupție în afara caracterului sunt următoarele (dar nu se limitează la):

- Scurgere de informații despre facțiune; și
- Luarea cu bună știință a deciziilor părtinitoare care afectează facțiunea (sau o altă persoană) în afara caracterului.

 **((**09.00 Permisiune dublă facție**))**

 Pentru a permite membrilor facțiunii să rămână motivați și să aibă experiențe diferite în cadrul serverului, facțiunea permite membrilor facțiunii să participe la sistemul Double Faction care este folosit în majoritatea facțiunilor oficiale. Double Faction este actul de a fi în două facțiuni oficiale cu personaje diferite în același timp. O facțiune oficială este considerată a fi o facțiune cu capacitatea de /invite.

 Membrii facțiunii trebuie să mențină jumătate și jumătate de activitate între cele două facțiuni în timp ce dețin permisiunea dublă facție. 0.8 Activitatea UCP trebuie realizată înainte de a solicita permisiunea Double Faction. Membrii facțiunii trebuie să fie un administrator de pompieri sau un pompier II+ pentru a fi eligibili pentru permisiunea dublă facție.

 Membrii facțiunii solicită permisiunea dublei facțiuni prin Centrul de solicitări de personal. Solicitanții facțiunii folosesc subiectul relevant în forumul Recepție.

 **((**10.00 Regulile facțiunii**))**

 Se așteaptă ca membrii facțiunii să fie familiarizați cu regulile și/sau reglementările în afara caracterului impuse în manualul de operațiuni. Se așteaptă ca membrii facțiunii să fie familiarizați cu toate regulile Los Santos Roleplay de pe forumuri, server de joc, server TeamSpeak3, Discord și orice altă platformă.

 Se așteaptă ca membrii facțiunii să se mențină la curent cu politica. Se așteaptă ca ofițerii șefi de pompieri să notifice în mod rezonabil schimbarea politicii, după cum consideră necesar.

 **((**11.00 Absență în afara caracterului**))**

 Rapoartele de absență sunt considerate a fi notificări de absență în afara caracterului și au două forme: absență, activitate redusă. Pentru ambele forme se aplică următoarele:

- Membrii facțiunii pot fi supuși încetării angajării în ciuda faptului că au un Raport de absență postat;
- Membrii facțiunii pot să nu aibă un Raport de absență activ pentru o durată mai mare de șase (6) săptămâni;
- Se așteaptă ca membrii facțiunii să posteze un raport de absență pentru ambele facțiuni dacă dețin permisiunea dublă facție; și
- Membrii facțiunii trebuie să mențină comunicarea între ei și ofițerii de pompieri pentru a-și menține raportul de absență actualizat.

 Membrii facțiunii care au un raport de absență folosind formatul de absență sunt considerați absențe pe termen lung în caracter. Vezi 7/09.00.

 **((**12.00 Schimbarea numelui caracterului**))**

 Membrilor facțiunii li se permite să schimbe numele personajului său, fie printr-o schimbare legală a numelui, fie prin utilizarea unui nou fundal de caracter. Membrii facțiunii trebuie să obțină permisiunea de la conducerea facțiunii înainte de a schimba numele personajului său de facțiune și li se cere să facă acest lucru prin intermediul Centrului de solicitare a personalului Vezi MOPS 07/08.00.

 Membrii facțiunii pot: să schimbe numele personajului său printr-o schimbare de nume UCP, un nou spațiu de caractere sau o ucidere a caracterului. Acest lucru ar trebui menționat în secțiunea Informații suplimentare a cererii. Membrii facțiunii nu au voie să-și schimbe numele cu un personaj cu antecedente penale, afiliere în bande sau orice activitate recentă care ar intra în conflict cu 5/08.00.

 Membrii facțiunii care doresc să efectueze o schimbare legală a numelui său ar trebui să specifice acest lucru în câmpul motiv al cererii, împreună cu motivul (adică: căsătorie).

---

## #6 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

6. Beneficii de angajare

---

 01.00 Scop

 Acest capitol pune bazele diferitelor beneficii pe care le primesc angajații actuali și anteriori ai Departamentului.

 02.00 Beneficii de bază

 Toți angajații Departamentului împart beneficiile de angajare pe durata angajării. Angajații departamentului pot primi și beneficii postangajare. Aceste beneficii pot fi impuse de legea muncii și pot avea anumite restricții impuse de terți.

 03.00 Planuri de acoperire

 Toți angajații Departamentului, civili și jurați, au dreptul la diferite acoperiri ca parte a contractului său de muncă. Planurile de acoperire sunt după cum urmează:

- Acoperire stomatologică;
- Acoperirea vederii;
- Asigurare de sănătate; și
- Planuri de pensii.

 04.00 Concediu medical

 Toți angajații Departamentului, civili și jurați, au dreptul la concediu din cauza unei boli ca parte a contractului de muncă. Timpul liber diferă între angajații civili și angajații jurați.

 Angajații civili au dreptul la până la 90 de concedii medicale pe an, acumulând timp în proporție de 8 ore. Angajații civili care folosesc mai mult de 90 de zile pot fi supuși concedierii medicale.

 Angajații jurați nu sunt limitați în totalul concediilor medicale pe an. Angajații jurați care pierd patru (4) ture consecutive vor fi obligați să prezinte o declarație a medicului care detaliază natura bolii.

 05.00 Concediu de vacanță

 Toți angajații Departamentului, civili și jurați, au dreptul la concediu pentru concediu, ca parte a contractului de muncă. Timpul liber diferă între angajații civili și angajații jurați.

---

## #7 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

7. Politici administrative

---

 01.00 Scop

 Acest capitol pune bazele politicilor administrative principale pentru angajații Departamentului.

 02.00 Certificari

 Toți angajații jurați de incendiu trebuie să obțină și să mențină certificarea de bază de tehnician medical de incendiu și urgență de la Biroul de instruire și asistență. Toate cerințele de formare educațională sunt responsabilitatea de a obține angajatul, Departamentul asigurându-se că cerințele de formare educațională de bază sunt îndeplinite pentru ca angajatul să fie eligibil pentru continuarea angajării în cadrul Departamentului.

 Există două niveluri principale de certificare medicală disponibile pentru angajații Departamentului: Tehnician medical de urgență – de bază („EMT-B”) și Tehnician medical de urgență – paramedic („EMT-P”).

 Tehnician medical de urgență - de bază este după cum urmează:

- Autorizat să angajeze practica de Suport vital de bază, în conformitate cu reglementările și standardele medicale menținute în Manualul de operațiuni medicale; și
- Autorizat să opereze o ambulanță de salvare din clasa Suport vital de bază.

 Tehnicianul medical de urgență - Paramedic este următorul:

- Autorizat să angajeze practică Advanced Life Support, în conformitate cu reglementările medicale și standardele menținute în Manualul Operațional Medical; și
- Autorizat să opereze o ambulanță de salvare din clasa Avansat Life Support.

 Există trei niveluri principale de certificare de stingere a incendiilor disponibile pentru angajații Departamentului: FIRE 1, FIRE 2 și FIRE 3.

 FOC 1 este după cum urmează:

- Autorizat să folosească abilități și tactici de stingere a incendiilor 1, în conformitate cu politicile operaționale standard menținute în Manualul operațiunilor de stingere și salvare a incendiilor.
- Autorizat să creeze echipajul unei companii de motoare sau camioane și să utilizeze echipamentul corespunzător.

 FIRE 2 este după cum urmează:

- Autorizat să folosească abilitățile și tacticile de stingere a incendiilor 2, în conformitate cu politicile operaționale standard menținute în Manualul operațiunilor de stingere și salvare a incendiilor.
- Autorizat să creeze echipajul unei companii Squad și să utilizeze echipamentul corespunzător.

 FIRE 3 este după cum urmează:

- Autorizat să folosească abilități și tactici de stingere a incendiilor 3, în conformitate cu politicile operaționale standard menținute în Manualul operațiunilor de stingere și salvare a incendiilor.

 03.00 Sistem de promovare

 Departamentul folosește un sistem de promovare proactiv care plasează angajații Departamentului în poziția în care sunt atât solicitați, cât și capabili să fie. Sistemul de promovare constă din două tipuri principale de promovare: upgrade de clasă și promovare de rang. Un angajat al Departamentului care intră în sistemul de promovare are două tipuri de retrogradare: retrogradare de clasă și degradare de rang.

 Sistemul de promovare al Departamentului constă din două tipuri de promoții: upgrade de clasă și promoții de rang.

 Upgrade-urile (—< Degradările) sunt definite ca atunci când un angajat menține aceeași clasă de bază, dar avansează la o desemnare superioară, însoțită de o creștere a salariului și/sau responsabilitatea sau obligația.

 Promovările (—< Retrogradări) sunt definite ca atunci când un angajat este trecut la următoarea clasă de bază cu o creștere a salariului și o creștere clară a responsabilității sau obligației.

 03.01 Sistem de promovare: cerințe de progres

 Upgrade-urile clasei pompierilor sunt legate de îndeplinirea cerințelor de certificare, mai degrabă decât de cerințe individuale sau specializate. Cerințele de actualizare a clasei pentru toate clasele de pompieri sunt următoarele:

 Pompierul I la Pompierul II
- Finalizarea cu succes a Programului de instruire pe teren (vezi 7/11.00);
- Necesar de timp servit;
- Nu a fost primită nicio măsură disciplinară serioasă; și
- Certificari corespunzătoare dobândite (Tehnician medical de urgență — Paramedic, FIRE 2)

 Pompierul II la Pompierul III
- Candidatura depusă pentru postul de Ofițer de pregătire pe teren;
- Necesar de timp servit;
- Nicio acțiune disciplinară serioasă primită în ultima (1) lună;
- Certificari corespunzătoare obținute (FIRE 3)

 Pentru a menține standardul și a se menține în conformitate cu legislația statului, pompierii trebuie să servească o anumită perioadă de timp într-o anumită poziție înainte de a avansa în clasă sau de promovare la rang și, de asemenea, li se poate cere să aibă o anumită vârstă. Aceste cerințe sunt după cum urmează:

- Pompierul de la I la II are o cerință de timp de un (1) an (( trei (3) săptămâni )) înainte de progres și o cerință de vârstă de douăzeci și unu (21) de ani.
- Pompierul II până la III are o cerință de timp de patru (4) ani (( o (1) lună )) înainte de progres și o cerință de vârstă de treizeci (30) de ani.
- Pompierul III la Inginer are o cerință de timp de trei (3) ani ((două (2) luni)) înainte de progres și o cerință de vârstă de treizeci și trei (33) de ani.
- Inginerul Căpitanului I are o cerință de timp de trei (3) ani ((două (2) luni)) înainte de progres și o cerință de vârstă de treizeci și șapte (37) de ani.
- Căpitanul I la Căpitanul II are o cerință de timp de doi (2) ani ((două (2) luni)) înainte de progres și o cerință de vârstă de patruzeci (40) de ani.
- Căpitanul I/ Căpitanul II la șef de batalion are o cerință de timp de patru (4) ani (( două (2) luni )) înainte de progres și o cerință de vârstă de patruzeci și cinci (45) de ani.[/list ]    03.02 Sistem de promovare: Promoții pentru ofițeri    Promovările de ofițer au loc pe bază de post vacant și sunt gestionate de Biroul șefului pompierilor. Acest lucru se aplică atât ofițerilor de pompieri de departament, cât și ofițerilor de pompieri șef de departament. În cazul în care Departamentul aspiră pentru alți ofițeri de pompieri, pompierii III sunt primul grup care este considerat ca ofițeri de instruire pe teren. Ofițerii de instruire pe teren trebuie să trimită o notificare de interes înregistrat (NFI) Diviziei de resurse umane pentru a fi luate în considerare. Trimiterea acesteia nu garantează o promovare, ci doar face ca pompierul să fie eligibil.    **((**03.03 Sistem de promovare: cerințe de activitate**))**    Pentru a menține standardele, membrii facțiunii trebuie să îndeplinească anumite cerințe privind activitățile UCP în afara caracterului, în plus față de cerințele în caracter, inclusiv timpul petrecut în acea poziție. Pe lângă activitatea UCP, se ia în considerare și alte activități. Cerința de bază privind activitatea UCP este în prezent de 0,8. Îți poți găsi nivelul de activitate mergând la Faction Center din UCP și trecând cu mouse-ul peste bara de lângă numele tău.    04.00 Proceduri disciplinare    Ca parte a inițiativei Departamentului de a menține o imagine profesională și de a asigura cea mai înaltă calitate a serviciilor pentru orașul Los Santos, Departamentul menține un sistem disciplinar împletit între Ofițerii Departamentului și Divizia Standarde Profesionale.    Ofițerii departamentului sunt autorizați să emită măsuri disciplinare administrative la scară mică, cu toate acestea nu sunt autorizați să efectueze o investigație oficială (cu excepția Biroului șefului pompierilor, care poate efectua investigații independente asupra angajaților departamentului și/sau comportament) în timp ce acționează exclusiv ca un ofițer de departament. Ofițerii de departament, cum ar fi căpitanii de stație, sunt considerați a face parte din Unitatea de investigații pe teren, o subsidiară a Diviziei Standarde Profesionale. După cum este definit în Introducere/organigramă și Funcțiile Biroului Departamentului, Unitatea de Investigații pe teren este responsabilă pentru desfășurarea investigațiilor incidentelor administrative la scară mică în care nu se consideră că a avut loc imediat o abatere majoră sau o încălcare a politicii. Unitatea de investigații pe teren trebuie să trimită investigații în cazul în care o abatere majoră sau o încălcare a politicii este o posibilitate în cursul investigației. Datorită acestui scop, Unitatea de Investigații pe teren nu are permisiunea de a plasa angajații Departamentului în concediu administrativ.    Divizia Standarde Profesionale, în special Unitatea de Investigații Interne, este însărcinată cu preluarea Reclamațiilor angajaților până la încheiere. La primirea unei Plângeri a unui angajat de către o parte internă sau externă, se efectuează o investigație preliminară în care informațiile furnizate sunt revizuite. Dacă se crede în mod rezonabil că a avut loc o încălcare majoră a politicii, angajații relevanți pot fi plasați în concediu administrativ fără plată pe parcursul investigației. Deși Diviziei Standarde Profesionale nu i se permite să efectueze investigații penale, investigațiile administrative pot fi utilizate pentru a determina dacă este probabil ca un angajat relevant să fi încălcat Codul Penal din 2018 din statul San Andreas, o încălcare a politicii Departamentului. În conformitate cu Legea privind stabilirea drepturilor funcționarilor publici din 2016, informațiile colectate pe parcursul unei investigații administrative nu pot fi utilizate pentru acuzare penală. Cu toate acestea, orice investigație administrativă în care se crede că a avut loc o infracțiune va avea ca rezultat întocmirea unui raport către agenția de aplicare a legii relevantă pentru incidentul și jurisdicția presupusă.    Unul dintre principalele moduri prin care Divizia Standarde Profesionale conduce o investigație este utilizarea interviurilor în persoană. Persoana intervievată poate fi angajatul (angajații) raportați sau poate fi o parte despre care se crede că este implicată într-un fel, formă sau formă. În conformitate cu Legea privind instituirea drepturilor funcționarilor publici din 2016, angajații departamentului care se confruntă cu interviul nu sunt obligați să se autoincrimineze. Angajații departamentului care nu furnizează informații sau nu respectă o investigație administrativă sunt în continuare supuși măsurilor disciplinare ale departamentului, inclusiv încetarea raporturilor de muncă.    La încheierea unei investigații din partea Diviziei Standarde Profesionale, angajații relevanți pot fi sau nu informați, în funcție de rezultatul investigației. Investigațiile administrative în care sunt emise măsuri disciplinare necesită ca angajații Departamentului disciplinați să fie contactați și informați cu privire la măsurile luate.    Departamentul folosește mai multe acțiuni disciplinare principale: mustrare, mustrare, suspendare, desfacere (de angajare). Departamentul angajează, de asemenea, concediu administrativ plătit și fără plată. Aceste măsuri disciplinare sunt prezentate mai jos.    Avertismentele sunt emise de către Ofițerii Departamentului sau Divizia Standarde Profesionale pentru cazuri minore de conduită greșită sau încălcare indirectă a politicii Departamentului. Admonestările nu au niciun efect asupra angajatului în mod direct și nu sunt folosite ca un punct important atunci când se dezbate istoricul disciplinar anterior al unui angajat al Departamentului.    **((** Pot fi emise avertismente pentru incidente în afara caracterului de către căpitanul I sau mai sus. **))**    Reproșurile sunt emise de către ofițerii departamentului sau de către Divizia pentru standarde profesionale pentru încălcarea directă a politicii departamentului. mustrările pot avea un efect direct asupra angajatului și pot fi folosite ca un punct important atunci când se dezbate istoricul disciplinar anterior al unui angajat.    **((** Pot fi emise mustrări pentru incidente în afara caracterului de către căpitanul I sau mai sus. **))**    Suspendarile sunt emise de ofițerii superiori ai departamentului sau de Divizia pentru standarde profesionale pentru încălcări majore și grave ale politicii departamentului. Suspendarile au adesea un efect direct asupra angajatului și pot fi folosite ca un punct important atunci când se dezbate istoricul disciplinar anterior al unui angajat. Suspendarile nu sunt folosite ca instrument de interzicere a unui angajat în curs de investigare. Suspendarile interzic angajatului în cauză să participe la orice acțiune sau activitate relevantă pentru Departament, cu excepția cazului în care este autorizat în mod expres de către organul de suspendare sau un organism superior.    **((** Suspendarile pot fi emise pentru incidente în afara caracterului de către șeful batalionului sau mai sus. **))**    Rezilierile de angajare sunt emise de către șefii departamentului de pompieri sau Divizia pentru standarde profesionale pentru încălcări grave și inacceptabile ale politicii departamentului. Rezilierile au un efect direct asupra efectului asupra angajatului și pot fi folosite ca punct major atunci când se dezbate istoricul disciplinar anterior al unui angajat. Angajații departamentului care se confruntă cu încetarea contractului de muncă trebuie să returneze toate echipamentele sau echipamentele date din cauza statutului lor în cadrul Departamentului și sunt răspunzători pentru orice daune aduse acestor echipamente la returnare. Angajații departamentului care se confruntă cu încetarea raporturilor de muncă pot pierde statutul de a fi jurați de incendiu sau de certificare suplimentară, în funcție de natura încetării. Angajații departamentului care se confruntă cu încetarea raporturilor de muncă nu pot încerca o declarație la Departament pentru o perioadă de treizeci (30) de zile,    **((** Rezilierile pot fi emise pentru incidente în caracter sau în afara caracterului de către un șef de batalion cu autorizarea unui șef asistent. **))**    05.00 Contestații disciplinare și Consiliul drepturilor    În timp ce Divizia Standarde Profesionale și ofițerii săi asociați încearcă din plin să rezolve în mod rezonabil prima dată când apare un incident, angajații pot simți totuși că acțiunea disciplinară emisă nu este adecvată. În acest caz, angajaților departamentului li se permite să conteste un incident în care a fost emisă o acțiune disciplinară de către un ofițer al departamentului. Contestațiile sunt examinate de Consiliul pentru Drepturi și trebuie depuse în termen de două (2) săptămâni de la producerea incidentului. După acest interval de timp, Departamentul nu mai este responsabil să mențină dovezi complete relevante pentru incident, dacă nu se specifică altfel.    Contestațiile pot fi depuse cu asistența unui consilier juridic, cu condiția ca angajatul în cauză să conteste un incident în care au fost emise măsuri disciplinare împotriva lor ca persoană fizică. Angajații nu pot face apel pentru alți angajați, alte părți trebuie să prezinte propria lor contestație pentru ca implicarea sa în acel incident specific să fie revizuită. Contestațiile pot fi depuse o singură dată pe incident și nu pot fi depuse până când acțiunea disciplinară nu a fost efectiv emisă. Contestațiile trebuie făcute numai pentru incidente disciplinare rezolvate și nu se aplică acțiunilor luate temporar în cursul unei investigații, cum ar fi concediul administrativ. De asemenea, contestațiile trebuie depuse numai dacă există convingerea cu bună-credință că următoarele se aplică după cum urmează:   - Măsura disciplinară luată a fost excesivă față de încălcarea politicii Departamentului care a avut loc; și - Măsura disciplinară luată a fost emisă în ciuda convingerii puternice că nu a avut loc nicio încălcare a politicii Departamentului.     În plus, încetarea raporturilor de muncă nu poate fi contestată prin intermediul Consiliului pentru Drepturi și este considerată o rezoluție finală.    Contestațiile au aceleași rezultate de bază ca și plângerile angajaților, orice acțiune disciplinară relevantă fiind revocată sau ajustată după cum se consideră necesar. Toate contestațiile trec prin Consiliul pentru Drepturi și sunt confirmate de șeful pompierilor sau de adjunctul șefului de pompieri în lipsa acestuia. Părțile relevante sunt informate cu privire la rezultat odată ce contestația a fost închisă. Incidentele analizate de Consiliul pentru Drepturi nu pot fi contestate din nou, rezultatele sunt definitive.    06.00 Relație sau părtinire rezonabilă    Departamentul adoptă o atitudine proactivă pentru a asigura un loc de muncă echitabil, competitiv, în care angajații sunt recompensați pentru propriile contribuții. Ca parte a acestei poziții, Departamentul solicită tuturor angajaților aflați într-o relație activă cu un alt angajat al acestui Departament să prezinte o notificare conformă către Divizia Standarde Profesionale. De asemenea, Departamentul impune aceeași procedură pentru angajații care cred că poate exista o părtinire între aceștia și un alt angajat al acestui Departament din alte motive.    Angajații departamentului sunt obligați să notifice în termen de cinci (5) zile de la declararea unei astfel de relații și sunt încurajați să notifice Divizia Standarde Profesionale la încetarea unei astfel de relații. Angajații departamentului care cunosc o potențială problemă legată de părtinirea mai multor părți sunt încurajați să trimită un raport oficial prin sistemul de plângeri ale angajaților.    Angajații departamentului pot găsi informațiile trimise pe portalul web Rapoarte și Laudări.    07.00 Angajare unități și divizii    Angajații departamentului pot solicita realocări la diferite birouri, unități sau secțiuni din cadrul Departamentului de Pompieri Los Santos. Angajații trebuie să trimită o Notificare de Interes Înregistrat (NRI) la Divizia de Resurse Umane, unde un Reprezentant de Resurse Umane și supervizorul postului ocupat vor începe o Evaluare Administrativă pentru Adecvarea Misiunii (ARAS).    Divizia de Resurse Umane (și supervizorul corespunzător) va selecta candidatul dorit și va măsura capacitatea/adecvarea acestuia pentru postul solicitat. Odată ce procesul de selecție este finalizat și s-a finalizat o decizie cu privire la candidații care vor primi o atenție suplimentară, se administrează o misiune sau un test și/sau un interviu formal. Aceasta variază în funcție de postul solicitat.    Procesarea și finalizarea solicitărilor de notificare și revizuire administrativă poate dura până la câteva zile lucrătoare. Angajații pot depune un singur formular de cerere pentru fiecare misiune. MOPS 06.00/07.00 acoperă funcțiile și responsabilitățile specifice ale biroului pentru informații suplimentare despre fiecare post vacant activ.    **((** Se așteaptă ca membrii facțiunii să joace de rol în jurul misiunii lor principale în comparație cu misiunea lor secundară. Acest lucru este în scopuri realiste și pentru a evita să aveți un singur personaj în numeroase unități. **))**    Angajații au o gamă largă de misiuni primare și secundare din care să aleagă. Informații despre posturile vacante și formularele disponibile sunt disponibile în Centrul de Cereri de Personal.    08.00 Premii și calificări    Departamentul păstrează dosare pentru toți angajații Departamentului. Unul dintre aceste dosare reprezintă diferitele premii și medalii ale angajaților actuali și anteriori. Acest fișier se citește ca elementele în persoană și este întreținut de Administrația de incendii.    Premiile și Calificările sunt separate în două paranteze — Laudări și Calificări. O laudă este o citare dată pe baza devotamentului, performanței sau statutului de veteran al unui angajat al Departamentului, în timp ce o calificare (sau certificare) este dată pe baza pregătirii și experienței unui angajat al Departamentului.    08.01 Premii și calificări: laudări    **Panglica de laudă a șefului pompierilor**    Mențiunea șefului pompierilor este acordată angajaților veterani ai Departamentului care au evoluat într-un mod extrem de lăudabil în cadrul Serviciului de Pompieri.    **Panglica de laudă pentru Medalia Valorii**    Medalia Valoarei este acordată angajaților Departamentului care, în fața unor condiții periculoase, au efectuat un act de eroism evident fără cunoștința prealabilă a unui risc personal iminent. Acest act de curaj a promovat cele mai înalte tradiții ale acestui Serviciu de Pompieri și ale Departamentului.    **Panglică de laudă pentru medalia curajului**    Medalia pentru curaj este acordată angajaților Departamentului care au efectuat un act de curaj și rezistență deosebită în condiții nefavorabile de foc, mediu, vreme sau materiale.    **Panglică de laudă pentru conduită meritorie**    Mențiunea pentru conduită meritorie este acordată angajaților Departamentului care au îndeplinit un act de distincție notabil în îndeplinirea sarcinilor care reflectă integritatea și devotamentul arătate față de Departament.    **Panglică de laudă pentru serviciu distins**    Distinguished Service Commendation este acordată angajaților Departamentului care au efectuat un act de distincție extrem de neobișnuit în condiții nefavorabile.    **Panglică de laudă care salvează vieți**    Mențiunea pentru salvarea vieții este acordată angajaților Departamentului care au fost implicați în principal în salvarea vieții unei alte persoane și ale căror acțiuni personale au fost direct responsabile pentru actul de salvare a vieții, luând în același timp toate măsurile de precauție necesare și respectând toate protocolul și liniile directoare de siguranță ale Departamentului.    **Panglică de laudă pentru realizări educaționale**    Mențiunea de realizare educațională este acordată angajaților Departamentului care au promovat pregătirea fie pentru Serviciul de Urgență Medicală, fie pentru Serviciul de Pompieri al acestui Departament.    **Panglică de laudă pentru realizări educaționale avansate**    Lauda pentru performanțe educaționale avansate este acordată angajaților departamentului care au obținut o calificare în timp ce au performat impecabil în timpul pregătirii relevante pentru acea calificare.    **Panglică de laudă pentru inimă violet**    Lauda Purple Heart este acordată angajaților Departamentului care au fost răniți semnificativ în timpul serviciului, luând toate măsurile de precauție necesare și respectând toate regulile de protocol și de siguranță ale Departamentului.    **Panglică de laudă administrativă**    Mențiunea administrativă este acordată angajaților Departamentului care au contribuit cu suficient timp și efort la operațiunile administrative ale Departamentului.    **Panglica de laudă pentru pompierul lunii**    Mențiunea pentru pompierul lunii este acordată angajaților Departamentului care au fost aleși de colegii lor drept cei mai buni performanți din cadrul Serviciului de Pompieri pentru luna respectivă.    **Panglica de laudă EMT a lunii**    Mențiunea EMT a lunii este acordată angajaților Departamentului care au fost aleși de colegii lor ca fiind cei mai buni performanți în cadrul Serviciului Medical de Urgență pentru luna respectivă.    08.02 Premii și calificări: calificări    **Panglica de calificare Fire 1**    Calificarea Fire 1 este acordată angajaților Departamentului care au promovat pregătirea pentru serviciul de pompieri de bază și sunt calificați pentru a face parte dintr-un echipaj de motoare sau camion din cadrul acestui departament.    **Panglica de calificare Fire 2**    Calificarea Fire 2 este acordată angajaților Departamentului care au promovat instruirea pentru serviciul de pompieri avansat și sunt calificați pentru a face parte dintr-un echipaj de echipă din cadrul acestui Departament.    **Panglica de calificare Fire 3**    Calificarea Fire 3 este acordată angajaților departamentului care au promovat pregătirea pentru Comandarea incidentelor și conducerea de bază și sunt calificați să servească drept Comandamentul pentru incidente și ca asistent al căpitanului de stație relevant.    **Panglica de calificare EMT-B**    Calificarea EMT-B este acordată angajaților Departamentului care au promovat cursuri de formare pentru Suportul de viață de bază și sunt calificați să practice ca EMT în cadrul acestui Departament.    **Panglica de calificare EMT-P**    Calificarea EMT-P este acordată angajaților Departamentului care au promovat cursuri pentru Suportul Vieț Avansat și sunt calificați să practice ca Paramedic în cadrul acestui Departament.    **Panglică de calificare a tehnicianului în materiale periculoase**    Calificarea de tehnician în materiale periculoase este acordată angajaților departamentului care au promovat pregătirea necesară pentru echipa de răspuns la materiale periculoase și sunt calificați să manipuleze materiale periculoase.    **Panglică de calificare avansată pentru salvare**    Calificarea avansată de salvare este acordată angajaților Departamentului care au promovat pregătirea necesară pentru Căutare și Salvare Urbană și sunt calificați să asiste la incidente relevante.    09.00 Centru de solicitări de personal    Departamentul folosește un sistem simplificat prin intermediul intranetului care permite angajaților Departamentului să solicite diverse articole. Unele articole trebuie să fie solicitate în funcție de sarcina dvs.    **((** Toate „cererile” sunt momentan în afara caracterului. Solicitările sunt postate ca subiecte separate în formularul Centrului de Cereri Personal, urmând formatul specificat în subiectul informativ. Toate cererile, cu excepția corupției majore, sunt postate - corupția majoră este trimisă prin mesaj privat direct grupului de forum „LSFD Chief Fire Officers”. Următoarele solicitări sunt obligatorii și trebuie solicitate:   - Misiunea de discord - Temă TeamSpeak 3     Solicitările făcute în Centrul de Solicitari de Personal sunt tratate de către (Șef) Pompieri, în funcție de tipul de solicitare. Vă rugăm să nu trimiteți mesaje (șefii) pompierilor decât dacă există o problemă cu cererea dumneavoastră sau nu a fost tratată într-o perioadă de patruzeci și opt (48) de ore. **))**    10.00 Service Stripes    Angajații departamentului pot fi eligibili pentru benzi de serviciu purtabile, în funcție de vechimea în muncă și de istoricul serviciului. Aceste linii de serviciu arată vechimea și/sau mandatul unui angajat și își schimbă culorile în funcție de poziția generală a departamentului. Fiecare bandă de serviciu echivalează cu cinci (5) ani de serviciu **((** 3 luni **))** în cadrul acestui Departament sau al altui Departament eligibil.    Angajații departamentului sunt rugați să-și contacteze supervizorul direct pentru a confirma liniile de serviciu și pentru a plasa o comandă.    **((** Membrii facțiunii pot avea linii de serviciu afișate pe profilul său. Durata serviciului este echivalentă cu timpul petrecut în facțiune pe parcursul tuturor mandatelor, atâta timp cât personajul actual are în mod rezonabil aceeași vechime în timpul caracterului. Membrii facțiunii care doresc să fie adăugată o bandă de serviciu ar trebui să depună o cerere în Centrul de solicitări de personal. **))**    11.00 Program de instruire pe teren    Programul de instruire pe teren îi ajută pe noii pompieri la nivel de intrare să se adapteze la Departament și la operațiunile de zi cu zi așteptate de la aceștia. Toți angajații Departamentului cu rangul Pompier I sunt înscriși în Programul de instruire pe teren. Programul de instruire pe teren impune restricții asupra acestor pompieri:   - Nu poate răspunde la apeluri medicale sau de incendiu numai dacă nivelul de personal nu permite un alt membru al echipajului; - Nu se poate alătura anumitor unități, secțiuni și divizii;     Programul de instruire pe teren este împărțit în două faze diferite:    Faza 1: Introducere  - În timpul fazei de introducere, ofițerul de instruire pe teren va ghida patrula și va explica procedurile și manualele pompierului I. Un pompier I ar trebui să se concentreze pe observarea acțiunilor ofițerului său de pregătire pe teren și până la sfârșitul fazei 1, ar trebui să poată îndeplini sarcinile menționate și, de asemenea, trebuie să ajute în timpul scenelor. Trebuie să finalizați o patrulă de fază 1 - această fază durează cel puțin o săptămână. În această săptămână, nu aveți voie să patrulați singur, decât dacă numărul de personal nu permite patrularea cu echipaj.     Faza 2: Evaluare  - A doua fază asigură că pompierii au o înțelegere generală a procedurilor și principiilor departamentului. În acest moment, pompierul ar trebui să se implice mai mult și să ia inițiativă în situații. Trebuie să fii fluid și să arăți o învățare consecventă. Trebuie să finalizați două patrule din faza 2 - această fază durează cel puțin două săptămâni.     Ofițerii de pregătire pe teren și (asistentul) căpitanilor de stație sunt însărcinați cu menținerea fișierelor interne pentru toți pompierii care trec prin Programul de instruire pe teren. Aceste fișiere documentează progresul și patrulele acestor pompieri și sunt, de asemenea, folosite pentru a documenta orice probleme care necesită abordare.    Se așteaptă ca pompierii care trec prin programul de instruire pe teren să mențină un jurnal al programului de instruire pe teren. Aceste jurnale ar trebui să documenteze toate patrulele de antrenament pe teren și orice alte zone pe care pompierul dorește să le documenteze.    O patrulă de pregătire pe teren poate fi condusă numai de un ofițer de instruire pe teren și este de obicei considerată valabilă în următoarele condiții:  - A durat o (1) oră sau mai mult; sau - A participat la cel puțin două (2) scene; sau - A participat la o (1) scenă și a efectuat o demonstrație medicală;     Raportul care acoperă evaluarea trebuie adăugat la dosarul angajatului cât mai curând posibil, fără întârzieri inutile. În cadrul raportului, trebuie utilizată scala de evaluare adecvată. Pentru mai multe informații, vezi MOPS 07/11.01.    Atunci când se decide eligibilitatea angajatului de a absolvi programul, vor fi luate în considerare următoarele cerințe:  - Timpul petrecut în cadrul Programului, un (1) an **((**trei (3) săptămâni**))** este minim; - A efectuat cel puțin trei (3) evaluări; - Evaluat de cel puțin doi (2) ofițeri de pregătire pe teren diferiți; - Cunoștințe de stingere a incendiilor și medicale afișate într-un grad satisfăcător; și - S-au dovedit a fi suficient de capabili pentru a obține mai multă responsabilitate;     11.01 Program de instruire pe teren: scară de evaluare    Pentru a fi utilizat la trimiterea unui raport de instruire pe teren:  1. Nu satisface așteptările (se luptă cu abilitățile, ratează obiectivele atribuite, multe puncte slabe); 2. Îndeplinește așteptările (performanțe adecvate, lucrează în sfera postului); 3. Depășește așteptările (automotivat, performanțe dincolo de cerințe, fără puncte slabe semnificative); 4. Remarcabil (Înțelege în detaliu complexitatea sarcinilor, afișează profunzimea cunoștințelor/aptitudinilor mult peste cerințe, performanță peste marea majoritate a personalului cu experiență în același loc de muncă).     **((**12.00 Rapoarte de absență**))**    Membrii facțiunii care nu se pot conecta la joc pentru o perioadă rezonabilă de timp într-o perioadă de cinci (5) zile trebuie să posteze un Raport de absență folosind formatul Absență. Membrii facțiunii care au activitate incertă, dar încă se pot conecta la fiecare cinci (5) zile, în majoritatea cazurilor, trebuie să posteze un Raport de absență folosind formatul Activitate redusă. Vezi 5/11.00.    **((**13.00 Pedeapsa administrativă**))**    În conformitate cu 5/09.00, membrii facțiunii trebuie să respecte toate regulile relevante pentru platformele Los Santos Roleplay. În cazul în care unui membru al unei facțiuni i se emite o pedeapsă administrativă de către un administrator de server, notificarea trebuie să fie transmisă prin mesaj privat ofițerilor șef de pompieri. Aceasta include (dar nu se limitează la):   - Avertisment de forum sau interdicție pe forumurile principale; - Lovitură cu piciorul în joc, închisoare sau ban; - Discord interdicție pe Discord principal;     Membrii facțiunii trebuie să notifice în termen de două (2) zile de la apariția pedepselor. Se așteaptă ca membrii facțiunii să notifice cât mai curând posibil, folosind timpul suplimentar în caz de indisponibilitate din cauza unor circumstanțe din viața reală.    **((**14.00 Demisia**))**    Membrii facțiunii sunt considerați a fi în voie și sunt liberi să se îndepărteze de facțiune în funcție de dorința personală sau în afara caracterului, după cum se simte potrivit. Cu toate acestea, demisia și demisia frecventă în care un membru al unei facțiuni demisionează după o perioadă scurtă de timp, instalează și repetă, este atât descurajată, cât și interzisă. Membrii facțiunii trebuie să treacă prin sistemul de demisie atunci când el sau ea are intenția de a demisiona din facțiune. Membrii facțiunii nu pot să-și abandoneze pur și simplu caracterul sau să li se elimine statutul de facțiune prin alte mijloace. Demisiile sunt postate pe forumul Demisii din Recepție și pot avea orice structură de titlu/format adecvată. Demisiile sunt un proces în caracter, în timp ce sistemul de demisie este în afara caracterului. Personajul care demisionează este lipsit de orice acces în caracter la sistemele restricționate,    Membrii facțiunii sunt sfătuiți să se gândească la demisii, deoarece reconsiderările nu vor fi onorate. Membrii facțiunii resemnați care au a doua gânduri vor fi informați să încerce o declarație.    Membrii facțiunii care demisionează au dreptul de a fi angajat în pensie pe forumuri și pe serverul Discord al facțiunii, cu condiția să fie îndeplinite cerințele. Membrii facțiunii trebuie să fie Pompier II sau mai mare în momentul demisiei, cu excepția membrilor care au servit înainte, acum demisionează ca Pompier I. Membrii facțiunii care au revenit ca un rang inferior în timp ce Pompierul II sau mai mult vor fi considerați bazați. pe o serie de factori, inclusiv activitatea de la întoarcere. Se așteaptă ca membrii facțiunii demisionați care obțin acest statut să acționeze în mod corespunzător pe toate platformele și pot fi revocați statutul dacă se consideră necesar. Membrii facțiunii demisionați cu rangul de Asistent șef al pompierilor sau mai mult pot avea, de asemenea, dreptul la gradul de Ofițer șef de pompieri pensionat.    **((**15.00 Sugestii**))**    Membrii facțiunii sunt liberi să sugereze schimbări ale facțiunii care se potrivesc cu ideologia facțiunii și ar contribui pozitiv la experiența tuturor membrilor facțiunii. Sugestiile ar trebui să se concentreze mai degrabă pe facțiune decât pe comunitatea sau scenariul de joc de rol Los Santos. Sugestiile de scenariu care afectează direct facțiunea sunt acceptabile.    Toți membrii facțiunii sunt liberi să lase informații despre sugestiile postate. Nu există un format strict — Subiectele cu sugestii trebuie să fie concise și ușor de citit.

---

## #8 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

8. Politici operaționale

---

 01.00 Scop

 Acest capitol stabilește temelia reglementărilor operaționale și a așteptărilor pentru angajații Departamentului.

 02.00 Utilizarea asistenței civile

 Angajaților departamentului nu li se permite să solicite asistență civililor care nu servesc într-o calitate oficială în orașul Los Santos sau statul San Andreas relevant pentru incident la un răspuns de incendiu, medical, de salvare sau de alt tip de urgență. Acest lucru este exclus numai în circumstanțe exigente în care există o convingere rezonabilă și durabilă că situația în cauză este o chestiune de viață sau de moarte. În cazul în care asistența civilă este utilizată într-o astfel de circumstanță, numele complet și adresa sa trebuie incluse în Raportul de incident relevant. Angajatul Departamentului este responsabil pentru acțiunile civilului în această circumstanță.

 03.00 Ride Alongs

 Angajații departamentului au permisiunea de a înrola o (1) persoană ca plimbare. Acesta poate fi fie la o stație de pompieri, fie într-un echipaj de intervenție. Călătoriile administrative nu sunt permise fără autorizația unui ofițer de pompieri șef al departamentului.

 Angajații departamentului relevant sunt responsabili pentru persoană pe toată durata călătoriei. Angajații departamentului nu sunt răspunzători pentru nicio vătămare suferită care nu a rezultat din propria neglijență.

 Membrii publicului care doresc să ia parte la o călătorie trebuie să prezinte un act de identitate legal, trebuie să aibă cel puțin optsprezece (18) ani, trebuie să fie într-o formă fizică acceptabilă, să nu aibă antecedente penale și să nu aibă nicio armă. persoana ei pe durata călătoriei.

 Angajații departamentului sunt responsabili pentru asigurarea respectării reglementărilor de mai sus înainte de a duce un membru al publicului într-o plimbare. Trebuie efectuată o lovitură, iar persoana care participă la călătorie trebuie să semneze o derogare care exclude Departamentul de răspundere pe durata călătoriei.

 Angajații departamentului nu au responsabilitatea de a duce o persoană într-o plimbare la cerere.

 03.01 Ride Alongs: Comportamentul unui Ride Along

 Ridelong-urile sunt, după cum am spus, ridealongs. Aceste persoane nu au niciun statut în cadrul Departamentului și nu au voie să asiste în nicio calitate. Departamentul se așteaptă ca persoanele care participă la o plimbare să fie plasate într-o zonă în care el sau ea nu va servi ca o distragere a atenției sau nu va îndepărta niciun angajat.

 **((** Persoanele care participă la o călătorie trebuie să urmeze aceleași așteptări de conduită ca și un membru al unei facțiuni. Persoanele care participă la o călătorie care aleg să troleze trebuie să fie excluse din cursă din motive nepersonale și raportate la administrația serverului prin comanda /report. **))**

 03.02 Ride Alongs: Terminarea unui Ride Along

 Ridelong-urile pot fi refuzate în timpul unei călătorii într-o locație sigură, dacă acomodarea acestuia cauzează un risc sau o problemă majoră cu funcționarea în desfășurare. În caz contrar, persoanele care participă la o călătorie trebuie să li se asigure transport la locul de plecare la încheierea cursei.

 04.00 Găsirea obiectelor de valoare

 Banii, bijuteriile sau alte proprietăți valoroase găsite la un incendiu, medical, salvare sau alte intervenții trebuie să fie predate comandantului incidentului (sau unui ofițer de departament relevant, cum ar fi un căpitan de stație), unui ofițer de pace sau altui investigator autorizat. pentru păstrare până când proprietarul proprietății poate fi contactat și/sau identificat.

 Angajații departamentului nu pot păstra proprietățile găsite pentru uzul lor personal, cu excepția cazului în care se prevede altfel prin legea municipală, statală sau federală.

 05.00 Personal în afara serviciului

 Angajaților departamentului care sosesc la un intervenție de incendiu, medical, de salvare sau de altă natură le este interzis să se implice în incident, cu excepția cazului în care comandantul incidentului solicită altfel (sau un ofițer de departament relevant, cum ar fi un căpitan de stație). Angajații departamentului sunt de altfel considerați în afara serviciului și nu trebuie să intervină în operațiuni.

 Cele de mai sus nu se aplică ofițerilor de departament.

 06.00 Descoperirea unui incident în timpul răspunsului

 Echipajele de răspuns care răspund la un intervenție de incendiu, medical, de salvare sau de altă natură trebuie să facă o evaluare rapidă a incidentului și să stabilească dacă incidentul necesită o atenție imediată din partea echipajului. În cazul în care echipajul consideră că incidentul este un statut emergent, echipajul trebuie să devieze de la răspunsul inițial și să informeze Metropolitan Fire Communications. Echipa de răspuns trebuie să informeze despre noile detalii ale incidentului, în care Metropolitan Fire Communications va confirma și aranja un echipaj alternativ pentru apelul de răspuns inițial.

 07.00 Găsirea unui cadavru

 Angajații departamentului și/sau echipajele de răspuns care descoperă o persoană evident decedată trebuie să evite deranjarea sau modificarea în alt mod a corpului, cu excepția cazului în care nerespectarea acestui lucru ar duce la distrugerea în continuare a cadavrului. Se așteaptă ca echipajele de intervenție să informeze Metropolitan Fire Communications, care vor lua apoi legătura cu forțele de ordine pentru investigare.

 Echipajele de răspuns care declară o persoană decedată la fața locului trebuie să urmeze aceeași procedură, totuși, poate fi chemat un medic legist de la o companie independentă dacă ancheta poliției nu este considerată necesară.

 **((** Coronerii vor fi interpretați ca o companie independentă. Utilizați comanda /do pentru a descrie Coronerul care sosește și scoate cadavrul de la scenă. Anchetatorii de poliție ar trebui chemați prin /dep ca de obicei, deoarece este un serviciu existent. **))**

 8.00 Alarma de panică și conștientizarea primejdiei

 Toți pompierii sunt echipați cu o alarmă de panică atașată la dispozitivul lor de comunicații radio Motorola. Alarma de panică permite angajaților Departamentului să comunice rapid și în tăcere către Metropolitan Fire Communications că se află în primejdie imediată, în care comunicarea radio verbală ar risca să agraveze situația. Alarmele de panică ar trebui să fie ultima linie a unei încercări de apel de urgență în care toate celelalte metode au fost epuizate sau nu sunt posibile.

 **((** Alarmele de panică sunt accesibile numai în timpul serviciului. Membrii facțiunii trebuie să prezinte un joc de rol vizibil prin /me sau /ame de atingere și activare a alarmei de panică. Membrii facțiunii trebuie apoi să utilizeze comanda /hq cu următoarea sintaxă: *Alarma de panică activată — Prenume Nume*. Nicio locație nu trebuie atașată. **))**

 9,00 înregistrări de la Dash Camera

 Majoritatea activelor vehiculelor deținute și sau operate de Departament sunt echipate cu camere frontale, posterioare și interioare pentru bord. Înregistrările camerei de bord sunt protejate și accesul este blocat la Fire Administration și la Divizia Standarde Profesionale.

 Înregistrarea video a camerei de bord începe automat odată ce videoclipul este conectat la list de unități și va rămâne înregistrarea până la zece (10) minute după ce unitatea este deconectată. Înregistrarea audio a camerei de bord nu începe automat cu video, ci trebuie să fie activată sau oprită manual de către operatorul unității respective. Activarea unui model de iluminare sau a unei sirene audibile va începe automat înregistrarea audio și nu va permite operatorului unității menționate să modifice starea înregistrării audio.

 Echipamentul camerei Dash este blocat într-o carcasă rezistentă la deteriorare, ceea ce păstrează integritatea camerei în majoritatea cazurilor. Înregistrarea video cu camera de bord afișează informații după cum urmează:

- Numărul intern al unității;
- Indicativ extern al unității;
- Data (ZZ/LL/AAAA), Ora (XX:XX);
- Cap direcțional;
- Viteza;
- Starea vehiculului; și
- Starea modelelor de iluminare și a sirenei sonore.

 **((**10.00 Comenzi facțiuni**))**

 Membrilor facțiunii li se oferă un set de comenzi pentru utilizarea facțiunii. Utilizarea unei comenzi enumerate împotriva scopului enumerat este strict interzisă și va avea ca rezultat luarea unor măsuri disciplinare împotriva acelui membru al facțiunii. Comenzile facțiunii sunt după cum urmează:

- /dep și /deplow [MESAJ]: folosit pentru a comunica cu alte agenții guvernamentale. Se difuzează în mod implicit către toate facțiunile. Vezi /setdep.
- /duty: folosit pentru a te stabili ca la datorie prin scenariu. Oferă jumătate de armură (jucat ca o vestă anti-înjunghiere) și o etichetă colorată a facțiunii. Oferă acces la anumite comenzi ale facțiunii.
- /f [MESAJ]: folosit pentru a tasta în chat-ul facțiunii.
- /factionon: folosit pentru a arăta care membri ai facțiunii sunt online. Membrii facțiunii sunt codificați cu culori în funcție de statutul de serviciu: culoarea facțiunii reprezintă în serviciu, gri reprezintă în afara serviciului.
- /factionmenu: panou de administrare pentru managementul facțiunii. Limitat la ofițerii șef de pompieri.
- /fireduty: vă echipează cu stingător de incendiu și ferăstrău cu lanț. Folosit numai cu unelte de turnare.
- /gate: folosit pentru a opera porțile Aeroportului Los Santos, precum și porțile Stației de Pompieri 11.
- /hq [MESAJ]: folosit pentru a difuza pagere și anunțuri importante pentru membri.
- /fix: afișează meniul facțiunii de telefon fix.
- /nofam: dezactivează chat-ul facțiunii pentru toți membrii. Limitat la pompieri.
- /offduty: folosit pentru a te stabili ca offduty prin intermediul scenariului. Îndepărtează armura dată și revine culoarea etichetei la alb. Revocă accesul la anumite comenzi ale facțiunii. Trebuie să fie de serviciu prin scriptul de utilizat.
- /operațiune [NUMELE JUCĂTORULUI sau ID-UL JUCĂTORULUI]: folosit pentru a resuscita un jucător din sistemul rănit brutal odată ce jocul de rol a fost realizat. Poate fi folosit oriunde, dar ar trebui să fie folosit în spitale, cu excepția cazului în care jucătorul este eliberat la fața locului unei răni minore. Trebuie să fie de serviciu prin scriptul de utilizat.
- /park: modifică poziția unui vehicul fracționat la apariție. Limitat la ofițerii șef de pompieri.
- /particlegun [CLASIFICAT]: folosit pentru a genera efecte de particule în joc. Limitat la pompieri.
- /putinambu [NUMELE JUCĂTORULUI sau ID-UL JUCĂTORULUI]: folosit pentru a plasa un jucător în spatele unei ambulanțe. Trebuie utilizat în interiorul unei ambulanțe sau un elicopter. Permite jucătorului să se miște dacă se află în modul rănit brutal. Trebuie să fie de serviciu prin scriptul de utilizat.
- /pl: răspunde la telefon fix de facțiune.
- /setcarcolor [VEHICLEID COLOR1 COLOR2]: modifică culorile unui vehicul fracționat. Limitat la ofițerii șef de pompieri.
- /setdep [ALL/LSPD/LSSD/LSFD/COURTS/DCR]: folosit pentru a seta cu ce agenție veți comunica când utilizați comanda /dep.
- /tagcolor: folosit pentru a da o etichetă colorată a facțiunii. Unitate restricționată.
- /togfam: dezactivează chat-ul facțiunii.
- /towcar [VEHICLE ID]: remorcă un anumit vehicul al unei facțiuni. Limitat la pompieri.
- /towcars: remorcă vehicule ale facțiunii. Limitat la pompieri.
- /towcars2: remorcă vehicule ale facțiunii care nu au fost folosite într-un anumit interval de timp. Limitat la pompieri.
- /v faction: fracționează sau de-facționează un vehicul. Limitat la ofițerii șef de pompieri.

---

## #9 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

9. Politici de comunicare

---

 01.00 Scop

 Acest capitol pune bazele sistemelor de comunicare relevante pentru angajații Departamentului.

 02.00 Telefoane

 Rețelele fixe (sau alt dispozitiv similar de telefon) trebuie să primească următoarele informații: identificatorul stației de pompieri (sau unității), rangul angajatului care răspunde și numele de familie al angajatului care răspunde. EXEMPLU: Stația de pompieri Eleven, „Doe pompier”.
 Telefoanele fixe pot fi utilizate pentru apeluri personale limitate, cu condiția ca o astfel de activitate să nu interfereze cu operațiunile Departamentului. Toate alertele de „apel în așteptare” trebuie să primească un răspuns prompt.

 03.00 Telefoane mobile

 Angajații departamentului au voie să poarte telefoane mobile personale în timpul serviciului. Asemenea dispozitive nu trebuie utilizate în timp ce funcționează activ pe o scenă, participă la un antrenament al Departamentului, un eveniment public sau în timpul conducerii unui vehicul al Departamentului. Dispozitivele sunt de așteptat să vibreze atunci când una dintre condițiile de mai sus poate apărea și nu trebuie să servească drept o distragere a atenției. dispozitivele nu trebuie să fie utilizate (cu excepția afacerilor departamentului și/sau a urgențelor personale extreme) în timp ce echipajele operează activ pe scene, în timpul antrenamentelor departamentului, evenimentelor de relații publice sau în timpul conducerii unui vehicul departament. În timpul evenimentelor enumerate mai sus, aceste dispozitive trebuie lăsate în vehicul sau cel puțin plasate în alertă de vibrație pentru a nu perturba activitatea respectivă.

 04.00 Paginare

 Paginarele trebuie să fie transportate în timpul serviciului și în afara serviciului, dacă sunt accesibile. Paginile sunt transmise de către Polițiștii de Comunicare și Pompieri Metropolitani în situații de urgență și lipsuri de personal sau resurse. Paginarele pot fi folosite în alte situații, cum ar fi un civil care solicită un supervizor. Trebuie folosit bunul simț.

 **((** Paginarele pe Discord pot fi trimise numai dacă /hq [PAGER] a fost jucat pe rol în joc. **))**

 05.00 Calculatoare și MDT-uri

 Toată tehnologia (cum ar fi un computer sau MDT) întreținută de Departament este permisă strict pentru utilizarea Departamentului. Angajații departamentului pot avea acces la Internet atâta timp cât site-urile vizitate sunt legale, adecvate și de bună natură morală. Utilizarea personală a calculatoarelor stației va fi determinată și monitorizată de către căpitanul de stație relevant. Site-urile ilegale sau sexual explicite sunt interzise pentru utilizare cu o astfel de tehnologie.

 06.00 Comunicații radio

 Pentru a menține un standard clar și ușor de înțeles de comunicare radio, anumite expresii trebuie folosite în locul codurilor radio, care nu sunt folosite de Departament. Comunicarea radio are loc folosind limba engleză simplă, ușor de înțeles, denumită prin prezenta engleză simplă. Comunicarea radio ar trebui să fie lipsită de argou, vulgaritate și neprofesionalism.

 Locațiile trebuie menționate după numele străzii atunci când sunt disponibile. În absența unui nume de stradă cunoscut, locațiile trebuie să conțină o locație din apropiere sau un reper notabil. O zonă generală precum „Idlewood” nu ar trebui utilizată în comunicațiile radio.

 **((** /streetname ar trebui folosit pentru locații. Trebuie să puteți vedea un semn rutier pe hartă pentru a putea folosi comanda, cu excepția cazului în care utilizați un dispozitiv precum GPS sau telefon mobil pentru a obține numele străzii în caracter. **))**

 Angajații departamentului și lucrătorii din serviciul public trebuie să fie referiți într-o manieră respectuoasă, folosindu-și rangul atunci când este disponibil. În absență, trebuie folosit un nume de familie, cu excepția cazului în care este necesar numele complet pentru identificarea unei persoane. Un exemplu de referință la nume este Căpitanul Doe sau Doe dacă nu se cunoaște poziția.

 **((** Comenzile rapide nu trebuie folosite atunci când faceți referire la un individ în joc. Poziția completă ar trebui să fie specificată. Abrevieri precum FFI sau CPT nu trebuie folosite. Aceasta este considerată o problemă în afara caracterului. **))**

 06.01 Comunicații radio: utilizarea expresiei

 Expresiile de utilizat în comunicațiile radio sunt următoarele:

 „Se schimbă grupul care raportează numele de familie în [CALLSIGN]. Ocupant singur.”

 Folosit la schimbarea indicativului ca ocupant singur al indicativului respectiv.

 „Echipa de raportare a numelui de familie de rang în [CALLSIGN], alături de numele de familie a rangului.”

 Folosit la schimbarea indicativului de apel cu un alt ocupant al indicativului respectiv.

 „Clasați echipa de raportare a numelui de familie [CALLSIGN] în serviciu, în baza [REPORT LOCATION].”

 Folosit pentru a informa Metropolitan Fire Communications că echipajul este disponibil, folosit în verificările de stare.

 „Numele de rang recunoaște ultimul.” „[CALLSIGN] confirmă ultimul.”

 Folosit pentru a confirma transmisia anterioară.

 „[CALLSIGN] răspunde în mod neemergent către [LOCAȚIA ATRIBUITĂ].”

 Folosit atunci când răspunde la o locație neemergentă.

 „[CALLSIGN] răspund emergent la [LOCAȚIA ATRIBUITĂ].”

 Folosit atunci când răspunde la o locație emergentă.

 „[CALLSIGN] se transportă la [SPITAL/LOCATION]. [PATIENT COUNT] s-a încărcat.”

 Folosit pentru a informa Metropolitan Fire Communications că echipajul transportă un pacient pentru ca aranjamentele să fie făcute cu Spitalul sau cu unitatea.

 „[CALLSIGN] clar de la ultimul. În serviciu, cu sediul la [REPORT LOCATION].”

 Folosit pentru a informa Metropolitan Fire Communications că sunteți departe de ultimul și că sunteți din nou în serviciu.

 „[CALLSIGN] pe scena unui steag jos. Locația este [LOCATION].”

 Folosit atunci când se află pe scena unui steag jos sau când a fost descoperit un incident.

 „[CALLSIGN] solicită răspunsul poliției. Locația este [LOCATION], scopul este [PURPOSE].”

 Folosit pentru a informa Metropolitan Fire Communications că aveți nevoie de asistență de poliție. Scopul ar trebui să fie clar și să informeze Metropolitan Fire Communications despre situație și urgență, astfel încât răspunsul adecvat să poată fi coordonat cu agențiile de poliție.

 06.02 Comunicații radio: frecvențe

 Angajații departamentului operează un radio Motorola cu mai multe frecvențe. Angajații departamentului trebuie să se asigure că radioul său este reglat la frecvențele enumerate la începutul fiecărei ture. Frecvențele sunt după cum urmează:

 858.43750 **((** 85843 **))** — Metropolitan Fire Communications

 860,93750 **((** 86093 **))** — TAC

 863.50001 **((** 86350 **))** — Comunicații simplex

 999.80250 **((** 99980, parolă: speedwhenitmatters **))** — Comunicații de asistență de urgență

 07.00 Teme radio

 Comanda 1 (CM1) — Comanda de incident
 Comandamentul 10 (CM10) — Șeful pompierilor
 Comandamentul 20 (CM20) — Șef adjunct
 Comandamentul 30 (CM30) — Asistent șef
 Comandamentul 40 (CM40) — Asistent șef

 Batalionul 11 ​​(B11) — Șeful batalionului
 Batalionul 21 (B21) — șef de batalion

 Supervizorul EMS 11 (EM11) — Căpitanul batalionului EMS
 Supervizorul EMS 21 (EM21) — Căpitanul batalionului EMS

 Ambulanță de salvare (RA##) – Salvare ALS
 Ambulanță de salvare (RA2##) - Rezervă de salvare ALS
 Ambulanță de salvare (RA8##) — Salvare BLS
 Ambulanță de salvare (RA9##) - Rezervă de salvare BLS

 Răspuns rapid (FR11) — Motor de evaluare, utilitar și suport ALS

 Motor (E##) — Motor

 Camion (T##) — Camion

 Squad (SQ##) — Squad

 Brush Patrol (BP##) — Brush Patrol

 Copter (Aer##) — Elicopter de pompieri

 Barcă de foc (FB##) — Barcă de foc

 USAR (USAR#) — Căutare și salvare urbană

 08.00 Terminologie

 Aparat — O piesă de echipament al Departamentului utilizat pentru operațiunile de teren, adesea folosit pentru a descrie un vehicul Departament.

 Cod 1 – Răspuns non-emergent, fără lumini și sirene pentru răspunsul vehiculului.
 Cod 2 – Răspuns la urgență, lumini și fără sirenă pentru răspunsul vehiculului.
 Cod 3 – Răspuns la urgență, lumini și sirenă pentru răspunsul vehiculului.

 Dispecerat — Alias ​​pentru Metropolitan Fire Communications.

 Urgență — Răspuns în caz de urgență, incident critic.

 MCI – Incident cu victime în masă, un incident care implică un număr mare de persoane rănite sau rănite în alt mod.
 MVA — Accident de vehicule cu motor, o coliziune care implică unul sau mai multe vehicule.

 SCBA — Aparat de respirație autonom, termen pentru combinația de mască de oxigen și rezervor.

 Non-emergent — Răspuns fără urgență, incident necritic.

 EIP – Echipament de protecție personală, o combinație de echipamente utilizate pentru siguranță în timpul unui incendiu sau alte operațiuni.

 09.00 E-mailuri și scrisori ale departamentului

 Comunicarea în cadrul Departamentului este adesea sub forma unui e-mail sau a unei scrisori, aceasta din urmă fiind livrată fie printr-un serviciu poștal, fie printr-o tranzacție în persoană. Pentru a menține un standard uniform și profesional, comunicarea oficială folosește un format proprietar. Comunicarea care nu implică Departamentul în calitate oficială nu trebuie să utilizeze acest format proprietar.

 Toate comunicările relevante pentru Departament trebuie să utilizeze formatul ZZ/MMM/AAAA pentru toate datele. Exemplu de format: 01/JAN/2018, care este 1 ianuarie a anului 2018.

 Toate comunicările relevante pentru Departament trebuie să utilizeze formatul XX:XX pentru tot timpul (formatul militar). Exemplu de format: 21:00, adică 21:00.

 **((** Mesajele private de pe forumuri sunt considerate a fi un sistem în afara caracterului, cu toate acestea, pot fi folosite în scopul de a trimite un e-mail sau o scrisoare în caractere. Parantezele ar trebui folosite în mod normal pentru comunicarea în afara caracterului. **))**

 10.00 Metropolitan Fire Communications

 Metropolitan Fire Communications Dispatch gestionează toate apelurile medicale și de stingere a incendiilor de urgență și non-urgențe pentru orașul Los Santos și departament. În plus, centrul de dispecerat gestionează resursele Departamentului și atribuie unităților adecvate apelurilor, comunicând și cu unitățile de teren.

 Metropolitan Fire Communications Dispatch deține autoritatea asupra unităților și resurselor alocate cărora apelurile. Ofițerii departamentului, cum ar fi un căpitan de stație relevant, pot trece peste comunicațiile Metropolitan Fire atunci când sau dacă consideră necesar. Niciun alt personal nu va răspunde la un incident pe cont propriu, fără a fi desemnat de Metropolitan Fire Communications.

 **((** Rolul de Dispatcher în joc este atribuit automat primei persoane de serviciu. Este de înțeles că, din cauza naturii facțiunii și a activității acesteia, dispecerul va trebui adesea să se desfășoare pe teren sub o unitate. Pentru a maximiza imersiunea și a păstra conceptul realist, dispecerii sunt încurajați să rămână la stație atunci când este posibil și să nu folosească radioul atunci când se află pe o scenă activă sau într-o zonă puternic populată. În plus, nu trebuie să trimiteți în timpul scenelor active de joc de rol, deoarece acest lucru ruinează atmosfera jocului de rol. În plus, unitățile nu pot utiliza frecvența departamentului. Este activat numai pentru utilizare de la Metro Dispatch și anumiți ofițeri de pompieri.**))**

 11.00 Partajarea informațiilor

 Departamentului i se încredințează o varietate de informații privilegiate și neprivilegiate, dintre care unele pot fi protejate de politica Departamentului sau de legea orașului, de stat sau federală.

 11.01 Partajarea informațiilor: informații despre pacient

 Informațiile despre pacienți sunt puternic protejate de legile și actele din San Andreas, în special de Legea privind sănătatea cetățenilor și protecția informațiilor din 2016. Această lege definește modul în care informațiile pot fi partajate relevante pacienților. Această politică cuprinde Legea în sine, care se așteaptă să fie citită de toți angajații Departamentului ca parte a acestui capitol.

 Confuzia cu funcționarea actului ar trebui să fie transmisă unui ofițer de departament relevant, cum ar fi un căpitan de stație. Încălcarea acestei politici poate duce la amendă sau acuzare civilă sau penală din partea orașului Los Santos sau a statului San Andreas.

 11.02 Partajarea informațiilor: documente departamentale

 Documentele departamentului sunt, de asemenea, considerate bunuri protejate. Acestea includ Manualul de operațiuni, Manualul de stingere și intervenție la incendiu, Manualul de operațiuni medicale, Rapoartele pacienților, Rapoartele de incident, comunicarea cu ofițerii departamentului, orice informație care este privilegiată de o poziție suplimentară în cadrul Departamentului dincolo de Pompierul I. Alte documente care nu sunt enumerate. pot fi, de asemenea, protejate.

 Partajarea documentelor enumerate va duce la emiterea de măsuri disciplinare, în plus față de potențiala amendă sau acuzare civilă sau penală.

 **((** Acest lucru se aplică în afara caracterului în plus față de în caracter. Partajarea documentelor este strict interzisă. **))**

 **((**12.00 Discordie**))**

 Membrii facțiunii trebuie să fie membri ai serverului Discord al facțiunii. Serverul Discord al facțiunii este în principal o metodă de comunicare în afara caracterului, totuși, poate fi folosit pentru paginarea unităților suplimentare pentru a se îndrepta în joc. Serverul Discord este, de asemenea, folosit de conducerea facțiunii pentru a comunica rapid cu membrii facțiunii: fie pentru a anunța informații, fie pentru a măsura feedback-ul rapid cu privire la schimbările potențiale sau evenimentele din joc.

 Membrii facțiunii trebuie să solicite alocarea Discord prin Centrul de solicitare a personalului. Membrii facțiunii trebuie să aibă numele personajului setat ca pseudonim.

 Membrii facțiunii trebuie să se alăture serverului Discord odată ce cererea a fost trimisă. Serverul Discord poate fi conectat prin linkul de mai jos:

 [https://discord.gg/v9Pd3Du](https://discord.gg/v9Pd3Du)

 Membrii facțiunii care nu pot folosi Discord trebuie să contacteze ofițerii șefi de pompieri pentru a discuta despre o excepție. În rest, utilizarea este obligatorie.

 **((**13.00 TeamSpeak 3**))**

 Membrii facțiunii pot utiliza TeamSpeak 3 ori de câte ori sunt de serviciu sau desfășoară o misiune în cadrul unei facțiuni. Canalele de voce din Serverul TeamSpeak 3 pentru comunicarea verbală în caractere sunt interzise. Comunicarea verbală în afara caracterului este permisă, dar ar trebui să rămână limitată la discuții în afara caracterului și camaraderie. Trollingul nu este permis prin voce și va avea ca rezultat luarea unor măsuri disciplinare.

 Membrii facțiunii pot solicita atribuirea TeamSpeak 3 prin Centrul de solicitari de personal. Membrii facțiunii trebuie să aibă numele personajului și facțiunea în descrierea TeamSpeak 3 - aceasta este o regulă de server pentru facțiunile legale TeamSpeak Server.

---

## #10 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

10. Politici privind flotele și instalațiile

---

 01.00 Scop

 Acest capitol stabilește fundamentul politicii relevante pentru flota și instalația Departamentului.

 02.00 Responsabilitate

 Căpitanii de stație au autoritate asupra posturilor lor respective în timpul serviciului. Căpitanii de stație sunt responsabili pentru a se asigura că toate ordinele, regulile și reglementările și procedurile sunt respectate pe tot parcursul serviciului. Căpitanii de stație sunt reporteri mandatați pentru încălcările constatate și pot emite măsuri disciplinare în măsura în care autoritatea departamentului său o permite. Căpitanii de stație sunt responsabili pentru a se asigura că toate aparatele, echipamentele și generatoarele de energie sunt gata pentru desfășurare și sunt responsabili pentru asigurarea îngrijirii fizice a proprietății.

 03.00 Open House Concept

 Departamentul funcționează în baza unui concept de case deschise, care permite cetățenilor să viziteze Gara la ore rezonabile ale zilei. Datorită acestui concept de pornire deschisă, căpitanii de stație sunt în mod special responsabili pentru a se asigura că stația desemnată rămâne curată și prezentabilă nu numai pentru pompieri, ci și pentru oaspeți. Aceasta include asigurarea că niciun material controversat nu este vizibil pentru oaspeți. Mai multe informații despre oaspeți și conceptul casei deschise pot fi găsite în 10/04.00.

 04.00 Vizitatori

 Căpitanii de stație trebuie să fie informați cu privire la orice vizitator la stația lor relevantă. Este responsabilitatea căpitanului stației să se asigure că toți vizitatorii sunt întâmpinați cu curtoazie și că toți vizitatorii sunt luați în considerare. Vizitatorii nu au voie să se plimbe prin incintă sau să se plimbe. Vizitatorii cu vârsta sub optsprezece (18) ani trebuie să fie supravegheați cu prioritate, acești vizitatori trebuie să fie însoțiți de un pompier, precum și de tutorele acestuia, dacă nu este permis altfel de către căpitanul stației.

 Vizitatorii trebuie să fie înlăturați de la stație la ora 22:00 până la ora 11:00, cu excepția cazului în care este permis altfel de către căpitanul stației. Doar angajații departamentului pot dormi pe proprietatea stației, cu excepția cazului în care este permis altfel de către căpitanul stației.

 05.00 Înregistrări și comenzi

 Angajaților departamentului nu le este permis să completeze nicio documentație în timp ce se află pe o scenă activă. Toată documentația trebuie înregistrată după ce scena sa încheiat. Comandanții incidentului sau ofițerul responsabil sunt responsabili, dar pot delega sarcina oricărui angajat desemnat la fața locului. Apoi, este responsabilitatea angajaților desemnați să se asigure că raportul este corect și precis, deoarece orice erori va fi răspunzătoare în fața ofițerului care a depus documentele.

 06.00 Atribuții de stații și poziții ale aparatelor alocate

 Stația 11 — Golf 1: EMS Supervisor 11 (EM11)
 Stația 11 - Golful 2: Batalionul 11 ​​(B11), Răspuns rapid 11 (FR11)
 Stația 11 — Golful 3: Ambulanța de salvare ALS (RA11) / Ambulanța de salvare ALS (RA211)
 Stația 11 — Golful 4: Ambulanța de salvare BLS (RA811) / Ambulanța de salvare BLS (RA911)
 Stația 11 – Golful 5: Echipa 11 (SQ11)
 Stația 11 — Golful 6: Camionul 11 ​​(T11)
 Stația 11 - Golf 7: Motor 11 (E11)
 Stația 11 - Golf 8: Motor 12 (E12)

 07.00 Sarcini

 Angajații departamentului, în special pompierii, care sunt repartizați la o stație sunt responsabili pentru asistența căpitanului stației în întreținerea acelei stații. Sarcinile standard ale stației includ curățarea podelei aparatului, ridicarea gunoiului și a resturilor din interiorul și exteriorul stației, curățarea camioanelor și a altor aparate, măturarea, curățarea și aspirarea tuturor zonelor de locuit.

 Angajații departamentului care locuiesc la Gară trebuie să își scoată lenjeria de pat și să le depoziteze în consecință înainte de a începe schimbul. Căpitanii de stație sunt responsabili să se asigure că stația este echipată corespunzător cu provizii, precum și să se asigure că generatoarele de rezervă sunt în stare de funcționare în cazul unei întreruperi de curent.

 Aparatură principală: Motoare, Scări, Echipă, Ambulanțe de salvare — goliți și curățați toate compartimentele, curățați toate echipamentele, curățați cabinele, completați inventarul aparatelor.

 Aparatură secundară: SUV-uri, camioane specializate — goliți și curățați toate compartimentele, curățați toate echipamentele, curățați cabinele, completați inventarul aparatelor.

 Sarcinile standard ale stației includ instruirea de rutină și dezvoltarea profesională a angajaților departamentului. Aceasta este organizată de Căpitanul Gării.

 08.00 Reparații

 Ofițerii departamentului trebuie să raporteze prompt elementele pentru reparare echipei de finanțare a departamentului. Angajații departamentului nu sunt autorizați să comande sau să autorizeze repararea niciunui articol al departamentului, cu excepția cazului în care au fost autorizați de către un ofițer de pompieri șef al departamentului. Angajații departamentului care dețin un articol de departament care necesită reparații trebuie să informeze un ofițer de departament, cum ar fi căpitanul de stație al acestuia.

 **((** Membrii facțiunii își pot repara scriptul vehiculului într-o locație Pay N Spray. Acest lucru este considerat a fi pentru daune în afara caracterului și nu este o metodă în caracter de reparare a unui vehicul de facțiune. Membrii facțiunii nu sunt responsabili pentru întreținerea combustibilului vehiculelor facțiunii, deoarece vehiculele fracționate nu folosesc sistemul de gaz. **))**

 09.00 Disponibilitatea aparatului

 Aparatele din cadrul stației trebuie să fie pregătite pentru desfășurarea de rutină. Aparatul ar trebui să fie indisponibil numai în scopul curățării în timpul orelor libere, în cazul în care există o convingere rezonabilă că un astfel de aparat nu ar necesita desfășurare imediată în timpul perioadei de curățare.

 10.00 Arme de foc și alte arme

 Armele de foc, muniția, părțile de arme de foc, proviziile de muniție sau alte arme diverse sunt interzise în timpul serviciului și în timp ce se află pe proprietatea întreținută de Departament. Ofițerii de pace care servesc în calitate de serviciu sunt scutiți de această politică.

 11.00 Vehicule personale

 Vehiculele personale nu au permisiunea de parcare în interiorul sau pe bordura sau trotuarul unei stații de pompieri, cu excepția cazului în care o autorizație specifică a fost acordată de către pompierii departamentului.

 Bicicletele, motocicletele și alte vehicule de dimensiuni mici pot fi permise pentru parcare în interiorul unei stații de pompieri cu aprobarea căpitanului stației relevante, în funcție de spațiu și disponibilitate.

 12.00 Desfășurarea aparatului

 Scopul acestei proceduri standard de operare este de a se asigura că este urmat un răspuns standardizat, ordonat și practic la incendiile de structură și alte incidente semnificative. Este conceput pentru a desfășura un număr adecvat de aparate și personal pentru a începe operațiunile.

 Ambulanțele de salvare trebuie să aibă un echipaj de două persoane. Companiile trebuie să aibă un echipaj format din două persoane. Vehiculele de comandă pot avea unul sau doi ofițeri responsabili.

 **((** Datorită mecanicii jocului, este de așteptat ca membrii facțiunii să nu fie întotdeauna parteneri în timpul serviciului. În timp ce echipajul solo este autorizat, este permis numai atunci când nu există alți membri ai facțiunii de serviciu. Dacă un alt membru al facțiunii se raportează la datorie, trebuie să se urce imediat în echipaj. Dacă un număr inegal de oameni sunt de serviciu, echipajul ar trebui să fie prioritatea principală - cu toate acestea, nu poate fi fezabil și, prin urmare, echipajul individual ar fi considerat adecvat. **))**

 13.00 implementări de răspuns

 Personalul trebuie să aștepte la posturile respective pentru o atribuire a apelului. Membrii echipajului care nu aderă la regulamentele de desfășurare vor fi luați în considerare pentru măsuri disciplinare.

 **((** Pentru a încuraja jocul de rol activ, fluent și pasiv în stația de pompieri, se așteaptă ca membrii facțiunii să-și petreacă cea mai mare parte a timpului de serviciu la stație. **))**

 13.01 Implementări de răspuns: implementare incidente

 Incidentele medicale trebuie să trimită o ambulanță de salvare, un motor de suport vital de bază sau avansat și un supraveghetor medical. Ultimele două pot fi omise din cauza lipsei de personal, totuși, toate răspunsurile medicale trebuie să trimită o ambulanță de salvare.

 Incidentele de incendiu trebuie să trimită aparate de incendiu după cum consideră necesar de către comandantul activ al incidentului respectiv. Incidentele de incendiu ar trebui să urmărească, de asemenea, trimiterea a cel puțin o (1) ambulanță de salvare, atunci când este disponibilă.

---
