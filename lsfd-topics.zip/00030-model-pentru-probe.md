# (( MOdel pentru probe))

- **Topic ID:** 30
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=30
- **Posts:** 1

---

## #1 — Kellan Dunley

![](https://i.imgur.com/2jlMxHe.png)

FIREFIGHTER UNION MANUAL

---

 CAPITOLUL I – INTRODUCERE GENERALĂ A FIREFIGHTER UNION
---

---

- **(1.1)** Rolul și importanța unui sindicat al pompierilor într-un sistem modern de intervenție

---

---

- Firefighter Union reprezintă fundamentul protecției profesionale și al echilibrului instituțional din cadrul unui Departament de Pompieri modern. Într-o profesie în care riscul, presiunea psihologică, expunerea la traume și responsabilitatea față de viața altora sunt realități cotidiene, existența unei structuri sindicale puternice devine nu doar necesară, ci esențială. Sindicatul nu este o organizație paralelă cu Departamentul, ci un partener instituțional care asigură respectarea drepturilor angajaților, menținerea standardelor etice și crearea unui climat de muncă stabil și predictibil.    Pompierii activează într-un mediu în care erorile pot avea consecințe tragice, iar presiunea publică poate influența decizii administrative sau politice. Firefighter Union asigură că aceste decizii nu sunt luate în mod abuziv, pripit sau nefundamentat. Manualul prezent reprezintă instrumentul care clarifică funcțiile, atribuțiile și procedurile necesare unui sindicat modern, adaptat la nevoile unui departament urban de intervenție, unde complexitatea operațională este în creștere constantă.

 -

---

---

- **(1.2)** Contextul profesional al pompierilor și necesitatea unei structuri de protecție colectivă

---

---

- Profesia de pompier este una dintre cele mai exigente din punct de vedere fizic, psihic și moral. Membrii Departamentului se confruntă cu intervenții la incendii majore, accidente rutiere, situații cu victime multiple, apeluri medicale critice, dezastre naturale, incidente periculoase cu substanțe chimice, precum și cu situații sociale în care agresivitatea sau instabilitatea persoanelor aflate în dificultate poate crea riscuri suplimentare.    În aceste condiții, este esențial ca personalul operativ să beneficieze de o structură care să asigure sprijin juridic, psihologic și profesional ori de câte ori situația o impune. Firefighter Union este instituția care transformă eforturile individuale ale pompierilor într-o forță colectivă, capabilă să influențeze politicile interne, alocările bugetare, măsurile de siguranță și standardele de lucru.    Sindicatul devine astfel un garant al stabilității profesionale, protejând angajații de decizii arbitrare, de presiuni administrative nejustificate sau de consecințe disproporționate în urma unor situații operaționale complexe. Acest Capitol expune bazele filosofice și operaționale ale Union, justificând necesitatea unei structuri organice bine definite, cu responsabilități clare și proceduri solide.

 -

---

---

- **(1.3)** Obiectivele fundamentale ale Firefighter Union

---

---

- Firefighter Union urmărește o serie de obiective strategice care stau la baza existenței sale:    **(1.3.1) Protejarea drepturilor profesionale și personale ale membrilor**    Sindicatul asigură că fiecare pompier beneficiază de tratament corect în procesul de angajare, promovare, disciplină, evaluare și remunerare. Firefighter Union este prezent în orice interacțiune formală între membru și conducere, garantând transparența și legalitatea procedurilor.    **(1.3.2) Asigurarea unui proces disciplinar corect și echilibrat**    Pompierii se confruntă uneori cu situații în care rezultatele intervențiilor pot fi interpretate în mod eronat de public, de administrație sau de mass-media. Sindicatul intervine pentru a preveni sancțiunile injuste și pentru a asigura un proces disciplinar bazat pe fapte, dovezi și proceduri standardizate.    **(1.3.3) Negocierea contractelor colective și a condițiilor de lucru**    Firefighter Union reprezintă vocea colectivă în fața autorităților locale, negociind salarii, beneficii, ore de lucru, programe de pensionare, sporuri de risc, acces la echipamente moderne și protecție medicală adecvată.    **(1.3.4) Promovarea siguranței la locul de muncă**    Sindicatul monitorizează în mod constant standardele de siguranță, verifică dotările, intervine în situațiile în care echipamentele nu sunt conforme și acționează pentru reducerea riscurilor profesionale.    **(1.3.5) Sprijin social și psihologic pentru membri**    Intervențiile critice, traumele, burnout-ul, PTSD-ul și expunerea continuă la evenimente extreme pot afecta sănătatea unui pompier. Union oferă programe de recuperare, asistență psihologică și suport pentru familiile membrilor.

 -

---

---

- **(1.4)** Rolul acestui manual în funcționarea Union

---

---

- Manualul Firefighter Union este un document de referință care oferă:  • un cadru legal și procedural,  • o structură organizațională clară,  • drepturile și responsabilitățile membrilor,  • mecanisme disciplinare și de apel,  • norme de negocieri și reprezentare,  • proceduri pentru situații extraordinare,  • standarde de comunicare și etică profesională.    Acest document funcționează ca un ghid intern obligatoriu, menit să ofere unitate și coerență în activitatea sindicală. Manualul nu este doar un set de reguli, ci o bază conceptuală care descrie modul în care Firefighter Union interacționează cu membrii săi, cu conducerea Departamentului și cu administrația orașului.

 -

---

---

- **(1.5)** Viziunea pe termen lung a Firefighter Union

---

---

- Firefighter Union urmărește dezvoltarea unui sistem modern în care pompierii:  • sunt protejați juridic și profesional,  • primesc echipamente adecvate și instruire continuă,  • au acces la servicii de sănătate fizică și mentală,  • beneficiază de salarii și pensii proporționale cu riscurile meseriei,  • au o voce reală în stabilirea politicilor interne.    Viziunea Union este ca fiecare pompier, indiferent de rang sau vechime, să simtă că face parte dintr-o comunitate puternică, care îl susține și îi respectă dedicarea față de siguranța publică.

 -

---

---

- **(1.6)** Domeniul de aplicare al manualului

---

---

- Acest manual se aplică:  • tuturor membrilor sindicali activi,  • personalului administrativ afiliat,  • reprezentanților sindicali,  • comisiilor interne,  • proceselor disciplinare,  • procedurilor de negociere colectivă,  • interacțiunilor cu Fire Department Command Staff.    Manualul va fi actualizat periodic pentru a reflecta noua legislație, standardele operaționale moderne și schimbările interne ale organizației.

 -

---
