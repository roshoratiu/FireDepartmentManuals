# MANUAL OF OPERATIONS (MOP)

- **Topic ID:** 45
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=45
- **Posts:** 1

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

 MANUAL OF OPERATIONS (MOP)

---

 **CAPITOLUL 1: INTRODUCERE**

 **1.01 Scop**
 Acest capitol stabilește fundamentele standardelor etice, morale și profesionale ale **Los Santos Fire Department**. Informațiile conținute aici sunt considerate de cunoștință publică și reprezintă un set de directive pe care toți angajații trebuie să le respecte.

 **1.02 Preambul**
 **Manual of Operations**, abreviat **MOP**, este o colecție de documente care dictează politicile, procedurile și standardele Departamentului. Acest manual este destinat angajaților actuali ai Departamentului și trebuie citit în întregime de către noii **Probationary Firefighters** înainte de a se angaja în orice activitate relevantă.

 O citire periodică a acestor documente este recomandată pentru a asigura reținerea cunoștințelor. Orice modificare adusă **MOP**-ului care vă afectează ca angajat va fi comunicată prin memorandum sau notificare formală. Dacă există confuzii sau întrebări cu privire la orice parte a manualului, angajații sunt îndrumați să contacteze direct **Supervisor**-ul lor ierarhic.

 **1.03 Declarație de Misiune**
 **Los Santos Fire Department** protejează viețile și proprietățile, promovează siguranța publică și sprijină dezvoltarea economică prin angajamentul față de prevenire, pregătire, răspuns și recuperare, fiind furnizorul principal de intervenție pentru siguranța vieții în fața tuturor riscurilor.

 **1.04 Valori Fundamentale**
 Valorile fundamentale ale Departamentului sunt cunoscute prin acronimul **SPIRIT** și sunt după cum urmează:

- **Service** - Dedicație completă față de Comunitatea pe care o servim.
- **Professionalism** - Onorarea **Firefighter Oath** prin competență și excelență.
- **Integrity** - Respectarea conduitei morale și etice în permanență.
- **Respect** - Aprecierea diversității și recunoașterea valorii fiecărui individ.
- **Innovation** - Asumarea riscurilor creative pentru adaptare și îmbunătățire.
- **Trust** - Încredere în integritatea, puterea și capacitatea membrilor noștri.

 **1.05 Principii de Operare**
 Un **Operating Principle** este o linie directoare de bază care reprezintă munca desfășurată în cadrul Departamentului. Acestea sunt:

1. **Operate through Teamwork:** Nicio intervenție nu este realizată individual; succesul depinde de coordonare.
2. **Operate to position the Department for the future:** Pregătirea continuă și adaptarea.
3. **Operate ethically, and with integrity:** Informațiile corecte și raportarea onestă sunt esențiale.

 **1.06 Organigramă Organizațională**
 Structura ierarhică asigură un **Chain of Command** clar, esențial pentru coordonarea eficientă și siguranța operațională.

 **Ierarhia Rankurilor:**
1. **Fire Chief**
2. **Deputy Chief**
3. **Battalion Chief**
4. **Captain**
5. **Lieutenant**
6. **Engineer** / **Paramedic** (Specializare)
7. **Firefighter**
8. **Probationary Firefighter**

 **Notă:** După avansarea la rank-ul de **Firefighter**, membrii pot alege calea de specializare: **Engineer** (specialist tehnic în operarea aparatelor și echipamentelor) sau **Paramedic** (specialist medical avansat). Ambele rankuri sunt echivalente ierarhic, dar cu responsabilități diferite.

 **1.07 Birouri și Funcții Departamentale**
 Departamentul este organizat în trei **Operations Bureaus** principale, care conțin **Divisions** specializate. Fiecare birou este gestionat de un **Bureau Commander** (rank minim **Captain**). Diviziile sunt conduse de un **Division Lead** (rank minim **Engineer** sau **Paramedic**).

 **1.07.01 Primary Operations Bureau**
 Biroul principal care administrează operațiunile de bază ale departamentului. **Toți membrii Fire-sworn fac parte din acest birou**. Este condus de un **Bureau Commander** și include două componente formale:
- **Fire Operations:** Operațiuni de stingere a incendiilor, salvare tehnică și răspuns la urgențe non-medicale. Toți membrii sunt instruiți în aceste operațiuni de bază.
- **Emergency Medical Services (EMS):** Răspuns medical pre-spitalicesc. Toți membrii dețin certificare **Basic Life Support (BLS)**. Membrii care doresc să se specializeze în EMS pot obține certificarea **Advanced Life Support (ALS)** și rankul de **Paramedic**.

 **Notă:** Aceste două componente nu sunt divizii separate cu leadership propriu, ci reprezintă domeniile de instruire și operare pentru tot personalul departamentului.

 **1.07.02 Special Operations Bureau**
 Gestionează operațiunile specializate în medii periculoase și complexe. Este condus de un **Bureau Commander** și include:
- **Division 2:** HSOD - Hazmat, Special Operations & Disaster Response (include **Urban Search and Rescue Unit**)
- **Division 3:** Wildland & Environmental Operations (include **Air Operations Unit**)
- **Division 4:** Water Rescue Operations

 **1.07.03 Administrative & Support Bureau**
 Gestionează funcțiile administrative, logistice și de suport. Este condus de un **Bureau Commander** și include:
- **Division 5:** Fire Investigation & Prevention
- **Division 6:** Training & Professional Development (include **Recruit Training Academy**)
- **Division 7:** Fleet, Logistics & Communications
- **Division 8:** Administration & Human Resources (include **Professional Standards Division** pentru investigații disciplinare)
- **Division 9:** Union & Labor Relations

 **1.08 Jurământul de Serviciu**
 Cunoscut și ca **Firefighter Oath**, acesta este depus de fiecare angajat la absolvire. Scopul este de a insufla un sentiment de responsabilitate:

> "Jur solemn că voi susține și apăra Constituția Statelor Unite și Constituția Statului San Andreas împotriva tuturor dușmanilor, externi și interni, că voi purta adevărată credință și loialitate Constituției Statelor Unite și Constituției Statului San Andreas, că îmi asum această obligație liber, fără nicio rezervă mentală sau scop de evaziune și că voi îndeplini bine și cu credință îndatoririle pe care sunt pe cale să le îndeplinesc."

 **2. COD DE ETICĂ**

 **2.01 Scop**
 Acest capitol stabilește fundamentele standardelor etice profesionale pe care angajații Departamentului trebuie să le respecte. Codul definește busola morală necesară pentru menținerea încrederii publice și a integrității organizaționale.

 **2.02 Așteptări și Standarde Departamentale**
 Departamentul angajează standarde riguroase pentru toți angajații și operațiunile sale pentru a oferi cea mai înaltă calitate a serviciilor. Așteptările de bază sunt următoarele:

- **Respectarea Legii:** Department employees trebuie să urmeze toate legile și actele delineate de State of San Andreas și organismele locale.
- **Conduita Profesională:** Department employees trebuie să se prezinte într-o manieră profesională în orice moment, onorând uniforma și **Badge**-ul pe care îl poartă.
- **Respect Reciproc:** Department employees trebuie să trateze colegii și civilii cu respect, indiferent de rang sau neînțelegeri personale. Niciun angajat nu va critica public acțiunile unui coleg sau contact profesional.
- **Chain of Command:** Angajații sunt așteptați să urmeze **Chain of Command** în mod corespunzător și să respecte ordinele date de un **Superior Officer**, cu excepția cazului în care ordinul încalcă legea sau pune în pericol nejustificat siguranța.
- **Integritate:** Acțiunile trebuie să fie transparente și oneste. Utilizarea poziției pentru câștiguri personale sau **Corruption** minoră/majoră neautorizată este strict interzisă.

 **2.03 Așteptări Faction **((****))****
 Ca membru al facțiunii, mențineți așteptări **Out-of-Character** cu privire la modul în care acționați și vă comportați. Acest lucru se aplică tuturor personajelor in-game, precum și conturilor de pe alte platforme.

- **Regulamentul Serverului:** Membrii trebuie să urmeze toate regulile serverului pe toate platformele asociate.
- **Roleplay Realist:** Membrii trebuie să practice un roleplay realist, fidel personajului lor și dezvoltării acestuia (character development). Mentalitatea de tip "play-to-win" este interzisă.
- **Activitate:** Membrii trebuie să mențină o activitate **UCP** minimă (curent 0.8) și să participe la operațiunile facțiunii.
- **Respect OOC:** Membrii trebuie să trateze alți membri ai comunității cu respect, evitând toxicitatea și conflictele **OOC**.
- **Gestionarea Absențelor:** Orice perioadă de inactivitate mai mare de 5 zile necesită un **Absence Report** pe forum.

 **3. DESCRIEREA POZIȚIILOR ȘI RANKURILOR**

 **3.01 Scop**
 Acest capitol stabilește fundamentele informațiilor relevante pentru rankurile și pozițiile specifice din cadrul Departamentului. Fiecare rank are responsabilități, autoritate și cerințe de calificare specifice.

 **3.02 Fire Chief**
- **Nivel Autoritate:** Comandă Supremă
- **Tip Poziție:** Administrative, Fire-sworn

 Reprezintă managerul general al Departamentului. Este responsabil pentru supravegherea dezvoltării și operării generale, gestionarea bugetului și stabilirea politicilor strategice. Reprezintă Departamentul în relațiile publice și inter-agenții. Deține autoritatea finală în toate deciziile administrative și operaționale majore.

 **3.03 Deputy Chief / Battalion Chief**
- **Nivel Autoritate:** Comandă Senior / Bureau Commander
- **Tip Poziție:** Administrative, Fire-sworn

 Acționează ca **Senior Command**. Acești ofițeri pot servi ca **Bureau Commander** pentru **Administrative & Support Bureau** sau **Special Operations Bureau**.
 **Responsabilități:** Supraveghează toate **Divisions** din cadrul Bureau-ului lor, evaluează performanța pentru **Captains** și **Lieutenants**, dezvoltă **SOPs** (Standard Operating Procedures) și preiau comanda la **Major Incidents**. În absența **Fire Chief**, **Deputy Chief** preia comanda completă a departamentului.

 **3.05 Captain**
- **Nivel Autoritate:** Company Officer / Incident Commander
- **Tip Poziție:** Fire-sworn

 Este ofițerul responsabil de o stație sau companie (**Station Captain**). Poate servi ca **Bureau Commander** pentru un birou mic sau ca **Division Lead** într-o divizie specializată.

 **Responsabilități:** Acționează ca **Incident Commander (IC)** la scenele de urgență, supervizează schimbul (shift), gestionează personalul și programările, coordonează training-ul echipei și acționează ca **Safety Officer**. Este primul nivel de management care poate conduce operațiuni complexe multi-echipaj.

 **3.06 Lieutenant**
- **Nivel Autoritate:** Junior Company Officer
- **Tip Poziție:** Fire-sworn

 Primul rank de ofițer, responsabil de interacțiunea directă cu personalul în teren.

 **Responsabilități:** Acționează ca **Assistant Incident Commander**, conduce echipe mici sau **Apparatus**, facilitează training-ul zilnic și asigură mentoratul pentru personal. Preia comanda în absența **Captain**-ului. Poate servi ca **Division Lead** într-o divizie specializată dacă deține calificările necesare.

 **3.07 Engineer**
- **Nivel Autoritate:** Specialist Tehnic
- **Tip Poziție:** Fire-sworn

 Specialistul tehnic responsabil cu operarea vehiculelor și echipamentelor grele. Acest rank se obține după **Firefighter** și reprezintă calea de specializare tehnică (alternativa fiind **Paramedic**).

 **Responsabilități:** Conduce și operează toate tipurile de **Apparatus** (Engine, Truck, Squad), gestionează **Water Supply** și **Pump Operations**, operează dispozitivele aeriene (scări, platforme). Este responsabil de inspecția și mentenanța echipamentului. Reprezintă rank-ul minim pentru a deveni **Division Lead** în divizii tehnice sau operaționale.
 Cerinte pentru avansare: Minim 6 luni ca Firefighter, finalizarea Supervisor Training Program (STP), obținerea calificărilor Interior Operations, Rope Rescue, Pump Operations, Fire 3, toate specializările tactice din Primary Operations (cu excepția Incident Safety Officer și Operations Coordinator), și certificarea Incident Command System (ICS).

 **3.08 Paramedic**
- **Nivel Autoritate:** Advanced Life Support Provider (ALS)
- **Tip Poziție:** Fire-sworn, Medical Specialist

 Specialistul în îngrijire medicală avansată. Acest rank se obține după **Firefighter** și reprezintă calea de specializare medicală (alternativa fiind **Engineer**). Ambele rankuri (**Engineer** și **Paramedic**) sunt echivalente ierarhic.

 **Responsabilități:** Lider medical la scenele de urgență, administrează medicamente (IV/IO), efectuează management avansat al căilor respiratorii (intubație), monitorizare cardiacă și interpretare EKG. Supervizează activitatea membrilor cu certificare **BLS** la scenă. Poate servi ca **Division Lead** pentru divizii medicale sau operaționale.

 Cerinte pentru avansare: Minim 6 luni ca Firefighter, obținerea Emergency Medical Technician (EMT), Field Medic, și Advanced Life Support (ALS) - Critical Care Provider.
- **Nivel Autoritate:** Personal de Teren
- **Tip Poziție:** Fire-sworn

 Coloana vertebrală a departamentului, executând operațiunile tactice.
 Responsabilități: Execută Fire Suppression, Search and Rescue, Ventilation și oferă suport medical. Participă la menținerea stației și la antrenamente continue. Un Firefighter poate deveni Division Lead într-o Secondary Division dacă acumulează toate calificările acelei divizii.

 **3.10 Probationary Firefighter**
- **Nivel Autoritate:** Recruit / Trainee
- **Tip Poziție:** Academic

 Poziția de intrare în departament.

 **Responsabilități:** Completarea **Recruit Training Academy**, învățarea procedurilor de bază, asistarea personalului experimentat ("shadowing") și participarea la **Field Training Program** sub supervizarea unui **Field Training Officer (FTO)**.

 **Restricții:** Nu pot răspunde la apeluri singuri, trebuie să fie sub supravegherea permanentă a unui **FTO** și au roluri limitate la scenă (support tasks, observare). Nu pot opera **Apparatus** în răspuns la urgențe și nu pot acționa ca echipaj principal.

 **4. SISTEMUL DE DIVISION ȘI AVANSARE**

 **4.01 Scop**
 Acest capitol explică structura organizațională bazată pe **Divisions** și modul în care angajații pot avansa profesional prin specializare.

 **4.02 Cum Funcționează Sistemul**
 Fiecare membru al departamentului are:
1. **Operational Rank:** Poziția ierarhică generală (de la **Fire Chief** la **Probationary Firefighter**).
2. **Bureau Assignment:** Toți membrii fac parte din **Primary Operations Bureau**. Birourile suplimentare (**Special Operations**, **Administrative & Support**) sunt conduse de management.
3. **Secondary Division:** Maxim două specializări opționale (ex: **Hazmat**, **Wildland**, **Training**).
4. **Qualifications:** Certificările care determină nivelul de expertiză (TIER) într-o divizie.

 **Structura de comandă:**
- **Bureau Commander:** Conduce un birou întreg. Rank minim: **Captain**. De obicei: **Battalion Chief** sau **Deputy Chief**.
- **Division Lead:** Conduce o divizie specializată. Rank minim: **Engineer** sau **Paramedic**. Poate fi de la **Lieutenant** în sus.

 **Numirea Division Leads:**
 **Division Lead** este numit de către **Bureau Commander** pe baza următoarelor criterii:
1. **Qualifications:** Numărul și nivelul calificărilor obținute în divizia respectivă.
2. **Experience:** Timpul petrecut în divizie și performanța demonstrată.
3. **Leadership Ability:** Capacitatea de a coordona echipe, dezvolta proceduri și instrui alți membri.
4. **Rank:** În caz de egalitate, rank-ul operațional mai înalt are prioritate.

 **Important:** **Division Lead** trebuie să dețină majoritatea calificărilor din divizia respectivă și să fie la minim **TIER 3**. Experții tehnici pot conduce divizii chiar dacă au rank operațional mai mic decât alți membri ai diviziei, demonstrând că expertiza tehnică este valorizată la fel de mult ca și rank-ul.

 **4.03 Primary Operations Bureau**
 **Primary Operations Bureau** este fundația activității departamentului. **Toți membrii Fire-sworn fac parte din acest birou**. Biroul este condus de un **Bureau Commander** și include două componente operaționale principale:

 **Fire Operations:** Operațiuni de stingere a incendiilor, salvare tehnică, ventilație și răspuns la urgențe non-medicale. Toți membrii sunt instruiți în aceste operațiuni.

 **Emergency Medical Services (EMS):** Răspuns medical pre-spitalicesc. Toți membrii dețin certificare **Basic Life Support (BLS)**. Membrii care doresc să se specializeze în EMS obțin certificarea **Advanced Life Support (ALS)** și pot avansa la rank-ul de **Paramedic**.

 **Calificările de bază necesare:** **Fire Suppression**, **Interior Operations**, **Basic Life Support (BLS)**, **Vehicle Extrication**.

 **Notă:** Aceste două componente nu au **Division Leads** separați, deoarece toți membrii operaționali fac parte din ele. Coordonarea este asigurată de **Bureau Commander** și de ofițerii de stație (**Captains**, **Lieutenants**).

 **4.04 Secondary Divisions**
 Membrii pot alege să se specializeze în maximum 2 **Secondary Divisions**. Acestea sunt organizate sub cele două birouri suplimentare:

 **Sub Special Operations Bureau:**
- **Division 2:** HSOD - Hazmat, Special Operations & Disaster Response
- **Division 3:** Wildland & Environmental Operations
- **Division 4:** Water Rescue Operations

 **Sub Administrative & Support Bureau:**
- **Division 5:** Fire Investigation & Prevention
- **Division 6:** Training & Professional Development
- **Division 7:** Fleet, Logistics & Communications
- **Division 8:** Administration & Human Resources
- **Division 9:** Union & Labor Relations

 Fiecare divizie are un **Division Lead** (rank minim **Engineer**/**Paramedic**) care coordonează activitatea, instruirea și echipamentul specific.

 **4.05 Sistemul TIER (1-4)**
 Avansarea într-o **Secondary Division** se face prin obținerea de calificări (**Qualifications**). Sistemul TIER reflect nivelul de expertiză și responsabilitate în cadrul unei divizii specializate:

- **TIER 1: Entry Level** (1-2 calificări)  - Membru nou în divizie - Învață bazele și procedurile specifice - Roluri de suport și asistență - Necesită supraveghere din partea membrilor mai experimentati - Participă la training-uri pentru obținerea calificărilor suplimentare
- **TIER 2: Technician/Specialist** (3-4 calificări)  - Operator competent și independent - Poate executa misiuni specifice diviziei fără supraveghere directă - Poate instrui și mentora membrii TIER 1 - Participă activ la operațiuni specializate - Contribuie la dezvoltarea procedurilor
- **TIER 3: Advanced Specialist** (5+ calificări)  - Expert în domeniul diviziei - Capabilități multi-rol și leadership tehnic - Dezvoltă proceduri operaționale și instruiește membri de toate nivelurile - Poate acționa ca **Incident Commander** pentru incidente specifice diviziei - Eligibil pentru poziția de **Division Lead** - Consiliază conducerea în legătură cu achiziții de echipament și training
- **TIER 4: Division Lead** (Majoritatea calificărilor + numire oficială)  - Liderul oficial al diviziei, desemnat de **Bureau Commander** - Coordonează întreaga activitate a diviziei - Răspunde direct la **Bureau Commander** - Are autoritate tehnică supremă în domeniul diviziei - Gestionează bugetul, echipamentul și training-ul diviziei - Evaluează și aprobă avansarea membrilor în TIER-uri - Rank minim necesar: **Engineer** sau **Paramedic**

 **Notă Importantă:** TIER-ul reflect expertiza tehnică în divizie, nu rank-ul operațional. Un **Engineer** cu TIER 4 în **Hazmat** poate fi **Division Lead** și are autoritate tehnică în acel domeniu peste un **Captain** care este doar TIER 2 în aceiași divizie.

 **4.06 Avansarea prin Colectarea Calificărilor**
 Procesul de progresie într-o divizie secundară este liniar și bazat pe merit:
1. Intrare în divizie la **TIER 1**.
2. Participarea la **Training Programs** și obținerea certificărilor specifice.
3. Trecerea automată la un **TIER** superior pe măsură ce se acumulează calificări.
4. Atingerea **TIER 4** și a statutului de **Division Lead** la completarea setului integral de calificări.

 Nu se pot sări etapele; fiecare calificare necesită instruire și testare. Unele calificări necesită **Recertification** periodică pentru a menține statusul activ.

 **5. CALIFICĂRI ȘI CERTIFICĂRI**

 **5.01 Scop**
 Acest capitol listează toate **Qualifications** și certificările disponibile în cadrul Departamentului. Calificările sunt esențiale pentru avansarea în carieră și pentru a deveni **Division Lead** în cadrul unei **Secondary Division**, conform regulii "cel cu cele mai multe calificări conduce".

 **5.02 Core Operations (Primary Division)**
 Acestea sunt calificările de bază pe care toți membrii **Fire-sworn** trebuie să le dețină pentru a opera în teren.
- **Fire Suppression:** Tactici și tehnici de bază pentru stingerea incendiilor.
- **Interior Operations:** Operațiuni desfășurate în interiorul structurilor incendiate (necesită **SCBA**).
- **Pump Operations:** Operarea sistemului de pompare și managementul **Water Supply**. Necesar pentru **Engineer**.
- **Apparatus Driver:** Conducerea vehiculelor departamentale (**Apparatus**). Necesar pentru **Engineer**.
- **Vehicle Extrication:** Extragerea victimelor din vehicule folosind unelte hidraulice (**Jaws of Life**).
- **Rope Rescue:** Salvarea folosind sisteme de frânghii (unghi înalt, spații închise).

 **5.03 Emergency Medical**
 Calificările medicale sunt esențiale pentru furnizarea îngrijirii pre-spitalicești.
- **Basic Life Support (BLS):** CPR, AED, prim ajutor de bază. Obligatoriu pentru toți.
- **Emergency Medical Technician (EMT):** Îngrijire medicală intermediară.
- **Field Medic:** Îngrijire medicală în condiții austere, combinând operațiunile de foc cu cele medicale.
- **Critical Care Provider (Paramedic):** Suport vital avansat (**ALS**), administrare medicamente, management avansat al căilor respiratorii.

 **5.04 Hazmat**
 Calificări specifice pentru **Division 2: HSOD**.
- **Hazmat Operations:** Nivel de intrare - recunoaștere, izolare, notificare.
- **Hazmat Technician:** Specialist care intră în **Hot Zone** pentru mitigare și controlul scurgerilor.

 **5.05 Wildland Operations**
 Calificări specifice pentru **Division 3: Wildland & Environmental**.
- **Wildland Firefighter - Type 2:** Nivel de intrare pentru incendii de vegetație.
- **Wildland Firefighter - Type 1:** Nivel avansat, leadership de echipă.
- **Wildland Engine Operator:** Operarea autospecialelor off-road (**Brush Trucks**).
- **Wildland Helitack:** Operațiuni cu elicopterul, inserție aeriană.
- **Wildland Incident Commander:** Comandă tactică pentru incendii de vegetație majore.

 **5.06 Water Rescue**
 Calificări specifice pentru **Division 4: Water Rescue**.
- **Water Rescue Awareness:** Conștientizare și salvare de pe mal.
- **Swift Water Rescue Technician:** Salvare din ape curgătoare rapide.
- **Marine Operations Specialist:** Operarea ambarcațiunilor (**Fire Boats**).
- **Dive Rescue Technician:** Căutare și salvare subacvatică (**SCUBA**).
- **Ice Rescue Technician:** Salvare de pe gheață și din apă rece.
- **Flood Response Operator:** Răspuns la inundații și evacuare.

 **5.07 Technical Specializations**
- **Technical Rescue Specialist:** Salvare complexă (spații înguste, prăbușiri structurale, tranșee).
- **Apparatus Engineer:** Operare avansată a dispozitivelor aeriene (scări, platforme) și mentenanță grea.

 **5.08 Investigation & Prevention**
 Calificări specifice pentru **Division 5**.
- **Fire Investigator:** Investigarea cauzelor incendiilor (Origin & Cause).
- **Fire Inspector:** Inspecții de siguranță și aplicarea codului (**Code Enforcement**).

 **5.09 Training & Leadership**
 Calificări specifice pentru **Division 6**.
- **Field Training Officer (FTO):** Instruirea și evaluarea **Probationary Firefighters**.
- **Fire Instructor:** Instructor general pentru departament.
- **Academy Instructor:** Instructor dedicat pentru **Recruit Academy**.
- **Curriculum Developer:** Dezvoltarea programelor de instruire.

 **5.10 Administration**
 Calificări specifice pentru **Division 7, 8**.
- **Human Resources Officer:** Recrutare, dosare personal, evaluări.
- **Internal Affairs Officer:** Investigații interne disciplinare.
- **Fleet Operations Manager:** Managementul mentenanței flotei.
- **Supply & Logistics Officer:** Gestiunea stocurilor și achiziții.

 **5.11 Cum se Obțin Calificările**
 Procesul de obținere a oricărei calificări este coordonat de **Division 6: Training & Professional Development**, conform pașilor de mai jos:

1. Membrul contactează **Division 6: Training & Professional Development** și exprimă interesul pentru o calificare specifică.
2. **Division 6** revizuiește eligibilitatea membrului (rank, calificări existente, timp în serviciu) și îl contactează cu detaliile complete: cerințe, program de instruire și metoda de evaluare.
3. Membrul parcurge procesul de instruire și evaluare stabilit de **Division 6**.
4. La finalizare, calificarea este înregistrată oficial de **Certification Officer** din **Division 6** și adăugată în dosarul de personal.

 **Notă:** Unele calificări au cerințe prealabile (prerequisite). Verificați lista completă din secțiunile 5.02-5.10 și din **CALIFICARI Registry** înainte de a contacta **Division 6**.

 **6. REGULAMENTE UNIFORME ȘI ASPECT**

 **6.01 Scop**
 Acest capitol stabilește standardele vizuale stricte pentru angajații Departamentului. Aspectul profesional este obligatoriu pentru menținerea încrederii publice.

 **6.02 Class A Uniform**
 Cunoscută ca **Dress Uniform**.
- **Utilizare:** Ceremonii, evenimente oficiale, înmormântări.
- **Componente:** **Dress Hat** (tip Pilot), cămașă cu mânecă lungă (Navy Blue sau White pentru Chief Officers), cravată, **Dress Pants**, **Badge** metalic.

 **6.03 Class B Uniform**
 Cunoscută ca **Duty Uniform**.
- **Utilizare:** Activități zilnice în stație, inspecții, răspuns la apeluri non-critice.
- **Componente:** Cămașă sau tricou polo (Navy Blue), pantaloni tactici sau casual (Navy Blue), ghete negre, **Badge** (poate fi brodat sau metalic).

 **6.04 Class C Uniform**
 Cunoscută ca **PT Uniform** (Physical Training).
- **Utilizare:** Antrenamente fizice, activități în jurul stației.
- **Componente:** Tricou și pantaloni scurți Navy Blue cu inscripția departamentului, pantofi sport.

 **6.05 Class D Uniform (Turnout Gear)**
 Echipamentul complet de protecție personală (**PPE**).
- **Utilizare:** Stingerea incendiilor, operațiuni de salvare, medii periculoase.
- **Componente:**  - **Helmet:** Galben (pentru **Firefighter**), Roșu/Portocaliu (pentru **Captain**), Alb (pentru **Chief Officers**). - **Turnout Coat & Bunker Pants:** Material rezistent la foc cu benzi reflectorizante. - **Protective Hood & Gloves.** - **SCBA:** Aparat de respirat autonom. - **PASS Device:** Dispozitiv de alertă pentru imobilitate.

 **6.06 Utilizarea Uniformei**
 Angajații trebuie să poarte uniforma completă pe durata **Shift**-ului. Este interzisă combinarea elementelor civile cu cele de uniformă. Uniformele trebuie menținute curate și călcate.

 **6.07 Mutilarea Corpului**
 Modificările corporale extreme sunt interzise. Aceasta include, dar nu se limitează la: bifurcarea limbii, implanturi subdermice vizibile, întinderea exagerată a lobilor urechii.

 **6.08 Păr**
 Părul trebuie să fie îngrijit și să nu atingă gulerul cămășii (pentru bărbați).
- **Interzis:** Coafuri excentrice (Mohawk, culori nenaturale).
- **Facial Hair:** Barba este strict interzisă deoarece interferează cu etanșeitatea măștii **SCBA**. Mustățile sunt permise dacă sunt îngrijite și nu depășesc colțurile gurii.

 **6.09 Bijuterii**
 Sunt permise doar un ceas de mână și un inel (verighetă), atâta timp cât nu prezintă risc de siguranță (agățare). Colierele trebuie purtate sub tricou.

 **6.10 Piercing-uri**
 Piercing-urile vizibile (față, urechi, nas) sunt interzise în timp ce angajatul este **On Duty**.

 **6.11 Tatuaje**
 Tatuajele vizibile pe față, gât sau mâini sunt interzise. Tatuajele pe brațe trebuie acoperite de uniformă (mânecă lungă) dacă sunt considerate ofensatoare sau neprofesionale.

 **6.12 Articole de Îmbrăcăminte **((****))****
 Utilizarea accesoriilor din script (toys) este reglementată:
- **Permis:** Black Law Glasses, Yellow Fire Hat, Flashlight, Medical Kit, Gas Mask (rolată ca **SCBA**).
- **Interzis:** Orice cască sau pălărie de tip Police/SWAT, ochelari colorați strident, bandane, măști care nu sunt de uz medical/pompier.

 **7. CONDUITĂ**

 **7.01 Scop**
 Acest capitol definește comportamentul așteptat atât în timpul serviciului, cât și în afara acestuia.

 **7.02 Conduită Generală**
 Angajații trebuie să se comporte ca cetățeni model. Orice acțiune care aduce prejudicii imaginii Departamentului va fi sancționată. Aceasta include comportamentul în trafic și interacțiunile publice.

 **7.03 Reguli și Regulamente**
 Necunoașterea regulilor din **MOP** nu este o scuză validă. Angajații sunt obligați să verifice periodic avizierele și actualizările de procedură.

 **7.04 Limbaj și Comunicare Verbală**
 Se impune un limbaj profesional, fără vulgarități sau argou, atât pe stația radio, cât și în interacțiunea cu publicul. Pe radio se folosește "Plain English" și **Clear Text**, fără coduri 10 (cu excepția cazurilor extrem de specifice).

 **7.05 Respect pentru Colegi și Contacte Profesionale**
 Criticarea publică a unui coleg sau a unei alte agenții (PD, EMS privat) este interzisă. Disputele se rezolvă prin **Chain of Command**, nu în public.

 **7.06 Angajare În Afara Serviciului**
 Angajații pot avea un al doilea job (Off-Duty Employment) doar cu aprobarea scrisă prin **Personnel Request Center**. Joburile care prezintă conflict de interese sau risc ridicat de imagine nu vor fi aprobate.

 **7.07 Absență**
 Absențele neplanificate (boală, urgențe) trebuie raportate imediat către **Station Captain** sau **Battalion Chief**. Absența nemotivată la un **Shift** programat poate duce la acțiuni disciplinare.

 **7.08 Corupție **((****))****
- **Minor Corruption:** Permisă în limitele roleplay-ului realist (ex: mici abateri de trafic, "heat of the moment"), fără aprobare prealabilă.
- **Major Corruption:** (Ex: colaborarea cu grupuri criminale, furt de echipament, luare de mită substanțială) necesită **Aprobare Explicită** din partea Leadership-ului facțiunii.

 **7.09 Permisiune Double Faction **((****))****
 Membrii pot face parte din două facțiuni oficiale simultan doar dacă:
1. Au minim rank-ul de **Firefighter**.
2. Mențin o activitate constantă (0.8 UCP activity).
3. Obțin aprobare prin **Personnel Request Center**.

 **7.10 Reguli Faction **((****))****
 Respectarea regulamentului serverului este obligatorie. **Metagaming**, **Powergaming** sau comportamentul toxic atrag excluderea imediată din facțiune.

 **7.11 Absență Out-of-Character **((****))****
 Orice inactivitate mai mare de 5 zile necesită un **Absence Report** pe forum.
 Lipsa raportului duce la un avertisment după 5 zile și demitere (termination) după 10 zile de inactivitate neanunțată.

 **7.12 Schimbare Nume Character **((****))****
 Schimbarea numelui (Namechange) necesită aprobarea Leadership-ului pentru a asigura continuitatea dosarului de personal sau pentru a gestiona corect un **Character Kill (CK)**.

 **8. BENEFICII DE ANGAJARE**

 **8.01 Scop**
 Prezentarea pachetului de beneficii oferit angajaților Departamentului.

 **8.02 Beneficii de Bază**
 Include salariul competitiv (paycheck), echipamentul complet asigurat, training gratuit și acces la facilitățile stației (dormitoare, sală de forță, bucătărie).

 **8.03 Planuri de Acoperire**
- **Health Coverage:** Asigurare medicală completă pentru angajat și familia imediată.
- **Dental & Vision:** Inclusă în pachetul standard.
- **Life Insurance:** Asigurare de viață substanțială, cu clauze speciale pentru decesul la datorie (**Line of Duty Death**).
- **Pension Plan:** Disponibil după o perioadă minimă de serviciu (Vesting).

 **8.04 Concediu Medical**
- **Sick Leave:** Pentru angajații **Fire-sworn**, concediul medical este nelimitat în caz de accidentare la locul de muncă sau boală justificată.
- Absențele mai lungi de 4 ture consecutive necesită certificat medical de la un medic autorizat.

 **8.05 Concediu de Vacanță**
 **Vacation Leave** se acumulează în funcție de vechime:
- 0-5 ani vechime: 96 ore/an.
- 5-10 ani vechime: 144 ore/an.
- 10-15 ani vechime: 192 ore/an.
- 15+ ani vechime: 240 ore/an.

 Solicitările de concediu trebuie făcute prin **Personnel Request Center** și aprobate de **Battalion Chief**.

 **9. POLITICI ADMINISTRATIVE**

 **9.01 Scop**
 Acest capitol stabilește fundamentele politicilor administrative principale pentru angajații Departamentului, acoperind certificări, promovări și proceduri disciplinare.

 **9.02 Certificări**
 Toți angajații **Fire-sworn** trebuie să obțină și să mențină certificarea de bază **Fire** și **Emergency Medical Technician** de la **Training and Support Bureau**.
 **Certificări Obligatorii:**
- **Fire Suppression**
- **Interior Operations**
- **Basic Life Support (BLS)**
- **Emergency Medical Technician (EMT)** - Recomandat pentru toți, obligatoriu pentru **Paramedics**.

 Certificările au date de expirare și necesită **Recertification**. Este responsabilitatea angajatului să mențină certificările curente prin **Continuing Education**.

 **9.03 Sistemul de Promovări**
 Departamentul angajează un sistem proactiv care constă din două tipuri principale: **Class Upgrade** și **Rank Promotion**.

 9.03.01 Cerințe de Progresie
 Avansarea necesită îndeplinirea unor perioade minime de timp (Time Served) și obținerea calificărilor specifice:
- **Probationary Firefighter -> Firefighter:** Completarea Field Training Program (FTP). Necesită Basic Life Support (BLS), Fire Suppression (Fire 1), Fire 2, Apparatus Driver, Vehicle Extrication, Rope Rescue.
- **Firefighter -> Engineer:** Minim 6 luni ca Firefighter, finalizarea Supervisor Training Program (STP). Necesită Interior Operations, Pump Operations, Fire 3, toate Specializările Tactice (cu excepția Incident Safety Officer și Operations Coordinator), și Incident Command System (ICS).
- **Firefighter -> Paramedic:** Minim 6 luni ca Firefighter. Necesită Emergency Medical Technician (EMT), Field Medic, și Advanced Life Support (ALS) - Critical Care Provider.
- **Engineer / Paramedic -> Lieutenant:** Minim 3 ani IC / 2 luni OOC, trecerea Promotional Exam. Necesită Field Training Officer (FTO), Operations Coordinator și Incident Safety Officer, plus specializările Engineer și Paramedic.
- **Lieutenant -> Captain:** Finalizarea Officer Training Program (OTP).

 **9.03.02 Promovări Officer**
 Promovările la nivel de **Officer** (Lieutenant, Captain, Battalion Chief) au loc pe bază de **Vacancy**. Procesul include:
1. **Notification of Registered Interest (NRI)** depusă la **Human Resources Division**.
2. **Administrative Review** pentru eligibilitate.
3. **Promotional Exam** (scris și practic).
4. **Interview Board** cu **Chief Fire Officers**.

 **9.03.03 Cerințe de Activitate **((****))****
 Membrii facțiunii trebuie să mențină o activitate **UCP** minimă de **0.8**.
- Activitatea sub 0.6 atrage un **Warning**.
- Activitatea sub 0.4 persistentă duce la **Termination**.

 **9.04 Proceduri Disciplinare**
 Departamentul folosește un sistem progresiv de disciplină administrativă gestionat de **Professional Standards Division**:
1. **Admonishment:** Pentru abateri minore (misconduct) sau încălcări indirecte de policy. Nu afectează direct dosarul.
2. **Reprimand:** Pentru încălcări directe de policy. Poate afecta evaluările viitoare.
3. **Suspension:** Pentru încălcări majore. Interzice orice activitate on-duty. Poate fi **Paid** sau **Unpaid**.
4. **Termination of Employment:** Pentru încălcări severe și inacceptabile. Angajatul pierde statutul **Fire-sworn**.

 **9.05 Apeluri Disciplinare și Board of Rights**
 Angajații pot contesta o acțiune disciplinară (cu excepția **Termination**) prin depunerea unui **Appeal** în termen de 2 săptămâni.
 Cazul este revizuit de **Board of Rights**, compus din:
- Un **Chief Fire Officer**
- Un **Captain**
- Un **Union Representative**

 Deciziile pot fi: **Sustained** (menținută), **Modified** (ajustată), **Overturned** (anulată) sau **Remanded** (retrimisă la investigații).

 **9.06 Relații sau Bias Rezonabil**
 Pentru a asigura un loc de muncă echitabil, angajații trebuie să notifice **Professional Standards Division** în termen de 5 zile dacă intră într-o relație activă (romantică, familială sau financiară) cu un alt angajat, pentru a evita **Conflict of Interest**.

 **9.07 Asignare Division și Unit**
 Angajații pot solicita transferul sau asignarea într-o **Secondary Division** prin depunerea unei **Notification of Registered Interest (NRI)**. Procesul include un **Administrative Review for Assignment Suitability (ARAS)** realizat de **Human Resources** și **Division Lead**-ul respectiv.

 **9.08 Premii și Calificări**
 **9.08.01 Commendations**
 Decorații pentru performanță excepțională, incluzând: **Medal of Valor**, **Medal of Bravery**, **Life-Saving Commendation**, **Purple Heart**.

 **9.08.02 Qualifications**
 Ribbons purtate pe uniformă care indică expertiza tehnică: **Fire 1/2/3**, **EMT-P**, **Hazmat Technician**, **Advanced Rescue Qualification**.

 **9.09 Personnel Request Center**
 Sistemul prin care angajații depun cereri oficiale pentru: **Discord assignment**, **Division assignment**, **Vacation Leave**, **Secondary Employment** sau **Name Change**. Toate cererile sunt procesate de **Chief Fire Officers** sau **Administrative Staff**.

 **9.10 Service Stripes**
 Angajații eligibili poartă **Service Stripes** pe mâneca uniformei **Class A**. Fiecare dungă reprezintă 5 ani de serviciu (3 luni OOC). Culorile diferă: **Blue** (Firefighter-Engineer), **Red** (Officers), **Gold** (Chiefs).

 **9.11 Field Training Program**
 Programul obligatoriu pentru **Probationary Firefighters**.
- **Phase 1: Introduction:** Observare și învățare sub ghidarea unui **Field Training Officer (FTO)**. Minim 1 săptămână.
- **Phase 2: Evaluation:** Demonstrarea competenței și inițiativei. Minim 2 săptămâni.

 Recruții trebuie să mențină un **FTP Journal** și nu pot patrula singuri.

 **9.11.01 Rating Scale**
 Folosită în **Daily Observation Reports (DOR)**:
1. **Does Not Meet Expectations:** Necesită îmbunătățiri semnificative.
2. **Meets Expectations:** Performanță adecvată.
3. **Exceeds Expectations:** Auto-motivat, peste cerințe.
4. **Outstanding:** Performanță excepțională, rar acordată.

 **9.12 Absence Reports **((****))****
 Orice inactivitate mai mare de 5 zile necesită un raport pe forum. Lipsa raportului duce la **Warning** după 5 zile și **Termination** după 10 zile.

 **9.13 Administrative Punishments **((****))****
 Dacă un membru primește **Admin Jail**, **Ban** sau **Warning** de la staff-ul serverului, trebuie să notifice **Leadership**-ul facțiunii prin PM în termen de 48 de ore.

 **9.14 Resignation **((****))****
 Membrii trebuie să folosească sistemul oficial de demisie. Demisiile frecvente și reangajările ("faction hopping") sunt interzise. Membrii care demisionează onorabil (rank minim **Firefighter**) pot primi statutul de **Retired Employee**.

 **9.15 Suggestions **((****))****
 Membrii sunt încurajați să propună schimbări care îmbunătățesc facțiunea (politici noi, echipamente, proceduri) prin secțiunea dedicată de sugestii.

 **10. PRIMARY OPERATIONS BUREAU - OPERAȚIUNI DE BAZĂ**

 **10.01 Descriere și Scop**
 **Primary Operations Bureau** este biroul fundamental din care fac parte **TOȚI** membrii departamentului. Nu se organizează în divizii cu leadership separat, ci este condus direct de **Bureau Commander** și de ofițerii de stație. Scopul său este furnizarea serviciilor esențiale: **Fire Suppression**, **Emergency Medical Response** și **Rescue Operations**.

 Biroul include două componente operaționale principale:
- **Fire Operations:** Stingerea incendiilor, salvare tehnică, ventilație
- **Emergency Medical Services:** Răspuns medical pre-spitalicesc (BLS/ALS)

 Toți membrii sunt instruiți în ambele componente, cu specializare opțională în EMS prin obținerea certificării ALS și a rank-ului de **Paramedic**.

 **10.02 Structură Operațională**
 Structura ierarhică la scenă urmează sistemul **ICS (Incident Command System)**:
- **Incident Commander (IC):** De obicei un **Captain** sau **Battalion Chief**.
- **Company Officer:** **Lieutenant** sau **Captain** care conduce un echipaj.
- **Apparatus Assignments:**  - **Engine Company:** Water supply și fire attack. - **Truck Company:** Ventilation, forcible entry, aerial ops. - **Squad Company:** Technical rescue și manpower. - **Rescue Ambulance:** Medical transport (ALS/BLS).

 **10.03 Poziții și Calificări**

 **Fire Attack Specialist**
 Execută operațiunile directe de stingere. Avansează **Hose Lines** în interiorul structurilor, efectuează **Aggressive Knockdown** și **Primary Search** în medii cu fum dens. Necesită **Fire Suppression** și **Interior Operations**.

 **Engine Operator**
 Conduce **Fire Engine**, stabilește **Water Supply** (de la hidrant sau draft) și operează pompa (**Pump Operations**) pentru a asigura presiunea corectă pe furtunuri.

 **Ventilation Specialist**
 Efectuează **Vertical Ventilation** (pe acoperiș) sau **Positive Pressure Ventilation (PPV)**. Coordonează eliberarea fumului și căldurii pentru a crește vizibilitatea echipei de atac.

 **Heavy Rescue Technician**
 Specializat în **Vehicle Extrication** folosind unelte hidraulice (**Jaws of Life**). Gestionează situații de **Technical Rescue** și **Structural Collapse**.

 **Rope Rescue Operator**
 Execută salvări la înălțime (**High-Angle Rescue**) sau în spații înguste (**Confined Space Rescue**) folosind sisteme complexe de frânghii și scripeți.

 **Crash Response Specialist**
 Se concentrează pe stabilizarea vehiculelor (**Cribbing/Struts**), gestionarea sticlei și crearea punctelor de acces la pacient în accidente rutiere.

 **Critical Care Provider (Paramedic)**
 Liderul medical la scenă (**ALS Provider**). Administrează medicamente (IV/IO), efectuează **Intubation**, monitorizare cardiacă și transport medical critic.

 **Field Medic**
 Oferă îngrijire medicală în condiții austere sau în timpul operațiunilor prelungite (**Rehab**). Monitorizează semnele vitale ale pompierilor la incendii majore.

 **Emergency Medical Technician (EMT)**
 Oferă **Basic Life Support (BLS)**, evaluare pacient, **Spinal Immobilization** și operarea ambulanței. Asistă paramedicii în proceduri avansate.

 **Apparatus Engineer**
 Expert în operarea tuturor vehiculelor grele, inclusiv dispozitive aeriene (**Aerial Ladders**). Responsabil de **Troubleshooting** și mentenanța echipamentului la scenă.

 **Incident Safety Officer**
 Monitorizează scena pentru pericole (**Hazards**), menține **Accountability** pentru personal și are autoritatea de a opri operațiunile nesigure (**Emergency Stop**).

 **Operations Coordinator**
 Gestionează alocarea resurselor (**Resource Allocation**) și comunicațiile radio la incidente majore, asistând **Incident Commander**-ul cu planificarea tactică.

 **10.04 Incident Commander — Desemnare și Autoritate**

 Fiecare intervenție activă are un singur **Incident Commander (IC)** desemnat la un moment dat. IC deține autoritatea operațională completă asupra scenei și a tuturor echipajelor prezente, indiferent de aparatul sau divizia din care provin.

 **10.04.01 Desemnarea IC**

1. **Regula generală:** IC este, implicit, cel mai mare rank prezent la scenă. Primul echipaj sosit preia IC până la sosirea unui officer superior.
2. **Excepție — Incidente specializate:** Dacă scena impune calificări specifice (ex: Hazmat, Water Rescue, USAR, Structural Collapse), IC este cel mai mare rank prezent care deține calificările necesare acelui tip de incident. Un **Captain** fără calificarea **Hazmat Operations** nu poate fi IC la o scenă Hazmat; în schimb, un **Engineer** cu **TIER III** în **Division 2: HSOD - Hazmat, Special Operations & Disaster Response** preia IC pentru acel incident specific.
3. **Predarea IC (Transfer of Command):** Când sosește un officer cu rank superior și cu calificările necesare, IC se transferă. Transferul se anunță explicit pe canal principal înainte de efectuare: *"Transfer of Command towards [Rank] [Prenume] [Nume], [Rank] [Prenume] [Nume] has Command."* Noul IC confirmă preluarea pe același canal.

 **10.04.02 Autoritatea și Prioritatea IC pe Canal**

- **Prioritate absolută:** IC are prioritate absolută pe canalul principal de Dispatch (**Stația 712**). Nicio altă transmisie nu întrerupe IC, cu excepția unui **Code 0** sau a unui **Mayday**.
- **Sectorizarea comunicațiilor:** IC poate redirecta echipaje sau grupuri pe canalele tactice dedicate incidentelor: **Stația 713 (IC1 / TAC1)** sau **Stația 714 (IC2 / TAC2)**. Această decizie se ia când incidentul crește în complexitate și traficul radio pe 712 devine supraîncărcat.
- **Subordonare:** Toate transmisiile de pe canalele 713 și 714 sunt subordonate IC principal de pe 712. Ofițerii care coordonează un sector pe TAC1 sau TAC2 raportează periodic situația către IC principal.
- **Revenirea pe 712:** La încheierea incidentului sau la ordinul IC, echipajele revin pe canalul principal 712 și raportează *"Clear from scene, back in service."*

 **10.04.03 Responsabilitățile IC la Scenă**

- Preia comanda și anunță scenei pe 712: *"[Rank] [Prenume] [Nume] has Command at [Locație]."*
- Evaluează scena, stabilește strategia (ofensivă sau defensivă) și comunică obiectivele tactice.
- Alocă resursele și sectorizează incidentul dacă este necesar.
- Menține **Accountability** (evidența personalului în zonele active).
- Solicită resurse suplimentare prin Dispatch (**Stația 712**) dacă situația o impune.
- Declară **Code 4** când scena este securizată și raportează situația finală.

 **11. DIVISION 2: HAZMAT, SPECIAL OPERATIONS & DISASTER RESPONSE**

 **11.01 Descriere și Scop**
 **Division 2 (HSOD)** este responsabilă pentru incidente cu materiale periculoase (**Hazmat**), amenințări **CBRN** (Chimic, Biologic, Radiologic, Nuclear) și **Disaster Response**. Operează în medii extrem de periculoase care necesită echipament de protecție specializat (**Level A/B Suits**).

 **11.02 Sistemul TIER**
 Avansarea se face prin acumularea calificărilor:
- **TIER 1 (Entry):** Decontamination Specialist (necesită **Hazmat Operations**).
- **TIER 2 (Technician):** Hazmat Entry Technician (necesită **Hazmat Technician**).
- **TIER 3 (Advanced):** CBRN Response Officer.
- **TIER 4: Division Lead** - Deține toate calificările și poate fi numit **HSOD Coordinator** de către **Bureau Commander**.

 **11.03 Poziții și Calificări**

 **HSOD Coordinator (Division Lead)**
 Liderul diviziei, numit de **Bureau Commander** bazat pe calificări și experiență. Responsabil de coordonarea antrenamentelor și echipamentului. Acționează ca **Incident Commander** la scenele Hazmat, având autoritate tehnică supremă în domeniul Hazmat. Gestionează coordonarea **Multi-Agency** și răspunde direct la **Bureau Commander**.

 **Decontamination Specialist**
 Stabilește **Decon Corridor** în **Warm Zone**. Responsabil pentru curățarea victimelor și a personalului de intrare (**Gross & Technical Decon**) pentru a preveni contaminarea secundară.

 **Hazmat Entry Technician**
 Operează în **Hot Zone**. Identifică substanțele, efectuează **Leak Control** (plugging/patching), prelevează mostre și mitigează pericolul direct.

 **CBRN Response Officer**
 Specialist avansat în arme de distrugere în masă (**WMD**) și amenințări teroriste. Utilizează echipamente sofisticate de detecție și colaborează cu agențiile federale.

 **Hazmat Equipment Officer**
 Gestionează inventarul și mentenanța costumelor de protecție, detectoarelor de gaz și stocurilor de substanțe neutralizante. Asigură **Readiness** pentru **Hazmat Unit**.

 [hr]
---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---
