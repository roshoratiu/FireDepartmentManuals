# RECLAMA UN ANGAJAT

- **Topic ID:** 5
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=5
- **Posts:** 1

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

PROFESSIONAL STANDARDS DIVISION

---

 **INTERNAL AFFAIRS**

---

---

 **SUBIECT: PROCEDURA DE RAPORTARE A UNUI MEMBRU AL LOS SANTOS FIRE DEPARTMENT**

 **SCOP**:
- Scopul prezentului anunț este de a informa publicul cu privire la posibilitatea raportării unei abateri săvârșite de un angajat al departamentului.

 **PROCEDURĂ**:

- Orice cetățean are dreptul de a raporta o abatere de la protocolul departamental sau de la legile statale a unui angajat. Se va completa un raport care va fi trimis către **Professional Standards Division**.

- Pentru a începe o investigație, ofițerii de afaceri interne necesită ca următorul raport să fie întocmit și semnat de declarant. Raportul trebuie să conțină suficiente detalii pentru a valida o investigație oficială. Raportul trebuie expediat catre [Internal Affairs](https://lsfd.ro-rp.mp/memberlist.php?mode=viewprofile&u=73) prin posta. ((Mesaj privat))

```
[divbox=#F7F7F7][color=transparent]-[/color]

[aligntable=right,0,0,09,0,0,transparent][img]https://i.imgur.com/cvtboSt.png[/img][/aligntable]

[color=#2d2e2f][list=none][size=200][font=calibri]Plângere la adresa unui angajat al Los Santos Fire Department[/font][/size][/list]

[list=none][size=160][b][font=calibri]PROFESSIONAL STANDARDS DIVISION[/font][/b][/size]

[size=140][font=calibri]QUALITY SERVICE IS YOUR RIGHT[/font][/size][/list]
[/color]

[hr][/hr]

[size=85][b][size=125]1. Reclamant[/size][/b]

[list=none][b]1.1. Nume:[/b]
[b]1.2. Număr Telefon:[/b]
[b]1.3. Adresă:[/b]
[b]1.4. Agenție (Dacă se aplică):[/b]
[b]1.5. Rang (Dacă se aplică):[/b]
[b]1.6. Copie carte identitate:[/b] (( /showid ))
[/list]

[b][size=125]2. Angajat (Angajați)[/size][/b]

[list=none][b]2.1. Nume:[/b]
[b]2.2. Nr. Insignă (Badge):[/b]
[b]2.3. Callsign(s):[/b] Dacă îl cunoști
[b]2.4. Descriere:[/b] Descriere detaliată a angajatului (angajaților) dacă nu se cunoaște numărul insignei. Include orice informație care poate fi folosită pentru identificare.
[/list]

[b][size=125]3. Incident[/size][/b]

[list=none][b]3.1. Data și Ora:[/b] ZZ/LL/AAAA HH:MM
[b]3.2. Locație:[/b]
[b]3.3. Descriere detaliată a evenimentului:[/b]
[b]3.4. Martori:[/b]
[b]3.5. Dovezi:[/b] (phone recording, video, etc.)
[b](( 3.6. Dovezi Out-of-Character )):[/b] (chatlogs, screenshots, video footage, etc.)
[/list]

[b][size=125]4. Informații[/size][/b]

[list=none][b]4.1. Restituirea solicitată:[/b] (expunerea acuzațiilor, compensație monetară, etc.)
[b]4.2. Informații adiționale:[/b]
[/list]
[/size]

[b][size=125]5. Declaraţie[/size][/b]

[list=none][size=85]5.1. Prin trimiterea acestei plângeri și semnarea de mai jos, reclamantul acordă permisiunea Los Santos Fire Department să efectueze o anchetă de fond a semnatarului (și a reclamantului), dacă se consideră necesar de către departament, și să contacteze orice persoană (persoanele) sau agenție care poate adăuga sau ajuta la această anchetă. În plus, dacă este cazul, solicitantul autorizează persoanele, firmele, agențiile și instituțiile de pe acest formular să elibereze sau să confirme informații pertinente pentru acestea și pentru anchetă, precum și orice declarații pe care le-au făcut ca fiind incluse în plângere.

În timp ce Los Santos Fire Department va încerca să păstreze confidențiale semnătura și identitatea reclamantului față de angajații acuzați sau alte persoane relevante, semnatarul înțelege că Departamentului i se poate solicita să dezvăluie identitatea sa, părți din acest formular sau orice probă atașată, dacă Departamentul consideră că este strict necesar. Semnatarul înțelege că sfera anchetei interne lansate ca urmare a plângerii nu se limitează doar la acuzațiile formulate împotriva angajaților acuzați.

Mai mult, semnatarul certifică prin prezentul act că detaliile furnizate în plângere sunt adevărate din cunoștințele sale și nu includ nicio declarație înșelătoare sau falsă. Depunerea de mărturii false poate atrage acuzații penale. Semnatarul confirmă faptul că a citit integral documentul de plângere la adresa unui angajat și confirmă că reclamația și conținutul acesteia sunt în conformitate cu reglementările stipulate în procedură.

[b](( Semnatarul confirmă faptul că toate probele Out of Character din plângere (dacă există) sunt adevărate și nu au fost fabricate în niciun fel sau formă. Fabricarea de dovezi este strict interzisă și atrage acțiuni Out of Character întreprinse împotriva sa de către administrația serverului, până la și inclusiv o interdicție permanentă pe server. ))[/b][/size]

[b]Semnătura:[/b] X
[b]Data:[/b] ZZ/LL/AAAA
[/list]
[/divbox]
```

- **(( ATENŢIE:**   - Dacă aveţi CCTV sau Dashcam-ul unității FD ca dovadă la plângere, **trebuie să faceţi tot posibilul să aduceţi dovezi Out of Character asociate, fie acestea video-uri sau screenshot-uri**. O plângere nu va fi acceptată fără dovezi OOC; implicit toate plângerile bazate pe camere fără dovezi OOC vor fi ignorate. - Ţineţi minte că putem să invităm reclamatul să verifice dovezile dacă credem că acest fapt ne va ajuta în rezolvarea anchetei. Nu este responsabilitatea noastră dacă din dovezile aduse se poate deduce cine sunteţi. - Professional Standards Division işi rezervă dreptul să ignore orice plângere pe baza unui incident mai vechi de 31 de zile. - Dacă reclamantul recurge la orice formă de a întrerupe legăturile caracterului cu departamentul (ex. namechange), divizia îşi rezervă dreptul de a respinge plângerea sau de a înceta ancheta, de la caz la caz. - **Trimiteţi toate plângerile prin PM către contul [Internal Affairs](http://fd.na-rp.ro/memberlist.php?mode=viewprofile&u=150), conform procedurii departamentale.** ))

 **MENŢIUNI**:

- Ne rezervăm dreptul de a nu înştiinţa publicul cu exactitate despre natura sancțiunii disciplinare (ex: Admonishment, Reprimand, Suspension, Termination of Employment) pe care un membru FD a primit-o în urma unei reclamaţii fondate.
- Dacă o reclamaţie este acceptată, ancheta oficială poate dura minim între 14 şi 28 de zile.

---
