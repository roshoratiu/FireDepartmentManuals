# RESCUE - RE

- **Topic ID:** 72
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=72
- **Posts:** 1

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

RESCUE

---

---

---

**RESCUE COMPANY - MANUAL DE OPERATIUNI**
---

---

- Rescue Company este unitatea specializata pentru technical rescue (salvare tehnica), heavy extrication (extragere grea), collapse response (raspuns la prabusiri), confined space rescue (salvare din spatii inchise) si suport avansat la incidente complexe. Incadrata in **Special Operations Bureau**, sub **Division 2: HSOD - Hazmat, Special Operations & Disaster Response**, prin componenta **Urban Search and Rescue Unit - USAR**, Rescue intervine acolo unde Engine, Truck sau Squad nu dispun de echipament sau personal calificat.

---

---

**1. PPE - PERSONAL PROTECTIVE EQUIPMENT (ECHIPAMENT INDIVIDUAL DE PROTECTIE)**
---

---

- La Rescue Company, PPE-ul standard de interventie este obligatoriu in orice operatiune activa. In plus, tipul interventiei impune echipament suplimentar specific: harness pentru rope rescue, casca structurala integrala pentru collapse response sau SCBA si gas meter pentru confined space entry.

 1.1 **Standard Turnout Gear (echipament standard de interventie)**
- Turnout Gear complet este obligatoriu la orice interventie. Include:  - **Bunker Pants & Turnout Coat:** protectie termica si mecanica la foc, caldura si debris. - **Helmet:** protectie la impact si caderi de materiale. La collapse response se foloseste casca structurala integrala in locul helmului standard. - **Flash Hood:** protejeaza urechile, gatul si zona dintre casca si masca SCBA. - **Fire Gloves:** protectie termica si grip la unelte. La confined space sau lucrul cu metal se adauga manusile anti-taiere (cut-resistant gloves). - **Fire Boots:** protectie termica, antiderapanta si anti-perforare. - **SCBA - Self-Contained Breathing Apparatus:** obligatoriu in orice atmosfera IDLH (imediat periculoasa pentru viata si sanatate), fum, confined space si Hazmat suspect. - **PASS Device:** activat inainte de intrarea in orice zona activa. La orice alarma neconfirmata, echipajul verifica imediat starea membrului si raporteaza catre IC.

 1.2 **Rescue-Specific PPE (echipament specific Rescue)**
- In functie de tipul operatiunii, Rescue Technicienii adauga urmatoarele:

- **Full-body harness (ham integral):** obligatoriu la rope rescue, high-angle entry si confined space cu acces vertical.
- **Structural helmet (casca structurala integrala):** pentru collapse response si trench rescue, ofera protectie superioara la impact si materiale cazute de sus.
- **Knee pads & elbow pads:** protectie la lucrul in spatii inchise, tuneluri sau daramaturi.
- **Protective goggles / face shield:** obligatoriu la taieri cu unelte electrice, structural debris si confined space entry.
- **Cut-resistant gloves (manusi anti-taiere):** la lucrul cu metal deformat, tabla sau geam.
- **Spare SCBA cylinder (butelie de rezerva):** obligatorie la confined space entry pentru a asigura redundanta de aer.

---

---

**2. TOOLS & EQUIPMENT (UNELTE SI ECHIPAMENTE)**
---

---

- Rescue Company transporta echipament greu specializat pentru extragere, stabilizare, rope rescue si suport de scena. Uneltele sunt verificate la inceputul fiecarui shift. Uneltele hidraulice si cele de ridicare se opereaza exclusiv de personal cu calificarea Heavy Rescue Technician sau Rope Rescue Operator.

 2.1 **Extrication Tools (unelte de extragere)**
- **[Spreader-cutters (departator/taietor hidraulic)](http://i.imgur.com/0GGu9Aa.jpg):** defarteaza usi, taie stalpi, balamalele si elementele deformate. Operatorul controleaza miscarea progresiv si monitorizeaza punctele de prindere pe toata durata.
- **[Hydraulic ram (berbec hidraulic)](http://i.imgur.com/TbPpHM0.jpg):** impinge dashboardul, stalpii sau elementele blocate. Se foloseste dupa stabilizare; operatorul monitorizeaza pacientul si structura la fiecare extensie.
- **[Glass-Master:](http://i.imgur.com/RfRBhQJ.jpg)** taierea controlata a parbrizelor laminare si a geamurilor securizate, fara fragmentare.
- **Center punch:** spargerea rapida si controlata a geamurilor laterale securizate.
- **[Reciprocating saw (fierastrau alternativ)](http://cdn0.blocksassests.com/assets/ozito/ozito-clean-pics/gSib6qHKBsXwpI0/RECIP-SAW-RSR-850.jpeg):** taiere prin tabla, tevi, elemente subtiri si materiale de constructie usoare.
- **[Cut-off saw (fierastrau circular)](http://www.northsidetoolrental.com/wp-content/uploads/2010/12/cut-off-saw.jpg):** taiere prin metal greu, cadre de usi, stalpi si structuri deformate.
- **[KED - Kendrick Extraction Device:](http://i.imgur.com/q3kLp9i.jpg)** extragere controlata din vehicule cand exista suspiciune de leziune spinala.
- **[Backboard / Spine Board:](http://www.savelives.com/media/images/j1p_full.jpg)** transfer si imobilizare a pacientului dupa extragere. Se preda catre EMS odata cu pacientul.

 2.2 **Stabilization & Lifting (stabilizare si ridicare)**
- Stabilizarea este intotdeauna primul pas inaintea oricarei taieri, lifting-uri sau intrari langa pacient. Un obiect nestabilizat poate aluneca, se poate rasturna sau cedea in timp ce echipajul lucreaza.

- **[Cribbing (materiale de calare)](https://paulhasenmeier.files.wordpress.com/2011/12/2011-12-02_13-28-39_326.jpg):** bucati de lemn standardizate pentru blocarea vehiculelor, structurilor sau obiectelor in pozitia stabilizata.
- **[Stabilization struts (tije de stabilizare)](http://i.imgur.com/JJrWEew.jpg):** tije reglabile pentru vehicule rasturnate sau structuri inclinate. Se monteaza pereche, pe parti opuse.
- **[Lifting airbags (perne pneumatice de ridicare)](http://i.imgur.com/UJKAuE1.jpg):** ridica obiecte extrem de grele - vehicule, grinzi, placi de beton - cu presiune pneumatica controlata. Se stivuiesc maxim doua perne; cea de jos este totdeauna mai mare.
- **[Come-a-long:](https://i5.walmartimages.com/asr/b78b6109-7adf-4777-b690-ddba654c6669.59f5790901c6584434fbc37d554b61d7.jpeg)** tractiune mecanica manuala pentru deplasarea controlata a obiectelor la distanta mica.
- **[Winch (troliu)](http://www.bmsrescue.com/winch1.jpg):** recuperare si stabilizare la distanta, montat pe sasiul Rescue. Se foloseste cu lant sau cablu de otel.
- **Chains & hooks (lanturi si carlige):** fixare, ancorare si tractiune in combinatie cu winch sau come-a-long.
- **Shoring kit (kit de sprijinire structurala):** traverse, pari si panouri de lemn pentru sprijinirea peretilor, transeelor sau tavanelor partial prabusite.

 2.3 **Rope & Confined Space (coarda si spatii inchise)**
- **Rope bags (saci cu coarda):** coarda statica de salvare (11mm minim), organizata pentru desfasurare rapida fara rasucire.
- **Harnesses (hamuri):** ham integral pentru Rescue Technician si ham de pacient sau rescue basket pentru victima.
- **Carabiners (carabiniere):** conexiuni la sisteme de ancorare, directii si aparate de coborare. Numai carabiners cu surub de siguranta la punctele de sarcina.
- **Pulleys (scripeti):** sisteme de multiplicare a fortei (3:1, 6:1) pentru ridicarea pacientilor sau echipamentului greu.
- **[Rescue tripod (trepied de salvare)](http://g03.s.alicdn.com/kf/HT115cPFOtXXXagOFbX0/221018167/HT115cPFOtXXXagOFbX0.jpg):** ancorare verticala pentru extragere din confined space, puturi sau canalizare.
- **Edge protection (protectie pentru muchii):** role sau placi care protejeaza coarda la trecerea peste margini ascutite sau beton.
- **Patient harness / rescue basket (ham pacient / cos de salvare):** transport controlat al pacientului pe verticala, pe teren dificil sau prin daramaturi.
- **ATC / descender (aparat de coborare):** controleaza viteza de coborare pe coarda. Backup: nod de franare.

 2.4 **Scene Support (suport de scena)**
- **Portable lights (lumini portabile):** iluminat la operatiuni in spatii intunecate, daramaturi si interventii nocturne.
- **Generator:** sursa de curent portabila pentru unelte electrice, lumini si echipament medical.
- **Thermal imaging camera - TIC (camera termica):** detectarea victimelor in fum, daramaturi sau spatii inchise pe baza caldurii corporale.
- **Gas meter (detector de gaze):** masurarea O2, CO, H2S si a procentului de gaze explozive (LEL) inainte de orice confined space entry.
- **Salvage covers:** protectia victimelor si a zonei de lucru impotriva debris-ului, apei si fumului.
- **Medical jump bag:** kit de prim ajutor si stabilizare medicala de baza pana la preluarea de catre EMS.
- **RIT pack / spare SCBA bottle:** rezerva de aer pentru echipaj sau pentru pompieri in pericol la suport Mayday.

---

---

**3. DIVISION ASSIGNMENT (INCADRARE IN DIVIZIE)**
---

---

- **Primary assignment:** **Division 2: HSOD - Hazmat, Special Operations & Disaster Response**, sub **Special Operations Bureau**.    **Unit specialization:** Urban Search and Rescue Unit - USAR.    Rescue Company poate raspunde si la incidente din **Primary Operations Bureau** (MVA, fire support, Mayday), dar incadrarea si calificarea principala raman in **Division 2: HSOD**.

 **Calificari recomandate (in ordinea prioritatii):**
- **Vehicle Extrication** - Core Operations, necesar pentru Firefighter.
- **Rope Rescue** - Core Operations, necesar pentru Firefighter.
- **Advanced Rescue Qualification** - Core Operations.
- **Heavy Rescue Technician** - Primary Operations Specializari, necesar pentru Engineer.
- **Rope Rescue Operator** - Primary Operations Specializari, necesar pentru Engineer.
- **Hazmat Operations** - Division 2: HSOD, TIER I.
- **Technical Rescue Specialist** - Technical Specializations (MOP 5.07).
- **Incident Command System (ICS)** - Core Operations, necesar pentru Engineer / Lieutenant.

 **Nivel minim recomandat:** Firefighter cu Vehicle Extrication + Rope Rescue pentru crew member; Engineer cu Heavy Rescue Technician + Rope Rescue Operator pentru Rescue Operator.

---

---

**4. VEHICLE EXTRICATION (EXTRAGERE DIN VEHICUL)**
---

---

- Rescue Company preia extrication-ul complex la MVA/RTC cand Engine nu dispune de echipament sau personal calificat. La accident cu persoane blocate, Rescue asigura stabilizarea vehiculului, extragerea controlata si predarea pacientului catre EMS.

 4.1 **Scene Size-Up (evaluarea scenei)**
- **1.** Pozitionati Rescue ca blocking apparatus daca scena o cere sau parcati lateral pentru acces la compartimentele de unelte.  **2.** Raportati numarul de vehicule, numarul estimat de pacienti blocati si hazards vizibile.  **3.** Solicitati Engine pentru fire protection si water supply, EMS pentru pacienti, PD/SD pentru trafic.  **4.** Identificati: foc activ, scurgeri de combustibil, cabluri electrice, airbag-uri neactivate, rezervoare de gaz comprimat (struts, gas springs), vehicule instabile.  **5.** Stabiliti hot zone (zona vehiculului), warm zone (zona de lucru Rescue) si cold zone (staging si triage EMS).

 4.2 **Vehicle Stabilization (stabilizarea vehiculului)**
- **Regula de baza:** stabilizarea vine INTOTDEAUNA inaintea taierii, spreading-ului sau intrarii EMS la pacient. Un vehicul nestabilizat poate aluneca sau se poate rasturna in timp ce echipajul lucreaza.

- **1.** Deflatati anvelopele sau plasati cribbing sub cadru pentru blocarea miscarilor verticale.  **2.** Montati struts sub punctele solide ale vehiculului, pereche, pe parti opuse.  **3.** Testati stabilizarea impingand usor vehiculul inainte de a incepe lucrul.  **4.** Dezactivati bateria daca este accesibila si sigur de facut.  **5.** Raportati "vehicle stabilized" catre IC si EMS inainte de a incepe extragerea.

 4.3 **Patient Protection (protectia pacientului)**
- Pacientul se protejeaza inainte de orice taiere sau spreading. Personalul EMS este responsabil de pacient pe toata durata extragerii.

- **1.** Acoperiti pacientul cu hard protection (plastic rigid) sau patura groasa impotriva sticlei si metalului.  **2.** Aplicati eye protection pacientului.  **3.** Comunicati cu pacientul pe toata durata extragerii: el trebuie sa stie ce urmeaza.  **4.** Anuntati inainte de orice miscare sau zgomot brusc: "Urmeaza un zgomot puternic", "Nu te misca".

 4.4 **Tehnici de extragere (extrication techniques)**

 4.4.1 **Door Removal (indepartarea usii)**
- **1.** Creati purchase point (punct de prindere) cu Halligan la balama sau la latch.  **2.** Folositi spreader pentru a mari spatiul progresiv, verificand constant pacientul.  **3.** Taiati balamalele sau latch-ul cu cutters cand spatiul este suficient.  **4.** Controlati usa cand se desprinde si indepartati-o din zona de lucru imediat.

 4.4.2 **Roof Removal (indepartarea plafonului)**
- **1.** Indepartati sticla necesara cu Glass-Master sau center punch.  **2.** Taiati A-pillar, B-pillar si C-pillar in ordinea planului de extrication.  **3.** Protejati pacientul de metal si sticla pe toata durata taierii - hard protection sau patura peste cap.  **4.** Ridicati si mutati plafonul cu minimum doi membri, coordonat la comanda.

 4.4.3 **Dashboard Lift / Roll (ridicarea si deplasarea bordului)**
- **1.** Verificati stabilizarea vehiculului inainte de a pozitiona ramul.  **2.** Pozitionati hydraulic ram intre puncte solide ale cadrului, nu pe plastic sau metal subtire.  **3.** Extindeti lent pana cand picioarele pacientului sunt eliberate.  **4.** Monitorizati permanent pacientul si structura vehiculului la fiecare extensie.

 4.4.4 **Rapid Extrication (extragere rapida)**
- Rapid extrication se foloseste cand pacientul este critic sau scena devine nesigura: cardiac arrest, hemoragie necontrolata, foc activ sau pericol iminent de collapse.

- **1.** Mentineti manual cervical stabilization pe toata durata.  **2.** Deschideti ruta cea mai rapida catre pacient.  **3.** Transferati pacientul pe backboard cu miscari coordonate: unul tine capul, doi ridica corpul la comanda.  **4.** Indepartati pacientul din hazard zone si incepeti tratamentul imediat.

---

---

**5. STRUCTURAL COLLAPSE (RASPUNS LA PRABUSIRI)**
---

---

- Structural collapse (prabusirea structurala) este unul dintre cele mai periculoase tipuri de incidente. Cladiri prabusite sau partial instabile pot ceda suplimentar fara avertisment. Rescue Company coordoneaza cautarea si extragerea victimelor in colaborare cu **Division 2: HSOD - Hazmat, Special Operations & Disaster Response**, prin componenta **Urban Search and Rescue Unit - USAR**.

 5.1 **Scene Size-Up & Zonare**
- **1.** Nu intrati in structura fara evaluarea prealabila a stabilitatii de catre Rescue Officer sau IC.  **2.** Stabiliti perimetrul de siguranta: hot zone (daramaturi si structura instabila), warm zone (zona de lucru Rescue), cold zone (staging si triage EMS).  **3.** Solicitati USAR, Hazmat, engineering support si EMS in numar suficient.  **4.** Ascultati activ: voci, batai, sunete de miscare. Folositi TIC pentru detectarea caldurii corporale.  **5.** Identificati riscuri secundare: gaz, curent electric, apa, materiale periculoase si instabilitate reziduala.

 5.2 **Collapse Patterns (modele de prabusire)**
- Cunoasterea modului de prabusire ajuta la localizarea victimelor si la identificarea spatiilor de supravietuire.  - **Pancake collapse (prabusire tip clatita):** etajele se prabusesc orizontal, unul peste altul. Spatiile de supravietuire sunt foarte mici, intre dale. - **V-shape collapse (prabusire in V):** centrul podelei cedeaza, marginile raman ridicate. Victimele pot fi la margini sau in zona centrala. - **Lean-to collapse (prabusire laterala):** o margine cade, cealalta ramane fixata la perete. Spatii triunghiulare de supravietuire se formeaza sub portiunea ramasa. - **A-frame collapse (prabusire tip A):** peretii laterali cad, centrul ramane, formand un spatiu triunghiular central. Victimele pot fi la extremitatile spatiului.

 5.3 **Shoring (sprijinire structurala)**
- Shoring-ul se aplica inainte si in timpul extragerii pentru a preveni prabusiri secundare. Se construieste cu lemnul din shoring kit, inainte ca echipa sa intre in zona activa.

- **1.** Identificati directia de incarcare a structurii si punctele de cedare probabile.  **2.** Construiti vertical shores pentru pereti instabili sau shoring orizontal pentru tavane partial cazute.  **3.** Testati shoring-ul usor inainte de a trimite echipa in spatiu.  **4.** Monitorizati continuu structura pe toata durata operatiunii.  **5.** Semnalul de evacuare de urgenta este un sunet scurt repetat pe fluier sau radio - la auzirea lui, toata echipa se retrage imediat fara sa astepte ordin suplimentar.

 5.4 **Search & Victim Removal (cautare si extragere victima)**
- **1.** Folositi TIC si strigati periodic pentru a localiza victimele; ascultati activ in liniste.  **2.** Initiati contact vocal sau tactil cu victima inainte de a incepe extragerea.  **3.** Creati spatiu in jurul victimei cu lifting airbags, come-a-long sau cribbing incremental.  **4.** Extrageti victima pe backboard sau placa dreapta daca exista suspiciune spinala.  **5.** Predati victima catre EMS in cold zone imediat dupa extragere.  **6.** Raportati "victim removed" si starea victimei catre IC.

---

---

**6. CONFINED SPACE RESCUE (SALVARE DIN SPATII INCHISE)**
---

---

- Confined space (spatiu inchis) este orice spatiu cu acces limitat care nu este proiectat pentru ocupare continua: tuneluri, canalizari, rezervoare, silozuri, camere tehnice, puturi. Pericolele principale sunt atmosfera deficitara in oxigen, gaze toxice (CO, H2S), riscul de inglobare (engulfment) si imposibilitatea autoevacuarii. Nicio persoana nu intra fara evaluarea atmosferei si fara echipaj de suport la exterior.

 6.1 **Evaluarea atmosferei (atmospheric testing)**
- **1.** Masurați cu gas meter inainte de orice intrare: O2 (zona sigura: 19.5%-23.5%), CO (sub 35 ppm), H2S (sub 10 ppm), gaze explozive (LEL sub 10%).  **2.** Daca orice valoare este in afara limitei sigure, nu intrati fara SCBA si echipament de protectie corespunzator.  **3.** Repetati masuratorile la intervale regulate pe toata durata operatiunii.

 6.2 **Entry Protocol (protocol de intrare)**
- **1.** Stabiliti entry point si exit point clare, marcate vizibil.  **2.** Echipa de intrare: minimum 2 persoane, cu SCBA, harness, radio si spare air.  **3.** Echipa de suport la exterior: minimum 2 persoane, cu rescue tripod si coarda conectata la harness-ul echipei. Echipa de exterior nu intra sub nicio forma.  **4.** Montati rescue tripod deasupra entry point vertical, cu coarda tensionata la harness.  **5.** Comunicati continuu cu echipa interioara; tacerea mai mult de 30 de secunde declansaza protocol de urgenta.

 6.3 **Non-Entry Rescue (salvare fara intrare)**
- Daca atmosfera nu poate fi controlata sau victima este aproape de entry point, considerati non-entry rescue: tragerea victimei cu coarda si winch din exterior, fara trimiterea de personal in spatiu. Este varianta preferata ori de cate ori este fezabila.

 6.4 **Emergency Egress (evacuare de urgenta)**
- **1.** Daca conditiile atmosferice se deterioreaza brusc sau apare pericol structural, echipa interioara se evacueaza imediat pe coarda de ghidaj fara a astepta ordin.  **2.** Echipa exterioara trage activ coarda si asista la extragere.  **3.** IC este notificat imediat si dispune resurse suplimentare: Hazmat, USAR, aer suplimentar.

---

---

**7. ROPE RESCUE / HIGH-ANGLE (SALVARE PE COARDA / UNGHI INALT)**
---

---

- Rope rescue se aplica la victime la inaltime sau sub nivel: cladiri, stanci, pante, structuri, poduri sau santuri adanci. Rescue Company cu calificarea Rope Rescue Operator executa operatiuni complete de coborare si ridicare pe coarda.

 7.1 **Anchor System (sistem de ancorare)**
- **1.** Identificati cel putin doua puncte de ancorare solide si independente: structuri fixe, vehicule ancorate, tije batute in beton.  **2.** Distribuiti sarcina echitabil intre ancore cu sling-uri si carabinere cu surub.  **3.** Testati sistemul cu greutate simulata inainte de a conecta pacientul sau echipajul.  **4.** Aplicati edge protection oriunde coarda trece peste o margine ascutita sau beton.

 7.2 **Patient Packaging (pregatirea pacientului)**
- **1.** Aplicati patient harness sau plasati pacientul in rescue basket (cos de salvare), cu capul imobilizat.  **2.** Asigurati fixarea capului, trunchiului si membrelor in cos - nimic nu ramane liber.  **3.** Conectati cosul la linia principala si la belay line (linie de siguranta) independent.  **4.** Raportati catre IC "patient packaged, ready for lower/raise" inainte de a incepe miscarea.

 7.3 **Lower vs. Raise (coborare vs. ridicare)**
- **Lower (coborare):** metoda preferata cand pacientul este deasupra punctului de acces. Se controleaza viteza cu descender; coborarea lenta si uniforma este mai sigura decat una rapida.    **Raise (ridicare):** necesara cand pacientul este sub nivelul de acces (santuri, puturi, ravene). Se foloseste sistem de scripeti cu multiplicare de forta 3:1 sau 6:1 pentru a reduce efortul fizic al echipajului.

- **1.** Desemnati un Rope Rescue Operator pentru comanda intregului sistem.  **2.** Un al doilea Technician opereaza belay line, independent de linia principala.  **3.** Un al treilea Technician insoteste pacientul pe linie daca distanta si conditiile permit.  **4.** Comenzile de miscare se dau scurt si clar si se confirma inainte de executie:  - **"LOWER"** - incepeti coborarea. - **"STOP"** - opriti imediat, fara nicio miscare. - **"RAISE"** - incepeti ridicarea. - **"SLACK"** - dati coarda libera.

---

---

**8. MAYDAY SUPPORT / RIT ASSIST**
---

---

- La incendii majore, Rescue Company poate fi desemnata de IC ca suport pentru RIT (Rapid Intervention Team) sau pentru extragerea unui pompier in pericol. Aceasta misiune are prioritate absoluta si anuleaza orice alta sarcina curenta a Rescue.

 8.1 **Standby Readiness (pregatire la scena)**
- SCBA complet, PASS activ si verificat, radio pe canalul tactic.
- RIT pack si spare SCBA bottle pregatite si accesibile.
- Cunoasterea layout-ului structurii si a pozitiei echipelor interioare.
- Monitorizare permanenta a canalului radio pentru orice Mayday.
- Nu primiti sarcini secundare cat timp sunteti desemnati Mayday support.

 8.2 **Raspuns la Mayday**
- **1.** IC activeaza RIT si aloca Rescue ca suport tehnic de extragere grea.  **2.** Rescue intra cu minimum 2 persoane, cu rope/tag line si echipament de extragere.  **3.** Localizati pompierul: ascultati alarma PASS, urmariti radio, folositi TIC.  **4.** Evaluati: air supply ramas, entrapment (blocare fizica), stare fizica.  **5.** Furnizati aer din spare bottle daca rezerva pompierului este critica - conectati bottle-ul inainte de a incerca deplasarea.  **6.** Extrageti pe cea mai scurta ruta sigura, cu sprijin activ pe toata durata.  **7.** Raportati progresul catre IC la fiecare 60 de secunde: "Mayday team, contact made / moving to exit / victim out".

---

---

**9. HAZMAT SUPPORT (SUPORT HAZMAT)**
---

---

- In incidentele Hazmat gestionate de **Division 2: HSOD - Hazmat, Special Operations & Disaster Response**, Rescue Company asigura acces, stabilizare mecanica si extragerea victimelor din warm zone si cold zone. Rescue nu intra in hot zone fara calificarea Hazmat Operations (TIER I, Division 2: HSOD) si echipament de nivel corespunzator.

 9.1 **Rolul Rescue in incidente Hazmat**
- **Warm zone:** extragere de victime dupa decontaminarea initiala efectuata de Hazmat Entry Technician din **Division 2: HSOD**.
- **Cold zone:** stabilizare mecanica (vehicule rasturnate, structuri), suport logistic si pregatire echipament pentru echipa Hazmat.
- **Decontamination support:** asistenta la decon corridor daca Hazmat are personal insuficient, conform instructiunilor HSOD Coordinator.
- **Victim packaging:** pregatirea victimelor decontaminate pentru transport catre EMS.

 9.2 **Limitari clare**
- Rescue nu intra in hot zone fara:  - Calificarea **Hazmat Technician** (TIER II, Division 2: HSOD - Hazmat, Special Operations & Disaster Response). Calificarea **Hazmat Operations** (TIER I) permite lucrul doar in Warm Zone, la Decon Corridor, nu in Hot Zone. - Echipament de protectie de nivel corespunzator (Level B/A suit), pus si verificat corect. - Coordonarea si aprobarea explicita din partea HSOD Coordinator sau Division Lead.   Orice tentativa de intrare neautorizata in hot zone se raporteaza imediat catre IC si HSOD Coordinator. Entuziasmul nu inlocuieste calificarea.

---
