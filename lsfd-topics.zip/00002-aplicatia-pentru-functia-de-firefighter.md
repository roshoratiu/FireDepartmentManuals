# APLICAȚIA PENTRU FUNCȚIA DE FIREFIGHTER

- **Topic ID:** 2
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=2
- **Posts:** 2

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

APLICAȚIE PENTRU FUNCȚIA DE FIREFIGHTER

---

---

---

- **(1.0)**INFORMAȚII CU CARACTER PERSONAL

---

---

- **(1.1) Nume:** Răspunde aici  **(1.2) Prenume:** Răspunde aici  **(1.3) Sex:** Răspunde aici  **(1.4) Vârstă:** Răspunde aici  **(1.5) Înălțime:** Răspunde aici  **(1.6) Greutate:** Răspunde aici  **(1.7) Naționalitate:** Răspunde aici  **(1.8) Adresă:** Răspunde aici  **(1.9) Număr de telefon:** Răspunde aici

 -
---

---

- **(2.0)**INFORMAȚII CU CARACTER LEGAL

---

---

- **(2.1) Sunteți un cetățean legal al statului San Andreas?:** [ ] Da [ ] Nu    **(2.2) Suferiți de vreo boală cronică?:** [ ] Da [ ] Nu  **Dacă da, specificați:** Răspunde aici sau scrie N/A.    **(2.3) Întâmpinați vreo problemă fizică?:** [ ] Da [ ] Nu  **Dacă da, specificați:** Răspunde aici sau scrie N/A.    **(2.4) Ați consumat substanțe interzise sau controlate în trecut, astfel încât în prezent să simțiți stări de sevraj?:** [ ] Da [ ] Nu  **Dacă da, specificați:** Răspunde aici sau scrie N/A.    **(2.5) Ați fost vreodată sancționat penal pentru comiterea unei infracțiuni sau a unei crime?:** [ ] Da [ ] Nu  **Dacă da, explicați:** Răspunde aici sau scrie N/A.    **(2.6) Ați primit vreodată o contravenție?:** [ ] Da [ ] Nu  **Dacă da, specificați motivul și suma plătită:** Răspunde aici sau scrie N/A.    **(2.7) Sunteți în posesia unui permis de conducere categoria I, valabil în statul San Andreas?:** [ ] Da [ ] Nu  **Dacă da, v-a fost vreodată suspendat? Specificați motivul:** Răspunde aici sau scrie N/A.    **(2.8) Sunteți în posesia unei licențe de port-armă, valabilă în statul San Andreas?:** [ ] Da [ ] Nu  **Dacă da, v-a fost vreodată suspendată? Specificați motivul:** Răspunde aici sau scrie N/A.

 -
---

---

- **(3.0)**INFORMAȚII CU CARACTER ARGUMENTATIV ȘI DE EXPRIMARE

---

---

- **(3.1) Sunteți capabil să comunicați atât verbal cât și scris în limba engleză?:** [ ] Da [ ] Nu    **(3.2) Cunoașteți o altă limba străină în afară de limba engleză?:** [ ] Da [ ] Nu  **Dacă da, specificați:** Răspunde aici sau scrie N/A.    **(3.3) În opinia dumneavoastră, care sunt îndatoririle și obligațiile unui angajat al Los Santos Fire Department?** (Depune efort.)   - Răspunde aici.   **(3.4) De ce doriți să vă angajați în cadrul Los Santos Fire Department?** (Depune efort.)   - Răspunde aici.

 -
---

---

- (( **(4.0)**INFORMAȚII OUT OF CHARACTER ))

---

---

- **(4.1) Prenume:** Răspunde aici  **(4.2) Vârstă:** Răspunde aici  **(4.3) Oraș sau localitate:** Răspunde aici  **(4.4) De când joci pe comunități de roleplay?:** Răspunde aici  **(4.5) De când joci pe această comunitate?:** Răspunde aici  **(4.6) Discord:** Răspunde aici  **(4.7) Acces către contul de forum:** [ACCES](https://lsfd.ro-rp.mp/LinkDeAcces)  **(4.8) În prezent, ești membru al unei alte facțiuni? Dacă da, specifică:** Răspunde aici  **(4.9) Prezintă poze needitate cu Admin Record-ul de pe toate caracterele** (album): [ACCES](https://lsfd.ro-rp.mp/LinkDeAcces)  **(4.10) Prezintă o poză needitată cu /stats de pe caracterul cu care aplici:** [ACCES](https://lsfd.ro-rp.mp/LinkDeAcces)  **(4.11) Acces către cererea de Double Faction acceptată (dacă este cazul):** [ACCES](https://lsfd.ro-rp.mp/LinkDeAcces)

---

## #2 — Aisha Dubois

Titlu:
```
[#ZZLLL] Nume Prenume
```

 Unde ZZ reprezeinta ziua, iar LLL luna. Exemplu: 13 martie -> 13MAR -> [#13MAR] Aisha Dubois

 Cod:
```
[birou=APLICAȚIE PENTRU FUNCȚIA DE FIREFIGHTER white]
[hr][/hr]
[list=none][b][size=120](1.0)[/b]INFORMAȚII CU CARACTER PERSONAL[/size][/list]
[hr][/hr]
[list=none]
[b](1.1) Nume:[/b] Răspunde aici
[b](1.2) Prenume:[/b] Răspunde aici
[b](1.3) Sex:[/b] Răspunde aici
[b](1.4) Vârstă:[/b] Răspunde aici
[b](1.5) Înălțime:[/b] Răspunde aici
[b](1.6) Greutate:[/b] Răspunde aici
[b](1.7) Naționalitate:[/b] Răspunde aici
[b](1.8) Adresă:[/b] Răspunde aici
[b](1.9) Număr de telefon:[/b] Răspunde aici
[/list]
[color=#FFFFFF]-[/color]
[hr][/hr]
[list=none][b][size=120](2.0)[/b]INFORMAȚII CU CARACTER LEGAL[/size][/list]
[hr][/hr]
[list=none]
[b](2.1) Sunteți un cetățean legal al statului San Andreas?:[/b]  [ ] Da [ ] Nu

[b](2.2) Suferiți de vreo boală cronică?:[/b] [ ] Da [ ] Nu
[b]Dacă da, specificați:[/b] Răspunde aici sau scrie N/A.

[b](2.3) Întâmpinați vreo problemă fizică?:[/b] [ ] Da [ ] Nu
[b]Dacă da, specificați:[/b] Răspunde aici sau scrie N/A.

[b](2.4) Ați consumat substanțe interzise sau controlate în trecut, astfel încât în prezent să simțiți stări de sevraj?:[/b] [ ] Da [ ] Nu
[b]Dacă da, specificați:[/b] Răspunde aici sau scrie N/A.

[b](2.5) Ați fost vreodată sancționat penal pentru comiterea unei infracțiuni sau a unei crime?:[/b] [ ] Da [ ] Nu
[b]Dacă da, explicați:[/b] Răspunde aici sau scrie N/A.

[b](2.6) Ați primit vreodată o contravenție?:[/b] [ ] Da [ ] Nu
[b]Dacă da, specificați motivul și suma plătită:[/b] Răspunde aici sau scrie N/A.

[b](2.7) Sunteți în posesia unui permis de conducere categoria I, valabil în statul San Andreas?:[/b] [ ] Da [ ] Nu
[b]Dacă da, v-a fost vreodată suspendat? Specificați motivul:[/b] Răspunde aici sau scrie N/A.

[b](2.8) Sunteți în posesia unei licențe de port-armă, valabilă în statul San Andreas?:[/b] [ ] Da [ ] Nu
[b]Dacă da, v-a fost vreodată suspendată? Specificați motivul:[/b] Răspunde aici sau scrie N/A.
[/list]
[color=#FFFFFF]-[/color]
[hr][/hr]
[list=none][b][size=120](3.0)[/b]INFORMAȚII CU CARACTER ARGUMENTATIV ȘI DE EXPRIMARE[/size][/list]
[hr][/hr]
[list=none]
[b](3.1) Sunteți capabil să comunicați atât verbal cât și scris în limba engleză?:[/b] [ ] Da [ ] Nu

[b](3.2) Cunoașteți o altă limba străină în afară de limba engleză?:[/b] [ ] Da [ ] Nu
[b]Dacă da, specificați:[/b] Răspunde aici sau scrie N/A.

[b](3.3) În opinia dumneavoastră, care sunt îndatoririle și obligațiile unui angajat al Liberty City Fire Department?[/b] (Depune efort.)

[list=none]Răspunde aici.[/list]

[b](3.4) De ce doriți să vă angajați în cadrul Liberty City Fire Department?[/b] (Depune efort.)

[list=none]Răspunde aici.[/list]
[/list]
[color=#FFFFFF]-[/color]
[hr][/hr]
[list=none][size=120](( [b](4.0)[/b]INFORMAȚII OUT OF CHARACTER ))[/size][/list]
[hr][/hr]
[list=none]
[b](4.1) Prenume:[/b] Răspunde aici
[b](4.2) Vârstă:[/b] Răspunde aici
[b](4.3) Oraș sau localitate:[/b] Răspunde aici
[b](4.4) De când joci pe comunități de roleplay?:[/b] Răspunde aici
[b](4.5) De când joci pe această comunitate?:[/b] Răspunde aici
[b](4.6) Discord:[/b] Răspunde aici
[b](4.7) Acces către contul de forum:[/b] [url=LinkDeAcces]ACCES[/url]
[b](4.8) În prezent, ești membru al unei alte facțiuni? Dacă da, specifică:[/b] Răspunde aici
[b](4.9) Prezintă poze needitate cu Admin Record-ul de pe toate caracterele[/b] (album): [url=LinkDeAcces]ACCES[/url]
[b](4.10) Prezintă o poză needitată cu /stats de pe caracterul cu care aplici:[/b] [url=LinkDeAcces]ACCES[/url]
[b](4.11) Acces către cererea de Double Faction acceptată (dacă este cazul):[/b] [url=LinkDeAcces]ACCES[/url]
[/list]

[/birou]
```

---
