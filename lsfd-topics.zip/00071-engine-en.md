# ENGINE - EN

- **Topic ID:** 71
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=71
- **Posts:** 1

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

ENGINE

---

---

---

**1. PPE - PERSONAL PROTECTIVE EQUIPMENT (ECHIPAMENT INDIVIDUAL DE PROTECȚIE)**
---

---

- Engine Company este unitatea principală pentru fire suppression (stingerea incendiilor), water supply (alimentarea cu apă), initial attack (atacul inițial), medical support și vehicle incidents. În orice intervenție cu foc, fum, materiale fierbinți sau risc structural, PPE-ul complet este obligatoriu.

 1.1 **Bunker Pants (pantaloni de intervenție)**
- Bunker pants protejează membrele inferioare împotriva căldurii, flăcărilor, obiectelor ascuțite și resturilor. Bretelele mențin pantalonii fixați, iar buzunarele permit transportul unor unelte mici, webbing sau gloves de rezervă.  ``` [SHOW] ```

 1.2 **Turnout Coat (haină de intervenție)**
- Turnout coat protejează toracele, brațele și gâtul. Închiderile trebuie fixate complet înainte de intrarea în hot zone (zona fierbinte). Manșetele și gulerul reduc expunerea pielii la heat, steam și embers (jar).  ``` [SHOW] ```

 1.3 **Flash Hood (cagulă de protecție)**
- Flash hood acoperă urechile, gâtul și zonele expuse dintre helmet și SCBA facepiece. Se pune înainte de mască sau se trage peste seal-ul măștii, fără a compromite etanșarea.  ``` [SHOW] ```

 1.4 **Helmet (cască)**
- Helmet protejează capul împotriva impactului, căldurii și resturilor. Shield-ul frontal indică de obicei rank-ul, unitatea sau numărul de badge.  ``` [SHOW] ```

 1.5 **Fire Boots (cizme de intervenție)**
- Fire boots oferă protecție termică, antiderapantă și împotriva perforării. Trebuie purtate sub bunker pants și verificate pentru deteriorări înainte de shift.  ``` [SHOW] ```

 1.6 **Fire Gloves (mănuși de intervenție)**
- Fire gloves protejează mâinile împotriva căldurii, tăieturilor și resturilor. Trebuie să permită grip (prindere) suficient pentru nozzle, tools și hose line.  ``` [SHOW] ```

 1.7 **SCBA - Self-Contained Breathing Apparatus (aparat autonom de respirat)**
- SCBA se poartă în orice atmosferă IDLH (imediat periculoasă pentru viață și sănătate), smoke condition (fum), hazmat suspect sau interior attack. Componentele principale sunt:  - air cylinder (butelie de aer); - regulator (regulator); - facepiece (mască facială); - harness (ham); - PASS device (dispozitiv de alarmă).    ``` [SHOW] ```

 1.8 **PASS Device (dispozitiv personal de alarmare)**
- PASS device emite o alarmă puternică dacă Firefighter-ul nu se mișcă o perioadă scurtă sau dacă activează manual alarma. La orice alarmă PASS neconfirmată, echipajul trebuie să verifice imediat starea membrului și să informeze IC.

---

---

**2. TOOLS & EQUIPMENT (UNELTE ȘI ECHIPAMENTE)**
---

---

 2.1 **General Tools (unelte generale)**
- Engine transportă unelte pentru fire attack, forcible entry, vehicle stabilization, medical support și overhaul. Uneltele trebuie verificate la începutul shift-ului.

- **[Center punch](http://i.imgur.com/sy62ry5.jpg):** spargerea controlată a geamurilor laterale.
- **[Cutting pliers (clește de tăiere)](http://i.imgur.com/2YNezi1.jpg):** tăierea cablurilor sau firelor.
- **[Fire axe (topor de pompieri)](http://i.imgur.com/GQGbqDl.jpg):** forțare, spargere și acces.
- **[Glass-Master](http://i.imgur.com/RfRBhQJ.jpg):** tăierea parbrizelor și geamurilor.
- **[Halligan bar](http://i.imgur.com/NF72G7Q.jpg):** forcible entry, prying, striking, twisting.
- **[Hose bridge](http://i.imgur.com/mg2YdJn.jpg):** protejează hose line-ul când este traversat.
- **[Nozzle (duză)](http://i.imgur.com/M1o3Ihh.jpg):** controlează debitul și pattern-ul de apă.
- **[Hydrant tool (cheie de hidrant)](http://i.imgur.com/VzqeKcs.jpg):** deschiderea hidranților.
- **[KED - Kendrick Extraction Device](http://i.imgur.com/q3kLp9i.jpg):** extragere controlată din vehicule.
- **[Mallet](http://i.imgur.com/qCVwzM2.jpg):** lovire controlată.
- **[Pike pole](https://4.bp.blogspot.com/-PTvAo3OAKTU/TzGyyfrIBBZI/AAAAAAF7E/JgFQEgeW4Hc/s640/pike+pole.jpg):** verificarea tavanului, pereților și materialelor mocnite.
- **[Salvage covers](http://i.imgur.com/9M5F0VX.jpg):** protecția proprietății.
- **[Sledgehammer](http://i.imgur.com/YmZKNrl.jpg):** spargere grea.
- **[X-Collar](http://i.imgur.com/KXa4p03.jpg):** stabilizare cervicală.

 2.2 **Hydraulic Rescue Tools (unelte hidraulice de salvare)**
- Hydraulic rescue tools, cunoscute ca Jaws of Life, sunt folosite la vehicle extrication (extragere din vehicul), prăbușiri ușoare și acces forțat.

 2.2.1 **Spreader-Cutters (depărtător/tăietor hidraulic)**
- Spreader-cutters pot depărta uși, crea spațiu, rupe elemente deformate și tăia stâlpi sau balamale. Operatorul trebuie să controleze mișcarea lent și să urmărească punctele de prindere.  ``` [SHOW] ```

 2.2.2 **Hydraulic Ram (berbec hidraulic)**
- Hydraulic ram împinge elemente deformate, cum ar fi dashboard-ul la un MVA/RTC. Se folosește doar după stabilization și cu atenție la pacient, airbag-uri și puncte de sprijin.  ``` [SHOW] ```

---

---

**3. HOSE LINES & EXTINGUISHERS (FURTUNURI ȘI EXTINCTOARE)**
---

---

 3.1 **Hose Lines (tipuri de furtun)**

 3.1.1 **Crosslay / Live Line (linie de atac preconectată)**
- Crosslay este prima linie folosită la majoritatea incendiilor de vehicul sau structură mică. Este preconnected (preconectată), ușor de desfășurat și potrivită pentru interior attack.    **Locație:** lateral, deasupra pump panel-ului.  **Preconnected:** Da.  ``` [SHOW] ```

 3.1.2 **Booster Line (linie booster)**
- Booster line se folosește pentru fires mici: trash fire, grass fire, răcire sau mop-up. Nu este potrivită pentru incendii structurale avansate.    **Preconnected:** Da.  ``` [SHOW] ```

 3.1.3 **2.5-inch Line (linie de 2.5 inch)**
- Linia de 2.5 inch oferă debit mare pentru exterior attack, defensive operations și incendii mari. Când este charged (încărcată cu apă), este greu de manevrat și necesită mai mulți membri.    **Preconnected:** Da.  ``` [SHOW] ```

 3.1.4 **Deck Gun / Master Stream (tun de apă)**
- Deck gun oferă debit foarte mare și este folosit la incendii industriale, defensive attack sau când interior attack este imposibil. Se folosește cu aprobarea IC, deoarece poate produce daune mari și consumă rapid apa.    **Locație:** partea superioară a Engine-ului.  **Preconnected:** Da.  ``` [SHOW] ```

 3.1.5 **Hose Pack (pachet de furtun)**
- Hose pack permite extinderea unei linii la etaje superioare sau în clădiri mari. Nu este preconectat și trebuie alimentat dintr-o linie existentă sau standpipe.    **Preconnected:** Nu.  ``` [SHOW] ```

 3.1.6 **Supply Line / Relay Line (linie de alimentare)**
- Supply line conectează Engine-ul la hydrant (hidrant), tender sau alt Engine. Water supply trebuie stabilit rapid la incendiile active; rezervorul intern se consumă repede la debite mari.    **Preconnected:** Nu.  ``` [SHOW] ```

 3.2 **Extinguishers (extinctoare)**
- Extinguisher-ul potrivit depinde de fire class (clasa incendiului):  - **Class A:** solide combustibile: lemn, hârtie, textile. - **Class B:** lichide inflamabile: benzină, ulei, solvenți. - **Class C:** gaze inflamabile: propan, butan, gaz natural. - **Class D:** metale combustibile. - **Class E/Electrical:** echipamente electrice active. - **Class F/K:** uleiuri și grăsimi de gătit.   ![Image](http://i.imgur.com/d04ni5K.jpg)    **Tipuri uzuale:**  - **Dry powder (pulbere uscată):** eficientă pentru A/B/C și unele D. - **CO2 (dioxid de carbon):** B și electrical fires. - **Foam (spumă):** A și B, în funcție de tip. - **Water (apă):** doar Class A.

 3.3 **Firefighting Foam (spumă de stingere)**
- Foam creează o pătură care separă fuel-ul de oxygen și reduce vaporii inflamabili.  - **Class A foam:** lemn, hârtie, materiale plastice și vegetație. - **Class B foam:** lichide inflamabile, combustibili și vapori.   Foam se introduce prin pump panel conform echipamentului Engine-ului. Verificați concentrația și evitați folosirea inutilă.

---

---

**4. MVA / RTC - MOTOR VEHICLE ACCIDENT (ACCIDENT RUTIER)**
---

---

- La MVA/RTC, Engine Company asigură scene safety, fire protection, stabilization și vehicle extrication când este necesar. Prima unitate poate prelua IC până la sosirea unui officer superior.

 4.1 **Scene Size-Up (evaluarea scenei)**
- **1.** Poziționați Engine-ul ca blocking apparatus (vehicul de protecție), protejând echipajul de trafic.  **2.** Raportați numărul de vehicule, numărul estimat de pacienți și pericolele vizibile.  **3.** Solicitați PD/SD pentru trafic, EMS pentru pacienți, Hazmat pentru scurgeri și Squad/Truck pentru extrication complex.  **4.** Identificați hazards: foc, fum, combustibil, cabluri, trafic, vehicule instabile, airbag-uri neactivate.  **5.** Stabilizați vehiculul înainte ca EMS să intre complet în zona de lucru.  **6.** Deconectați bateria dacă este sigur și accesibil.

 4.2 **Leaks (scurgeri)**
- **1.** Identificați tipul și dimensiunea scurgerii.  **2.** Stabiliți o hose line pregătită.  **3.** Pentru combustibil, aplicați Class B foam pentru a reduce vaporii.  **4.** Țineți sursele de aprindere la distanță și solicitați Hazmat dacă substanța este necunoscută.

 4.3 **Vehicle Fire (incendiu de vehicul)**
- **1.** Abordați vehiculul din unghi, nu direct din față sau spate.  **2.** Folosiți water pentru foc mic fără scurgeri; folosiți foam dacă există combustibil.  **3.** La engine compartment fire (incendiu în compartimentul motor), răciți din lateral și deschideți capota controlat cu Halligan.  **4.** Fiți atenți la tires, airbags, gas struts și materiale sub presiune.  **5.** După knockdown, verificați reignition (reaprindere).

 4.4 **Vehicle Extrication (extragere din vehicul)**

 4.4.1 **General Extrication (extragere generală)**
- **1.** Stabilizați vehiculul cu cribbing/struts.  **2.** Protejați pacientul cu blanket sau hard protection.  **3.** EMS aplică C-collar/X-Collar dacă există suspiciune spinală.  **4.** Îndepărtați centura, obstacolele și sticla.  **5.** Folosiți KED/backboard dacă este necesar.  **6.** Extrageți pacientul controlat și predați către EMS.

 4.4.2 **Rapid Extrication (extragere rapidă)**
- Rapid extrication se folosește când pacientul este critic sau scena devine nesigură: cardiac arrest, respiratory failure, shock, hemoragie necontrolată, foc activ sau pericol iminent.    **1.** Mențineți manual cervical stabilization.  **2.** Deschideți ruta cea mai rapidă.  **3.** Transferați pacientul pe backboard cu mișcări coordonate.  **4.** Îndepărtați pacientul din hazard zone și începeți tratamentul.

 4.4.3 **Door Removal (îndepărtarea ușii)**
- **1.** Creați purchase point (punct de prindere) cu Halligan.  **2.** Folosiți spreader pentru a mări spațiul.  **3.** Tăiați hinges (balamalele) sau latch-ul cu cutters.  **4.** Controlați ușa când se desprinde și îndepărtați-o din zona de lucru.

 4.4.4 **Roof Removal (îndepărtarea plafonului)**
- **1.** Îndepărtați sticla necesară cu Glass-Master.  **2.** Tăiați A/B/C pillars conform planului de extrication.  **3.** Protejați pacientul de metal și sticlă.  **4.** Ridicați și mutați plafonul cu minimum doi membri.

 4.4.5 **Dashboard Lift/Roll (ridicarea/deplasarea bordului)**
- **1.** Stabilizați vehiculul.  **2.** Poziționați hydraulic ram între puncte solide.  **3.** Extindeți lent până când picioarele pacientului sunt eliberate.  **4.** Monitorizați permanent pacientul și structura vehiculului.

 4.5 **Aftermath (încheierea scenei)**
- Verificați hazards rămase: focare, scurgeri, sticlă, metal ascuțit.
- Solicitați tow/wrecker prin canalul potrivit.
- Strângeți echipamentul și raportați unitățile clear/back in service către Dispatch.

---

---

**5. PATIENT CARRIES (TRANSPORT MANUAL AL VICTIMELOR)**
---

---

 5.1 **Fireman's Carry (transport pe umăr)**
- Fireman's carry se folosește doar când scena cere evacuare rapidă și nu există suspiciune majoră de spinal injury. Nu este metoda preferată pentru pacienți traumatici stabili.  ``` [SHOW] ```

 5.2 **Hawes Carry (transport Hawes)**
- Hawes carry este o metodă de transport manual pentru mutarea unei victime când echipamentul nu poate ajunge imediat. Folosiți doar dacă beneficiul depășește riscul.  ``` [SHOW] ```

 5.3 **Two-Person Support (transport în doi)**
- Two-person support este mai sigur decât transportul individual și se folosește pentru victime conștiente sau semi-conștiente care pot fi mutate fără agravarea leziunilor.  ``` [SHOW] ```

---
