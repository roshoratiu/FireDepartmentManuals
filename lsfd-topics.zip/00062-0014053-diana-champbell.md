# [#0014053] Diana Champbell

- **Topic ID:** 62
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=62
- **Posts:** 1

---

## #1 — Kellan Dunley

![](https://i.imgur.com/2jlMxHe.png)

TRAINING DIVISION

---

 **DOSAR FIELD TRAINING PROGRAM**
 **FTP Personnel File**
 *Los Santos Fire Department | Training & Professional Development Bureau*

 **— PROFIL TRAINEE —**

 **Nume Complet (IC):** Diana Champbell
 **Rank:** Firefighter
 **Stație Atribuită:** Station 72
 **Data Intrării în FTP:** 22-05-2026 (IC) | 20-05-2026 (OOC)
 **Data Estimată de Finalizare:** 22-06-2026 (IC) | 20-06-2026 (OOC)
 **Număr Dosar:** FTP-[2026]-[0014053]

 **— FIELD TRAINING OFFICER ATRIBUIT —**

 **Nume FTO (IC):** Frent Samson
 **Rank FTO:** Engineer
 **Supervizor Program:** Kellan Dunley | Rank *Deputy Chief*

 **— TRACKER FAZE FTP —**

 *Actualizează simbolul și detaliile la fiecare tranziție de fază.*

 **□ FAZA I — Introduction (Observare)**
 Durată minimă: 1 săptămână operațională
 Data start: [22-05-2026] | Data finalizare: [29-06-2026]
 Zile active: [—] | Status: [Inceputa]

 **□ FAZA II — Operațiuni Asistate**
 Durată minimă: --
 Data start: [—] | Data finalizare: [—]
 Zile active: [—] | Status: [Neîncepută]

 **□ FAZA III — Conducere Controlată**
 Durată minimă: --
 Data start: [—] | Data finalizare: [—]
 Zile active: [—] | Status: [Neîncepută]

 **□ FAZA IV — Evaluare Finală**
 Durată: 1 zi operațională
 Data evaluare: [—]
 Rezultat: [—] | Status: [Neîncepută]

 **— INDEX RAPOARTE DOR —**

 *Adaugă linkul fiecărui DOR postat, în ordine cronologică.
 Format: Ziua # | Faza # | Data | Link*

 **Faza I:**
- Ziua 1 | Faza I | [Data] | [**DOR #1**](https://lsfd.ro-rp.mp/LINK)
- Ziua 2 | Faza I | [Data] | [**DOR #2**](https://lsfd.ro-rp.mp/LINK)
- *— adaugă rânduri pe măsură ce postezi DOR-uri —*

 **Faza II:**
- Ziua 1 | Faza II | [Data] | [**DOR #**](https://lsfd.ro-rp.mp/LINK)
- *— adaugă rânduri pe măsură ce postezi DOR-uri —*

 **Faza III:**
- Ziua 1 | Faza III | [Data] | [**DOR #**](https://lsfd.ro-rp.mp/LINK)
- *— adaugă rânduri pe măsură ce postezi DOR-uri —*

 **Faza IV:**
- Ziua evaluare | Faza IV | [Data] | [**DOR Final**](https://lsfd.ro-rp.mp/LINK)

 **Total DOR-uri postate:** [0]

 **— ISTORIC STRIKE-URI —**

 *Completează fiecare rând la momentul emiterii unui Strike.
 Dacă trainee-ul nu a primit niciun Strike, lasă tabelul cu „Fără sancțiuni înregistrate".*

 **Fără sancțiuni înregistrate.**

 *Model de completare când apare un Strike:*
 *Strike #1 | Nivel I | [Data] | Motiv: [descriere scurtă] | DOR referință: [link]*
 *Strike #2 | Nivel II | [Data] | Motiv: [descriere scurtă] | DOR referință: [link]*

 **Total strike-uri:** [0] | **Nivel I:** [0] | **Nivel II:** [0] | **Nivel III:** [0]

 **— OBSERVAȚII GENERALE FTO —**

 *Secțiune opțională — actualizabilă pe parcurs.
 Notează aici observații generale despre profilul trainee-ului, punctele forte, ariile de îmbunătățire
 sau orice informație relevantă care nu se regăsește în DOR-uri.*

 [Data] — [Observație]
 [Data] — [Observație]

 **— DECIZIE FINALĂ —**

 *Completează această secțiune EXCLUSIV la finalizarea FTP-ului (după Faza IV).*

 **Decizie:** [NECOMPLETATĂ]
 **Justificare:** [—]
 **Data deciziei (IC):** [—]
 **Data deciziei (OOC):** [—]
 **Aprobat de:** [—] | [Rank]
 **Dosar înaintat la Division 6:** [ DA / NU ]

 **— SEMNĂTURĂ FTO —**

 **Dosar deschis de:** Prenume Nume | Rank | LSFD
 **Data deschiderii:** ZZ/LL/AAAA
 **Ultima actualizare:** ZZ/LL/AAAA

 *Dosarul FTP este un document oficial al LSFD — Training & Professional Development Bureau.
 Toate informațiile trebuie să fie complete, corecte și actualizate la zi.
 Falsificarea sau neglijarea deliberată a dosarului constituie conduită gravă.*
---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---
