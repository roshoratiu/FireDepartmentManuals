# CAPITOLUL II – MISIUNEA ȘI PRINCIPIILE FUNDAMENTALE

- **Topic ID:** 32
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=32
- **Posts:** 1

---

## #1 — Kellan Dunley

![](https://i.imgur.com/2jlMxHe.png)

FIREFIGHTER UNION MANUAL

---

 CAPITOLUL II – MISIUNEA ȘI PRINCIPIILE FUNDAMENTALE ALE FIREFIGHTER UNION
---

---

- **(2.1)** Fundamentul moral și instituțional al misiunii Union

---

---

- Misiunea Firefighter Union se bazează pe înțelegerea profundă a responsabilităților și riscurilor pe care pompierii le asumă în fiecare zi. Profesia de pompier este una dintre puținele meserii în care angajatul este chemat să se expună deliberat situațiilor periculoase pentru a proteja vieți, proprietăți și comunități. În acest context, misiunea Union nu reprezintă un simplu set de obiective administrative, ci reflectă angajamentul colectiv al unei organizații construite pe solidaritate, echitate și devotament față de membri.    Sindicatul își asumă rolul de gardian al drepturilor pompierilor, nu pentru a crea un conflict cu administrația, ci pentru a asigura un echilibru instituțional sănătos. O instituție de intervenție care nu are un mecanism intern de protecție a personalului riscă să degradeze performanța operațională, să piardă încrederea publicului și să creeze un mediu de lucru ostil sau imprevizibil. De aceea, misiunea Union reflectă atât valorile profesiei, cât și necesitatea unui parteneriat responsabil între pompieri și conducerea Departamentului.

 -

---

---

- **(2.2)** Obiectivul strategic: protejarea integrității profesionale și personale a membrilor

---

---

- Obiectivul central al misiunii Union este protejarea integrității profesionale și personale a fiecărui membru. Aceasta înseamnă:  • protecție împotriva abuzurilor administrative,  • asigurarea unui proces disciplinar corect,  • promovarea unor condiții de muncă sigure,  • negocierea salariilor și beneficiilor corespunzător riscurilor profesiei,  • sprijin psihologic în situații critice,  • asistarea membrilor în interacțiunile oficiale.    Integritatea profesională nu privește doar capacitatea pompierului de a-și îndeplini atribuțiile, ci și reputația acestuia în interiorul departamentului și în comunitate. Firefighter Union se asigură că niciun membru nu este pus în situația de a-și apăra singur cariera, reputația sau statutul în cazuri disciplinare, incidente mediatizate sau situații administrative complexe.

 -

---

---

- **(2.3)** Principiul solidarității – Fundația oricărui sindicat de pompieri

---

---

- Solidaritatea este valoarea fundamentală a Firefighter Union și se manifestă în toate interacțiunile dintre membri. În intervenții, pompierii depind unii de alții pentru supraviețuire. În viața sindicală, aceeași dependență devine o forță colectivă. Union nu este o entitate abstractă – este suma tuturor membrilor săi, a experiențelor lor, a eforturilor comune și a dorinței de a proteja profesia.    Solidaritatea se reflectă prin:  • sprijin reciproc în fața procedurilor disciplinare,  • unitate în negocierile colective,  • apărarea membrilor vulnerabili,  • participarea activă la voturi și ședințe,  • disponibilitatea de a interveni atunci când un coleg este nedreptățit.    Un sindicat fără solidaritate devine o structură formală fără impact real. Un sindicat în care membrii cooperează, comunică și participă activ devine un partener cu greutate în fața conducerii și a autorităților publice.

 -

---

---

- **(2.4)** Principiul echității și al tratamentului egal

---

---

- Firefighter Union recunoaște că fiecare membru, indiferent de rang, vechime sau specializare, are dreptul la un tratament egal în fața regulilor sindicale și administrative. Echitatea este un principiu care depășește strict cadrul disciplinar – ea trebuie aplicată în promovări, transferuri, evaluări, alocări de resurse și acces la programe de formare.    Sindicatul se opune oricărei forme de favoritism, discriminare sau abuz de autoritate. În toate analizele interne, Union pleacă de la ideea că fiecare membru este prezumat a acționa în spiritul profesiei. Orice încălcare gravă trebuie dovedită prin proceduri clare, nu prin supoziții sau presiuni externe.

 -

---

---

- **(2.5)** Principiul transparenței – Condiție esențială pentru un climat de încredere

---

---

- Transparența este un element definitoriu al misiunii Union. Membrii trebuie să aibă acces clar și neîngrădit la:  • informațiile despre negocieri,  • modul de cheltuire a fondurilor sindicale,  • deciziile interne ale conducerii Union,  • procedurile disciplinare,  • procesele de vot,  • rapoartele anuale.    Secretomania, lipsa de comunicare sau deciziile netransparente slăbesc structura oricărui sindicat. Firefighter Union se angajează să mențină un proces continuu de informare a membrilor, folosind ședințe, comunicate interne, platforme digitale sau întâlniri de stație.

 -

---

---

- **(2.6)** Principiul responsabilității colective și individuale

---

---

- Fiecare membru are responsabilitatea de a contribui la funcționarea corectă a sindicatului, respectând normele etice, participând la voturi și susținând obiectivele comune. În același timp, conducerea Union are responsabilitatea de a acționa în interesul tuturor membrilor, nu al unor grupuri restrânse, de a respecta statutele și de a consulta organizația în toate deciziile majore.    Responsabilitatea colectivă implică:  • participarea activă la dezvoltarea politicilor interne,  • sprijinirea colegilor în nevoie,  • respectarea procedurilor interne.    Responsabilitatea individuală implică:  • menținerea unei conduite profesionale,  • informarea promptă asupra eventualelor abuzuri,  • colaborarea cu reprezentanții sindicali.

 -

---

---

- **(2.7)** Principiul cooperării instituționale cu conducerea Departamentului

---

---

- Un sindicat al pompierilor nu poate funcționa eficient dacă relația cu conducerea este una conflictuală permanent. Misiunea Firefighter Union presupune un echilibru între fermitate și cooperare. Sindicatul este pregătit să conteste decizii nedrepte, dar este în același timp un partener loial în procesul de îmbunătățire a condițiilor de lucru și a procedurilor operaționale.    Cooperarea presupune:  • întâlniri periodice cu Fire Chief și comandanții de stații,  • evaluări ale nevoilor operaționale,  • discuții pe marginea politicilor noi,  • colaborare în formarea personalului.    Această cooperare nu diminuează independența Union, ci îi întărește legitimitatea și capacitatea de influență.

 -

---

---

- **(2.8)** Principiul protecției sănătății fizice și mentale

---

---

- Pompierii se confruntă cu traume cumulative, expunere la stres extrem, pericole chimice și riscuri de accidentare. Misiunea Union include promovarea unui sistem solid de suport psihologic, medical și operațional. Aceasta presupune:  • programe anti-PTSD,  • evaluări periodice ale stării mentale,  • intervenție rapidă în cazuri critice,  • reconversii temporare în roluri non-operative,  • sprijin pentru familiile membrilor afectați.

 -

---

---

- **(2.9)** Misiunea Union ca pilon de stabilitate în cadrul Fire Department

---

---

- În esență, misiunea Firefighter Union este de a asigura stabilitatea internă a întregului Departament. Un departament în care pompierii sunt protejați, respectați și reprezentați corect este un departament eficient și pregătit să răspundă tuturor provocărilor comunitare.    Union nu este o structură de opoziție; este o componentă indispensabilă a echilibrului profesional dintre cultură organizațională, siguranță și performanță operațională.

 -

---
