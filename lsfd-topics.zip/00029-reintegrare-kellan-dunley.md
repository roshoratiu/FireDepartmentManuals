# [REINTEGRARE] Kellan Dunley

- **Topic ID:** 29
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=29
- **Posts:** 1

---

## #1 — Kellan Dunley

![](https://i.imgur.com/2jlMxHe.png)

OFFICE OF THE FIRE CHIEF

---

 FORMULAR DE REINTEGRARE
---

---

- **(1.0)** INFORMAȚII CU CARACTER PERSONAL

---

---

- **(1.1) Nume:** Dunley  **(1.2) Prenume:** Kellan  **(1.3) Adresă:** Mirror Park 113  **(1.4) Număr de telefon:** 0252 77523

 -
---

---

- **(2.0)** INFORMAȚII DESPRE DEMITERE

---

---

- **(2.1) Rang precedent:** Capitan  **(2.2) Tipul demiterii:** Onorabil  **(2.3) Motivul demiterii:** --  **(2.4) Data demiterii:** 15/11/2025  **(2.5) Legătură către demitere:** [ACCES](https://lsfd.ro-rp.mp/LinkDeAcces)

 -
---

---

- **(3.0)** MOTIVAȚIE

---

---

- **(3.1) Ce ocupații ați avut din momentul demiterii până în prezent?:** Sunt inscris la o scoala de calificare profesionala pentru "Sisteme si instalatii de incendiu".    **(3.2) Dacă ați fost demis(ă) neonorabil, specificați motivul sau motivele pentru care Office of the Fire Chief ar lua în considerare cererea dumneavoastră de reintegrare:**     --    **(3.3) De ce doriți să vă reintegrați în Los Santos Fire Department?** (minim 50 de cuvinte)    Doresc sa revin in cadrul Departamentului deoarece solicit un transfer in zona de domiciliu. Doresc sa fiu cat mai aproape de familie, de asta am urmat si cursurile de calificare ale "Los Santos Fire Academy (LSFA)". Sper sa pot obtine o pozitie pe baga calificarii mele .

 -
---

---

- (( **(4.0)** INFORMAȚII OUT OF CHARACTER ))

---

---

- **(4.1) Pe plan Out Of Character, de ce dorești să te reintegrezi în Los Santos Fire Department?:**     Doresc să reiau acest tip de roleplay pe care îl îndrăgesc și pe care l-am practicat de-a lungul timpului. Consider că am experiența necesară pentru a contribui la dezvoltarea facțiunii, pentru a obține performanțe cât mai bune și pentru a aduce un plus acestui tip de RP și departamentului.    **(4.2) Dacă ai fost demis(ă) neonorabil din motive Out Of Character, specifică motivul sau motivele pentru care ar trebui să luăm în considerare cererea ta de reintegrare:** (minim 50 de cuvinte)    --    **(4.3) Acces către contul de forum:** [ACCES](https://forum.ro-rp.mp/index.php?/profile/5-jeanclau/)  **(4.4) În prezent, ești membru al unei alte facțiuni? Dacă da, specifică:** --  **(4.5) Prezintă poze needitate cu Admin Record-ul de pe toate caracterele** (album): [ACCES](https://lsfd.ro-rp.mp/LinkDeAcces)  **(4.6) Prezintă o poză needitată cu /stats de pe caracterul cu care aplici:** ACCES

 -

---
