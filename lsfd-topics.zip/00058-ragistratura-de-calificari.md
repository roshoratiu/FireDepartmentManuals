# Ragistratura de Calificari

- **Topic ID:** 58
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=58
- **Posts:** 1

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

Training & Professional

---

 **QUALIFICATIONS REGISTRY**
 Los Santos Fire Department - Training & Professional Development
 Registru oficial al calificarilor disponibile in LSFD, organizate pe divizii si niveluri TIER.

**CUM SE OBTINE O CALIFICARE**

 **1.** Contacteaza **Division 6: Training & Professional Development** si specifica calificarea dorita.
 **2.** **Division 6** verifica eligibilitatea ta si te contacteaza cu cerintele, programul de instruire si metoda de evaluare.
 **3.** Parcurgi instruirea si evaluarea conform planului stabilit.
 **4.** La finalizare, **Certification Officer** inregistreaza oficial calificarea in dosarul tau de personal.

**CORE OPERATIONS - Primary Operations Bureau**

-
- **Basic Life Support (BLS)** - obligatoriu pentru toti membrii.
- **Fire Suppression (Fire 1)** - obligatoriu pentru toti membrii.
- **Vehicle Extrication** - necesar pentru Firefighter.
- **Rope Rescue** - necesar pentru Firefighter.
- **Apparatus Driver** - necesar pentru Firefighter.
- **Fire 2** - necesar pentru Firefighter.
- **Interior Operations** - necesar pentru Engineer.
- **Pump Operations** - necesar pentru Engineer.
- **Fire 3** - necesar pentru Engineer.
- **Incident Command System (ICS)** - necesar pentru Engineer / Lieutenant.
- **Advanced Rescue Qualification** - calificare avansata de rescue.

**PRIMARY OPERATIONS - Specializari**

-
- **Fire Attack Specialist** - necesar pentru Engineer.
- **Engine Operator** - necesar pentru Engineer.
- **Ventilation Specialist** - necesar pentru Engineer.
- **Heavy Rescue Technician** - necesar pentru Engineer.
- **Rope Rescue Operator** - necesar pentru Engineer.
- **Crash Response Specialist** - necesar pentru Engineer.
- **Apparatus Engineer** - necesar pentru Engineer.
- **Incident Safety Officer** - necesar pentru Lieutenant.
- **Operations Coordinator** - necesar pentru Lieutenant.

**EMERGENCY MEDICAL**

-
- **Emergency Medical Technician (EMT)** - necesar pentru Paramedic.
- **Field Medic** - necesar pentru Paramedic.
- **Advanced Life Support (ALS) - Critical Care Provider** - necesar pentru Paramedic.

**DIV. 2 - HAZMAT, SPECIAL OPERATIONS & DISASTER RESPONSE**

-
- **TIER I** - Hazmat Operations.
- **TIER I** - Decontamination Specialist.
- **TIER II** - Hazmat Technician.
- **TIER II** - Hazmat Entry Technician.
- **TIER II** - Hazmat Equipment Officer.
- **TIER III** - CBRN Response Officer.
- **TIER IV** - HSOD Coordinator (Division Lead).

**DIV. 3 - WILDLAND & ENVIRONMENTAL OPERATIONS**

-
- **TIER I** - Wildland Firefighter - Type 2.
- **TIER II** - Wildland Firefighter - Type 1.
- **TIER III** - Wildland Engine Operator.
- **TIER III** - Wildland Helitack.
- **TIER III** - Environmental Response Specialist.
- **TIER IV** - Wildland Incident Commander.
- **TIER IV** - Wildland Operations Coordinator (Division Lead).

**DIV. 4 - WATER RESCUE OPERATIONS**

-
- **TIER I** - Water Rescue Awareness.
- **TIER II** - Swift Water Rescue Technician.
- **TIER II** - Marine Operations Specialist.
- **TIER II** - Ice Rescue Technician.
- **TIER II** - Flood Response Operator.
- **TIER III** - Dive Rescue Technician.
- **TIER IV** - Water Rescue Coordinator (Division Lead).

**DIV. 5 - FIRE INVESTIGATION & PREVENTION**

-
- **TIER I** - Fire Safety Officer.
- **TIER I** - Public Education Officer.
- **TIER II** - Fire Inspector.
- **TIER III** - Fire Investigator.
- **TIER III** - Arson Investigator.
- **TIER III** - Fire Marshal.
- **TIER IV** - Fire Prevention Chief (Division Lead).

**DIV. 6 - TRAINING & PROFESSIONAL DEVELOPMENT**

-
- **TIER I** - Field Training Officer (FTO), necesar si pentru Lieutenant.
- **TIER II** - Fire Instructor.
- **TIER II** - Academy Instructor.
- **TIER II** - Certification Officer.
- **TIER II** - Scenario Designer.
- **TIER II** - Skills Development Instructor.
- **TIER III** - FTO Coordinator.
- **TIER III** - Senior Academy Instructor.
- **TIER III** - Curriculum Developer.
- **TIER III** - Academy Director.
- **TIER IV** - Training Division Chief (Division Lead).

**DIV. 7 - FLEET, LOGISTICS & COMMUNICATIONS**

-
- **TIER I** - Fleet Technician / Dispatcher.
- **TIER II** - Senior Fleet Technician.
- **TIER II** - Supply Officer.
- **TIER II** - Facilities Coordinator.
- **TIER III** - Lead Dispatcher.
- **TIER III** - Fleet Manager.
- **TIER III** - Communications Manager.
- **TIER IV** - Support Services Chief (Division Lead).

**DIV. 8 - ADMINISTRATION & HUMAN RESOURCES**

-
- **TIER I** - HR Assistant / Records Assistant.
- **TIER II** - Human Resources Officer.
- **TIER II** - Recruitment Coordinator.
- **TIER II** - Employee Relations Officer.
- **TIER II** - Records Management Officer.
- **TIER III** - Internal Affairs Officer.
- **TIER III** - Public Information Officer (PIO).
- **TIER IV** - Administrative Services Chief (Division Lead).

---
