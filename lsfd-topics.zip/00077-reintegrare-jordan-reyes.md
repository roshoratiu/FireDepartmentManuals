# Reintegrare Jordan Reyes

- **Topic ID:** 77
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=77
- **Posts:** 1

---

## #1 — Jordan Reyes

**![Image](https://i.imgur.com/2jlMxHe.png)

 OFFICE OF THE FIRE CHIEF**

 FORMULAR DE REINTEGRARE
 (1.0) INFORMAȚII CU CARACTER PERSONAL
 (1.1) Nume: Reyes
 (1.2) Prenume: Jordan
 (1.3) Adresă: Los Santos
 (1.4) Număr de telefon: N/A
 -
 (2.0) INFORMAȚII DESPRE DEMITERE
 (2.1) Rang precedent: Shift Supervisor
 (2.2) Tipul demiterii: Onorabila
 (2.3) Motivul demiterii: Probleme personale
 (2.4) Data demiterii: 14.07.2026
 (2.5) Legătură către demitere: ACCES
 -
 (3.0) MOTIVAȚIE
 (3.1) Ce ocupații ați avut din momentul demiterii până în prezent?:
 Am fost plecat din San Andreas la părinții mei care trăiesc în North Yankton; ei au avut mari probleme și cu banca, dar și cu familia. Recent a decedat bunicul meu, iar părinții mei erau foarte triști și nu se mai descurcau; ei aveau probleme zi de zi și aveau nevoie de mine alături de ei.

 (3.2) Dacă ați fost demis(ă) neonorabil, specificați motivul sau motivele pentru care Office of the Fire Chief ar lua în considerare cererea dumneavoastră de reintegrare: (minim 50 de cuvinte)

 Răspunde aici.

 (3.3) De ce doriți să vă reintegrați în Los Santos Fire Department? (minim 50 de cuvinte)
 Eu îmi doresc să mă reintegrez în Los Santos Fire Department pentru că aici am fost toată viața mea și asta îmi doresc să fac în continuare; acesta a fost primul meu job și vreau să fie în continuare. Pur și simplu m-am îndrăgostit de acest job, de la situațiile de stres și situațiile amuzante alături de colegii mei, eu nu vreau să pierd așa ceva. Am fost plecat o perioadă la părinții mei, dar acum că totul s-a rezolvat, eu mă pot întoarce în Los Santos Fire Department fără nicio problemă și chiar îmi doresc asta.
 -
 (( (4.0) INFORMAȚII OUT OF CHARACTER ))
 (4.1) Pe plan Out Of Character, de ce dorești să te reintegrezi în Los Santos Fire Department?: (minim 50 de cuvinte)
 Eu chiar îmi doresc asta pentru că sunt pasionat de tot ce ține de Pompieri/LSFD etc. și m-am îndrăgostit de acest job; eu chiar mă regăsesc aici și chiar vreau să continui roleplay-ul în LSFD fără probleme. Eu am parte de momente destul de faine în LSFD, momente pe care nu o să le uit niciodată.

 (4.2) Dacă ai fost demis(ă) neonorabil din motive Out Of Character, specifică motivul sau motivele pentru care ar trebui să luăm în considerare cererea ta de reintegrare: (minim 50 de cuvinte)

 ----

 (4.3) Acces către contul de forum: ACCES
 (4.4) În prezent, ești membru al unei alte facțiuni? Dacă da, specifică: Răspunde aici.
 (4.5) Prezintă poze needitate cu Admin Record-ul de pe toate caracterele (album): ACCES
 (4.6) Prezintă o poză needitată cu /stats de pe caracterul cu care aplici: ACCES
 -

---
