# SQUAD - Handbook

- **Topic ID:** 15
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=15
- **Posts:** 1

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

SQUAD

---

---

---

**1. INSTRUMENTE ȘI ECHIPAMENTE**

---

---

 Echipa este echipată cu următoarele:

- **[Halligan Bar](https://m.media-amazon.com/images/I/317RxbNBPxL.jpg)** - Folosit pentru a trage, lira, puncție, răsuciți, îndepărtați și tăiați deschide orice și toate tipurile de bariere /obstrucții.
- **[Firaxe](http://www.zeelandtwp.org/portals/0/ZCTFD/Images/FireAxe.jpg)** - Folosit pentru a dărâma pereții/ușile sau pentru a reduce obstacolele.
- **[Cut off saw](http://www.unifireusa.com/images/prodImages/uf-k960-14.jpg)** - Capabil să taie prin materiale de construcție (acoperișul unei clădiri, metal etc)
- **[Chainsaw](http://firesafetyplus.com/images/ventmaster-22.jpg)** - Folosit pentru a tăia prin materiale din lemn.
- **[Ferăstrău recipring](https://paulhasenmeier.files.wordpress.com/2011/11/sawzalltool.jpg)** - Folosit pentru a tăia prin sticlă și oțel, de exemplu, un parbriz și țevi de oțel.
- **[Set portabil de torță](http://www.northerntool.com/images/product/2000x2000/171/171742_2000x2000.jpg)**
- **[Come-a-long](https://i5.walmartimages.com/asr/b78b6109-7adf-4777-b690-ddba654c6669.59f5790901c6584434fbc37d554b61d7.jpeg?odnWidth=612&odnHeight=612&odnBg=ffffff)**
- **[Winch](http://www.bmsrescue.com/winch1.jpg)**
- **[Materiale cribbing](https://paulhasenmeier.files.wordpress.com/2011/12/2011-12-02_13-28-39_326.jpg)**
- **[Lanțuri și cârlige](http://www.teamrescuestore.com/images/Rescue-Chain-THR6.jpg)**
- **Material de urcare:**  - **[Carabiners](http://blog.weighmyrack.com/wp-content/uploads/2014/08/Omega-Pacific-Tephra-Vulcan-Carabiners.jpg)** - **[Rope](https://cdn.webshopapp.com/shops/263124/files/205077329/450x450x2/climbing-rope-30mm-ring.jpg)** - **[Harness](http://ww1.prweb.com/prfiles/2013/08/29/11076851/gI_132994_Gemtor-543-harness.jpg)** - **[Scripete](http://i00.i.aliimg.com/wsphoto/v0/1426779150/-font-b-Climbing-b-font-font-b-Scripete-b-font-font-b-scripete-b-font.jpg)**
- [**Further covers**](http://i21.geccdn.net/site/images/n-picgroup/88480.jpg)- Folosit pentru a acoperi materiale pentru a obține deteriorate (în continuare)
- [**Hydrant Tool**](http://i.imgur.com/VzqeKcs.jpg)- Pentru deschiderea unui hidrant regulat și atașarea furtunului.
- [**X-collar**](https://cdn.webshopapp.com/shops/275773/files/253252235/800x1024x2/x-collar-nexsplint-nexsplint-plus-neck-splint.jpg) Folosit pentru a imobiliza gâtul pentru a preveni alte leziuni.
- [**Kendrick's Extraction Device**](http://i.imgur.com/q3kLp9i.jpg)- Extrageți oameni din vehicule / zona lui, prevenirea leziunilor gâtului și spatelui, asigurarea gâtului, capului și spatelui.
- [**Glas-Master**](http://i.imgur.com/qNZn0Ts.jpg) - Spargerea sticlei, tăierea sticlei (gândiți-vă la MVA etcetera)
- [**Cutting Pliers**](https://img.everychina.com/nimg/3c/9f/84075a04606c81d8a0374fa2c471-600x600-0/high_strength_bc360_electric_hydraulic_cutting_pliers_fire_fighting_equipment.jpg)Folosit pentru a tăia cablurile, de exemplu cablurile bateriei.
- [**Spreader-Cutters**](http://i.imgur.com/0GGu9Aa.jpg) - Atât un spreader și cutter într-unul. Se utilizează pentru a trage bucăți dintr-o ușă (de exemplu, o ușă) sau poate fi utilizat pentru a tăia un vehicul (de exemplu, stâlpii acestuia).
- [**Berbeci hidraulici**](http://i.imgur.com/TbPpHM0.jpg)- Funcția berbecului este de a îndepărta secțiuni ale mașinii (sau altă structură), de exemplu tabloul de bord al unui vehicul.
- [**Rescue Tripod**](http://g03.s.alicdn.com/kf/HT115cPFOtXXXagOFbX0/221018167/HT115cPFOtXXXagOFbX0.jpg)- Folosit pentru a ridica oamenii din spații înguste și poate fi attatched la KED și backboards.
- [**Airbag gonflabil**](http://i.imgur.com/UJKAuE1.jpg)- Pentru a ridica echipamente grele din drum (cum ar fi o masina, copac etcetera).
- [**Jump Pad**](http://i.imgur.com/QU6CFdG.jpg)- Pentru a lăsa oamenii să sară pe ea atunci când sunt la mare altitudine, fără a fi rănit.
- [**Tije de stabilizare**](http://i.imgur.com/JJrWEew.jpg)- Folosit pentru astabiliza un vehicul răsturnat.

---

---

**2. ECHIPA DE INTERVENȚIE RAPIDĂ (RIT)**
---

---

 Echipa de Intervenție Rapidă este formată din cel puțin 2 pompieri și este dedicată exclusiv căutării și salvării. Această echipă este configurată de comandantul incidentului și sunt desfășurate atunci când comenzile IC.

 2.1 **Rescue**
- Rescue rămâne cea mai mare prioritate. În timpul dimensiunea scenei până IC poate determina în ce moment acest lucru trebuie să aibă loc. De exemplu, atunci când se confirmă că o persoană este prinsă în clădire, acest punct va ridica scara. În cazul în care vecinii sau proprietarii în sine confirma toată lumea este contabilizat, acest punct se va face într-o etapă ulterioară în timpul căutării regulate primare și secundare și amenințarea termică a fost redusă. În acest timp lucrăm cu sistemul VEIS explicat mai jos.    2.1.1 **Vent** - Ventilarea este o parte importantă și în lupta împotriva unui incendiu. Ventilația permite fumului să iasă și să permită oxigenului să intre în cameră. Acest lucru ar putea arata contrar ca noi, de obicei, ar trebui să prevină oxigen suplimentar pentru a încuraja focul. Cu toate acestea, aceasta este o operațiune de salvare și victima este în ăspăt și fumul este umplerea camerei, prin urmare, vom ventila camera.  - **1.** Utilizați o scară la sol în cazul în care este la etajul al doilea sau mai mare.  **2.** Uita-te prin fereastra pentru a arunca o privire la condițiile actuale în interiorul camerei.   **3.** Dacă este sigur, sparge fereastra cu bara halligan / topor, eliminarea toate piesele ascuțite de la margine.   2.1.2 **Enter** - **4.** După ce ați ventilat, utilizați bara halligan / topor pentru a vă asigura că podeaua este suficient de stabil pentru a intra prin lovirea-l pe podea.  **5.** Intrați în cameră dacă este sigură.  **6.** Faceți o primă privire rapidă în jurul camerei (dacă este posibil cu camera termică).   2.1.3 **Izolează** - **7.** Următorul lucru pe care trebuie să-l faceți la intrare este să căutați uși deschise. Puteți utiliza o lanternă sau camera termică vă ajută cu acest lucru.  **8.** Odată ce ați găsit o ușă deschisă, asigurați-vă că o închideți pentru a îndepărta calea de curgere.   2.1.4 **Search** - **9.** Ultimul pas al salvării este de a matura în jurul camerei pentru orice victime. Asigurați-vă că vă târâți și stați cât mai jos posibil.   **10.** În cazul în care victima este găsită, trageți-o spre ieșire (sau fereastră dacă etajul al doilea sau mai mare) și coborâți-o pe scara de la sol.   **11.** Dacă nu ați maturat încă întreaga cameră, continuați căutarea.

 2.2 **Salvage**
- Dacă o clădire nu este implicată pe deplin, RIT poate începe, de asemenea, să reducă daunele aduse proprietății (de exemplu, daunele aduse fumului și apei). Acest lucru se poate face pur și simplu prin plasarea capacelor de salvare sau prin începerea copartamentalizării pe măsură ce vă deplasați prin structură prin închiderea unei uși deschise.

---

---

**3. ATAC INTERIOR**
---

---

 Pe lângă căutările sistematice, Echipa este responsabilă și de stingerea incendiilor. Din cauza condițiilor atmosferice periculoase din interiorul structurii, pompierii echipei de atac interior vor trebui să poarte kiturile SCBA. Nu trebuie să fie cel puțin două persoane în echipă, și ei trebuie să rămânem împreună în orice moment ("doi-in, doui-out" politica / sistem de prieteni) - unul este un hoseman (cineva care controlează furtunul), iar celălalt este un humper (cineva care ghidează furtunul și ajută hoseman în transport). Atunci când se formează o echipă de atac interior, indicativul prin radio va fi, pur și simplu, "Atac unu, interior unu" (sau doui, în funcție de numărul de echipe desfășurate). Rămâneți în contact permanent cu Comandantul incidentului (IC) și, cel mai important, **RĂMÂNEȚI CU ECHIPA DVS**.!

- **1.** Comandantul incidentului ar trebui să atribuie oamenii echipei, în cadrul misiunilor echipei vor fi date.   **2.** Asigurați-vă că aveți SCBA gata și înființat.  **3.** Asigurați-vă că verificați toate ușile atunci când sunteți în interiorul clădirii, sau pe cale de a intra într-o clădire. Glisați mâinile pe părți, simțiți dacă este cald sau nu. Dacă nu e cald, poți deschide încet ușa și să verifici înăuntru. Dacă este cald, stai cu spatele spre ușă și deschide-o încet, nu te uita la ușă. Numără de la 0 la 3 și apoi verifică înăuntru de ce e atât de cald. Dacă s-a găsit un incendiu, asigură-te că stingi asta. Când focul este încetinit, se deplasează mai aproape pentru a face o stingere completă. Asigurați-vă că pentru a raporta acțiunile dumneavoastră la IC.  **4.** Dacă ușa nu se deschide corect și se găsește căldură, încercați să găsiți o altă cale. Dacă nu există nici o altă cale, sparge ușa cu un topor de incendiu, doar încercați să vă asigurați că veți rămâne în siguranță. Cele mai multe ori există alte uși sau ferestre, precum și în cazul în care puteți face intrarea, face o prioritate în acest sens.  **5.** Fiți conștienți de [backdrafts](https://www.youtube.com/watch?v=U4otd1Ron-0) atunci când sunteți deschiderea unei uși și de [flashovers](https://www.youtube.com/watch?v=QqMVm72FMRk) atunci când sunteți în interiorul unei clădiri.  **6.** În timp ce acționați în interiorul clădirii, asigurați-vă că verificați pereții și podeaua pentru a vă asigura că totul este stabil, utilizați mâinile și picioarele pentru acest lucru, în cazul în care este instabil, raport în și îndepartați-vă de părțile instabile. **Siguranța proprie mai întâi**.  **7.** În timp ce faci verificare, faci etaj cu etaj, astfel încât primul etaj e prioritar înainte de a trece la etajul al doilea, dacă există.  **8.** Nu pulverizați direct pe un foc, ci puțin deasupra lui, astfel încât apa să cadă pe el. Când este mai sigur, puteți să vă apropiați și să-l stingeți complet (Pasul 3)  **9.** Când găsiți o persoană în timp ce faci de intervenție, asigurați-vă că iț extragi și raportezi la IC, astfel încât echipa medicală va fi conștientă de victimă.  **10.** Odată ce focul este stins și intervenția dumneavoastră este completă, asigurați-vă raportați acest lucru în la Incident Commander.

---
