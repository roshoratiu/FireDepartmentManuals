# [18052050] Victoria Anderson

- **Topic ID:** 59
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=59
- **Posts:** 1

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

 Administrative & Support

---

 **PATIENT CARE REPORT**
 Los Santos Fire Department · Emergency Medical Services

**I — INFORMAȚII GENERALE**

- **PERSONAL:** Lieutenant Sybil Gale  **UNITATE:** RA-07  **DISPECERAT:** 911  **ORA SOSIRII:** 18/MAI/2026 20:40  **ORA ÎNCHEIERII:** 18/MAI/2026 21:15  **REZULTAT:** Refuz - Pacientă a refuzat transportul și a semnat formularul de refuz

**II — DATE PACIENT**

- **NUME:** Victoria Anderson  **VÂRSTĂ:** Necunoscută  **SEX:** Femeie  **RASĂ:** Necunoscută  **ALERGII:** NKDA

**DECES — completați numai dacă este cazul**

- — Nu este cazul —

**III — PREJUDICIU & EVALUARE**

- **PREJUDICIU:** Fractură suspectată la nivelul mâinii stângi, echimoze și eritem difuz pe fața dorsală și palmară a mâinii stângi  **LOCAȚIA RĂNII:** Membrul superior stâng - mâna stângă  **MECANISMUL PREJUDICIULUI:** Fizic - traumatism prin cădere accidentală

**IV — SEMNE VITALE**

- **ORA:** 20:42 | **PULS:** 94 bpm | **RESP:** 17/min | **T.A.:** 134/82 mmHg | **LOC-AVPU:** A  **ORA:** 20:52 | **PULS:** 88 bpm | **RESP:** 16/min | **T.A.:** 128/78 mmHg | **LOC-AVPU:** A

**V — MEDICAȚIE ADMINISTRATĂ**

- **MEDICAMENT:** Demerol (Meperidină)  **DOZĂ:** 50 mg  **METODĂ:** IM - administrat la 20:48, anterior aplicării atelei de vid

**VI — NARAȚIUNE**

- La ora 20:40, unitatea RA-07 a sosit la fața locului în urma unui apel 911. La evaluarea inițială, pacienta Victoria Anderson a fost identificată conștientă și alertă, prezentând durere acută la nivelul mâinii stângi în urma unei căderi accidentale. S-au observat echimoze și eritem difuz pe fața dorsală și palmară a mâinii stângi, cu sensibilitate marcată la palpare și impotență funcțională - suspiciune de fractură.    La ora 20:48, anterior imobilizării, s-a administrat Demerol 50mg pe cale intramusculară pentru managementul durerii. Ulterior s-a aplicat atelă de vid la nivelul mâinii stângi, cu imobilizare corespunzătoare. Pacienta a prezentat un comportament verbal agresiv pe toată durata intervenției, refuzând cooperarea și transportul la spital.    La ora 21:00, din cauza comportamentului pacientei și a riscului de escaladare, Lieutenant Gale a contactat LSPD prin radio departamental solicitând suport la scenă. În prezența ofițerilor LSPD, Victoria Anderson a semnat formularul de refuz al transportului medical și a părăsit scena pe cont propriu, în stare stabilă, cu mâna imobilizată.    Pacienta a fost informată cu privire la riscurile asociate refuzului de transport și a primit recomandarea de a se prezenta la o unitate medicală pentru investigații radiologice.

 Semnat,
 Lieutenant Sybil Gale

---
