# FORMULAR DE TRANSFER

- **Topic ID:** 8
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=8
- **Posts:** 2

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

OFFICE OF THE FIRE CHIEF

---

 FORMULAR DE REINTEGRARE
---

---

- **(1.0)** INFORMAȚII CU CARACTER PERSONAL

---

---

- **(1.1) Nume:** Răspunde aici.  **(1.2) Prenume:** Răspunde aici.  **(1.3) Adresă:** Răspunde aici.  **(1.4) Număr de telefon:** Răspunde aici.

 -
---

---

- **(2.0)** INFORMAȚII DESPRE DEPARTAMENT

---

---

- **(2.1) Rang actual:** Răspunde aici.  **(2.2) Department:** Răspunde aici.  **(2.3) Adresa departament:** Răspunde aici.

 -
---

---

- **(3.0)** MOTIVAȚIE

---

---

- **(3.1) De ce doriti transferul in Los Santos Fire Department?:**  - Raspunde aici.   **(3.2) Cu ce credeti ca puteti ajuta departamentul daca am accepta cererea de transfer?:**  - Raspunde aici.

 -
---

---

- (( **(4.0)** INFORMAȚII OUT OF CHARACTER ))

---

---

- **(4.1) Discord:**      **(4.2) Prezinta un character background al caracterului tau:** (minim de 100 de cuvinte, 2 paragrafe)   ``` [SHOW]Raspunde aici ```     **(4.3) Acces către contul de forum:** [ACCES](https://lsfd.ro-rp.mp/LinkDeAcces)  **(4.4) În prezent, ești membru al unei alte facțiuni? Dacă da, specifică:** Răspunde aici.  **(4.5) Prezintă poze needitate cu Admin Record-ul de pe toate caracterele** (album): [ACCES](https://lsfd.ro-rp.mp/LinkDeAcces)  **(4.6) Prezintă o poză needitată cu /stats de pe caracterul cu care aplici:** [ACCES](https://lsfd.ro-rp.mp/LinkDeAcces)  **(4.7) Prezentati experienta dumneavoastra OOC in cadrul Fire Derpartment de pe orice server roleplay:**    ``` [SHOW]Raspunde aici ```

 -

---

## #2 — Aisha Dubois

Titlu:
```
[TRANSFER] Nume Prenume sau (([TRANSFER] Nume Prenume ))
```

 Cod:
```
[birou=OFFICE OF THE FIRE CHIEF white]

[size=150][center]FORMULAR DE REINTEGRARE[/center][/size]
[hr][/hr]
[list=none][size=120][b](1.0)[/b] INFORMAȚII CU CARACTER PERSONAL[/size][/list]
[hr][/hr]
[list=none]
[b](1.1) Nume:[/b] Răspunde aici.
[b](1.2) Prenume:[/b] Răspunde aici.
[b](1.3) Adresă:[/b] Răspunde aici.
[b](1.4) Număr de telefon:[/b] Răspunde aici.
[/list]
[color=#FFFFFF]-[/color]
[hr][/hr]
[list=none][size=120][b](2.0)[/b] INFORMAȚII DESPRE DEPARTAMENT[/size][/list]
[hr][/hr]
[list=none]
[b](2.1) Rang actual:[/b] Răspunde aici.
[b](2.2) Department:[/b] Răspunde aici.
[b](2.3) Adresa departament:[/b] Răspunde aici.
[/list]
[color=#FFFFFF]-[/color]
[hr][/hr]
[list=none][size=120][b](3.0)[/b] MOTIVAȚIE[/size][/list]
[hr][/hr]
[list=none]
[b](3.1) De ce doriti transferul in Los Santos Fire Department?:[/b]
[list=none]Raspunde aici.[/list]
[b](3.2) Cu ce credeti ca puteti ajuta departamentul daca am accepta cererea de transfer?:[/b]
[list=none]Raspunde aici.[/list]

[/list]
[color=#FFFFFF]-[/color]
[hr][/hr]
[list=none][size=120](( [b](4.0)[/b] INFORMAȚII OUT OF CHARACTER ))[/size][/list]
[hr][/hr]
[list=none]
[b](4.1) Discord:[/b]

[b](4.2) Prezinta un character background al caracterului tau:[/b] (minim de 100 de cuvinte, 2 paragrafe)

[spoiler]Raspunde aici[/spoiler]

[b](4.3) Acces către contul de forum:[/b] [url=LinkDeAcces]ACCES[/url]
[b](4.4) În prezent, ești membru al unei alte facțiuni? Dacă da, specifică:[/b]  Răspunde aici.
[b](4.5) Prezintă poze needitate cu Admin Record-ul de pe toate caracterele[/b] (album): [url=LinkDeAcces]ACCES[/url]
[b](4.6) Prezintă o poză needitată cu /stats de pe caracterul cu care aplici:[/b] [url=LinkDeAcces]ACCES[/url]
[b](4.7) Prezentati experienta dumneavoastra OOC in cadrul Fire Derpartment de pe orice server roleplay:[/b]

[spoiler]Raspunde aici[/spoiler]

[/list]
[color=#FFFFFF]-[/color]

[/birou]
```

---
