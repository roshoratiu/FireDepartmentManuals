# Manual OTP

- **Topic ID:** 53
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=53
- **Posts:** 1

---

## #1 — Kellan Dunley

![](https://i.imgur.com/2jlMxHe.png)

OFFICE OF THE FIRE CHIEF

---

 **PROGRAMUL DE FORMARE A OFIȚERILOR (OTP)**
 **MANUAL OFICIAL**
 Departamentul de Pompieri din Los Santos
 *Biroul de Instruire și Dezvoltare Profesională*

 *„Un ofițer nu este cineva care dă ordine — este cineva care poartă responsabilitatea fiecărei decizii luate sub comanda sa. Rangul nu este un privilegiu. Este o datorie."*
 — Training & Professional Development Bureau, LSFD

 **RESURSE DEPARTAMENTALE**

 [**➤ Manual FTP — Field Training Program**](https://lsfd.ro-rp.mp/URL) [**➤ Manual of Operations (MOP)**](https://lsfd.ro-rp.mp/URL) [**➤ Ierarhia Rankurilor & Jurământul**](https://lsfd.ro-rp.mp/URL) [**➤ Incident Command System (ICS)**](https://lsfd.ro-rp.mp/URL)

 **CUPRINS**

1. Introducere
2. Scopul Programului OTP
3. Condiții de Eligibilitate și Acces
4. Structura Programului
5. Fazele OTP
6. Ofițerul Supervizor (Mentorul OTP)
7. Responsabilitățile Candidatului
8. Sistemul de Evaluare — Officer Performance Report (OPR)
9. Sistemul de Sancțiuni și Retragere din Program
10. Evaluarea Finală
11. Absolvirea și Promovarea
12. Excluderea din Program
13. Standarde de Conduct și Profesionalism Ofițeresc
14. Autoritatea și Responsabilitățile Rank-ului de Lieutenant
15. Dispoziții Finale

 **1. INTRODUCERE**

 **1.1 Definiție și Context**

 Programul de Formare a Ofițerilor (**Officer Training Program — OTP**) reprezintă etapa obligatorie de tranziție pe care orice candidat la rangul de **Lieutenant** în cadrul Los Santos Fire Department trebuie să o parcurgă și să o finalizeze cu succes. OTP-ul nu este o continuare a Field Training Program — este un program de calibru fundamental diferit, conceput pentru a transforma un pompier experimentat și dovedit într-un lider operațional capabil să poarte responsabilitatea comenzii.

 Dacă FTP-ul transformă un recrut în pompier, OTP-ul transformă un pompier în ofițer. Diferența nu este de grad — este de mentalitate, responsabilitate și scop. Un Probationary Firefighter urmează instrucțiuni. Un Lieutenant le dă. Un FTP evaluează supraviețuirea operațională individuală. OTP-ul evaluează capacitatea de a conduce, coordona și decide în numele altora.

 Participarea la OTP nu este deschisă oricărui membru al departamentului. Candidații sunt selectați pe baza unor criterii stricte de eligibilitate, iar programul în sine este riguros, complex și deliberat solicitant. Acesta reflectă gravitatea responsabilităților pe care un Lieutenant le va purta imediat după promovare.

 **1.2 Contextul Ierarhic**

 Conform structurii operaționale a LSFD, **Lieutenant-ul** reprezintă primul rang de ofițer al departamentului — prima linie de leadership operațional direct. Lieutenantul conduce echipe mici, operează ca Assistant Incident Commander, coordonează aparatele de intervenție și preia comanda stației în absența Căpitanului. Responsabilitățile sale se extind dincolo de propria performanță individuală: el este răspunzător pentru performanța, siguranța și conduita întregii echipe pe care o conduce.

 Această realitate este miza OTP-ului: nu formarea unui pompier mai bun, ci formarea unui lider capabil să protejeze viețile celor din subordinea sa.

 **1.3 Statut Obligatoriu**

 **Niciun membru al LSFD nu poate fi promovat la rangul de Lieutenant fără finalizarea cu succes a Programului de Formare a Ofițerilor.**

 Această regulă nu admite excepții. Experiența operațională extinsă, reputația profesională sau alte merite personale nu pot substitui parcurgerea formală și completă a OTP-ului.

 **2. SCOPUL PROGRAMULUI OTP**

 **2.1 Obiective Principale**

 Programul de Formare a Ofițerilor a fost instituit pentru a îndeplini o serie de obiective fundamentale, distincte față de cele ale FTP-ului:

 **a) Formarea mentalității de lider**
 Tranziția de la rolul de Firefighter la cel de Lieutenant implică o schimbare profundă de perspectivă. Candidatul trebuie să internalizeze faptul că responsabilitatea sa nu mai este limitată la propria sa performanță individuală — ci se extinde asupra întregii echipe pe care o conduce. OTP-ul construiește această mentalitate sistematic, prin expunere progresivă la scenarii de comandă și responsabilitate.

 **b) Dezvoltarea competenței în Incident Command**
 Lieutenantul acționează ca Assistant Incident Commander și, în absența Căpitanului, preia comanda completă a scenei. OTP-ul testează și consolidează capacitatea candidatului de a aplica principiile Incident Command System (ICS) în condiții reale, cu resurse limitate și presiune temporală maximă.

 **c) Formarea abilităților de management al personalului**
 Un ofițer nu gestionează incidente — gestionează oameni. OTP-ul dezvoltă capacitatea candidatului de a superviza echipajul, de a oferi feedback constructiv, de a identifica și adresa problemele de performanță și de a mentora membrii mai puțin experimentați ai echipei.

 **d) Înțelegerea responsabilităților administrative**
 Rangul de Lieutenant implică o componentă administrativă semnificativă: redactarea rapoartelor de incident, gestionarea documentației de personal, coordonarea programărilor de tură și comunicarea formală cu Căpitanul stației. OTP-ul expune candidatul la toate aceste responsabilități într-un cadru supervizat.

 **e) Consolidarea cunoașterii și aplicării SOP/MOP**
 Lieutenantul este responsabil pentru respectarea procedurilor de operare standard atât de propria persoană, cât și de membrii echipajului său. OTP-ul testează profunzimea cunoașterii MOP-ului, capacitatea de a interpreta situații ambigue prin prisma procedurilor și de a lua decizii conforme cu politicile departamentului.

 **f) Evaluarea integrității și judecății morale sub presiune**
 Pozițiile de comandă implică decizii dificile în momente critice. OTP-ul evaluează nu doar competența tehnică a candidatului, ci și capacitatea sa de a acționa cu integritate, corectitudine și transparență chiar și atunci când situația este ambiguă sau presiunea este extremă.

 **g) Validarea pregătirii pentru leadership independent**
 Scopul final al OTP-ului este certificarea faptului că un candidat este pregătit să poarte insigna de Lieutenant fără a pune în pericol siguranța echipajului, eficiența operațiunilor sau reputația departamentului.

 **2.2 OTP ca Standard de Calitate Instituțional**

 OTP-ul nu există doar în beneficiul candidaților individuali. El există pentru a proteja standardele de calitate ale întregului departament. Fiecare Lieutenant care poartă insigna LSFD este, în esență, o reflecție a standardelor pe care departamentul le-a aplicat prin OTP. Un ofițer slab format nu pune în pericol doar propria carieră — pune în pericol viețile membrilor echipajului și eficacitatea operațiunilor la care participă.

 **3. CONDIȚII DE ELIGIBILITATE ȘI ACCES**

 **3.1 Cerințe Obligatorii**

 Accesul în OTP nu este automat și nu este disponibil oricărui pompier care dorește promovarea. Candidatul trebuie să îndeplinească **simultan** toate condițiile de mai jos:

 **a) Rank operațional — Firefighter III**
 Candidatul trebuie să dețină rangul de **Firefighter III** la data depunerii cererii de participare la OTP. Firefighter I sau Firefighter II nu sunt eligibili, indiferent de alți factori. Rangul de Firefighter III este singurul care conferă maturitatea operațională, experiența și autoritatea necesare pentru a accesa programul de formare a ofițerilor.

 **b) Certificare FTO activă**
 Candidatul trebuie să dețină o certificare **Field Training Officer (FTO) activă** și să fi finalizat cu succes supervizarea a cel puțin unui ciclu complet de FTP — adică să fi condus un Probationary Firefighter prin program până la absolvire. Această cerință este non-negociabilă: un ofițer care nu a demonstrat anterior că poate mentora și evalua un subordonat nu este pregătit pentru responsabilitățile unui Lieutenant.

 [c]Motivație:[/c] Un Lieutenant trebuie să fie capabil să instruiască, să evalueze și să răspundă pentru performanța membrilor echipajului său. Experiența FTO este singura cale prin care un pompier poate demonstra că a dezvoltat deja aceste abilități înainte de a accede la comandă.

 **c) Recomandare scrisă din partea unui Captain sau ofițer superior**
 Candidatul trebuie să depună o **Notificare de Interes Înregistrat (Notification of Registered Interest — NRI)** însoțită de o recomandare scrisă semnată de un Captain sau ofițer cu rang superior. Această recomandare trebuie să confirme în mod explicit că ofițerul recomandant consideră candidatul pregătit din punct de vedere operațional, profesional și comportamental pentru asumarea responsabilităților unui ofițer. Recomandările formale, lipsite de conținut substanțial, vor fi returnate.

 **3.2 Condiții Dezacordante — Excluderi Automate**

 Candidatul este **automat descalificat** din procesul de selecție dacă, în ultimele **30 de zile calendaristice** înainte de depunerea NRI, se află în oricare dintre situațiile:

- Are o sancțiune disciplinară activă de orice nivel (Admonishment, Reprimand sau Suspension)
- A primit evaluări OPR/DOR de tip **DOES NOT MEET EXPECTATIONS** în orice categorie în ultimele 2 luni
- Are un dosar de activitate sub pragul minim departamental (UCP activity sub 0.8)
- Face obiectul unei investigații active a Professional Standards Division
- A demisionat și s-a reangajat în ultimele 3 luni (faction re-entry recents)

 **3.3 Procesul de Selecție**

 Odată ce NRI este depusă și condițiile de eligibilitate sunt confirmate, Human Resources Division realizează un **Administrative Review for Assignment Suitability (ARAS)**. Acesta include:

1. Verificarea completă a dosarului disciplinar al candidatului
2. Analiza evaluărilor DOR/OPR din ultimele 3 luni
3. Confirmarea certificărilor active și a experienței FTO
4. Validarea recomandării scrise
5. Comunicarea rezultatului candidatului și supervizorului direct

 Candidații aprobați primesc data de start OTP și sunt repartizați unui Ofițer Supervizor (Mentor OTP).

 **4. STRUCTURA PROGRAMULUI**

 **4.1 Organizare Generală**

 OTP-ul este structurat în **trei faze operaționale progresive** urmate de o **Evaluare Finală**. Spre deosebire de FTP — care urmărește adaptarea la serviciu — OTP-ul urmărește o schimbare de paradigmă: de la execuție la comandă.

 Fiecare fază conține **module tematice specifice** care adresează un domeniu distinct de competență ofițerească. Progresul nu este liniar în timp — este condiționat de demonstrarea competenței în fiecare modul înainte de avansarea la faza următoare.

 **4.2 Durata Minimă a Programului**

- **Faza I — Leadership & Tranziție:** minim 4-5 zile operaționale
- **Faza II — Command Operațional:** minim 5-7 zile operaționale
- **Faza III — Administrație & Management:** minim 3-4 zile operaționale
- **Evaluare Finală:** 1 zi (scenariu ICS + Interview Board)

 **Durată totală minimă: 2 săptămâni operaționale.** Ofițerul Supervizor poate extinde orice fază dacă candidatul nu demonstrează competența modulară necesară. Nu există durată maximă — programul se încheie când candidatul a dovedit că este pregătit, nu când a expirat un calendar.

 **4.3 Officer Performance Report (OPR)**

 La finalul fiecărei zile operaționale, Ofițerul Supervizor completează un **Officer Performance Report (OPR)** — echivalentul DOR din FTP, adaptat pentru evaluarea competențelor de leadership și comandă. OPR-urile sunt documentele primare pe baza cărora se iau deciziile de progresie și promovare.

 **4.4 Officer Training Journal**

 Pe întreaga durată a OTP-ului, candidatul este obligat să mențină un **Officer Training Journal** — un document personal în care documentează zilnic:

- Deciziile de comandă pe care le-a luat sau observat
- Situațiile dificile și modul în care le-a gestionat
- Cunoștințele noi asimilate din MOP, SOP sau din experiența directă
- Auto-evaluarea propriilor decizii: ce a funcționat, ce ar fi putut fi mai bun
- Întrebările și neclaritățile pe care le adresează Mentorului OTP

 Officer Training Journal-ul este predat la Evaluarea Finală și constituie parte din dosarul de evaluare al candidatului.

 **5. FAZELE OTP**

 **━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
 **FAZA I — LEADERSHIP ȘI TRANZIȚIE**
 **━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**

 **Durată minimă:** 4–5 zile operaționale

 **5.1.1 Descriere și Scop**

 Faza I adresează provocarea fundamentală a oricărei promovări ofițerești: tranziția psihologică și profesională de la coleg la superior. Această tranziție este adesea subestimată — și tocmai de aceea este adesea gestionată prost. Un pompier care lucra ieri alături de colegii săi devine mâine ofițerul lor. Relațiile, dinamicile și așteptările se schimbă fundamental.

 Faza I nu testează cunoștințe tehnice sau abilități tactice — acestea sunt presupuse la un candidat Firefighter III cu experiență FTO. Faza I testează ceva mai subtil și mai important: **capacitatea candidatului de a gândi, de a acționa și de a se comporta ca un lider**, nu ca un executant.

 Candidatul observă, asistă și începe să exercite autoritate în contexte controlate, sub supravegherea permanentă a Mentorului OTP. Fiecare zi din Faza I este o oportunitate de a construi reflexele de comandă care vor defini cariera ofițerească a candidatului.

 **5.1.2 Module — Faza I**

 **Modulul A — Tranziția de la Peer la Lider**

 Candidatul studiază și discută cu Mentorul OTP provocările specifice ale tranziției ofițerești:

- Gestionarea relațiilor cu foștii colegi care devin subordonați
- Stabilirea autorității fără a distruge relațiile interpersonale
- Cum arată un lider respectat vs. un lider temut — și care este diferența
- Limitele prieteniei la locul de muncă pentru un ofițer
- Cum să dai feedback negativ constructiv unui coleg cu care ai lucrat ani de zile
- Responsabilitatea disciplinară: ce faci când un prieten greșește sub comanda ta

 **Modulul B — Autoritatea Ofițerească și Lanțul de Comandă**

 Candidatul înțelege în profunzime structura de autoritate în care va funcționa:

- Autoritatea unui Lieutenant față de Firefighters și Probationary Firefighters
- Obligațiile față de Captain și superiorii ierarhici
- Cum se escaladează deciziile — ce poate decide un Lieutenant independent și ce necesită aprobarea Căpitanului
- Răspunderea ofițerilor pentru acțiunile subordonaților
- Gestionarea situațiilor în care un ordin superior pare incorect sau nesigur
- Procedurile de raportare pentru incidente disciplinare sau de siguranță

 **Modulul C — Prezența și Comunicarea Ofițerului**

 Candidatul dezvoltă abilități specifice de comunicare ofițerească:

- Tonul și limbajul specific unui ofițer — diferit de cel al unui Firefighter
- Comunicarea autorității fără agresivitate
- Cum să conduci un briefing pre-intervenție eficient (5-minute drill)
- Comunicarea clară a așteptărilor față de echipaj
- Cum să dai ordine clare, concise și neambigue
- Comunicarea radio ca ofițer: formatul, tonul, responsabilitatea suplimentară față de traficul radio

 **5.1.3 Restricțiile Candidatului în Faza I**

 În Faza I, candidatul **nu are voie să**:

- Emită ordine operaționale fără confirmarea prealabilă a Mentorului OTP
- Preia comanda unui incident fără prezența și supravegherea Mentorului
- Ia decizii administrative (program, sancțiuni, evaluări) în mod independent

 **5.1.4 Obiectivele Fazei I**

 La finalizarea Fazei I, candidatul trebuie să demonstreze că:

- Înțelege diferența fundamentală dintre mentalitatea de Firefighter și cea de ofițer
- Poate conduce un briefing de tură coerent și profesionist
- Demonstrează autoritate naturală în interacțiunile cu echipajul
- Cunoaște limitele autorității sale și momentul în care escaladează deciziile
- Înțelege responsabilitatea sa față de siguranța și performanța subordonaților

 **━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
 **FAZA II — COMMAND OPERAȚIONAL**
 **━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**

 **Durată minimă:** 5–7 zile operaționale

 **5.2.1 Descriere și Scop**

 Faza II este miezul OTP-ului — etapa în care candidatul este expus direct la responsabilitățile operaționale ale unui Lieutenant. Dacă Faza I construiește mentalitatea de lider, Faza II testează capacitatea de a o aplica în condiții reale, pe scena unui incident activ.

 Candidatul preia progresiv responsabilitatea de a conduce intervenții, de la incidente de complexitate redusă în primele zile până la scenarii multi-echipaj și ICS complex în ultimele zile ale fazei. Mentorul OTP rămâne prezent în permanență, dar intervine din ce în ce mai rar — rolul său devine cel de observator evaluator, nu de ghid.

 Această fază este deliberat solicitantă. Candidatul va face greșeli. Greșelile sunt așteptate și acceptate ca parte a procesului de formare — dacă sunt urmate de analiză corectă și ajustare. Ceea ce nu este acceptat este lipsa de reflecție sau repetarea aceleiași greșeli fără nicio îmbunătățire.

 **5.2.2 Module — Faza II**

 **Modulul A — Incident Command System (ICS) Aplicat**

 Candidatul aplică principiile ICS în intervenții reale:

- Structura ICS și rolul Lieutenantului ca Assistant IC sau IC la incidente minore
- Scene Size-up — evaluarea rapidă a dimensiunii, complexității și pericolelor unui incident la sosire
- Stabilirea Incident Command Post (ICP) și comunicarea comenzii către echipaj și Dispatch
- Gestionarea resurselor disponibile: alocarea echipajului pe pozițiile tactice corecte
- Managementul zonelor de siguranță: Hot Zone, Warm Zone, Cold Zone
- Cum se escaladează comanda unui incident care depășește resursele disponibile
- Documentarea deciziilor de comandă în timp real
- After-Action Review (AAR) — condus de candidat, nu de mentor

 **Modulul B — Conducerea Intervențiilor de Stingere**

- Coordonarea Engine și Truck Company la intervenții de incendiu structurale
- Alocarea echipajelor pe pozițiile tactice: Fire Attack, Search & Rescue, Ventilation, Water Supply
- Comunicarea cu pompieri în interior — managementul timpului de aer SCBA
- Decizii de tranziție ofensivă → defensivă
- Accountability — urmărirea locației tuturor membrilor echipajului la orice moment
- Declararea unui MAYDAY și protocoalele de urgență pentru pompier în pericol
- Coordonarea cu Căpitanul sosit ulterior — transferul comenzii

 **Modulul C — Conducerea Intervențiilor Medicale**

- Rolul Lieutenantului la scena medicală — nu ca ALS provider, ci ca coordonator al scenei
- Coordonarea echipelor BLS și ALS: delegarea rolurilor, gestionarea traficului de personal
- Managementul MCI (Mass Casualty Incident) — activarea protocolului, coordonarea triajului
- Comunicarea cu spitalul și cu Dispatch în timp real
- Gestionarea familiei și a martorilor la scena medicală

 **Modulul D — Coordonarea Multi-Agenții**

- Protocolul de colaborare LSFD — LSPD la scene comune
- Comunicarea cu ofițerii de poliție la scena unui incident complex
- Coordonarea cu LSEMS (servicii medicale externe) la scene de urgență
- Managementul media și al prezenței publice la scene majore
- Transferul comenzii — cum se cedează sau se preia IC de la o altă agenție

 **Modulul E — Siguranța Echipajului și Accountability**

- Sistemul LSFD de Accountability: Passport System, PAR (Personnel Accountability Report)
- Indicatorii de pericol iminent la incendii (rollover, backdraft, flashover — semne de avertizare)
- Protocoale de retragere de urgență (Emergency Evacuation Signal)
- MAYDAY: când și cum se declară, cum se gestionează ca IC
- Rehabilitation (Rehab) — monitorizarea stării fizice a pompierilor la incidente prelungite

 **5.2.3 Nivelul de Autonomie în Faza II**

- **Zilele 1-2:** Candidatul conduce incidente minore (medical BLS, alarme false, accidente rutiere fără victime prinse) cu Mentorul prezent activ
- **Zilele 3-4:** Candidatul conduce incidente de complexitate medie (structuri mici, MCI limitat) cu Mentorul în rol de observator
- **Zilele 5-7:** Candidatul conduce incidente complexe (incendii structurale, MCI major, coordonare multi-agenții) cu Mentorul doar ca factor de siguranță

 **5.2.4 Obiectivele Fazei II**

 La finalizarea Fazei II, candidatul trebuie să demonstreze că:

- Poate conduce un incident de la declararea comenzii până la terminarea operațiunilor și debriefing
- Aplică corect principiile ICS în situații reale cu resurse limitate
- Poate lua decizii tactice rapide și justificate sub presiune
- Menține accountability complet pentru întregul echipaj pe durata intervenției
- Conduce un After-Action Review (AAR) coerent și constructiv după fiecare incident major
- Comunică eficient cu toate agențiile prezente la scenă

 [hr]

 **━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
 **FAZA III — ADMINISTRAȚIE ȘI MANAGEMENT**
 **━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**

 **Durată minimă:** 3–4 zile operaționale

 **5.3.1 Descriere și Scop**

 Faza III adresează dimensiunea administrativă a funcției de ofițer — aspectul cel mai puțin spectaculos, dar esențial pentru buna funcționare a unui departament. Un Lieutenant excelent pe scenă, dar incapabil să gestioneze documentația, personalul și comunicarea formală internă, nu este un Lieutenant complet.

 Această fază pregătește candidatul pentru responsabilitățile zilnice ale unui ofițer de stație: managementul turei, redactarea documentelor oficiale, supervizarea personalului și gestionarea situațiilor disciplinare minore. Candidatul lucrează direct alături de Căpitanul stației sub supravegherea Mentorului OTP, observând și participând activ la activitățile administrative zilnice.

 **5.3.2 Module — Faza III**

 **Modulul A — Managementul Turei și al Personalului**

- Responsabilitățile Lieutenantului la începutul turei: briefingul de tură, verificarea echipamentului și a aparatelor, raportul de stare
- Alocarea personalului pe aparate și funcții de tură
- Gestionarea absențelor neplanificate și înlocuirilor
- Monitorizarea stării fizice și emoționale a membrilor echipajului
- Cum să identifici și să adresezi semne timpurii de burnout sau probleme de personal
- Responsabilitățile de la finalul turei: rapoarte, transferul comenzii, debriefing

 **Modulul B — Documentație și Raportare Ofițerească**

- Structura și cerințele unui **Incident Command Report** — redactat din perspectiva Incident Commander-ului
- Raportarea orelor de lucru și a activității operaționale
- Documentarea neconformităților de echipament sau de siguranță (Equipment Deficiency Reports)
- Comunicarea formală scrisă cu Căpitanul și cu Biroul Administrativ: memorandumuri, notificări, rapoarte de personal
- Redactarea unui **Personnel Action Report** pentru documentarea problemelor de conduită
- Utilizarea corectă a MDT-ului și a sistemelor informatice departamentale

 **Modulul C — Supervizarea și Mentoratul Subordonaților**

- Rolul Lieutenantului ca FTO Coordinator informal — supravegherea Probationary Firefighters din echipaj
- Cum să conduci o sesiune de training zilnic eficientă pentru echipaj (Daily Drill)
- Evaluarea performanței membrilor echipajului și comunicarea feedback-ului constructiv
- Identificarea membrilor cu potențial de avansare și cum să îi sprijini
- Identificarea membrilor cu probleme de performanță și protocolul de escaladare
- Gestionarea conflictelor interpersonale în cadrul echipajului

 **Modulul D — Proceduri Disciplinare și Etică Ofițerească**

- Autoritatea disciplinară a unui Lieutenant: ce poate gestiona independent și ce escaladează la Captain
- Protocolul de documentare al unui incident disciplinar minor
- Imparțialitatea — cum să aplici standardele uniform, indiferent de relația personală cu subordonatul
- Obligația de raportare: când un Lieutenant are datoria să raporteze un incident la superiorii săi
- Conflictele de interese și cum să le gestionezi (relații de prietenie, familie în echipaj)
- Etica utilizării autorității — diferența dintre disciplină necesară și abuz de putere

 **5.3.3 Obiectivele Fazei III**

 La finalizarea Fazei III, candidatul trebuie să demonstreze că:

- Poate conduce independent un briefing complet de tură
- Redactează documente oficiale la standardul cerut pentru rangul de ofițer
- Înțelege și poate aplica corect procedurile de personal și disciplinare
- Demonstrează echilibru și imparțialitate în relația cu membrii echipajului
- Poate gestiona situațiile administrative uzuale fără suport constant din partea Căpitanului

 [hr]

 **6. OFIȚERUL SUPERVIZOR — MENTORUL OTP**

 **6.1 Definiție și Autoritate**

 Ofițerul Supervizor, denumit în cadrul programului **Mentor OTP**, este ofițerul certificat responsabil de supervizarea directă a unui candidat pe durata întregului program. Mentorul OTP trebuie să dețină minimum rangul de **Captain** și să fi finalizat o sesiune formală de calibrare OTP condusă de Training Division (Division 6).

 Mentorul OTP are autoritate deplină asupra procesului de evaluare al candidatului său și asupra deciziei de progresie între faze. Recomandarea sa finală este componenta principală pe baza căreia Biroul de Instruire ia decizia de admitere la Evaluarea Finală.

 **6.2 Responsabilitățile Mentorului OTP**

- **Supervizează toate activitățile candidatului** pe durata OTP-ului, în special în fazele incipiente unde autonomia este limitată
- **Completează OPR-uri zilnice** cu evaluări obiective, specifice și documentate
- **Conduce sesiuni zilnice de debriefing** cu candidatul — minimum 15 minute la finalul fiecărei ture pentru a analiza deciziile luate și a identifica zonele de îmbunătățire
- **Oferă feedback continuu și constructiv** — nu doar la finalul zilei, ci imediat după momentele operaționale semnificative
- **Documentează progresul și regresul candidatului** în dosarul de OTP ținut la Division 6
- **Recomandă sau blochează progresia** între faze în baza performanței demonstrate
- **Coordonează cu Căpitanul stației** pentru accesul candidatului la activitățile administrative din Faza III
- **Depune raportul final** de evaluare la Division 6 înainte de Evaluarea Finală

 **6.3 Standardele de Conduită ale Mentorului OTP**

 Mentorul OTP este evaluat la rândul său pe calitatea muncii sale de supraveghere. Division 6 monitorizează consecvența și calitatea OPR-urilor și poate convoca Mentorul pentru clarificări dacă evaluările sunt inconsistente, superficiale sau suspecte de favoritism. Mentorul OTP **nu are voie**:

- Să favorizeze sau să saboteze deliberat un candidat pe baze personale
- Să completeze OPR-uri fără a fi asistat efectiv la activitățile evaluate
- Să promoveze un candidat între faze fără ca acesta să fi demonstrat competența necesară
- Să utilizeze relația de supervizare OTP pentru a-și construi influență politică sau a rezolva conflicte personale

 Încălcarea acestor standarde poate duce la decertificarea ca Mentor OTP și la inițierea unei investigații a Professional Standards Division.

 [hr]

 **7. RESPONSABILITĂȚILE CANDIDATULUI**

 **7.1 Angajamentul față de Program**

 Candidatul OTP a demonstrat deja că este un pompier competent — această premisă nu mai trebuie dovedită. Ceea ce OTP-ul cere este altceva: disponibilitatea de a fi pus în situații dificile, de a lua decizii sub presiune și de a accepta că procesul de formare a unui ofițer implică inevitabil disconfort și erori urmate de reflecție.

 Un candidat care intră în OTP cu atitudinea că va „trece prin program" fără a se angaja real va fi identificat rapid și eliminat. OTP-ul caută candidați care înțeleg că pregătesc pentru responsabilități reale, nu pentru un titlu.

 **7.2 Obligațiile Operaționale**

 Pe durata OTP-ului, candidatul este obligat să:

- **Abordeze fiecare intervenție cu mentalitate de ofițer** — să gândească activ la comenzi, alocarea resurselor și siguranța echipajului, chiar și atunci când rolul formal este de suport
- **Mențină Officer Training Journal-ul actualizat zilnic** — documentând decizii, observații și auto-evaluări
- **Participe activ la debriefingurile zilnice** cu Mentorul OTP — cu onestitate și deschidere față de feedback
- **Studieze MOP-ul, SOP-urile și manualul ICS** în afara orelor de serviciu
- **Conducă After-Action Reviews** după fiecare incident semnificativ în care a acționat ca IC
- **Raporteze imediat Mentorului OTP** orice situație sau decizie despre care nu a fost sigur

 **7.3 Standardele de Conduită**

 Candidatul OTP este deja Firefighter III și FTO certificat — standardele de conduită nu se relaxează pe durata programului. Dimpotrivă: un candidat la rangul de ofițer este ținut la standarde mai înalte decât un pompier de bază. Orice comportament neprofesional, insubordonare sau incident disciplinar pe durata OTP-ului va fi tratat cu maximă severitate.

 [hr]

 **8. SISTEMUL DE EVALUARE — OFFICER PERFORMANCE REPORT (OPR)**

 **8.1 Scopul OPR**

 Officer Performance Report (OPR) este documentul oficial de evaluare zilnică al candidatului OTP. Spre deosebire de DOR-ul din FTP — care evaluează competențe operaționale de bază — OPR-ul evaluează **competențe de leadership, decizie și management** specifice funcției ofițerești.

 OPR-ul este completat de Mentorul OTP la finalul fiecărei ture. Toate OPR-urile sunt transmise la Division 6 și rămân în dosarul permanent al candidatului. La Evaluarea Finală, membrii Interview Board-ului au acces complet la toate OPR-urile acumulate.

 **8.2 Categoriile de Evaluare OPR**

1. **Leadership & Autoritate** — Capacitatea de a exercita autoritatea natural și eficient; prezența comandantului la scenă
2. **Incident Command (ICS)** — Aplicarea corectă a principiilor ICS; size-up, alocare resurse, comunicarea comenzii
3. **Luarea Deciziilor sub Presiune** — Calitatea și promptitudinea deciziilor operaționale în situații de urgență
4. **Managementul Personalului** — Supervizarea echipajului, delegarea sarcinilor, monitorizarea performanței
5. **Comunicare Ofițerească** — Claritatea comunicărilor radio și verbale ca ofițer; tonul, concizia, autoritatea
6. **Siguranța Echipajului & Accountability** — Menținerea accountability complet; identificarea și adresarea pericolelor
7. **Cunoașterea SOP/MOP** — Aplicarea corectă a procedurilor departamentale; consecvența cu politicile LSFD
8. **Documentație & Raportare** — Calitatea rapoartelor de incident și a documentației administrative produse
9. **Conduită și Integritate Ofițerească** — Comportamentul etic, imparțialitatea, reprezentarea standardelor LSFD
10. **Potențial de Avansare** — Evaluarea generală a pregătirii pentru funcția de Lieutenant

 **8.3 Scala de Evaluare OPR**

 **DOES NOT MEET EXPECTATIONS — NU ÎNDEPLINEȘTE AȘTEPTĂRILE**
 Performanța nu atinge standardele minime cerute pentru funcția de ofițer. Deficiențe grave care compromit siguranța echipajului, eficiența operațiunilor sau autoritatea necesară rangului. O evaluare de acest nivel în categoria **Siguranța Echipajului** sau **Incident Command** poate declanșa imediat o revizuire a continuării în program. Mentorul OTP este obligat să documenteze specific natura deficienței și acțiunile corective recomandate.

 **MEETS EXPECTATIONS — ÎNDEPLINEȘTE AȘTEPTĂRILE**
 Performanța îndeplinește standardele minime cerute pentru stadiul de formare în care se află candidatul. Funcționează adecvat ca lider în curs de formare, cu greșeli minore care nu afectează semnificativ eficiența sau siguranța. Aceasta este **evaluarea minimă necesară pentru progresia de fază**.

 **EXCEEDS EXPECTATIONS — DEPĂȘEȘTE AȘTEPTĂRILE**
 Performanță peste medie pentru un candidat OTP. Demonstrează inițiativă, anticipare și judecată solidă fără a fi nevoie de îndrumare. Acționează mai degrabă ca un ofițer format decât ca un candidat în formare. Evaluare semnificativă care indică un potențial ridicat de comandă.

 **OUTSTANDING — EXCEPȚIONAL**
 Performanță excepțională, rar acordată. Candidatul demonstrează un nivel de comandă, judecată și leadership care depășește în mod constant așteptările pentru rangul vizat. Această evaluare trebuie să reflecte performanțe cu adevărat remarcabile și nu trebuie acordată cu generozitate.

 **8.4 Interpretarea Rezultatelor OPR**

- Toate categoriile trebuie să atingă minimum **MEETS EXPECTATIONS** pentru progresia de fază
- Evaluări de **DOES NOT MEET** în categoriile **Leadership, ICS sau Siguranța Echipajului** necesită plan de remediere imediat
- Evaluări de **DOES NOT MEET** în 3 sau mai multe categorii în aceeași zi declanșează revizuirea imediată a continuării în program
- Evaluări consistente de **EXCEEDS / OUTSTANDING** pot accelera progresia sau pot susține o recomandare de promovare accelerată

 [hr]

 **9. SISTEMUL DE SANCȚIUNI ȘI RETRAGERE DIN PROGRAM**

 **9.1 Principii Generale**

 Standardele disciplinare în OTP sunt superioare celor din FTP. Un candidat la funcția de ofițer este judecat la standarde mai înalte decât un Probationary Firefighter. Comportamentul unui candidat OTP este interpretat nu doar prin prisma regulilor de conduită generală, ci și prin prisma întrebării: *„Este aceasta conduita pe care o așteptăm de la un Lieutenant al LSFD?"*

 **9.2 Tipuri de Sancțiuni**

 **AVERTISMENT FORMAL (Formal Warning)**

 **Se aplică pentru:**
- Greșeli repetate de procedură care nu afectează siguranța
- Comunicare radio deficitară persistentă în ciuda corecțiilor
- Completarea neglijentă a Officer Training Journal-ului sau a documentației
- Lipsă de inițiativă repetată sau comportament pasiv inadecvat rangului vizat

 **SUSPENDARE TEMPORARĂ (Temporary Suspension)**

 **Se aplică pentru:**
- Decizie de comandă gravă care a pus sau ar fi putut pune în pericol siguranța echipajului
- Insubordonare față de Mentorul OTP sau față de ofițerii superiori
- Comportament neprofesional semnificativ la scenă sau în stație
- Eșec repetat de a demonstra îmbunătățire după Avertisment Formal

 Suspendarea implică retragerea temporară din activitățile OTP și sesiune obligatorie de evaluare cu Division 6 înainte de reluare.

 **ELIMINARE DIN PROGRAM (OTP Removal)**

 **Se aplică pentru:**
- Incident major de siguranță cauzat de decizia candidatului
- Comportament toxic, intimidare sau hărțuire față de membrii echipajului
- Acte grave de insubordonare sau nesupunere deliberată
- Eșec persistent de a demonstra orice progres spre standardele ofițerești
- Conduită incompatibilă cu funcția de ofițer LSFD

 Eliminarea din OTP este definitiva și implică revocarea eligibilității pentru o perioadă minimă de **3 luni calendaristice**. O a doua eliminare din OTP poate duce la ineligibilitate permanentă pentru funcții de ofițer.

 [hr]

 **10. EVALUAREA FINALĂ**

 **10.1 Condiții de Admitere la Evaluarea Finală**

 Accesul la Evaluarea Finală nu este automat la expirarea duratei minime a programului. Candidatul trebuie să îndeplinească simultan:

- Toate cele trei faze finalizate cu evaluare **MEETS EXPECTATIONS** sau superior în toate categoriile OPR
- Nicio evaluare **DOES NOT MEET** în ultimele 5 zile operaționale
- Officer Training Journal completat și predat la Division 6
- Recomandare formală de admitere la Evaluare din partea Mentorului OTP
- Aprobarea Training Division Chief (Division 6) pentru programarea evaluării

 **10.2 Structura Evaluării Finale**

 Evaluarea Finală se desfășoară pe **1 zi operațională completă** și cuprinde două componente obligatorii:

 [hr]

 **COMPONENTA I — SCENARIU PRACTIC DE INCIDENT COMMAND**

 **Durată:** 2–4 ore (variabil în funcție de complexitatea scenariului)

 **Descriere:**
 Candidatul este plasat în fruntea unui incident simulat de complexitate medie-ridicată, fără asistență din partea Mentorului OTP. Evaluatorii certificați (minimum rang Captain) observă și evaluează toate deciziile candidatului fără a interveni, cu excepția pericolelor directe de siguranță.

 **Scenariul poate include:**
- Incendiu structural cu victime multiple (interior + exterior)
- Accident rutier major cu eliberare de pacienți prinși și urgențe medicale simultane
- MCI (Mass Casualty Incident) cu necesar de activare a protocoalelor de triaj
- Incident Hazmat cu implicare multi-agenții
- Orice combinație a scenariilor de mai sus

 **Categoriile evaluate în scenariu:**
- Scene Size-up și declararea comenzii (Command Announcement)
- Alocarea resurselor și alocarea echipajului pe funcții tactice
- Comunicarea radio ca IC — claritate, frecvență, informații transmise
- Managementul zonelor de siguranță și accountability complet
- Decizii tactice — justificare, promptitudine, eficiență
- Gestionarea complicațiilor neprevăzute introduse de evaluatori în scenariul live
- After-Action Review condus de candidat la finalul scenariului

 [hr]

 **COMPONENTA II — INTERVIEW BOARD CU CHIEF OFFICERS**

 **Durată:** 45–90 minute

 **Descriere:**
 Candidatul susține un interviu formal în fața unui panel compus din minimum 2 Chief Officers (Battalion Chief, Deputy Chief sau Fire Chief). Interviul evaluează profunzimea cunoașterii, maturitatea judecății și pregătirea generală a candidatului pentru funcția de Lieutenant.

 **Structura interviului:**
1. **Prezentarea candidatului** — 5 minute; candidatul prezintă propria viziune despre funcția de Lieutenant și motivația pentru promovare
2. **Întrebări situaționale** — Board-ul prezintă scenarii ipotetice și evaluează calitatea raționamentului candidatului (ex: „Ce faci dacă un membru al echipajului tău refuză un ordin direct la scenă?")
3. **Întrebări procedurale** — Board-ul testează cunoașterea MOP, SOP și a procedurilor departamentale
4. **Întrebări de leadership** — Board-ul evaluează viziunea candidatului despre leadership, disciplină și managementul personalului
5. **Întrebări etice** — Scenarii cu componente etice complexe (conflicte de interese, raportare a unui superior, situații ambigue)
6. **Feedback și închidere** — Board-ul poate oferi feedback verbal candidatului la finalul interviului

 **10.3 Rezultatele Posibile ale Evaluării Finale**

 **PROMOVAT — RECOMANDAT PENTRU LIEUTENANT**
 Candidatul a demonstrat în ambele componente ale evaluării că este pregătit pentru funcția de Lieutenant. Dosarul complet (OPR-uri, Officer Training Journal, raportul Mentorului, rezultatele evaluării) este înaintat Fire Chief-ului pentru aprobarea finală a promovării.

 **AMÂNAT — REMEDIERE NECESARĂ**
 Candidatul a demonstrat competență în majoritatea domeniilor, dar prezintă deficiențe specifice care necesită lucru suplimentar. Candidatul revine la programul OTP pentru maxim **1 săptămână suplimentară** de instruire direcționată, urmată de o a doua sesiune de evaluare (parțială sau completă, la decizia Board-ului).

 **RESPINS — NECALIFICAT PENTRU PROMOVARE**
 Candidatul nu a îndeplinit standardele necesare în componente critice ale evaluării. Candidatul este retras din OTP și devine eligibil pentru o nouă candidatură după minimum **3 luni calendaristice**, timp în care se recomandă activitate intensă de mentorat și dezvoltare profesională.

 [hr]

 **11. ABSOLVIREA ȘI PROMOVAREA**

 **11.1 Procesul Formal de Promovare**

 Absolvirea OTP nu înseamnă automat promovarea imediată la rangul de Lieutenant. Procesul formal de promovare implică:

1. Dosarul complet OTP (toate OPR-urile, Officer Training Journal, rapoartele fazelor, raportul Evaluării Finale) este înaintat la Human Resources Division
2. Human Resources confirmă că toate cerințele administrative sunt îndeplinite (certificări, activitate, conduct)
3. Training Division Chief emite **Certificate of OTP Completion**
4. Fire Chief sau Deputy Chief aprobă formal promovarea
5. Ceremonia de promovare și depunerea **Officer Oath** — jurământul specific rangului de ofițer
6. Actualizarea dosarului de personal, a insignei și a asignărilor de discord/MDT

 **11.2 Responsabilitățile Imediate Post-Promovare**

 La momentul promovării, noul Lieutenant preia imediat toate responsabilitățile rangului, fără perioadă de tranziție suplimentară. Promovarea presupune că candidatul este **complet pregătit** să funcționeze independent. Mentorul OTP rămâne disponibil ca resursă informală pentru primele 2 săptămâni, dar fără rol formal de supervizare.

 **11.3 Probation Period Post-OTP**

 Noul Lieutenant parcurge o **Perioadă Probatorie de 30 de zile calendaristice** în care:

- Căpitanul stației monitorizează performanța și raportează orice îngrijorări la Division 6
- Lieutenantul completează automat **Officer Activity Reports** săptămânale
- Orice incident disciplinar major în această perioadă poate declanșa o revizuire formală a promovării

 La expirarea perioadei probatorii fără incidente, statutul de Lieutenant devine permanent și definitiv.

 [hr]

 **12. EXCLUDEREA DIN PROGRAM**

 **12.1 Motive de Excludere**

 Un candidat poate fi exclus din OTP pentru:

- **Inactivitate prelungită** — absența neanunțată de la activitățile OTP mai mult de 3 zile consecutive
- **Comportament incompatibil cu rangul vizat** — conduită care descalifică candidatul de la funcția de ofițer
- **Eșec persistent în demonstrarea progresului** — nicio îmbunătățire demonstrabilă după avertismente și intervenții corective
- **Retragerea recomandării** din partea ofițerului care a semnat NRI inițial, pe baza deteriorării conduitei sau performanței
- **Incident disciplinar major** în afara OTP-ului care aduce candidatul sub standardele de eligibilitate

 **12.2 Procedura de Excludere**

1. Mentorul OTP documentează motivele și înaintează un raport la Division 6
2. Training Division Chief analizează dosarul și decide în termen de 48 de ore
3. Candidatul este audiat formal înainte de decizia finală
4. Decizia este comunicată în scris candidatului și ofițerului care a semnat NRI-ul

 **12.3 Dreptul la Apel**

 Candidatul poate contesta decizia de excludere printr-un apel scris adresat **Battalion Chief sau Deputy Chief** în termen de **48 de ore** de la comunicare. Apelul trebuie să conțină argumente concrete și dovezi. Decizia ofițerului de apel este finală.

 [hr]

 **13. STANDARDE DE CONDUITĂ ȘI PROFESIONALISM OFIȚERESC**

 **13.1 Standardele Ofițerilor LSFD**

 Un ofițer LSFD nu este un pompier cu o insignă diferită. Este un reprezentant al autorității departamentale, un model de conduită pentru subordonați și un garant al standardelor pe care departamentul le susține public. Standardele de conduită ale unui ofițer depășesc în rigorozitate pe cele ale oricărui alt rang.

 **13.2 Conduita la Scenă**

- **Prezența comandantului** — un ofițer la scenă trebuie să fie imediat identificabil prin comportament calm, autoritar și organizat; panica sau dezorganizarea transmit incertitudine întregului echipaj
- **Decizia fermă** — un ofițer care ezită vizibil sau care schimbă frecvent ordinele fără justificare clară pierde credibilitatea echipajului; deciziile trebuie să fie rapide, comunicate clar și susținute consistent
- **Imparțialitatea** — standardele se aplică uniform tuturor membrilor echipajului, indiferent de gradul de prietenie sau afinitate personală
- **Siguranța mai presus de ego** — un ofițer care refuză să admită o decizie greșită din mândrie pune în pericol echipajul; corectarea unui curs de acțiune deficitar nu este slăbiciune, ci leadership

 **13.3 Conduita în Stație**

- **Accesibilitate profesională** — membrii echipajului trebuie să poată adresa preocupări Lieutenantului; un ofițer inaccesibil generează resentimente și probleme nerezolvate
- **Consistența standardelor** — regulile se aplică la fel la ora 09:00 și la ora 03:00; un ofițer care relaxează standardele noaptea sau în perioadele calme transmite că regulile sunt opționale
- **Exemplaritatea personală** — un ofițer nu poate cere echipajului standardele pe care el însuși nu le respectă; conduita personală este permanent observată de subordonați

 **13.4 Conduita în Afara Serviciului**

 Rangul de ofițer nu se oprește la ieșirea din stație. Un Lieutenant LSFD este permanent un reprezentant al departamentului și al funcției sale. Comportamentul public, activitatea pe rețelele sociale și interacțiunile cu alte agenții sau cu publicul trebuie să reflecte standardele unui lider al comunității.

 [hr]

 **14. AUTORITATEA ȘI RESPONSABILITĂȚILE RANK-ULUI DE LIEUTENANT**

 **14.1 Locul Lieutenantului în Ierarhia LSFD**

 Conform Manual of Operations al LSFD, Lieutenantul este **primul rang de ofițer** al departamentului — pozitionat imediat deasupra rangului de Firefighter/Engineer/Paramedic și subordonat Căpitanului. Acesta reprezintă interfața directă dintre personalul de teren și structura de comandă.

 **14.2 Autoritatea Operațională**

- **Assistant Incident Commander** — acționează ca AIC la orice scenă condusă de un Captain sau superior; preia IC dacă Căpitanul este absent sau devine incapacitat
- **Company Officer** — conduce un echipaj specific (Engine Company, Truck Company, Squad) sau un Apparatus
- **Scene Commander la incidente minore** — conduce independent incidente de complexitate redusă sau medie care nu necesită prezența unui Captain
- **Safety Officer delegat** — poate fi desemnat de IC ca Safety Officer la scene complexe

 **14.3 Autoritatea Administrativă**

- **Gestionarea turei** — responsabil pentru organizarea, eficiența și disciplina turei în absența Căpitanului
- **Evaluarea performanței** — poate completa evaluări informale ale Firefighters din echipaj și le transmite Căpitanului
- **Disciplina minoră** — poate emite avertismente verbale și poate documenta incidente disciplinare minore; disciplina formală (Admonishment+) este autoritatea Căpitanului
- **Training zilnic** — responsabil pentru conducerea Daily Drills ale echipajului

 **14.4 Limitele Autorității Lieutenantului**

 Există situații în care Lieutenantul **trebuie** să escaladeze decizia la Captain sau superior:

- Orice decizie care implică o sancțiune formală (Admonishment, Reprimand, Suspension) față de un subordonat
- Solicitări de concediu medical sau administrativ mai lungi de o tură
- Orice incident cu potențial de investigație disciplinară sau legală
- Decizii de achiziție sau înlocuire de echipament
- Comunicări externe oficiale cu alte agenții sau cu media
- Incidente de nivel Major sau incidente cu victime multiple care necesită resurse superioare

 **14.5 Jurământul Ofițeresc — Officer Oath**

 La promovarea la rangul de Lieutenant, candidatul depune **Officer Oath** — un jurământ distinct față de cel depus la intrarea în departament, care reflectă responsabilitățile suplimentare ale unui ofițer:

 *„Jur solemn că voi purta cu demnitate și integritate insigna de ofițer al Los Santos Fire Department, că voi asigura în permanență siguranța și bunăstarea celor aflați sub comanda mea, că voi aplica standardele departamentului cu imparțialitate și consecvență și că voi lua decizii în interes public și departamental, nu în interes personal, onorând astfel încrederea acordată mie de Los Santos Fire Department."*

 [hr]

 **15. DISPOZIȚII FINALE**

 **15.1 Autoritatea Biroului de Instruire**

 Biroul de Instruire și Dezvoltare Profesională (Division 6 — Training & Professional Development) deține autoritatea deplină de a administra, modifica și aplica OTP-ul. Acesta își rezervă dreptul de a:

- **Modifica structura OTP** — actualizând fazele, modulele și cerințele în funcție de evoluția nevoilor departamentale
- **Revizui standardele de evaluare** — ajustând criteriile OPR pentru a reflecta standardele operaționale curente
- **Suspenda temporar** un candidat în așteptarea unei investigații disciplinare
- **Decertifica Mentori OTP** care nu respectă standardele de supervizare
- **Decide la caz** situațiile excepționale neprevăzute de prezentul manual

 **15.2 Amendamentele la Manual**

 Orice modificare a prezentului manual va fi comunicată prin memorandum oficial tuturor Mentorilor OTP activi și afișată pe platformele interne ale LSFD. Versiunea curentă înlocuiește toate versiunile anterioare.

 **15.3 Interpretarea Prevederilor**

 În cazul oricărei ambiguități în interpretarea prevederilor, autoritatea de interpretare aparține **Training Division Chief**, cu drept de apel la **Battalion Chief** sau superior. Interpretarea este obligatorie și definitivă pentru toți participanții la program.

 **15.4 Conformitatea cu Manualul**

 Participarea la OTP implică acceptarea completă a tuturor prevederilor prezentului manual. **Statutul de Firefighter III sau experiența operațională extinsă nu conferă nicio excepție de la regulile programului.**

 [hr]

 **DECLARAȚIE DE ANGAJAMENT — CANDIDAT OTP**

 *Prin participarea la Programul de Formare a Ofițerilor al LSFD, recunosc că solicit asumarea unor responsabilități care depășesc propria mea performanță individuală. Mă angajez să abordez acest program cu maxima seriozitate, să accept fiecare corecție ca pe o oportunitate de creștere, să prioritizez siguranța echipajului meu în orice decizie și să port cu demnitate, dacă voi fi promovat, insigna de ofițer al Los Santos Fire Department.*

 [hr]

 **Biroul de Instruire și Dezvoltare Profesională**
 **Departamentul de Pompieri din Los Santos**
 *Training & Professional Development Bureau — LSFD*

 *Manualul OTP este un document oficial al LSFD. Orice reproducere sau distribuire neautorizată este interzisă.
 Versiunea curentă înlocuiește toate versiunile anterioare.*
---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---

---
