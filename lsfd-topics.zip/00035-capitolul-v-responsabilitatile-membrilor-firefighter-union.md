# CAPITOLUL V – RESPONSABILITĂȚILE MEMBRILOR FIREFIGHTER UNION

- **Topic ID:** 35
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=35
- **Posts:** 1

---

## #1 — Kellan Dunley

![](https://i.imgur.com/2jlMxHe.png)

FIREFIGHTER UNION MANUAL

---

 CAPITOLUL V – RESPONSABILITĂȚILE MEMBRILOR FIREFIGHTER UNION
---

---

- **(5.1)** Importanța responsabilităților în cadrul unei organizații sindicale

---

---

- Firefighter Union nu este doar o structură care oferă protecție și drepturi membrilor săi; este o comunitate solidară care funcționează eficient doar atunci când fiecare membru își asumă o parte din responsabilitățile colective. Responsabilitatea individuală asigură legitimitatea Union, susține forța sa instituțională și întărește poziția sa în negocieri, în proceduri disciplinare și în interacțiunile cu conducerea Departamentului.    O organizație sindicală își poate atinge obiectivele doar atunci când membrii săi sunt implicați, informați și dispuși să își exercite rolul în mod activ și responsabil.

 -

---

---

- **(5.2)** Responsabilitatea respectării Codului Etic și a standardelor profesionale

---

---

- Fiecare membru Firefighter Union este obligat să respecte Codul Etic al profesiei de pompier și regulamentele operaționale ale Departamentului. Aceste standarde includ:    • comportament profesionist în timpul intervențiilor;   • respectarea ordinelor operative;   • menținerea disciplinei în stații;   • interacțiuni adecvate cu publicul;   • conduită morală corespunzătoare;   • respect reciproc între colegi.    Sindicatul nu protejează comportamente imorale sau ilegale. Responsabilitatea morală reprezintă baza protecției sindicale; doar membrii care își îndeplinesc obligațiile profesionale pot beneficia pe deplin de suportul Union.

 -

---

---

- **(5.3)** Responsabilitatea de a respecta procedurile disciplinare și de a colabora cu Union

---

---

- Atunci când un membru este implicat într-o procedură disciplinară, acesta are responsabilitatea de:    • a coopera cu reprezentanții sindicali;   • a oferi informații exacte și complete;   • a participa la audieri și ședințe;   • a respecta termenii și condițiile investigației;   • a nu ascunde detalii care ar putea afecta rezultatul procedurii.    Un proces disciplinar corect depinde atât de profesionalismul Union, cât și de implicarea membrului în cauză. Refuzul colaborării poate limita capacitatea Union de a-l proteja.

 -

---

---

- **(5.4)** Responsabilitatea de a plăti cotizațiile sindicale

---

---

- Cotizațiile reprezintă principala sursă de finanțare a Firefighter Union. Ele acoperă:    • costurile avocaților;   • arbitrajele externe;   • programele de suport psihologic;   • fondurile pentru familiile pompierilor decedați sau răniți;   • campaniile publice și conferințele;   • logistica internă și administrarea Union.    Fiecare membru are obligația de a plăti cotizația la timp. Lipsa contribuției financiare afectează direct capacitatea Union de a apăra drepturile colective.

 -

---

---

- **(5.5)** Responsabilitatea de a participa la voturi și ședințe

---

---

- Deciziile majore ale sindicatului — alegerea conducerii, aprobarea contractelor colective, modificările de regulament — nu pot fi luate decât prin votul membrilor.    Responsabilitatea individuală include:  • participarea la alegeri;   • votarea contractelor colective;   • implicarea în ședințele Union;   • consultarea documentelor oficiale.    Un sindicat în care membrii sunt pasivi își pierde forța instituțională. Un sindicat în care membrii participă activ devine o putere reală în fața conducerii.

 -

---

---

- **(5.6)** Responsabilitatea de a menține un climat de lucru sănătos

---

---

- Fiecare membru are obligația de a contribui la un mediu de lucru sigur, profesionist și colegial. Asta include:    • evitarea conflictelor inutile;   • respectarea colegilor și superiorilor;   • adresarea problemelor într-o manieră constructivă;   • colaborarea în timpul intervențiilor;   • raportarea unui comportament periculos sau a neregulilor operaționale.    Firefighter Union încurajează dialogul și medierea în locul conflictelor directe. Membrii trebuie să susțină această cultură.

 -

---

---

- **(5.7)** Responsabilitatea de a proteja imaginea Union și a profesiei

---

---

- Pompierii sunt figuri publice, iar comportamentul lor poate afecta atât reputația departamentului, cât și credibilitatea sindicatului.    Responsabilitățile membrilor includ:    • evitarea declarațiilor publice care prejudiciază Union sau Fire Department;   • interacțiuni respectuoase cu presa;   • responsabilitate în utilizarea rețelelor sociale;   • protejarea informațiilor confidențiale.    Sindicatul oferă libertate de exprimare, dar această libertate trebuie exercitată cu prudență și maturitate, pentru a proteja imaginea profesiei.

 -

---

---

- **(5.8)** Responsabilitatea de a raporta abuzurile și neregulile

---

---

- Membrii au obligația morală și profesională de a raporta:    • abuzuri ale conducerii;   • hărțuire;   • discriminare;   • probleme de siguranță;   • defecțiuni ale echipamentelor;   • încălcări ale procedurilor.    Firefighter Union garantează confidențialitatea raportărilor și protejează membrii împotriva represaliilor. Neraportarea unui abuz poate pune în pericol întreaga organizație.

 -

---

---

- **(5.9)** Responsabilitatea de a susține colegii aflați în dificultate

---

---

- Solidaritatea nu este doar un principiu simbolic — ea trebuie aplicată în fiecare zi. Membrii sunt responsabili pentru:    • sprijin emoțional în situații critice;   • ajutor pentru colegii implicați în proceduri disciplinare;   • suport pentru familiile membrilor răniți sau decedați;   • participarea la campaniile Union pentru ajutorare.    Un sindicat adevărat nu își lasă niciodată membrii să lupte singuri.

 -

---

---

- **(5.10)** Responsabilitatea de a contribui la dezvoltarea Union pe termen lung

---

---

- Pompierii au responsabilitatea de a:    • propune îmbunătățiri ale regulamentelor;   • participa la programele de formare sindicală;   • se implica în comisiile interne;   • susține proiecte pentru siguranța operațională.    Evoluția Firefighter Union depinde direct de implicarea fiecărui membru în dezvoltarea organizației.

 -

---
