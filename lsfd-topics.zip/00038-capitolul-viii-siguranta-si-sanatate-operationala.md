# CAPITOLUL VIII – SIGURANȚĂ ȘI SĂNĂTATE OPERAȚIONALĂ

- **Topic ID:** 38
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=38
- **Posts:** 1

---

## #1 — Kellan Dunley

![](https://i.imgur.com/2jlMxHe.png)

FIREFIGHTER UNION MANUAL

---

 CAPITOLUL VIII – SIGURANȚĂ ȘI SĂNĂTATE OPERAȚIONALĂ ÎN CADRUL FIREFIGHTER UNION
---

---

- **(8.1)** Importanța siguranței operaționale în profesia de pompier

---

---

- Siguranța operațională reprezintă fundamentul activității desfășurate de Fire Department. Profesia de pompier este una dintre cele mai periculoase și solicitante din sectorul public, membrii fiind expuși zilnic la:    • incendii structurale;   • prăbușiri de clădiri;   • accidente rutiere grave;   • situații medicale critice;   • materiale periculoase și substanțe toxice;   • condiții meteorologice extreme.    Firefighter Union are responsabilitatea de a se asigura că fiecare pompier își desfășoară activitatea în condiții sigure, cu echipamente adecvate și proceduri actualizate. Siguranța nu este un privilegiu — este un drept fundamental garantat tuturor membrilor.

 -
---

---

- **(8.2)** Rolul Union în supravegherea condițiilor de siguranță

---

---

- Union monitorizează în mod activ starea de siguranță din stații și de pe teren. Intervine atunci când:    • echipamentele sunt uzate sau incomplete;   • procedurile operaționale nu sunt respectate;   • evaluările de risc lipsesc sau sunt insuficiente;   • personalul este expus inutil unor situații periculoase;   • stațiile nu oferă condiții decente de odihnă, igienă și securitate;   • există neglijență managerială privind protecția membrilor.    Rolul Union este și preventiv, nu doar reactiv. Scopul principal este protejarea membrilor înainte ca un incident să se producă.

 -
---

---

- **(8.3)** Evaluarea echipamentelor operaționale

---

---

- Fiecare membru are dreptul la echipament complet, functional și actualizat conform standardelor internaționale (NFPA / EN). Acesta include:    • cască de protecție certificată;   • mănuși ignifuge;   • încălțăminte rezistentă la temperaturi extreme;   • costum structural complet;   • SCBA (Self-Contained Breathing Apparatus) în stare impecabilă;   • radio operațional;   • lanternă tactică;   • detectori de gaze, unde este cazul.    Union monitorizează:    • frecvența testării echipamentelor;   • mentenanța periodică;   • înlocuirea componentelor defecte;   • raportarea problemelor tehnice.    Dacă echipamentele nu respectă standardele minime, Union poate solicita suspendarea activităților până la remedierea situației.

 -
---

---

- **(8.4)** Standardele de siguranță în timpul intervențiilor

---

---

- Union se asigură că intervențiile se desfășoară conform procedurilor acceptate profesional:    • instructaj actualizat și adecvat;   • echipe complete, fără deficit de personal;   • respectarea regulii "Two in, Two out";   • absența presiunilor nejustificate pentru a forța intrarea în zone periculoase;   • utilizarea echipamentului complet;   • comunicare radio constantă.    Sindicatul intervine imediat dacă:    • comandamentele forțează pompierii în situații ilegale sau periculoase;   • sunt ignorate recomandările de securitate;   • personalul este expus în mod nejustificat riscurilor extreme.

 -
---

---

- **(8.5)** Expunerea la substanțe toxice și protecția membrilor

---

---

- Pompierii sunt frecvent expuși la:    • fum toxic;   • gaze cancerigene;   • materiale chimice periculoase;   • particule fine rezultate din incendii industriale;   • substanțe care afectează sistemul respirator.    Union militează pentru:    • măști și filtre de înaltă performanță;   • protocoale stricte de decontaminare post-intervenție;   • acces rapid la testări medicale specializate;   • instruire HAZMAT periodică;   • monitorizarea sănătății pe termen lung.    Dacă un membru este expus fără protecție adecvată, Union poate solicita investigație disciplinară împotriva responsabililor.

 -
---

---

- **(8.6)** Programul Union de prevenire a riscurilor operaționale

---

---

- Union dezvoltă și actualizează permanent un program intern de prevenire a riscurilor, care include:    • audituri periodice în stații;   • analiza intervențiilor cu risc ridicat;   • recomandarea unor noi proceduri operaționale;   • training specializat pentru scenarii complexe;   • colaborare cu ingineri de securitate și specialiști în incendii.    Analiza anuală a incidentelor permite identificarea tiparelor de risc și corectarea lor înainte de reapariție.

 -
---

---

- **(8.7)** Sănătatea mentală – sprijin și protecție psihologică pentru membri

---

---

- Expunerea constantă la situații traumatizante poate conduce la:    • burnout;   • anxietate;   • depresie;   • PTSD;   • tulburări de somn;   • scăderea concentrării.    Union consideră sănătatea mentală la fel de importantă ca pe cea fizică.    Membrii au dreptul la:    • consiliere psihologică profesională;   • suport după intervenții traumatice;   • confidențialitate totală asupra evaluărilor;   • programe de recuperare;   • redistribuire temporară în roluri non-operative, dacă este necesar.    Union se opune oricărei sancțiuni aplicate unui membru pentru vulnerabilități psihologice cauzate de natura profesiei.

 -
---

---

- **(8.8)** Proceduri post-intervenție și recuperare

---

---

- După intervenții dificile, Union promovează:    • ședințe de debriefing;   • evaluări tehnice ale intervenției;   • discuții deschise privind riscurile și greșelile;   • suport între membri;   • evaluări medicale și psihologice imediate.    Recuperarea completă după evenimente extreme este un drept garantat al pompierilor.

 -
---

---

- **(8.9)** Protecția membrilor împotriva presiunilor operaționale

---

---

- Union se opune cu fermitate situațiilor în care:    • membrii sunt obligați să lucreze peste capacitate;   • orele suplimentare devin excesive;   • echipele sunt incomplete;   • sunt ignorate limitele fizice și mentale ale pompierilor;   • se impune participarea la intervenții în condiții nesigure.    Sindicatul poate solicita oprirea activității în situații de risc iminent.

 -
---

---

- **(8.10)** Concluzii privind siguranța și sănătatea operațională

---

---

- Protecția vieții și sănătății pompierilor este prioritatea absolută a Firefighter Union.   Un sindicat eficient protejează membrul:    • înainte de intervenție, prin instruire și echipament adecvat;   • în timpul intervenției, prin proceduri corecte;   • după intervenție, prin recuperare și suport psihologic.    Un Fire Department puternic există doar atunci când pompierii sunt protejați, pregătiți și sprijiniți pe toate planurile.

 -

---
