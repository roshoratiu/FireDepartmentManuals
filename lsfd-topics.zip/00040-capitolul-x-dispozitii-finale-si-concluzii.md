# CAPITOLUL X – DISPOZIȚII FINALE ȘI CONCLUZII

- **Topic ID:** 40
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=40
- **Posts:** 1

---

## #1 — Kellan Dunley

![](https://i.imgur.com/2jlMxHe.png)

FIREFIGHTER UNION MANUAL

---

 CAPITOLUL X – DISPOZIȚII FINALE ȘI CONCLUZII
---

---

- **(10.1)** Scopul dispozițiilor finale

---

---

- Dispozițiile finale ale acestui manual oficial Firefighter Union au rolul de a clarifica aplicabilitatea regulamentelor, responsabilitățile membrilor și ale conducerii sindicale, precum și cadrul în care documentul poate fi modificat sau actualizat în viitor. Aceste prevederi asigură coerența și continuitatea sistemului sindical, garantând faptul că activitatea Union se desfășoară într-un mod transparent, stabil și eficient.

 -
---

---

- **(10.2)** Aplicabilitatea manualului

---

---

- Acest manual:    • se aplică tuturor membrilor Firefighter Union, indiferent de rang, funcție sau vechime;   • este obligatoriu pentru reprezentanții sindicali în exercitarea atribuțiilor;   • reprezintă documentul principal de referință în materie de proceduri sindicale;   • prevalează asupra oricăror reguli interne contradictorii, cu excepția legislației în vigoare.    Toți membrii au obligația de a cunoaște și respecta prevederile manualului, iar necunoașterea acestuia nu poate fi invocată în apărare în cazuri disciplinare sau administrative.

 -
---

---

- **(10.3)** Procedura de modificare a manualului

---

---

- Modificările aduse presentului manual pot fi realizate doar respectând o procedură clară și transparentă:    **(10.3.1) Inițierea modificării**   Modificările pot fi propuse de:    • Președintele Union;   • membrii Comitetului Executiv;   • cel puțin 10% dintre membrii activi ai sindicatului.    **(10.3.2) Analiza și evaluarea propunerilor**   Orice propunere este analizată de:    • Comisia Juridică;   • Comisia de Proceduri;   • Comisia de Negocieri (dacă modificarea are impact salarial sau contractual).    **(10.3.3) Aprobarea prin vot**   Modificările devin oficiale doar după:    • un vot favorabil cu majoritate de 50% + 1;   • publicarea versiunii actualizate;   • informarea tuturor membrilor.    Regulamentul nu poate fi modificat fără consultare prealabilă cu baza sindicală.

 -
---

---

- **(10.4)** Interpretarea prevederilor manualului

---

---

- În cazul în care apar neclarități, prevederile manualului sunt interpretate:    • în favoarea membrului;   • în spiritul protecției sindicale;   • conform legislației muncii;   • ținând cont de jurisprudența din cazurile sindicale similare;   • cu consultarea consilierilor juridici ai Union.    Nicio interpretare nu poate fi făcută în detrimentul membrilor fără o justificare solidă și documentată.

 -
---

---

- **(10.5)** Validitatea documentelor și procedurilor interne

---

---

- Acest manual funcționează în paralel cu:    • Contractul Colectiv de Muncă (CCM);   • regulamentele interne ale Fire Department;   • standardele profesionale internaționale (NFPA / EN);   • legislația federală, statală și locală.    În cazul unui conflict între manual și regulamentele FD, prevalează documentul care oferă mai multă protecție membrului.

 -
---

---

- **(10.6)** Responsabilitățile de implementare ale conducerii Union

---

---

- De implementarea și interpretarea corectă a manualului răspund:    • Președintele Firefighter Union;   • Vicepreședintele;   • Directorii de Departamente Sindicale;   • Comisia Juridică;   • Comisia Disciplinară;   • reprezentanții sindicali din stații.    Aceștia trebuie să:    • explice membrilor prevederile;   • asigure aplicarea corectă a procedurilor;   • raporteze anual eventualele probleme;   • propună actualizări, dacă situația o impune.    Nerespectarea obligațiilor de implementare constituie abatere sindicală.

 -
---

---

- **(10.7)** Publicarea și accesul la manual

---

---

- Manualul este pus la dispoziția membrilor prin:    • platforma oficială a sindicatului;   • canalele interne de comunicare;   • afișare în fiecare stație de pompieri;   • distribuire digitală, la cerere.    Membrii au dreptul la acces permanent la toate versiunile manualului — inclusiv versiunile istorice, pentru transparență totală.

 -
---

---

- **(10.8)** Mecanisme de audit și revizuire periodică

---

---

- Manualul este revizuit oficial:    • o dată la 12 luni;   • după orice situație excepțională care expune probleme în procedurile curente;   • după modificări majore în legislație;   • la solicitarea justificată a Comitetului Executiv.    Revizuirea urmărește:    • adaptarea la noile nevoi ale membrilor;   • actualizarea procedurilor disciplinare;   • modernizarea standardelor de siguranță;   • îmbunătățirea proceselor de negociere colectivă.    Raportul anual de audit este făcut public membrilor.

 -
---

---

- **(10.9)** Principiul continuității protecției sindicale

---

---

- Indiferent de modificările administrative, de schimbarea conducerii union sau de transformările operaționale din cadrul Fire Department, un principiu rămâne imuabil:    **Protecția membrilor este prioritatea absolută a Firefighter Union.**    Niciun membru nu este lăsat singur în fața unei proceduri disciplinare, a unei probleme medicale, a unei situații traumatice sau a unei dispute cu administrația.

 -
---

---

- **(10.10)** Concluzii finale

---

---

- Acest manual reprezintă documentul central al identității Firefighter Union. Prin el, organizația:    • protejează membrii;   • reglementează procedurile;   • definește drepturile și responsabilitățile;   • stabilește mecanismele de negociere;   • garantează transparență și corectitudine.    Ca instituție, Firefighter Union se bazează pe solidaritate, curaj și devotament — valorile fundamentale care definesc profesia de pompier.   Manualul este un instrument viu, menit să evolueze odată cu nevoile membrilor și cu provocările profesiei.    **Un sindicat puternic înseamnă pompieri protejați.   Pompieri protejați înseamnă un oraș mai sigur.**

 -

---
