# ENGINE - Handbook

- **Topic ID:** 13
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=13
- **Posts:** 1

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

ENGINE

---

---

---

**1. ECHIPAMENT INDIVIDUAL DE PROTECȚIE (EIP)**
---

---

 Pompierii sunt supuși multor condiții periculoase de muncă. Din acest motiv, Statele Unite ale Americii solicită tuturor pompierilor să se asigure, în toate situațiile, că au echipament individual de protecție (EIP) în care nici o parte a hainelor nu se poate aprinde atunci când sunt expuse la temperaturi de 260 °C timp de 5 minute. Această îmbrăcăminte este, de asemenea, cunoscut sub numele de "echipament de teren" și constă din următoarele:

 1.1 **Bunker Pants**
- Pantalonii sau pantalonii de prezență la foc sunt, în general, prima piesă de îmbrăcăminte purtată de un pompier. Aceștia constau în bretele care asigură faptul că pantalonii sunt mereu ridicați, indiferent de modul de muncă și efortul depus. Buzunarele permit transportarea instrumentelor de stingere a incendiilor și a frânghiei în caz de urgență.   ``` [SHOW] ```

 1.2 **Turnout Coat**
- Haina de prezență la foc este formată din Velcro, pelerină de furtună și fermoare pentru a permite unui pompier să echipeze în mod corespunzător această haină de protecție. La fel ca pantalonii de prezență la foc buzunare supradimensionate permit pompierului să efectueze proceduri esențiale de stingere a incendiilor în caz de urgență. Tornout Coat oferă, de asemenea, protecție la încheietura mâinii prin utilizarea de material la sfârșitul mânecii, care permite trecerea degetului mare.   ``` [SHOW] ```

 1.3 **Flash Hood**
- Căștile nu sunt capabile să ofere suficientă protecție urechilor, gâtului și unei părți a feței și, prin urmare, este necesară utilizarea unui Flash Hood împotriva incendiilor cunoscută sub numele de capota flash. Pentru a purta corect gluga, trebuie mai întâi să introduceți gluga în guler, să îmbrăcați masca SCBA și apoi să trageți gluga peste sigiliul feței pentru a acoperi orice piele expusă.   ``` [SHOW] ```

 1.4 **Helmet**
- Casca protejează un pompier împotriva rănirii potențiale a capului de resturile care cad, precum și protecția împotriva căldurii. Vizorul protejează ochii pompierilor în timpul oricăror operațiuni de salvare/extirpare de praf, resturi și căldură. Pentru partea din față a fiecărei căști este un scut pentru a reprezenta un pompier, care prezintă rangul lor și numărul de insigna.   ``` [SHOW] ```

 1.5 **Fire Boots**
- Cizmele pompierilor sunt fabricate din cauciuc de oțel la picior. Acestea pot fi strecurate în picioarele pantalonilor prezenți și nu numai că sunt rezistente la foc, ci oferă pompierului o protecție suplimentară la loviturile potențiale care ar putea apărea.   ``` [SHOW] ```

 1.6 **Mănuși de foc**
- Pentru a asigura protecția mâinilor împotriva căldurii și a obiectelor ascuțite, se poartă mănuși structurale care se potrivesc peste Turnout Coat și sub manșonul stratului. Acestea sunt ușoare și permit pompierilor să dispună de dexteritatea degetelor pentru ca aceștia să poată îndeplini funcțiile necesare sarcinii unui pompier.   ``` [SHOW] ```

 1.7 **Aparatde respirat autonom (SCBA)**
- Un aparat de respirație autonom, sau SCBA, este purtat de pompieri în condiții în care nu este recomandabil sau imposibil ca aceștia să respire singuri (orice atmosferă periculoasă - de exemplu, o structură cu fum greu / dens). Există patru părți principale ale SCBA care sunt montate pe un cadru de transport pe spatele pompierilor:   - Un regulator de presiune - Un conector prin inhalare - mască bucală/mască bucală/mască facială - Un rezervor de înaltă presiune care conține oxigen - SCBA Ham - cu dispozitiv **PASS**    ``` [SHOW] ```

 1.8 **Dispozitivul PASS**
- Un dispozitiv de siguranță personală de alertă (PASS) este utilizat de toți pompierii atunci când intră într-o clădire periculoasă, cum ar fi un incendiu de structură. Dispozitivul PASS este atașat la hamul de pe toate SCBA și permite ajutorul să fie convocat de un zgomot puternic puternic de 95 decibeli.    Dispozitivul poate fi activat în două moduri, manual prin apăsarea unui buton roșu situat pe partea laterală a dispozitivului de trecere sau automat. Când este activat automat, înseamnă că nu au fost detectate mișcări de către laserele încorporate în dispozitivul de trecere timp de 15 secunde, ceea ce înseamnă un pompier rănit. Alerta va suna apoi permițând pompierilor să poată localiza pompierul urmărind sunetul emis de dispozitiv.

---

---

**2. INSTRUMENTE ȘI ECHIPAMENTE**
---

---

 2.1 **General Tools**
- În vehiculele de stingere a incendiilor există mai multe instrumente pentru a ajuta pompierul în toate situațiile care pot apărea și sunt depozitate în compartimentele găsite în partea și spatele motoarelor / camioanelor. Unelte medicale sunt, de asemenea, disponibile pe motoare / camioane, cum ar fi truse medicale, panouri, KED și coliere cervicale. Mai jos este o listă de instrumente de stingere a incendiilor care pot fi găsite în compartimente: (Faceți clic pe nume pentru a vedea o imagine)  - [**Center Punch**](http://i.imgur.com/sy62ry5.jpg) - Utilizat pentru a sparge ferestrele laterale ale unui vehicul. - [**Cutting Clești**](http://i.imgur.com/2YNezi1.jpg) - Folosit pentru a tăia cablurile, de exemplu cablurile bateriei. - [**Fireaxe**](http://i.imgur.com/GQGbqDl.jpg) - Folosit pentru a dărâma pereții/ușile sau pentru a reduce obstacolele. - [**Glass-master**](http://i.imgur.com/RfRBhQJ.jpg) - Folosit pentru a sparge sticla (MVA, etcetera). - [**Halligan bar**](http://i.imgur.com/NF72G7Q.jpg) - Se folosește pentru a îndepărta, lovi, găuri, răsuci, îndepărta și tăia orice tip de bariere / obstrucții. - [**Hose Bridge**](http://i.imgur.com/mg2YdJn.jpg) - Amplasat peste furtunuri pentru a preveni conducerea sau împiedicarea persoanelor. - [**Duza furtunului**](http://i.imgur.com/M1o3Ihh.jpg) - Folosit pe furtunurile de incendiu pentru a permite cantitatea corectă de apă să curgă prin și pentru a opri apa să devină incontrolabilă. - [**Hydrant Tool**](http://i.imgur.com/VzqeKcs.jpg) - Pentru deschiderea unui hidrant regulat și atașarea furtunului. - [**Kendrick's Extraction Device (KED)**](http://i.imgur.com/q3kLp9i.jpg)Extrageți oameni din vehicule / zona, prevenirea leziunilor gâtului și spatelui, asigurarea gâtului, capului și spatelui. - [**Mallet**](http://i.imgur.com/qCVwzM2.jpg) - Folosit pentru a sparge pereții și alte materiale ușoare. - [**Pike Pole**](https://4.bp.blogspot.com/-PTvAo3OAKTU/TzGyyfrIBBZI/AAAAAAF7E/JgFQEgeW4Hc/s640/pike+pole.jpg)- Poate fi folosit pentru a testa rezistența pereților/podea/tavan, precum și pentru a verifica cenușa pentru foc sau cărbuni fierbinți. - [**Salvage Covers**](http://i.imgur.com/9M5F0VX.jpg) - Folosit pentru a acoperi materialele pentru a se deteriora (în continuare). - [**Sledgehammer**](http://i.imgur.com/YmZKNrl.jpg) - Folosit pentru a dărâma pereții/ușile. - [**X-collar**](http://i.imgur.com/KXa4p03.jpg) - Folosit pentru a imobiliza gâtul pentru a preveni alte leziuni.

 2.2 **Hidraulic Rescue Tools**
- - Instrumentele hidraulice de salvare, denumite popular "Fălcile vieții", sunt aparate utilizate în extricarea vehiculului (eliberarea unei persoane prinse dintr-un vehicul). Există două variante principale ale acestor instrumente:    2.2.1 **Spreaders-Cutters** - Acest instrument, denumit în mod convenabil ca „instrument combinat” sau „instrument combinat”, combină atât distribuitorul, cât și tăietorul într-unul. Distribuitorul este folosit pentru a îndepărta bucăți din structura mașinii sau poate fi introdus în partea laterală a vehiculului pentru a rupe o secțiune (de exemplu, o ușă). Tăietorul, așa cum sugerează și numele, este folosit pentru a tăia vehiculul (de exemplu, stâlpii săi) ca o pereche de tăietoare cu șuruburi uriașe.   ``` [SHOW] ```   2.2.2 **Ram hidraulic** - Funcția Ram hidraulic este de a împinge secțiunile mașinii (sau alte structuri). De exemplu, un lucrător de salvare poate așeza un Ram hidraulic pe cadrul ușii și poate extinde pistonul pentru a împinge tabloul de bord în sus, creând suficient spațiu pentru a elibera victima unui accident.   ``` [SHOW] ```

---

---

**3. FURTUNURI ȘI EXTINCTOARE**
---

---

 3.1 **Tipuri de furtun**
- 3.1.1 **Crosslay/Live-Line** - La sosirea la fața locului, pompierii implementează de obicei aceste linii mai întâi. Ele sunt ușoare, ceea ce le face ușor de utilizat și ideal pentru cele mai multe incendii auto și incendii structura rezidentiala. Liniile sunt 1.80"grosime și 200ft lung.  **Locație:** Trei per motor, 2 în partea stângă (deasupra pompei), 1 în partea dreaptă (deasupra pompei).  **Pre-conectat:** Da   ``` [SHOW] ```   3.1.2 **Booster Line** - Linia se alimentează dintr-o bobină de furtun și nu este mai groasă de 1". Folosit pentru incendii la coșul de gunoi, incendii de iarbă la fața locului, incendii de coș de fum, răcire a obiectelor și alte incendii mici.  **Locație**: Partea dreaptă a motorului lângă panoul pompei.  **Pre-conectat:** Da   ``` [SHOW] ```   3.1.3 **2.5" Line** - Folosit în principal pentru atacuri exterioare și are o grosime de 2,5". Atunci când este încărcat, este foarte dificil de manevrat, de aceea trebuie sa stați îngenunchiați.   **Localizare:** 2 linii în patul furtunului.  **Pre-conectat:** Da   ``` [SHOW] ```   3.1.4 **Potop Gun/Deck Gun/Master Stream** - Cel mai puternic dintre toate liniile și este utilizat atunci când există dificultăți de stingere a unui incendiu mare și încăpățânat (cum ar fi focul industrial). Evacuări de peste 1000 galoane de apă pe minut și trebuie să fie utilizate cu moderație. De asemenea, se poate crea o mulțime de daune la obiecte și oameni, dacă nu este utilizat cu înțelepciune.  **Locație:** În partea de sus a Engine-ului.  **Pre-conectat:** Da.   ``` [SHOW] ```   3.1.5 **Hose Pack** - Se conectează la liniile live pentru a duce apa la niveluri mai înalte ale unei clădiri. Mici și mai ușor de a transporta pe scări fiind de 100ft lung și 1.80 "grosime.  **Locație:** Trei în partea din spate a motorului în dulapuri, doua randuri (șase în total).  **Pre-conectat:** Nu   ``` [SHOW] ```   3.1.6 **Supply Line/Relay Line** - Folosit pentru conectarea motorului de incendiu la un hidrant/tandrețe/alt motor pentru aportul de apă. Linia este de 1000ft lung și 5 "grosime.  **Localizare:** Spatele motorului într-un pat de furtun.  **Pre-conectat:** Nu   ``` [SHOW] ```     O mașină de pompieri își umple rezervoarele după fiecare repartizare și poate ține până la 1.000 galoane (3.785 litri). Prin urmare, în timp ce sunt repartizate unui incendiu, cele 1.000 de galoane de apă vor dura doar o anumită perioadă de timp. Deci, ca atare, straturile încrucișate scot 95 galoane (360 L) pe minut, prin urmare, după 10,5 minute, rezervorul va fi gol, în timp ce arma punții (potopului) scoate 1.000 de galoane pe minut, prin urmare, 1 minut mai târziu, rezervorul este gol. Ca urmare, o rețea de hidranți de incendiu se întinde pe raza Los Santos pentru a vă conecta liniile de alimentare în timpul stingerii incendiilor. Când ajungeți la o scenă unui incendiu, una dintre primele dvs. priorități ar trebui să fie localizarea celui mai apropiat hidrant și conectarea acestuia la primul Engine de la scenă. În cazul în care hidrantul este prea departe, luați în considerare utilizarea unui al doilea Engine ca „verigă” la hidrant și pompați apa prin intermediul mașinii de pompieri conectată la celălalt Engine în serviciu activ de stingere a incendiilor. În cazuri rare, un [hidrant](https://i.imgur.com/uzH1kLr.jpg) nu poate fi disponibil și ar trebui să căutați surse alternative de apă.   ``` [SHOW] ```

 3.2 **Extinctoare de incendiu**
- 3.0 2.1 **Fire Classes** - Imaginile vor putea fi găsite pe extinctorul pentru a arăta pentru ce este util.       ![Image](http://i.imgur.com/d04ni5K.jpg)      **Clasa A:** Util pentru stingerea solidelor (gândiți-vă la lemn, hârtie, textile etcetera)  **Clasa B:** Util pentru stingerea lichidelor (gândiți-vă la ulei, benzină, grăsimi etcetera)  **Clasa C:** Util pentru stingerea gazului (gândiți-vă la butan, propan, gaz natural) (Rețineți: Închiderea supapei sursei de gaz, ar fi o țeavă, este mai bună decât utilizarea unui extinctor)  **Clasa D:** Util pentru stingerea metalelor (gândiți-vă la magneziu, aluminiu etcetera)  **Clasa E:** Util pentru stingerea de electrice, în esență la fel ca A și B, dar nu puteți folosi spumă sau apă pe ea din cauza este o combinație proastă. Puteți utiliza CO² pe ea, care este cel mai probabil un extinctor clasa E.  **Clasa F:** Util pentru stingerea uleiurilor și grăsimilor foarte calde, ar fi cuptoarele de prăjire.   3.2.2 **Extinctor Types** - **Pulbere uscată:** Clasa A, B, C, D.  **Dioxid de carbon:** Clasa B, C, E (Utilizați alte stingătoare la incendiile din clasele B și C, dacă este posibil).  **Spumă:** Clasa A, B, C, D și F numai dacă este un extinctor clasa F.  **Apă:** Numai clasa A.

 3.3 **Firefighting Foam**
- Spuma de stingere a incendiilor este folosită la stingerea anumitor incendii și s-a dovedit a fi, în anumite circumstanțe, mai eficientă decât apa. Spumele ignifuge sunt rezistente la alcool și se răcesc rapid și pot potoli focul prin acoperirea combustibilului și acoperirea vaporilor. Ele sunt, de asemenea, utile pentru protejarea zonelor nearse de a se implica în flăcări. Spuma funcționează prin furnizarea unei pături pe suprafață și separându-l de aer (oxigen). Acest lucru funcționeaz cu Triunghiul de Foc.    Există multe tipuri diferite de concentrație de spumă, dar singurele cu care trebuie să fiți familiarizați sunt:  - **CLASA A Concentrat:** Utilizat la combaterea incendiilor din clasa A (hârtie, lemn, deșeuri menajere, haine, plastic, etcetera). - **CLASA B Concentrat:** Utilizat la combaterea clasei B (lichid/gaz inflamabil), clasa D (metale) și incendiile din clasa K (uleiuri/grăsimi de gătit).   Introducerea concentratului de spumă în apă este ușoară și poate fi realizată prin panoul pompei motorului. Cele mai multe motoare LSFD transporta aproximativ 20 galoane (76 L) de spumă pură.

---

---

**4. ACCIDENTE DE AUTOVEHICULE**
---

---

 Următorii pași vă prezintă modul în care ar trebui să abordați în mod obișnuit un accident de autovehicul (MVA) / (Road) Trafic coliziune ((R) TC), și modul în care ar trebui să efectueze extirparea vehiculului în cazul în care și atunci când mijloacele convenționale de ieșire sunt imposibile sau nerecomandabile. În cazuri mai puțin complicate, este posibil să se scoată victima fără a tăia efectiv vehiculul, ar fi îndepărtarea unei persoane de pe ușa laterală sau dintr-o altă parte a vehiculului. Această secțiune vă va arăta, de asemenea, să se ocupe de incendiu vehiculului și scurgeri.

 4.1 **Scene Size-Up**
- **1.** Parcați unitatea/autospeciala în mod strategic spre vehicul(e), de preferat cu partea laterală orientată spre vehicul, la o anumită distanță suficient de lungă încât vehiculul să nu se deterioreze în caz de incendiu sau explozie și totuși suficient de aproape pentru a avea acces rapid la echipament și ușor.  **2.** Prima unitate de la fața locului va prelua rolul de Comandament incident până când un angajat clasat mai sus preia controlul, sau atunci când șeful Spitalului preia Comanda incidentelor.  **3.** Comandamentul incidentelor va apela la resursele suplimentare atunci când este necesar la prima vedere (PD/SD, HAZMAT, echipamente suplimentare de stingere a incendiilor).  **4.** Verificați dacă există pericole, cum ar fi incendii, fum, scurgeri, trafic și mulțime.  **5.** Dacă există o scurgere activă trece la punctul 4.2. Dacă există un incendiu activ sau fum, treceți la secțiunea 4.3.   **6.** Asigurați-vă că vehiculul este în siguranță înainte de a trece mai departe pentru pașii următori, a se vedea dacă este stabilizat, dacă nu, adăugați tije de stabilizare sau berbeci hidraulici la părți pentru a vă asigura că mașina este asigurată.  **7.** Odată ce totul este în siguranță, spuneți EMT la fața locului că el sau ea este capabil să se uite la pacient (DR CAB etcetera).  **8.** În cazul în care EMT nu este în măsură să acceseze victima din cauza unei ferestre, utilizați un Glass-Master pentru a elimina fereastra (sparge-l în utilizarea pin, sticla cel mai probabil nu va cădea direct pe victimă.)  **9.** Deconectați firele bateriei folosind mâinile sau cleștele. (Va trebui să deschidă capota cu Halligan Bar) (Acest lucru se face pentru a opri activitățile electrice în vehicul pentru a preveni riscurile de incendiu, de siguranță și pentru a dezactiva airbag-uri active .)

 4.2 **Leaks**
- **1.** Luați un crosslay, utilizați spuma clasa B.  **2.** Aflați sursa scurgerii și cât de mare este.  **3.** Pulverizați spuma pe scurgere și împrejurimile acesteia, împiedicând-o să ia foc din cauza spumei care blochează oxigenul să ajungă la combustibil (Triunghiul de foc).

 4.3 **Fire vehicul**
- **1.** Dacă este un foc foarte mic și nu scurgeri, utilizați fie un Crosslay sau o linie de rapel cu apă.  **2.** Dacă există o scurgere, utilizați spuma clasa B.  **3.** Dacă focul este în afara hotei, stingeți direct.  **4.** Dacă focul este sub capotă, îndreptați duza furtunului între roată și motor și stingeți tot ce puteți.  **5.** După ce ați făcut acest lucru, deschideți capota încet și parțial cu un bar Halligan.  **6.** Așezați duza furtunului între bara de protecție și hotă și deschideți-o complet, după o perioadă de timp puteți deschide complet capota și termina stingerea.

 4.4 **Extrication**
- 4.4.1 **General Extrication** - Uneori nu este necesar să se taie ușa și/sau acoperișul pentru a extrage victima din cauza ușii care se poate deschidă perfect și există suficient spațiu pentru a extrage victima .    **1.** Îndepărtați orice obstacole, de exemplu dacă victima poartă centura de siguranță, tăiați-o sau îndepărtați-o manual.  **2.** Așezați un C-Guler în jurul gâtului pacienților dacă nu poarta încă unul.  **3.** Așezați un dispozitiv de extracție Kendrick 's (KED) în spatele pacientului, fixați curelele din jurul trunchiului, gâtului și capului. (Notă: utilizarea KED nu este obligatorie)  **4.** Ridicați pacientul din mașină cu ajutorul altcuiva, unul prinde de KED iar celalalt de picioare.  **5.** Odată scoasa din mașină, puneți victima pe tablă și pe targă.   4.4.2 **Extracție rapidă** - Această tehnică este utilizată atunci când o victimă este într-o stare cricticală și trebuie să fie extrase imediat. Exemplele de alegere a extracției rapide în locul extracției generale sunt:  - Stop cardiac. - Respiratorie defectare. - Șoc . - Intracranian presiune. - Incontrolabila sângerare externă. - Modificat pacienților. - Penetrant leziuni. - Nesigur situațiile de urgență.   **1.** Unul dintre EMS / pompieri aplică stabilizarea cervicală în timp ce se află în partea din spate a vehiculului, în spatele vicitimei.  **2.** EMS suplimentare / Pompier aplică gulerul corect pentru a ajuta cu stailiation cervicale.  **3.** Așezați placa de spate lângă victimă.  **4.** Întoarceți victima spre deschiderea ușii, astfel încât victima să fie perpendiculară pe volan.  **5.** Coborâți pacientul pe placa din spate, menținând în același timp o prindere sigură a capului și a spatelui pentru stabilizare.  **6.** Glisați pacientul mai sus pe placa din spate.   4.4.3 **Scoaterea ușii** - **1.** Scoateți fălcile vieții (JOL's) din motor (Spreaders-Cutters) și conectați-l la priza hidraulică a pompei.  **2.** Mergeti cu JOL-ul la usa si decideti daca est un spetiu suficient de mare pentru a intra taietorile inauintru. Daca nu, verificati daca este posibilia utilizarea spreaders, pentru a face un spatiu mai mare.  **3.** Dacă nu există un decalaj suficient de mare utilizați Halligan Bar pentru a crea un decalaj mai mare.  **4.** Utilizați spreaders pentru a face decalajul suficient de mare pentru a se potrivi pentru tăietori.  **5.** Folosiți cutters pentru a tăia prin balamalele ușii vehiculelor.  **6.** Până acum, ușa ar cădea din cadrul său.   4.4.4 **Scoaterea acoperișului** - **1.** Scoateți parbrizul folosind un Glas-Master,utilizați pinul pentru a face o gaură suficient de mare pentru ferăstrău.  **2.** Folosiți ferăstrăul glas-masterpentru a vedea partea de jos aparbrizului.  **3.** Luați fălcile vieții și utilizați tăietorii pentru a tăia prin stâlpii A, B, C și D ai vehiculului.  **4.** Scoateți acoperișul de pe mașină cu un alt pompier, glisați-l la portbagaj și în cele din urmă pe teren.   4.4.5 **Eliberarea picioarelor** - **1.** Luați berbecul hidraulic de la motor.  **2.** Așezați berbecul hidraulic între podeaua mașinii și tabloul de bord.  **3.** Apăsați butonul de pe ramul hidraulic, ceea ce îl face să se extindă și să apăsați tabloul de bord în sus.

 4.5 **Aftermath**
- Verificați dacă există pericole rămase (alte incendii, alte scurgeri active etc.
- Apel pentru Wrecker (FD Towtruck)prin TOC sau contactați o unitate de sechestrare peste departamental de la CITY, PD sau SD pentru a obține vehiculul remorcat departe de locul faptei.
- Ca Comandamentul incidentelor, lăsați unitățile să se retragă și să cheme un sistem clar.

---

---

**5. TIPURI DE TRANSPORT**
---

---

 În timpul executării acestei profesii, s-ar putea să fie nevoie să transporte o victimă inconștientă departe de o locație. Există câteva tipuri care sunt explicate în acest ghid în detaliu.

 5.1 **Fireman's Carry**
- **1.**Îngenuncheați lângă victimă în partea nevătămată.  **2.** Așezați brațele victimei deasupra capului.  **3.** Treci glezna cea mai îndepărtată de tine peste cea care este aproape de tine.  **4.** Apuca umărul victimei și șoldul, care este departe de tine.  **5.** Trageți victima spre tine pentru a rula victima pe stomac.  **6.** Așezați coatele sub axilele victimei.  **7.** Ridicați victima în picioare.  **8.** Puneți piciorului drept între picioarele victimei.  **9.** Apucați încheietura dreaptă a victimei cu mana stânga.  **10.** Așezați-vă într-o poziție ghemuit.  **11.** Înfășurați brațul în jurul spatelui genunchiului drept al victimei.  **12.** Ridicați-vă și odihniți coapsa dreaptă a victimei pe umărul vostru drept.  **13.** Transportați victima departe de locație.  ``` [SHOW] ```

 5.2 **Hawes Carry**
- **1.** Îngenuncheați lângă victimă în partea nevătămată.  **2.** Așezați brațele victimei deasupra capului sale.  **3.** Treceți glezna cea mai îndepărtată de dvs. peste cea care vă este aproape.  **4.** Prindeți umărul și șoldul victimei care sunt departe de voi.  **5.** Trageți victima spre voi pentru a o rostogoli pe stomac prin partea ei nevătămată.  **6.** Așezați coatele sub axilele victimei.  **7.** Ridicați victima în picioare.  **8.** Folosiți una dintre mâini pentru a ridica brațul victimei în timp ce susțineți victima cu cealaltă.  **9.** Așezați-vă capul și corpul sub brațul ridicat al victimei, astfel încât să stați în fața ei.  **10.** Ridicați din nou brațul victimei și întoarceți-vă corpul la 180 de grade, astfel încât spatele să fie de pieptul ei, lăsând brațul victimei în jurul gâtului și umărului.  **11.** Ridicați victima de pe picioare aplecându-vă înainte.  **12.** Reglați corpul în mod corespunzător pe spate, dacă este necesar și duceți victima departe de locație.  ``` [SHOW] ```

 5.3 **Two-Person Support**
- **1.** Fiecare persoană se sprijină pe un genunchi (opus unul altuia).  **2.** Ambele persoane stau cu o mână sub umerii victimei.  **3.** Apucați încheieturile partenerului.  **4.** Mâinile libere sunt așezate sub genunchii victimei.  **5.** Apucați încheieturile partenerului.  **6.** Numărați până la trei și ambii EMS / pompieri ar trebui să se ridice sincronizat.  **7.** Duceți victima în siguranță.  ``` [SHOW] ```

---
