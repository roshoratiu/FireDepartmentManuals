# Marine Company No. 1 Operational Manual.

- **Topic ID:** 18
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=18
- **Posts:** 1

---

## #1 — Matthew Williams

![](https://i.imgur.com/2jlMxHe.png)

Marine Incidents

---

---

---

**1. Marine Indicents**
---

---

 Acest manual a fost conceput cu scopul de a instrui angajati departamentului despre cum sunt tratate incidentele maritime.

 1.1 **Evaluarea transportului**
 - Elementul transportat este obligatoriu notat pe partea din fata sau din spate a container-ului si nu trebuie sa lipseasca
```
[SHOW]Evaluarea transportului
```

![](https://i.imgur.com/2jlMxHe.png)

Marine Incidents

---

---

---

**2. Lupta cu incendiile in port.**
---

---

  **2.1 Strategii si tactici**
```
[SHOW](a) Actiunile difera de la nava la nava, insa, acestea sunt foarte similare. Primul lucru care se va face asta ca Fire Officer-ul sa contacteze cea mai inalta persoana din dispozitivul barcii, care ii va pune la dispozitie toate informatiile. Se vor oferii informatii cum ar fi:
 Cati oameni sunt la bord si cand au fost vazuti ultima data.
 Locatia focului.
 Ce materiale sunt implicate.
 Informatii despre materiale de risc ce sunt situate foarte aproape de foc.
 Cum se poate ajunge la locul incendiului.
 Ce sisteme de lupta cu focul sunt disponibile pe nava.
 Ce motoare principale si auxiliare pot fi utilizate.
 Ce sisteme de ventilatie pot fi utilizate.
Cel mai bine ar fi ca divizia sa isi foloseasca echipamentul propriu, insa, personalul navei poate ajuta fortele de interventie pentru ghidarea acestora, etc. Incident Commander-ul, obligatoriu, va opri sistemele de ventilatie si sistemele electronice.
(b) Localizarea focului se va realiza in functie de prezenta fumului si alti factori. Daca sistemele anti-incendiu ale navei sunt inca in functie, acestea vor afisa locatia incendiului.
(c) Apropierea fata de foc sa va face pe rute foarte scurte sau rute ce nu au o temperatura insuportabila.
```

  **2.2 Utilizarea apei**
```
[SHOW](a)Atacul cu apa se face direct in unele cazuri, atunci cand incendiul poate fi lichidat foarte rapid si riscul de distrugere cu apa este nesemnificativ.
(b) In cazul in care strategia de atac direct esuasa, se va apela o tactica numita "inundatia compartimentului". Pompieri la comanda Incident Commander-ului for inunda compartimentul, insa, aceasta tactica va fi folosita ca ultima varianta intrucat va distruge toata marfa din respectivul compartiment.
```

  **2.3 Utilizarea altor materiale pentru stingere**
```
[SHOW](a)Dioxidul de carbon (CO2) este un foarte bun agent pentru stingerea unor incendii navale. Nu avem nevoie de pompe pentru utilizarea acestuia, acesta nu afecteaza stabilitatea navei si nu deterioreaza bunurile de pe nava. Insa, acesta poate deterioara materialele ce au nevoie de oxigen, spre exemplu bumbacul, care la lipsa de oxigen se va oxida.
(b) Se poate utiliza ARFF(Firefighting Foam) intrucat aceasta este mult mai mobila, poate fi refulata pe distanta destul de mari, nu deterioreaza marfa de pe nava si nu afecteaza stabilitatea navei.
```

  **2.4 Ventilarea**
```
[SHOW]Ventilarea pe o nava este foarte dificila intrucat oxigenul produs in urma ventilarii acestuia poate contribui semnificativ la reizbucnirea incendiului, intrucat si sistemele de ventilatie ale navei sunt oprite la sosire de catre echipa de interventie din acest motiv.
Ventilatia pe o nava poate fi folosita doar in cazul in care este obligatorie evacuarea fumului pentru a permite trecea echipelor de interventie.
```

 **2.5 Nave generale**
```
[SHOW]O mare parte din marfă este, bineînțeles, transportată în prezent pe nave container și alte nave specializate.
Cu toate acestea, există încă nave de marfă generală de tip tradițional, care pot transporta o varietate de mărfuri. Pompierii trebuie să țină cont de faptul că încărcăturile pot fi foarte variate: unele sunt în mod inerent periculoase, în timp ce
altele pot deveni astfel în urma reacției lor la căldură sau apa. Unele încărcături, deși nu sunt periculoase din punct de vedere chimic, prezintă un risc pentru siguranța navei și, indirect, la adresa vieții, deoarece afectează stabilitatea navei prin deplasarea în mișcare sau prin umflarea ca urmare a absorbției de apă. Dimpotrivă, utilizarea nechibzuită a unui incendiu de stingere a incendiilor sau a unui agent de stingere greșit, poate cauza deteriorării inutile a încărcăturii. În urma unei evaluări dinamice a riscurilor, poate fi considerat necesar ca pompierii care poartă BA și care utilizează linii de ghidare să intre în cala pentru a aborda sediul incendiului.
```

 **2.6 Ferryboat**
```
[SHOW]Navele Ro-Ro variază în funcție de utilizarea lor. Un vagon pentru transportul în vrac poate transporta câteva mii de mașini, în timp ce un feribot poate transporta până la 500 de vehicule și 1.500 de persoane. Evident, atunci când un feribot ia foc în port, toți pasagerii vor fi evacuați cât mai curând posibil. Unele nave moderne sunt dotate cu dispozitive de evacuare de salvare similare cu cele de pe navele mari, aeronave, dar, în orice caz, pompierii ar putea întâlni un număr mare de persoane care părăsesc nava pe măsură ce sosesc. Ar trebui să se acorde toată asistența acordată pentru a asigura debarcarea lor în siguranță. Este posibil ca unele persoane să încerce să se întoarcă la mașini trebuie să fie luată în considerare.
```

  **2.7 Nave de Pasageri**
```
[SHOW]O primă asistență tipică la un incendiu ar putea consta înpatru pompe și un tender de urgență. Echipajelear trebui să se îmbarce cu echipamente care să includă echipamente generalelinii de uz general, adaptoare, aparate de respirație,plăci BA de etapa 2, camere de termoviziune, furtunuri de refulare și ramuri de control variabile. Pe navele mari, este posibil ca aceștia să poată face să funcționeze jeturi de la rețeaua electrică a navei, dar de obicei vor obține aprovizionarea de pe uscat sau de pe apă. În cazul în care există o instalație de aspersoare penava, ar trebui să o mențină în funcțiune până la focul este stins sau până când jeturile sunt în poziție. Pe unele nave pot exista sisteme de stingere a incendiilor la bordul navei și trebuie să se solicite sfatul acestora cu privire la instalațiile fixe; aceștia pot oferi, de asemenea, îndrumări în jurul navei..
```

![](https://i.imgur.com/2jlMxHe.png)

Marine Incidents

---

---

---

**3. Incidente pe mare**
---

---

 3.1 **Planificare**
```
[SHOW]Potențialul pentru un incident major chiar și în porturi și porturi mai mici și în largul coastelor pare a fi să crească. Numărul și dimensiunea incidentelor potențialmărfuri potențial periculoase care intră și ies din porturi au a crescut și au existat mai multe cazuri în care feriboturile de pasageri au fost implicate în incendii. Trebuie să existe prin urmare, trebuie să existe o planificare prealabilă pentru astfel de situații de urgență.
Indiferent de modul de transport utilizat pentru transportul inițial prezență (sau de recunoaștere), fie că este vorba de transport maritim sau aerian, ar trebui să se ia măsuri pentru ca o navă care să fie pregătită pentru siguranță pe toată durata incidentului. În mod ideal, o navă utilizată pentru a transporta personal sau echipamente către nava în pericol ar trebui să rămână în așteptare la locul incidentului în caz de urgență evacuarea rapidă fără ajutorul unui elicopter este sau în cazul în care un pompier cade peste bord. În cazul în care această nava nu poate rămâne în stație la incident, atunci trebuie să se ia măsuri pentru ca o altă navă să rămână în așteptare în scopuri de siguranță.
```

---
