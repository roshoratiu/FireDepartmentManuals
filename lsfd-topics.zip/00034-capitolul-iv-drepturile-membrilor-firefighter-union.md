# CAPITOLUL IV – DREPTURILE MEMBRILOR FIREFIGHTER UNION

- **Topic ID:** 34
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=34
- **Posts:** 1

---

## #1 — Kellan Dunley

![](https://i.imgur.com/2jlMxHe.png)

FIREFIGHTER UNION MANUAL

---

 CAPITOLUL IV – DREPTURILE MEMBRILOR FIREFIGHTER UNION
---

---

- **(4.1)** Importanța recunoașterii și garantării drepturilor membrilor

---

---

- Firefighter Union își întemeiază activitatea pe ideea că pompierii, prin natura profesiei lor, se confruntă cu riscuri, responsabilități și presiuni semnificative, care depășesc adesea limitele unei cariere obișnuite. Ca urmare, membrii trebuie să beneficieze de un set de drepturi bine definite, protejate atât de legislația muncii, cât și de propriul statut sindical.    Aceste drepturi nu sunt opționale, nu pot fi restrânse prin interpretări administrative și nu pot fi anulate în funcție de context. Ele sunt fundamentale pentru menținerea unui climat profesional echilibrat, sigur și transparent.

 -

---

---

- **(4.2)** Dreptul la reprezentare sindicală în toate procedurile oficiale

---

---

- Unul dintre cele mai importante drepturi ale membrilor este dreptul la reprezentare sindicală. În orice situație în care un pompier este chemat la o discuție oficială cu conducerea — fie disciplinară, profesională sau administrativă — acesta are dreptul:    • să fie însoțit de un reprezentant sindical;   • să solicite amânarea întâlnirii până la sosirea unui reprezentant;   • să refuze să răspundă la întrebări până la acordarea reprezentării;   • să beneficieze de consiliere prealabilă înainte de orice audiere.    Acest drept este fundamental pentru protejarea membrilor împotriva interpretărilor greșite, abuzurilor sau presiunilor nejustificate. Nicio declarație a unui membru nu poate fi considerată validă dacă acesta nu a fost informat de dreptul la reprezentare sindicală.

 -

---

---

- **(4.3)** Dreptul la un proces disciplinar corect și imparțial

---

---

- În cazul în care un membru este implicat într-o procedură disciplinară, acesta beneficiază de următoarele drepturi garantate:    • dreptul la prezumția de nevinovăție;   • dreptul la un investigator imparțial;   • dreptul de a fi informat în scris despre acuzații;   • dreptul de a vedea probele înainte de audiere;   • dreptul de a prezenta dovezi și martori proprii;   • dreptul la contestarea deciziilor;   • dreptul la apel și arbitraj extern;   • dreptul la asistență legală prin Union.    Firefighter Union tratează procedurile disciplinare cu maximă seriozitate, deoarece acestea pot afecta cariera, reputația și viața personală a unui membru. Dreptul la echitate procedurală reprezintă o linie de apărare indispensabilă.

 -

---

---

- **(4.4)** Dreptul la protecție împotriva abuzurilor administrative

---

---

- Membrii sindicatului sunt protejați explicit împotriva:    • sancțiunilor disproporționate;   • deciziilor luate fără probe sau fără proceduri clare;   • hărțuirii sau intimidării;   • discriminării pe bază de rang, vechime, origine sau statut personal;   • represaliilor pentru activitatea sindicală;   • presiunilor psihologice în timpul anchetelor.    Sindicatul are obligația de a interveni imediat în orice situație în care aceste drepturi sunt încălcate. Membrii sunt încurajați să raporteze orice abuz, chiar și atunci când nu sunt direct implicați.

 -

---

---

- **(4.5)** Dreptul la negociere colectivă și la condiții de muncă corecte

---

---

- Toți membrii Firefighter Union beneficiază de dreptul la:    • negocierea salariilor;   • negocierea sporurilor de risc;   • negocierea orelor suplimentare;   • stabilirea condițiilor de lucru;   • asigurări medicale corespunzătoare;   • programe de pensionare adaptate riscurilor profesiei.    Contractul colectiv de muncă este obligatoriu pentru administrație, și orice modificare trebuie negociată direct cu sindicatul. Nicio schimbare unilaterală a condițiilor de muncă nu este permisă.

 -

---

---

- **(4.6)** Dreptul la siguranță și sănătate operațională

---

---

- Profesia de pompier presupune expunerea constantă la riscuri extreme. Din acest motiv, membrii au dreptul la:    • echipamente complete și funcționale;   • instruire periodică;   • evaluări medicale regulate;   • protecție împotriva expunerii la substanțe toxice;   • acces la tratament și recuperare după incidente operaționale;   • protecție psihologică post-traumatică.    Union monitorizează în mod constant starea echipamentelor și condițiile de lucru din stații. Dacă o situație pune în pericol siguranța membrilor, sindicatul poate solicita oprirea activității într-un anumit sector până la remedierea problemelor.

 -

---

---

- **(4.7)** Dreptul la suport psihologic și programe de recuperare

---

---

- Intervențiile dificile, decesele, evenimentele cu victime multiple și situațiile de stres extrem pot avea un impact psihologic major asupra pompierilor.    Fiecare membru are dreptul la:  • evaluare psihologică post-incident;   • programe anti-PTSD;   • consiliere individuală;   • sprijin pentru familie;   • reconversie temporară în roluri non-operative în cazurile grave.    Sindicatul colaborează cu psihologi specializați în traume operaționale și are rolul de a semnala situațiile unde starea mentală a unui membru ar putea fi compromisă de stresul acumulat.

 -

---

---

- **(4.8)** Dreptul la transparență și informare

---

---

- Firefighter Union garantează membrilor acces la:    • bugetul sindical;   • rapoartele financiare;   • procesele-verbale ale ședințelor;   • planurile de negociere colectivă;   • rezumatul deciziilor Comitetului Executiv;   • ghiduri, proceduri și regulamente.    Un membru informat este un membru protejat. Sindicatul are obligația de a comunica deschis și constant.

 -

---

---

- **(4.9)** Dreptul la participare activă în viața Union

---

---

- Fiecare membru are dreptul de a:    • vota în alegeri;   • candida pentru funcții sindicale;   • participa la ședințe;   • propune modificări de regulament;   • solicita convocarea unei ședințe speciale;   • depune plângeri sau sesizări interne.    Participarea membrilor este esențială pentru legitimitatea sindicatului. Union nu este o structură pasivă, ci o organizație în continuă evoluție.

 -

---

---

- **(4.10)** Dreptul la confidențialitate

---

---

- Toate informațiile legate de:    • sănătate;   • proceduri disciplinare;   • istoricul personal;   • sesizări interne;   • declarații date în timpul investigațiilor,    sunt strict confidențiale. Acestea pot fi divulgate doar membrului în cauză, reprezentanților autorizați și instituțiilor prevăzute de lege.    Sindicatul consideră confidențialitatea un drept fundamental, care protejează integritatea personală și profesională a fiecărui pompier.

 -

---
