# [17052311] Alejandro Melendez

- **Topic ID:** 55
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=55
- **Posts:** 1

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

 Administrative & Support

---

 **PATIENT CARE REPORT**
 Los Santos Fire Department · Emergency Medical Services

**I — INFORMAȚII GENERALE**

- **PERSONAL:** Engineer Frent Samson, Lieutenant Sybil Gale  **UNITATE:** RA-07  **DISPECERAT:** Departamental - solicitare din partea LSPD  **ORA SOSIRII:** 17/MAi/2026 22:40  **ORA ÎNCHEIERII:** 17/MAi/2026 23:19  **REZULTAT:** Decedat

**II — DATE PACIENT**

- **NUME:** Alejandro Melendez  **VÂRSTĂ:** 34 ani  **SEX:** Bărbat  **RASĂ:** Hispanic  **ALERGII:** N/A

**DECES — completați numai dacă este cazul**

- **ORA DECESULUI:** 23:11 · Raportul continuă la secțiunea Prejudiciu, iar la final se trimite la Coroners.

**III — PREJUDICIU & EVALUARE**

- **PREJUDICIU:** Plăgi prin împușcare multiple - braț drept, braț stâng, abdomen (regiunea epigastrică și mezogastrică)  **LOCAȚIA RĂNII:** Membrul superior drept (1/3 medie), membrul superior stâng (1/3 proximală), abdomen anterior  **MECANISMUL PREJUDICIULUI:** Fizic - traumatism penetrant balistic (multiple GSW)

**IV — SEMNE VITALE**

- **ORA:** 22:50 | **PULS:** 38 bpm (filiform) | **RESP:** 6/min (agonale) | **T.A.:** 58/30 mmHg | **LOC-AVPU:** P  **ORA:** 23:00 | **PULS:** 0 bpm | **RESP:** 0/min | **T.A.:** —/— mmHg | **LOC-AVPU:** U

**V — MEDICAȚIE ADMINISTRATĂ**

- **MEDICAMENT:** Epinefrină (Adrenalină)  **DOZĂ:** 1 mg — administrată de două ori (23:05 și 23:09)  **METODĂ:** IV (acces antecubital drept)

**VI — NARAȚIUNE**

- La ora 22:34, unitatea RA-07 a fost activată prin radio departamental la solicitarea unui ofițer LSPD, care raporta un bărbat adult cu multiple plăgi prin împușcare, conștient diminuat, în zona Strawberry Avenue. Sosire la fața locului la 22:40, scena declarată sigură de către ofițerii LSPD prezenți.    La evaluarea inițială, pacientul Alejandro Melendez, sex masculin, 34 ani, a fost identificat în decubit dorsal, cu trei plăgi de intrare vizibile: membrul superior drept (1/3 medie), membrul superior stâng (1/3 proximală) și abdomenul anterior (regiunile epigastrică și mezogastrică). Hemoragie activă la nivelul tuturor plăgilor. Pacientul prezenta respirații agonale (6/min), puls filiform la 38 bpm, tensiune arterială 58/30 mmHg - LOC-AVPU: P.    S-a aplicat control hemoragic prin pansamente compresive pe plăgile membrelor și pansament ocluziv pe plaga abdominală. S-a asigurat acces IV la nivelul venei antecubitale drepte. S-a montat ECG în 4 derivații - ritm inițial: fibrilație ventriculară (VF). S-a aplicat AED cu descărcare de 200J la ora 23:03 - fără conversie la ritm perfuziv.    La ora 23:04 pacientul a intrat în stop cardio-respirator confirmat (absența pulsului, absența respirației spontane, LOC-AVPU: U). S-a inițiat imediat CPR cu compresii de calitate (raport 30:2), ventilație asistată prin BVM fara O₂. ECG post-șoc a arătat activitate electrică fără puls (PEA). S-a administrat Epinefrină 1mg IV la 23:05, urmată de o a doua doză la 23:09, conform protocolului pentru stop non-șocabil.    CPR a fost continuat neîntrerupt timp de 7 minute fără obținerea ROSC (Return of Spontaneous Circulation). La ora 23:11, în urma absenței oricărui răspuns terapeutic și a deteriorării ireversibile secundare traumatismului penetrant abdominal masiv, decesul a fost constatat. Ora decesului înregistrată: 23:11.    Raportul a fost transmis Coroners pentru proceduri ulterioare. Scena a rămas sub custodia LSPD.

 Semnat,
 Sybil Gale

---
