# SQUAD - SQ

- **Topic ID:** 73
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=73
- **Posts:** 1

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

SQUAD

---

---

---

**1. TOOLS & EQUIPMENT (UNELTE ȘI ECHIPAMENTE)**
---

---

- Squad Company este unitatea orientată spre technical rescue (salvare tehnică), rapid intervention, interior support și extrication (extragere). Squad transportă unelte pentru forcible entry (intrare forțată), cutting (tăiere), stabilization (stabilizare), rope rescue (salvare pe coardă) și heavy lifting (ridicare grea).

- **[Halligan Bar](https://m.media-amazon.com/images/I/317RxbNBPxL.jpg):** forțare, prindere, răsucire și deschidere de bariere.
- **[Fire Axe (topor de pompieri)](http://www.zeelandtwp.org/portals/0/ZCTFD/Images/FireAxe.jpg):** spargere, tăiere și îndepărtarea obstacolelor.
- **[Cut-off saw (fierăstrău circular)](http://www.unifireusa.com/images/prodImages/uf-k960-14.jpg):** tăiere prin metal, acoperișuri și materiale de construcție.
- **[Chainsaw (drujbă)](http://firesafetyplus.com/images/ventmaster-22.jpg):** tăiere prin lemn și materiale combustibile.
- **[Reciprocating saw (fierăstrău alternativ)](https://paulhasenmeier.files.wordpress.com/2011/11/sawzalltool.jpg):** tăiere prin sticlă, tablă, țevi sau elemente subțiri.
- **[Portable torch kit (set portabil de torță)](http://www.northerntool.com/images/product/2000x2000/171/171742_2000x2000.jpg):** tăieri sau încălzire controlată când procedura permite.
- **[Come-a-long](https://i5.walmartimages.com/asr/b78b6109-7adf-4777-b690-ddba654c6669.59f5790901c6584434fbc37d554b61d7.jpeg?odnWidth=612&odnHeight=612&odnBg=ffffff):** tracțiune mecanică și deplasarea controlată a obiectelor.
- **[Winch (troliu)](http://www.bmsrescue.com/winch1.jpg):** tragere, stabilizare și recuperare controlată.
- **[Cribbing (materiale de calare)](https://paulhasenmeier.files.wordpress.com/2011/12/2011-12-02_13-28-39_326.jpg):** stabilizarea vehiculelor, obiectelor grele sau structurilor.
- **[Chains & hooks (lanțuri și cârlige)](http://www.teamrescuestore.com/images/Rescue-Chain-THR6.jpg):** fixare, tracțiune și ancorare.
- **Rope rescue kit (kit de salvare pe coardă):** carabiners (carabiniere), rope (coardă), harness (ham), pulleys (scripeți).
- **[Salvage covers (prelate de protecție)](http://i21.geccdn.net/site/images/n-picgroup/88480.jpg):** protecția proprietății împotriva apei, fumului sau resturilor.
- **[Hydrant tool (cheie de hidrant)](http://i.imgur.com/VzqeKcs.jpg):** deschiderea hidranților și conectarea supply line.
- **[X-Collar (guler cervical)](https://cdn.webshopapp.com/shops/275773/files/253252235/800x1024x2/x-collar-nexsplint-nexsplint-plus-neck-splint.jpg):** stabilizare cervicală.
- **[KED - Kendrick Extraction Device](http://i.imgur.com/q3kLp9i.jpg):** extragerea controlată din vehicule sau spații înguste.
- **[Glass-Master](http://i.imgur.com/qNZn0Ts.jpg):** spargerea și tăierea sticlei la MVA/RTC.
- **[Cutting pliers (clește de tăiere)](https://img.everychina.com/nimg/3c/9f/84075a04606c81d8a0374fa2c471-600x600-0/high_strength_bc360_electric_hydraulic_cutting_pliers_fire_fighting_equipment.jpg):** cabluri, fire și elemente subțiri.
- **[Spreader-cutters (foarfecă/dispozitiv de depărtare hidraulic)](http://i.imgur.com/0GGu9Aa.jpg):** tăiere și depărtare la vehicle extrication.
- **[Hydraulic ram (berbec hidraulic)](http://i.imgur.com/TbPpHM0.jpg):** deplasarea bordului, stâlpilor sau elementelor blocate.
- **[Rescue tripod (trepied de salvare)](http://g03.s.alicdn.com/kf/HT115cPFOtXXXagOFbX0/221018167/HT115cPFOtXXXagOFbX0.jpg):** extragere din confined spaces (spații înguste).
- **[Lifting airbag (pernă pneumatică de ridicare)](http://i.imgur.com/UJKAuE1.jpg):** ridicarea obiectelor grele.
- **[Jump pad (saltea pneumatică de salvare)](http://i.imgur.com/QU6CFdG.jpg):** protecție la căderi de la înălțime, când este aprobată de IC.
- **[Stabilization struts (tije de stabilizare)](http://i.imgur.com/JJrWEew.jpg):** stabilizarea vehiculelor răsturnate.

---

---

**2. RIT - RAPID INTERVENTION TEAM (ECHIPA DE INTERVENȚIE RAPIDĂ)**
---

---

- RIT este formată din cel puțin doi Firefighters dedicați exclusiv salvării pompierilor aflați în pericol. RIT nu primește sarcini secundare cât timp este activă. Echipa este desemnată de IC și rămâne pregătită la intrare sau într-un punct stabilit.

 2.1 **RIT Readiness (pregătirea RIT)**
- SCBA complet, cu PASS activ și verificat.
- Radio funcțional pe canalul tactic.
- RIT pack (pachet RIT), spare bottle (butelie de rezervă), rope bag și forcible entry tools.
- Cunoașterea punctelor de intrare, layout-ului estimat și poziției echipelor interioare.
- Monitorizarea permanentă a Mayday-urilor, schimbărilor de condiții și ordinelor IC.

 2.2 **Mayday Response (răspuns la Mayday)**
- **1.** Confirmați Mayday-ul pe radio și ascultați locația, problema și identitatea membrului.  **2.** IC oprește traficul radio neesențial și alocă RIT.  **3.** RIT intră cu minimum două persoane, ghidaj pe rope/tag line și echipament de aer suplimentar.  **4.** Localizați membrul, evaluați air supply (rezerva de aer), entrapment (blocarea) și starea fizică.  **5.** Stabilizați, furnizați aer dacă este necesar și extrageți pe cea mai scurtă rută sigură.  **6.** Raportați progresul către IC constant.

---

---

**3. VEIS - VENT, ENTER, ISOLATE, SEARCH (VENTILEAZĂ, INTRĂ, IZOLEAZĂ, CAUTĂ)**
---

---

- VEIS este o metodă rapidă de search and rescue (căutare și salvare), folosită când există suspiciune că o victimă este într-o cameră accesibilă din exterior. Se execută coordonat cu IC și doar când riscul este acceptabil.

 3.1 **Vent (ventilează)**
- **1.** Poziționați ladder-ul dacă fereastra este la etaj.  **2.** Evaluați condițiile prin fereastră: smoke, heat, flame și vizibilitate.  **3.** Spargeți sau deschideți fereastra doar când sunteți pregătiți să intrați.  **4.** Curățați marginile ascuțite înainte de intrare.

 3.2 **Enter (intră)**
- **1.** Verificați podeaua cu tool-ul înainte de a pune greutate.  **2.** Intrați jos, cu SCBA, tool și contact cu partenerul.  **3.** Raportați intrarea către IC.

 3.3 **Isolate (izolează)**
- **1.** Căutați ușa camerei imediat după intrare.  **2.** Închideți ușa pentru a reduce flow path (calea de curgere a focului și fumului).  **3.** Dacă ușa nu poate fi închisă, raportați condiția către IC și continuați doar dacă este sigur.

 3.4 **Search (caută)**
- **1.** Căutați rapid în jurul ferestrei, lângă pat, sub mobilier și pe traseele probabile.  **2.** Stați jos, sub smoke layer (stratul de fum).  **3.** Dacă găsiți victima, raportați, extrageți spre fereastră sau spre ruta sigură și predați către EMS.  **4.** Dacă nu găsiți victimă, finalizați camera și raportați "primary search negative" către IC.

---

---

**4. INTERIOR ATTACK (ATAC INTERIOR)**
---

---

- Interior attack se execută în echipă de minimum doi membri, cu SCBA, hose line și contact permanent cu IC. Regula de bază este two-in/two-out (doi intră/doi rămân pregătiți), iar membrii nu se separă în interior.

- **1.** IC atribuie echipa, obiectivul și ruta de intrare.  **2.** Verificați SCBA, PASS, radio, nozzle pattern și presiunea liniei.  **3.** La uși, verificați heat (căldura) cu dosul mâinii sau tool-ul; deschideți controlat.  **4.** Fiți atenți la backdraft și flashover. Dacă apar condiții extreme, retrageți-vă și raportați.  **5.** Avansați jos, păstrați contact cu hose line și verificați podeaua înainte de deplasare.  **6.** Aplicați apă controlat, preferabil spre zona de căldură și foc, nu haotic în fum.  **7.** Dacă găsiți o victimă, raportați imediat și coordonați extragerea.  **8.** După knockdown (doborârea focului), verificați extension (extinderea) în pereți, tavan și încăperi adiacente.  **9.** Raportați "fire knocked down", "primary complete" sau orice schimbare majoră către IC.

---

---

**5. SALVAGE (PROTECȚIA PROPRIETĂȚII)**
---

---

- Salvage are scopul de a reduce daunele produse de apă, fum și intervenție, fără a compromite siguranța. Folosiți salvage covers, închideți uși pentru compartmentalization (compartimentare) și protejați bunurile când incendiul este controlat sau când IC autorizează.

---
