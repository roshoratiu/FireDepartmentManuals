# ADVANCED LIFE SUPPORT

- **Topic ID:** 16
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=16
- **Posts:** 3

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

ADVANCED LIFE SUPPORT

---

---

---

**1. INTRODUCERE**
---

---

 Un paramedic EMT este capabil să ofere asistență medicală avansată victimelor, ceea ce înseamnă că este o unitate ALS și nu BLS. Aceștia sunt capabili să efectueze multe proceduri complexe, inclusiv toracostomia cu ac și gestionarea avansată a căilor respiratorii. Acesta este cel mai înalt nivel pe care îl poate atinge un furnizor de servicii medicale prespitalicești.

 1.1 **Terminologii medicale**
```
[SHOW]Capnografie end-tidal - Monitorizarea nivelurilor de CO2 în expirații, foarte utilă într-o varietate de situații, dar mai ales în cazul stopului cardiac sau al stopului respirator - senzorul se numește capnograf și este atașat la o canulă nazală sau BVM.

Aspirație gastrică - Introducerea unui tub printr-o nară, pe esofag și în stomac. Conținutul stomacului poate fi apoi aspirat. Se folosește în cazul supradozelor prin ingestie.

Infuzie IO (intraosoasă) - Administrarea de medicamente și lichide prin măduva osoasă atunci când nu puteți avea acces la perfuzie din cauza unei traume, a unor vene cicatrizate sau a unor vene aplatizate din cauza tensiunii arteriale scăzute.

Ventilator mecanic - Dispozitiv montat în ambulanță care poate asigura ventilații reglabile cu presiune pozitivă, eliberând astfel mâinile pentru alte sarcini la fața locului și în timpul transportului.

Cardioversie sincronizată - O procedură efectuată cu ajutorul plăcuțelor defibrilatoare ale monitorului cardiac, în care un șoc cu energie redusă este administrat la momentul exact al unei anumite faze a bătăilor inimii. Această procedură este utilizată pentru a readuce la normal anumite tipuri de ritmuri cardiace cu ritm anormal de ridicat.

TCP (Stimulare transcutanată) - O procedură efectuată cu ajutorul plăcuțelor defibrilatoare ale monitorului cardiac, în cadrul căreia se administrează șocuri electrice la intervale regulate de timp către inimă la o rată stabilită, determinând-o să se contracte la o rată normală. Această procedură este utilizată pentru a menține în viață pacienții cu ritm cardiac scăzut în mod critic până când aceștia pot primi un tratament definitiv.

Hipotermie terapeutică - Facilitarea recuperării creierului prin scăderea temperaturii după resuscitarea în urma unui stop cardiac, prin utilizarea perfuziei cu soluție salină răcită și a unor tampoane răcoroase care înfășoară coapsele și pieptul.

Tromboliză - Administrarea anumitor medicamente pentru a distruge cheagurile în contextul unui atac de cord. Cel mai frecvent agent trombolitice se numește alteplază.

Faringe - Cunoscut în mod obișnuit sub numele de gât.

Nosofaringe - Prima diviziune a gâtului; este posterioară cavității nazale și continuă în jos, în spatele gurii.

Orofaringe - A doua diviziune a gâtului; este porțiunea care este vizibilă atunci când se privește în gură.

Laringofaringe - A treia diviziune a gâtului; deschiderea esofagului și a traheei.

Pneumonie - Inflamație a plămânilor în care sacii de aer se umplu de puroi sau de alt lichid.

Hipoventilație - Apare atunci când ventilația este insuficientă, ceea ce înseamnă că nu există o lipsă de oxigen care să ajungă la plămâni.

Hiperventilație - Apare atunci când respirația este mai rapidă decât în mod normal, ceea ce determină scăderea nivelului de dioxid de carbon din artere.

IV - Intravenos.

IM - Intramuscular.
```

---

---

**2. MANAGEMENTUL căilor respiratorii**
---

---

 Dacă pacientul dumneavoastră este găsit inconștient, înseamnă că toți mușchii, inclusiv cei ai maxilarului, s-au relaxat. Acest lucru duce la posibilitatea ca limba să obstrucționeze căile respiratorii ale pacientului. În calitate de EMT certificat ALS, există diferite proceduri de gestionare a căilor respiratorii disponibile pentru a preveni acest lucru și pentru a ajuta în continuare pacientul să respire. **Amintiți-vă că o respirație zgomotoasă este o obstrucție a căilor respiratorii.**

 2.1 **Căile aeriene orofaringiene (OPA)**
```
[SHOW]Calea de aer orofaringiană este un dispozitiv care se introduce în gura pacientului cu capul în jos, apoi se întoarce la 180 de grade când ajunge în partea din spate a gâtului. Acesta este folosit pentru a asigura căile respiratorii superioare, astfel încât limba să nu poată provoca sufocarea pacientului. Acest dispozitiv se folosește numai la victimele inconștiente. Acesta poate provoca uneori căscatul și/sau vărsăturile pacientului, ceea ce înseamnă că va trebui să folosiți NPA. Cu toate că este foarte puțin probabil ca o persoană să se gâfâie cu un OPA, este totuși foarte posibil.

Cum să:

1. Luați OPA de dimensiunea corectă din geanta ALS.
2. Deschideți gura și introduceți OPA în ea, până când simțiți că ajunge în partea din spate a gâtului.
3.3. Rotiți OPA la 180 de grade, permițându-i să fie introdus cu ușurință.
[SHOW]
```

 2.2 **Aspirarea căilor respiratorii**
```
[SHOW]O OPA oprește sufocarea unui pacient, însă nu are capacitatea de a elimina obstrucțiile precum sângele și voma, care pot duce la aspirație. Aspirația căilor respiratorii este utilizată pentru a minimiza riscul de aspirație și constă într-un cateter de aspirație și tuburi.

Cum să:

1. Luați pompa de aspirare din compartimentul de la ambulanță.
2. Conectați cateterul de aspirație Yankauer la tubulatura de la pompa de aspirație.
3.3. Sub vizorul de dirijare, direcționați cateterul în orofaringe (în spatele limbii, orificiul care duce în jos).
[SHOW]
```

 2.3 **Intubație endotraheală**
```
[SHOW]Intubația endotraheală este o procedură folosită în mod obișnuit de către chirurgi înainte de operație pentru a ajuta victima să respire, aceasta fiind folosită numai atunci când pacientul este sub sedare puternică sau inconștient. Pentru a efectua o intubație endotraheală, folosim un mic tub de plastic, cunoscut sub numele de tub endotraheal (tub ET), care este introdus în trahee cu ajutorul unui laringoscop. Capul trebuie să fie înclinat înainte de a face acest lucru.

Pe scurt, folosiți un ET dacă:

Au fost suferite răni la cap.
OPA nu a reușit să îmbunătățească respirația.
Pentru a ajuta la o încercare de resuscitare datorită faptului că BVM are mai mult succes.

Cum să:

1. Scoateți un tub endotraheal, un laringoscop și o seringă de aer; deschideți gura pacientului.
2. Introduceți laringoscopul prin gura lor deschisă, pe partea dreaptă a limbii.
3. Glisați tubul ET pe lama laringoscopului, pe lângă corzile vocale și în jos pe trahee.
4. Umflați bulbul tubului ET cu ajutorul seringii de aer din apropiere.
5. Atașați și fixați BVM-ul la docul de intrare a tubului ET.
[SHOW]
```

 2.4 **Forceps Magill**
```
[SHOW]Forcepsul Magill este folosit în primul rând pentru a îndepărta obiectele din gât la care nu poate ajunge o măturare cu degetul. Ele sunt folosite împreună cu laringoscopul pentru a introduce în gât și a obține blocajul rapid și eficient prin apucarea acestuia cu capetele. Asigurați-vă întotdeauna că folosiți dimensiunea corectă.

Există două dimensiuni: o dimensiune de 8" pentru copii și o dimensiune de 11" pentru adulți.

Cum să:

1. Scoateți o pereche de forceps Magill și un laringoscop.
2. Deschideți gura pacientului și înclinați-i capul pe spate.
3. Introduceți laringoscopul prin gura lor deschisă, pe partea dreaptă a limbii.
4. Glisați forcepsul Magill înăuntru, localizând obiectul străin.
5.5. Prindeți-l cu forcepsul Magill, scoțându-l încet din gura pacientului.
[SHOW]
```

 2.5 **Acul Cricothyriodotomy**
```
[SHOW]Aceasta este o incizie făcută prin piele și prin membrana cricotiroidiană pentru a stabili căile respiratorii ale unui patent în anumite situații care pun viața în pericol. Cricotirotomia este aproape întotdeauna efectuată în ultimă instanță, în cazurile în care intubația orotraheală nu este posibilă. Indicațiile care arată necesitatea de a efectua această procedură sunt următoarele:
Intubația nu este posibilă.
Traumatisme grave.
Edemul țesuturilor gâtului care împiedică vizualizarea corzilor (de exemplu, arsuri).
Corp străin în căile respiratorii superioare. (Nu poate fi îndepărtat).
Lipsa echipamentului pentru intubație endotraheală.
Eșecul tehnic al intubației.

Cum să:

1. Procedura trebuie efectuată într-un mediu steril, locul de puncție trebuie curățat cu iod după ce au fost puse mănușile non-latex.
2. Țineți acul de trahee în poziție.
3. Țineți atașată la ac o seringă de 10 ml pe jumătate plină cu soluție salină.
4. Așezați acul pe linia mediană a gâtului și îndreptați-l spre caudală (spre picioare) la un unghi de 30 până la 45 de grade.
5. Înțepați pielea.
6. Înaintați acul în timp ce aplicați continuu o presiune negativă asupra seringii, până când se văd bule de aer, confirmând plasarea intratraheală.
7. Scoateți seringa și împingeți cateterul înainte în timp ce scoateți acul.
8. Conectați seringa la cateter și confirmați că acesta este la locul lui.
9. Fixați cateterul.
10.10. Conectați BVM-ul pentru a confirma că cateterul este la locul lui
[SHOW]
```

 2.6 **Toracostomie cu ac**
```
[SHOW]Pneumotoraxul este definit ca o acumulare de aer sau de gaz în spațiul dintre plămân și peretele toracic, practic un colaps pulmonar. Pneumotoraxul apare din cauza unei găuri care se dezvoltă în plămân, care permite aerului să iasă în spațiul din jurul plămânului, ceea ce face ca plămânul să se prăbușească parțial sau complet. Prin urmare, trebuie efectuată toracostomia cu ac.

Cum să:

1. Localizați locul de puncție prin metoda standard (de exemplu, percuție, radiografie sau ultrasunete).
2. Pregătiți locul folosind precauțiile standard și în condiții sterile.
3. Îndepărtați capacul acului de pe cateter numai atunci când acul este în poziție.
4. Efectuați puncția peretelui toracic.
5. Dacă observați că indicatorul de culoare nu este roșu, trebuie să opriți procedura.
6. După poziționarea sistemului, conectați seringa inclusă în kit la supapa de siguranță a acului de puncție de siguranță prin apăsarea și rotirea acesteia. Apoi aspirați lichidul sau aerul trăgând pistonul seringii.
7. După ce cateterul a fost poziționat, aspirați lichidul cu seringa și apăsați pentru a goli seringa în pungă.
8. Această procedură poate fi repetată de mai multe ori fără a fi nevoie de ajustări ale sistemului.
9. Scoateți cateterul de drenaj de la pacient.
[SHOW]
```

---

---

**3. MANAGEMENTUL RĂNILOR**
---

---

 3.1 **Steri-Strips**
```
[SHOW]Steri-Strips sunt benzi adezive subțiri și lipicioase care pot fi folosite pentru a închide răni mici. (Sunt denumite și copci de hârtie). Acestea se aplică de-a lungul lacerației (rănii) într-un mod care să tragă împreună pielea de o parte și de alta a rănii. Steri-Strips pot fi utilizate în locul suturilor în cazul unor răni, deoarece diminuează cicatrizarea și sunt mai ușor de îngrijit. În general, acestea ar trebui să cadă la momentul potrivit și nu este nevoie ca accidentatul să se întoarcă la medic pentru a fi îndepărtate, ceea ce reprezintă un alt avantaj al acestor Steri-Strips.

Cum să:

1. Scoateți Steri-Strips din trusă.
2. Așezați-le peste rană.
3. Încet și cu grijă închideți rana.
[SHOW]
```

 3.2 **Tratament suplimentar al rănilor prin împușcare**
```
[SHOW]Certificarea ALS vă oferă metode mai avansate de tratare a rănilor prin împușcare. Folosirea tratamentului corect poate asigura furnizarea nivelului corect de îngrijire, reduce riscul de infecție și crește riscul de supraviețuire.

3.2.1 Sigiliul Bolin Chest Seal
Rănile deschise la piept nu trebuie tratate cu un pansament normal, ci cu un sigiliu toracic Bolin. Acest lucru se datorează aerului care este aspirat în plămâni, ceea ce ar putea duce la un plămân colapsat. Acest tip de răni sunt, de asemenea, denumite în mod obișnuit răni toracice prin aspirație. Ar trebui să se urmeze următorii pași:

1. BSI și DRCAB.
2. Începeți DPT, însă în loc de un pansament normal pentru traumatisme folosiți un pansament ocluziv. Un pansament de acest tip utilizat în mod obișnuit este sigiliul toracic Bolin.
3. Verificați dacă există semne de colaps pulmonar, folosind un stetoscop pe ambele părți ale pieptului. Dacă o parte are semne de respirație diminuate sau nu are niciun semn de respirație în comparație cu cealaltă, acesta este un semn de plămân colapsat.
4. Începeți toracostomia cu ac.
5. TREBUIE să folosiți o placă de sprijin, pieptul este aproape de coloana vertebrală și, prin urmare, riscul de rănire a coloanei vertebrale este ridicat.
[SHOW]

3.2.2 Abdomen
Orice rană localizată în jurul zonei abdomenului poate cauza probleme serioase pentru un pacient din cauza apropierii intestinelor. Aceste răni trebuie tratate cu grijă și rapid. Ar trebui să aibă loc procedura normală de DPT, în afară de organele precum intestinele sunt vizibile. Trebuie să folosiți un pansament umed și steril în loc de un pansament normal pentru traumatisme, pentru a proteja organele

3.2.3 Brațe și picioare
O rană la braț sau la picior ar fi putut, de asemenea, să ducă la sfărâmarea osului. De obicei, oamenii consideră că o rană la braț sau la picior este mai puțin dăunătoare decât una la piept sau la abdomen. Din păcate, nu este cazul, din cauza posibilei necesități de amputare dacă există semne de hemoragie internă și nimic din ceea ce faceți nu poate opri sângerarea. Prin urmare, este important să opriți sângerarea cât mai repede posibil:

1. BSI și DRCAB.
2. Așezați un pansament gros peste rană.
3. Aplicați o presiune directă peste pansamentul grosier.
4. Înfășurați pansamentul pe extremitate, însă numai până la jumătate sau o treime. Nu acoperiți niciodată complet extremitatea, deoarece acest lucru poate împiedica circulația și poate duce la o posibilă amputare.
5. Ridicați extremitatea deasupra pieptului.
6.6. Dacă bănuiți că osul a fost deteriorat, folosiți atelia corectă conform BLS.

NOTĂ: Nu folosiți un garou decât dacă sângerarea nu s-a oprit timp de 15 minute sau dacă este prezentă o hemoragie internă, caz în care este posibil să trebuiască să luați în considerare amputarea.

3.2.4 Cap și gât
O rană prin împușcare la nivelul capului sau al gâtului este cea mai frecventă cauză a decesului pentru majoritatea apelurilor legate de răni prin împușcare. Cu toate acestea, nu toate rănile prin împușcare la cap sau la gât pot fi tratate; în unele cazuri, este posibil, având în vedere că îngrijirea este asigurată rapid și eficient:
1. Puneți pe cineva să aplice presiune direct pe rană folosind un pansament cât mai voluminos posibil.
2. Stabilirea căilor respiratorii prin Cricothyroidotomie cu ac și ET.
3. Ca și în cazul unei răni toracice, folosiți un pansament ocluziv[/list][/list]
```

---

---

**4. TERAPIA INTRAVENOASĂ**
---

---

```
[SHOW]Terapia intravenoasă este o modalitate de a administra substanțe lichide direct în venă. O inserție de ac intravenos este de obicei introdusă într-o venă din partea de sus a mâinii sau din partea interioară inferioară a brațului. Se ia un ac și un cateter intravenos, se introduce acul până când acesta se află în interiorul venei, se împinge cateterul înainte în venă, apoi se scoate acul. Trebuie apoi să fixați cu bandă adezivă cateterul pentru a-l fixa în poziție.

Cateterele sunt apoi folosite pentru a injecta medicamente în pacient, ceea ce face ca totul să fie mult mai ușor. Există un orificiu în partea de sus, în care se introduce capătul seringii, care vă permite să injectați substanța din interior. Portul este cunoscut sub numele de canule portate. Explicația medicamentelor pe care le puteți folosi va fi puțin mai jos.

Modul corect de utilizare a unei linii IV este următorul:

1. Găsește o venă potrivită pe partea superioară a mâinii și scoate un ac de perfuzie din trusa ILS.
2. Introduceți acul IV în venă, asigurându-vă cu atenție că este introdus corect.
3. Împingeți cateterul peste ac și în venă, îndepărtând apoi acul încet și cu grijă.
4.4. Închideți cateterul cu bandă adezivă.
```

---

---

**5. HIPOTERMIA**
---

---

```
[SHOW]Hipotermia este o urgență medicală în care temperatura corpului este mai mică de 35,0°C (sau 95,0°F). În mod normal, este cauzată de expunerea la condiții reci. Lăsată netratată, hipotermia poate duce la stop cardiac și deces. Procesul principal de tratare a hipotermiei constă în utilizarea diferitelor metode de încălzire a corpului.

Simptomele hipotermiei sunt:

Tremurând.
Creșterea ritmului cardiac.
Creșterea frecvenței respiratorii.
Confuzie.

În stadiile ulterioare ale hipotermiei, simptomele sunt mai grave:

Paloare.
Buzele, urechile, degetele de la mâini și de la picioare devin albastre.
 Pierderea cunoștinței.
Puls slab (un puls pe care abia îl simți).
Respirație lentă, superficială.

În cazul tuturor pacienților hipotermici, primul lucru care trebuie făcut este de a îndepărta toate hainele umede de pe corpul lor, pentru a reduce și mai mult scăderea temperaturii. Aplicați pungi termice învelite în prosoape (evitați contactul direct cu pielea) pe trunchiul pacientului, la subsuori și în zona inghinală, pentru a încălzi sângele și a crește astfel temperatura corpului. Puteți folosi o pătură spațială pentru a maximiza efectul de încălzire. Asigurați-vă că transportați pacientul cât mai repede posibil.
```

---

---

**6. NAȘTEREA COPILULUI**
---

---

```
[SHOW]Nașterea unui copil se va întâmpla de obicei în timp ce un medic este prezent în interiorul unui spital, însă există ocazii în care va fi nevoie de un paramedic pentru a aduce pe lume copilul în afara unui spital. Nașterea copilului într-un mediu nesteril poate fi periculoasă și este esențial să se asume BSI. După asumarea BSI, asigurați-vă că verificați cu pacienta cât de departe se află. Dacă sunt aproape de 40 de săptămâni (37-42) nu ar trebui să existe niciun pericol pentru copil, totuși; dacă sunt mai puțin de 37 de săptămâni, atunci trebuie să aveți grijă suplimentară și să transportați copilul la spital cât mai curând posibil din cauza travaliului prematur.

În toate cazurile de naștere a unui copil, acestea trebuie duse la spital, însă, dacă nu puteți face acest lucru și travaliul este în plină desfășurare, atunci trebuie să efectuați următoarele proceduri:

1. Puneți pacientul să se întindă într-o poziție confortabilă, eliberați scena de oricine în afară de cine vrea pacientul să fie cu el.
2. Furnizați oxigen pacientului.
3. Puneți pacienta să își tragă genunchii spre ea și să își acopere picioarele cu un prosop, astfel încât doar dumneavoastră să puteți vedea regiunea vaginală. Intimitatea pacientei trebuie să fie întotdeauna o prioritate.
4. Încurajați pacientul să împingă atunci când simte nevoia să împingă.
5. În legătură cu numărul 4, Etonox poate fi administrat prin perfuzie (cunoscut sub numele de gaz de râs) pentru a ușura procesul.
6. Odată ce vedeți că se încoronează capul, încurajați pacienta să împingă la fiecare 30 de secunde și susțineți capul bebelușului cu mâinile.
7. După ce bebelușul a fost adus pe lume, înfășurați-l într-un prosop uscat și verificați imediat semnele vitale (căi respiratorii, respirație și puls). Dacă există vreun pericol, urmați procedurile normale, dacă nu există, treceți bebelușul la pacient și transportați-l.
```

---

---

**7. TRIAGE**
---

---

```
[SHOW]Triajul este un proces important la orice scenă care are mai mult de trei victime și ar trebui să fie folosit pentru a se asigura că personalul medical este alocat corect. Există patru culori/categorii diferite atunci când vine vorba de triaj:

CATEGORIILE DE TRIAJ ÎN ORDINE DE PRIORITATE:

ROȘU[/b] - IMEDIAT
Pacientul necesită îngrijiri imediate pentru tratarea leziunilor care îi pun viața în pericol dacă oricare dintre următoarele este adevărat:

 Frecvența respiratorie a pacientului este peste 30.
Pacientul nu respira la început, dar a început să respire după o ridicare a capului în jos și a bărbiei.
Pacientul are un puls radial (pulsul la încheietura mâinii) foarte slab sau inexistent. Acest lucru se datorează adesea unei tensiuni arteriale scăzute din cauza pierderii de sânge.
Pacientul este confuz sau nu poate înțelege comenzi simple.

YELLOW[/b] - ÎNT RZIAT
Pacientul nu îndeplinește niciunul dintre criteriile pentru o etichetă neagră sau roșie, dar nu poate merge.

GREEN[/b] - MINOR
Când i se cere, pacientul este capabil să meargă.

NEGRU - decedat
Pacientul nu are respirație, chiar și după o înclinare a capului și ridicarea bărbiei. Pacientul este mort sau pe cale să moară, iar eforturile de salvare vor fi folosite mai bine pe alți pacienți.

Este o procedură foarte simplă de realizat, iar o unitate ALS care ajunge la locul unui accident în masă trebuie să desemneze orice alt EMT aflat la fața locului să se pregătească pentru tratament în timp ce începe triajul. Paramedicii vor putea astfel să se asigure că se ocupă mai întâi de incidentele care pun în pericol cel mai mult viața.

Cum să:

1. Evaluați și diagnosticați pacientul folosind procedura DR CAB pentru a determina prioritatea pacientului.
2. Etichetați pacientul prin agățarea unui card de etichetă pe un membru adecvat (gât, braț) asigurându-vă că îl liniștițiți cu privire la ceea ce se întâmplă în prezent. Dacă a fost amenajată o zonă de triaj, asigurați-vă că îi direcționați către această zonă.
3. Treceți la următoarea victimă și repetați procesul.
[SHOW]
```

---

---

**8. ELECTROCARDIOGRAMA (ECG)**
---

---

```
[SHOW]Aparatul de electrocardiogramă (ECG) detectează modificările electrice de pe piele cauzate de mușchiul cardiac. LSFD utilizează o versiune portabilă a ECG-ului care poate fi efectuată cu ușurință cu ajutorul trusei ALS. Afișajul ECG indică ritmul general al inimii și slăbiciunile din diferite părți ale mușchiului cardiac. Informațiile obținute în urma unui ECG pot fi utilizate pentru a descoperi diferite tipuri de ritmuri cardiace neregulate, cum ar fi Activitatea electronică fără puls (PEA), Tahicardia ventriculară (VT) și Fibrilația ventriculară (VF). De asemenea, poate fi util pentru a determina cât de bine răspunde pacientul la tratament.

[SHOW]

Un ECG trebuie efectuat la orice pacient care are dificultăți de respirație, dureri în piept (angină pectorală), leșin sau palpitații. De asemenea, îl puteți utiliza pentru a le aduna semnele vitale în loc să le adunați manual. Pentru a utiliza aparatul, pur și simplu atașați cele trei derivații ca în imaginea de mai jos și porniți afișajul, iar semnele vitale vă vor fi date înapoi:

[SHOW]

(( Aceasta poate fi folosită pentru a obține două elemente vitale principale: Pulsul și tensiunea arterială, și poate fi folosit în locul metodei manuale de verificare a pulsului! În scopul LSRP, puteți să vă simțiți liberi să obțineți pulsul și frecvența respiratorie datorită faptului că majoritatea oamenilor nu înțeleg tensiunea arterială. ))
```

---

---

**9. MEDICAMENTE PERMISE**
---

---

 Există mai multe medicamente diferite în trusa ALS și fiecare dintre ele are o modalitate diferită de administrare a medicamentului. Administrarea medicamentului este modul în care medicamentul, lichidul, otrava sau altă substanță este introdusă în organism. Pot fi utilizate următoarele moduri:

 **1. Intranazală:** Folosită pentru administrarea nazală a medicamentelor prin utilizarea de spray-uri nazale.
 **2. Intravenos (IV):** Administrarea de substanțe lichide direct într-o venă (gât, încheietura mâinii sau braț). Poate fi intermitentă sau continuă. Administrarea continuă se utilizează cu ajutorul unei perfuzii intravenoase.
 **3. Intramuscular (IM):** Injectarea unei substanțe direct în mușchi.
 **4. Topică:** Crema/gelul/loțiunea se aplică direct pe suprafețele corpului, cum ar fi pielea sau membranele mucoase.
 **5. Orală:**Administrarea de pastile/băutură prin gură.

 9.1 **Intravenous Fluids**
```
[SHOW]Toate fluidele intravenoase sunt păstrate în pungi intravenoase; această pungă este conectată la tubulatura intravenoasă, care este conectată la cateter, care este conectat la venă. Ori de câte ori toate acestea sunt conectate, punga IV cu fluidul din interior trebuie ținută ridicată deasupra inimii pacientului. Există suporturi pe targă unde puteți atașa pungile IV sau puteți folosi un trecător pentru a ține punga sus. Dacă vă aflați într-un spital, sunt disponibile suporturi pentru perfuzii, dar vă sugerăm să folosiți suporturile care sunt atașate la paturile de spital din toate camerele.

Denumire: Soluție de Ringeri Lactați
Utilizare: Folosit pentru a trata pierderile de sânge datorate unei traume, intervenții chirurgicale sau arsuri.
Dimensiune: 500ml

Denumire: Soluție salină
Utilizare: Folosit pentru a furniza apă suplimentară unui pacient deshidratat sau pentru a acoperi necesarul zilnic de apă și sare al unui pacient.
Dimensiune: 500ml

Modul corect de utilizare a lichidelor intravenoase este următorul:

1. Scoateți o pungă intravenoasă de 500 ml de soluție salină sau soluție Lactated Ringers.
2. Atașați-o la suportul pentru pungi perfuzabile sau rugați un trecător să o susțină.
3.3. Atașați-l la tubulatura intravenoasă și pregătiți perfuzia
```

 9.2 **Antibiotics**
```
[SHOW]Claritromicina
Utilizare: Antibiotic macrolidic utilizat pentru tratarea faringitei, amigdalitei, sinuzitei maxilare acute, exacerbarea bacteriană acută a bronșitei cronice, pneumoniei (în special pneumoniile atipice asociate cu Chlamydia pneumoniae sau TWAR), infecții ale pielii și ale structurilor cutanate și, la pacienții cu HIV și SIDA, pentru prevenirea și tratarea complexului Mycobacterium avium diseminat (MAC). În plus, este uneori utilizat pentru a trata legioneloza și boala Lyme.
Doza: 250ml
Forma: IV
```

 9.3 **Pulse**
```
[SHOW]Lidocaina
Utilizare: Oprește bătăile anormale ale inimii. Poate fi folosit și pe cale troipcală pentru a ameliora mâncărimile, arsurile și durerile provocate de inflamațiile pielii. Utilizare suplimentară ca anestezic dentar și în intervenții chirurgicale minore.
Doza: 1-1,5 mg continuu timp de trei-cinci minute. 4,5mg dacă se utilizează pentru anestezie.
Forma: IV sau topică

Bicarbonat de sodiu
Utilizare: Folosit în etapele de după resuscitare când se fac eforturi de resuscitare îndelungate. Poate fi folosit, de asemenea, pentru tratarea indigestiei și a arsurilor la stomac.
Doza: 520mg, 650mg, 840mg și 1100mg sub formă de tablete.
Forma: Orală sau sub limbă

Atropină
Utilizare: Folosit pentru a crește ritmul cardiac lent și pentru a scădea tensiunea arterială ridicată.
Dozaj: Doza obișnuită este de 0,5 până la 1 mg, împingere IV la fiecare trei până la cinci minute. Doze maxime de 0,04mg/kg.
Forma: Oral, IV, rectal

Epinefrina
Utilizare: Denumită și adrenalină. Folosită în Anafilaxie (reacție alergică severă), crește vitezași puterea contracțiilor cardiace și crește tensiunea arterială.
Doza: 0,1mg pe kg de greutate a pacienților.
Forma: IV, IM

Verapamil
Utilizare: Ajută la încetinirea inimii, utilizat pentru tratamentul hipertensiunii, anginei pectorale, aritmiei cardiace și a durerilor de cap.
Doza: 0,1mg pe kg de greutate a pacienților.
Forma: Oral, IV

Glucagon
Utilizare: Un hormon important administrat atunci când glicemia este mai mică de 4,0 mmol și când nu poate fi inițiată o linie IV. Determină ficatul să transforme glicogenul stocat în glucoză și să o elibereze în sânge.
Doza: 1mg
Forma: IM
```

 9.4 **Cardiac**
```
[SHOW]Metroprolol
Utilizare: Hipertensiune arterială și ca blocant al receptorilor în tratamentele mai multor boli ale sistemului cardiovascular.
Doza: Comprimate de 50mg. Se vor lua câte 100mg odată, maximum 450mg într-o zi. 1mg când se administrează intravenos.
Forma: Oral, IV

Adenozină
Utilizare: Pentru a identifica un blocaj cardiac.
Doza: 6mg.
Forma: IV, injecție

Amiodarona
Utilizare: Bătăi neregulate.
Doza: 3mg/cc prin seringă.
Forma: Oral, IV

Dopamina
Utilizare: Crește ritmul cardiac și determină și creșterea tensiunii arteriale. Cu toate acestea, deoarece dopamina nu poate traversa bariera hemato-encefalică, dopamina administrată ca medicament nu afectează direct sistemul nervos central.
Doza: 2-5mg
Forma: IV

Clorură de calciu
Utilizare: Poate fi utilizat atunci când epinefrina nu a reușit să amelioreze contracțiile cardiace slabe sau ineficiente.
Doza: 2,7-5,0mg prin seringă.
Forma: IV, Oral

Labetalol
Utilizare: Folosit pentru a trata hipertensiunea arterială (tensiune arterială ridicată).
Doza: 80mg sub formă de tablete, maxim 300mg. IV 2mg/minut.
Forma: Oral, IV

Furosimide/Lasix
Utilizare: Pentru edem pulmonar și insuficiență cardiacă congestivă. Eliberează retenția de lichide din organism atâta timp cât rinichii nu s-au oprit.
Doza: 20mg, 40mg și 80mg
Forma: Oral, IV, IM

Aspirină
Utilizare: Tratamentul precoce în cazul atacurilor de cord, ajută la reducerea dimensiunii cheagurilor. Folosit ca analgezic pentru a ameliora durerile minore sau pentru a reduce febra.
Doza: Maxim 400mg la fiecare patru ore.
Forma: Orală, rectală

Nitroglicerină
Utilizare: Tratați afecțiunile cardiace, cum ar fi angina pectorală și insuficiența cardiacă cronică.
Dozaj: Trei concentrații, 0,3mg, 0,4mg, 0,6mg.
Forma: Orală sau sub limbă.
```

 9.5 **Blood**
```
[SHOW]Acid tranexamic (TXA)
Utilizare: Tratați sau preveniți pierderea excesivă de sânge în urma unor traumatisme majore, intervenții chirurgicale, îndepărtarea dinților, sângerări nazale și menstruație abundentă.
Doza: 1g/100mL
Forma: IV

Noradrenalina
Utilizare: Similar cu epinefrina cu unele efecte adverse, funcționează bine în combinație cu epinefrina în timpul stopului cardiac.
Doza: 5cc
Forma: IV
```

 9.6 **Calmarea durerii**
```
[SHOW]Demerol/Meperidină
Utilizare: Analegic utilizat pentru ameliorarea durerii severe.
Doza: 50-150mg sub formă de tablete, sirop sau seringă
Forma: Oral, IV, IM

Ketorolac/Toradol
Utilizare: Poate fi folosit pentru ameliorarea durerii pentru a trata durerile oculare și pentru a ameliora senzația de înțepătură și arsură provocată de alergiile sezoniere.
Doza: 40mg sub formă de comprimate/1,0mg IV.
Forma: Oral, IV, IN

Entonox
Utilizare: Ameliorarea temporară a durerii pentru arsuri, nașterea bebelușilor, fracturi și entorse. Nu durează la fel de mult ca alte tipuri de ameliorare a durerii. Cunoscut și sub numele de "gaz de râs".
Doza: 50% oxigen, 50% protoxid de azot.
Forma: Masca de oxigen

Fentanil
Utilizare: Calmarea durerii, mai puternic decât Entonox
Doza: 100/50mcg comprimate, 0,5mcg/ml prin IV cu un debit de 0,2ml.
Forma: IM, IV, Oral

Morfină
Utilizare: Controlul durerii, dar creează o dependență ridicată. Cea mai puternică ameliorare a durerii datorită faptului că afectează direct sistemul nervos central.
Dozaj: IM (2,5-5,0mg la fiecare trei ore), IV (4-15mg), sub formă de tablete 10-600mg
Forma: IV, IM, inhalat, oral

Aspirină
Utilizare: Tratamentul precoce în cazul atacurilor de cord, ajută la reducerea dimensiunii cheagurilor. Folosit ca analgezic pentru a ameliora durerile minore sau pentru a reduce febra.
Doza: Maxim 400mg la fiecare patru ore
Forma: Orală, rectală

Ibuprofen
Utilizare: Pentru a ameliora durerea ușoară până la severă.
Doza: 800mg (vine în pastile de 200mg sau 400mg)
Forma: Oral
```

 9.7 **Intoxicații și supradoze**
```
[SHOW]Cărbune activat
Utilizare: Folosit în caz de otrăvire/ supradoză datorită capacității sale de a absorbi otrava. (Lichid negru). Poate fi folosit și pentru consumul foarte intoxicat, dar este mai mult ca sigur capabil să îi facă să vomite. (Puneți o găleată lângă ei).
Dozaj: 8 oz sub formă lichidă sau 250mg sub formă de tablete
Forma: Orală (lichid sau tabletă)

Naloxone/Narcan
Utilizare: Inversează efectele supradozajului de narcotice, cum ar fi supradoza de heroină sau morfină. Folosit pentru a contracara depresia care pune în pericol viața sistemului nervos central și a sistemului respirator.
Dozaj: 0,4-2mg IV/IM/intranazal la fiecare 2-3 minute
Forma: IV, IM, Intranazal

Diazepam/Valium
Utilizare: Pentru convulsii, anxietate, retragere din alcool și spasme musculare. De asemenea, pentru a induce amnezia în procedurile chirurgicale.
Doza: 2-10mg sub formă de comprimate, 0,02-0,08mg IV
Forma: IV, IM, Oral
```

 9.8 **Respiratory**
```
[SHOW]Metilprednisolon
Utilizare: Antiinflamator, utilizat în astm și reacții alergice severe. Există efecte secundare grave dacă se administrează pe termen lung, inclusiv creștere în greutate, glaucom, osteoporoză și psihoză, în special atunci când se utilizează în doze mari.
Doza: 40-120mg
Forma: IV, IM, perfuzie IV, oral

Atrovent
Utilizare: Tratamentul bronhospasmului datorat astmului sau emfizemului și bronșitei. Se administrează prin inhalare pentru tratamentul bolilor pulmonare obstructive.
Doza: 500mcg
Forma: Inhalare

Sulfat de magneziu
Utilizare: Controlul convulsiilor, terapie pentru astm și bronhospasm.
Doza: 1g
Forma: Orală

Salbutamol
Utilizare: Cunoscut și sub numele de Ventolin. Este un bronhodilatator și este folosit pentru aceleași lucruri ca și Atrovent. Ajută la deschiderea căilor respiratorii în plămâni.
Doza: 500mg
Forma: Oral, Inhalare, IV
```

 9.9 **Diabetic**
```
[SHOW]Dextroză
Utilizare: Denumirea cea mai comună, glucoză (sau zahăr simplu). Se folosește atunci când glicemia este mai mică de 4,0 mmol. Atunci când se poate pune o perfuzie, dar nu este posibilă administrarea orală a glucozei, deoarece pacientul nu răspunde și nu are reflexul de vomă.
Doza: 0.5-1.0g per KG
Forma: IM, Oral

Glucoză orală
Utilizare: Atunci când glicemia este mai mică de 4,0 mmol, se poate administra numai atunci când pacientul are reflexul de vomă intact și NU este inconștient și poate răspunde la comenzile dumneavoastră.
Doza: 25-50mg
Forma: Oral
```

 9.10 **Nausea**
```
[SHOW]Dimenhidrinat/Gravol
Utilizare: Folosit pentru a reduce greața și vărsăturile. Este un medicament pentru a preveni greața și răul de mișcare. Nu se folosește la persoanele care au convulsii. Cel mai frecvent folosit în pastile, dar se administrează și sub formă lichidă.
Doza: 100mg
Forma: Oral, IV

Metoclopramidă/Maxeran
Utilizare: Ajută la reducerea grețurilor și vărsăturilor asociate cu afecțiuni precum: medicamente emetogene, uremie, boală de radiații, malignitate, travaliu și infecții.
Doza: 10-15mg.
Forma: Oral, IV, IM
```

 9.11 **Allergies**
```
[SHOW]Metilprednisolon
Utilizare: Medicament antiinflamator, utilizat în astm și anafilaxie.
Doza: 40-120mg
Forma: IV, IM, perfuzie IV, oral

Difenidramină/Benadryl
Utilizare: Folosit pentru reacții alergice. reducerea contracției mușchilor netezi, ceea ce face ca difenhidramină să fie o alegere populară pentru tratamentul simptomelor rinitei alergice, urticarie, rău de mișcare și mușcături și înțepături de insecte.
Doza: 25-50mg
Formă: Orală, IM, topică
```

 9.12 **Sedatives**
```
[SHOW]Ativan/Lorazepam
Utilizare: Este un sedativ. Folosit pentru anxietate și agitație la pacienți. Are toate cele cinci efecte benzodiazepine intrinseci: anxiolitic, sedativ/hipnotic, anticonvulsivant și relaxant muscular, în diferite grade.
Doza: 2-6mg
Forma: Oral, IM, IV

Haloperidol
Utilizare: Este un antipsihotic primitiv utilizat în tratamentul schizofreniei și, mai acut, în tratamentul stărilor psihotice acute și al delirului.
Doza: 1-5mg
Forma: Oral, IM, IV

Succinilcolină
Utilizare: Oprește mișcarea musculară. Ajută la sedarea pacienților. Folosit în medicina de urgență și în anestezie pentru a induce relaxarea musculară, de obicei pentru a face posibilă intubația endotraheală și poate fi denumit pe scurt "sux".
Doza: 1.5mg per Kg de greutate a pacienților
Forma: IV, IM

Ketamina
Utilizare: O gamă largă de efecte la om, inclusiv analgezie, anestezie, halucinații, creșterea tensiunii arteriale și bronhodilatație. Este utilizat în principal pentru inducerea și menținerea anesteziei generale, de obicei în combinație cu un medicament sedativ. Este, de asemenea, un anestezic popular în medicina veterinară.
Doza: 0.1-0.5mg
Forma: IV, IM, oral, topic

Midazolam/Versed
Utilizare: Folosit pentru sedare și convulsii. Prin urmare, este un medicament foarte util de utilizat pentru proceduri minore scurte, cum ar fi extracția dentară.
Doza: 0.02-0.1mg
Forma: Oral, IM, IV

Rockaronium/Zemuron
Utilizare: Ultimul medicament administrat în cazul în care sedarea normală nu funcționează. De asemenea, un relaxant muscular utilizat în anestezia modernă, pentru a facilita intubația endotraheală și pentru a asigura relaxarea mușchilor scheletici în timpul intervențiilor chirurgicale sau al ventilației mecanice.
Doza: 0.6-1.2mg
Forma: IV
```

 9.13 **Anesthetics**
```
[SHOW]Methohexital
Utilizare: Ca anestezic general pe cale intravenoasă.
Doza: 20cc
Forma: IV
```

 9.14 **Pregnancy**
```
[SHOW]Oxytosin
Utilizare: Forțează uterul femeii să se contracte pentru a ajuta la nașterea unui copil sau pentru a ajuta la eliberarea placentei femeii după ce a dat naștere copilului.
Doza: 0,5-1,0 miliunități
Forma: Intranazal, IV, IM
```

---

## #2 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

ADVANCED LIFE SUPPORT

---

---

---

**1. ECHIPAMENTE EXTERIOARE**
---

---

 Pompierii-EMT vor răspunde la o multitudine de apeluri și vor trebui să fie pregătiți pentru mai multe tipuri de leziuni și situații. Personalul care operează ambulanțele noastre de salvare se poate trezi deseori răspunzând la scene de incendiu alături de mașini, așa că va trebui să aibă echipament special și pentru asta.

 1.1 **Compartimentul din stânga față, în spatele portierei șoferului**
- În acest compartiment veți găsi suficient echipament de protecție pentru doi pompieri. Acesta este depozitat în fiecare ambulanță în cazul în care trebuie să ajute la locul unui incendiu ``` [SHOW] ```

 1.2 **Compartimentul din stânga spate, în spatele anvelopei din spate**
- În acest compartiment veți găsi plăci pentru spate, atele de tracțiune și coliere C suplimentare. ``` [SHOW] ```

---

---

**2. ECHIPAMENTE INTERIOARE**
---

---

 2.1 **Echipament de acces rapid**
- În partea din spate a fiecărei ambulanțe, veți găsi echipament de acces rapid. Ceea ce înseamnă că acestea sunt disponibile imediat și nu sunt depozitate într-un compartiment încuiat. Acest lucru vă asigură că scenele se desfășoară fără probleme și eficient.  ``` [SHOW]- Gurney - Electrocardiograma (ECG) - DAE - Atele de vid - Pături - Sticle de apă ```

 2.2 **Echipament de izolare a substanței corporale**
- Partea din spate a fiecărei ambulanțe are mai multe compartimente mai mici, toate acestea conținând echipamente și provizii suplimentare. Iată ce veți găsi în compartimentul BSI:  ``` [SHOW]- Ochelari de protecție din plastic suplimentar - Măști chirurgicale suplimentare - Mănuși de nitril fără latex suplimentare ```

 2.3 **Echipament de gestionare a rănilor**
- ``` [SHOW] - Foarfecă de traumă suplimentară - Pansamente suplimentare pentru traume - Sigilii de piept Bolin suplimentare - Rulouri suplimentare de tifon - Soluție salină suplimentară - Tampoane de bumbac suplimentare - Extra Steri-Strips - Bandaje extra sterile, neaderente - Bandă medicală suplimentară - Turnichete suplimentare - Pachete de gheață suplimentare - Bandaje triunghiulare suplimentare/banderole pentru brațe ```

 2.4 **Oxygen Equipment**
- ``` [SHOW]- Canistre de oxigen suplimentare. - Măști suplimentare care nu se refulează - Canule nazale suplimentare - Măști suplimentare pentru sacul cu valțuri ```

 2.5 **Echipament de gestionare a căilor respiratorii**
- ``` [SHOW] - Tuburi endotraheale suplimentare - Laringoscoape suplimentare - Forceps Extra Magill - Ace de trahee suplimentare - Căile aeriene extraorofaringiene (OPA) - Pompe de aspirație suplimentare ```

 2.6 **Medicamente**
- În plus față de rezerva mică pe care o aveți în gențile ALS, fiecare ambulanță are o rezervă de medicamente suplimentare, care este blocată.  ``` [SHOW]- Claritromicina - Aspirină - Ibuprofen - Cărbune activat - Narcan (IV) - Epinefrină (IV) - Lidocaină - Bicarbonat de sodiu - Metroprolol - Adenozină - Amiodarona - Dopamina - Clorură de calciu - Labetalol - Furosimidă/Lasix - Acid tranexamic - Demerol/Meperidină - Ketorolac/Toradol - Entonox (mască de oxigen) - Fentanil - Morfină - Diazepam/Valium - Metilprednisolon - Atrovent - Sulfat de magneziu - Sabutamol - Dextroză - Glucoză orală - Dimenhidrinat/Gravol - Metoclopramidă/Maxeran - Benadryl - Lorazepam - Ketamină - Metohexital - Oxitosin ```

 2.7 **Terapie intravenoasă (IV)**
- ``` [SHOW] - Ace IV suplimentare - Pungi de picurare suplimentare - Catetere suplimentare - Seringi suplimentare (în ambalaj sigilat) - Extra Veinlite Vein Finders ```

 2.8 **Echipamente pentru tratamentul alergiilor**
- ``` [SHOW]- Inhalatoare suplimentare - EpiPens suplimentare ```

---

## #3 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

ADVANCED LIFE SUPPORT

---

---

---

**1. ECHIPAMENTUL ALS JUMPBAG**
---

---

 Pompierii-EMT vor răspunde la o multitudine de apeluri și vor trebui să fie pregătiți pentru mai multe tipuri de leziuni și situații. Geanta de salt, denumită și "trusă", trebuie să fie cu dumneavoastră în permanență. În interiorul fiecărei genți se află instrumente și medicamente care nu trebuie să cadă în mâini greșite, așa că trebuie să fiți foarte atenți la locul în care se află geanta dumneavoastră. Țineți-o agățată în jurul umărului (umerilor) atunci când nu o folosiți și nu o lăsați niciodată nesupravegheată, cu excepția cazului în care este încuiată în interiorul ambulanței.

 1.1 **Echipament de izolare a substanței corporale**
- ``` [SHOW] - Ochelari de plastic - Măști chirurgicale - Mănuși de nitril non-Latex ```

 1.2 **Vital-Checking Equipment**
- ``` [SHOW] - Tensiometru - Stetoscop ```

 1.3 **Echipament de gestionare a rănilor**
- ``` [SHOW]- Foarfecele de traumă - Pansamente pentru traume - Bolin sigilii de piept Bolin - Rulouri de tifon - Soluție salină - Tampoane de bumbac - Steri-Strips - Bandaje sterile, neaderente - Bandă medicală - Turechetele - Pachete de gheață - Bandaje triunghiulare/banderole pentru brațe ```

 1.4 **Oxygen Equipment**
- ``` [SHOW] - Canistră de oxigen - Mască non-rebreather - Canulă nazală - Masca cu sac și valvă ```

 1.5 **Echipament de gestionare a căilor respiratorii**
- ``` [SHOW] - Tub endotraheal - Laringoscop - Forceps Magill - Ac de trahee - Calea de aer orofaringiană (OPA) - Pompă de aspirație ```

 1.6 **Medicamente**
- Fiecare geantă de salt are o mică rezervă de medicamente, motiv pentru care siguranța în geantă este de nezdruncinat.  ``` [SHOW]- Claritromicina - Aspirină - Ibuprofen - Cărbune activat - Narcan (IV) - Epinefrină (IV) - Lidocaină - Dopamina - Clorură de calciu - Morfină - Diazepam/Valium - Metilprednisolon - Dextroză - Glucoză orală - Benadryl - Lorazepam - Ketamină - Metohexital - Oxitosin ```

 1.7 **Terapie intravenoasă (IV)**
- Fiecare geantă de salt are o mică cantitate de echipament IV care va fi folosit cu anumite medicamente.  ``` [SHOW]- Ac IV - Pungi de picurare - Catetere - Seringi (în ambalaj sigilat) - Veinlite Vein Finder ```

 1.8 **Echipamente de tratament al alergiilor**
- ``` [SHOW]- Inhalatoare - EpiPen ```

---
