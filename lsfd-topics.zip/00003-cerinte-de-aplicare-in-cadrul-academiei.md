# CERINȚE DE APLICARE ÎN CADRUL ACADEMIEI

- **Topic ID:** 3
- **URL:** https://lsfd.ro-rp.mp/viewtopic.php?t=3
- **Posts:** 1

---

## #1 — Aisha Dubois

![](https://i.imgur.com/2jlMxHe.png)

HUMAN RESOURCES

---

 CERINȚE DE APLICARE ÎN CADRUL ACADEMIEI
---

---

- **Los Santos Fire Department** impune personalului său un nivel ridicat de profesionalism şi totodată solicită o serie de abilităţi şi aptitudini în vederea menţinerii standardelor înalte de etică profesională. Se aşteaptă de la fiecare cetăţean doritor să se alăture departamentului să deţină sau să obţină aceste abilităţi şi aptitudini pentru a deveni eligibil pentru angajare.

- **I. CONDIȚII ȘI INFORMAȚII IN CHARACTER**    Se cere din partea cetățenilor care vor să se înscrie în cadrul **Recruit Training Academy**:

- Vârsta de minimum 21 de ani împliniţi;
- Capacitatea de a vorbi fluent şi a scrie corect din punct de vedere gramatical în limba engleză;
- Un cazier curat, fără antecedente sau contravenții cu natură penală;
- Capacitatea de a lua decizii individuale, bazate pe o gândire rațională în situații de stres;
- Capacitatea de a lucra în echipă pentru un scop comun (Operate through Teamwork);
- Capacitatea de a avea o atitudine respectuoasă, morală și profesională, conform Codului de Etică;
- Deținerea unei licențe de conducere auto validă;
- Aptitudini fizice și medicale adecvate pentru a putea promova examenul medical obligatoriu.

- **(( II. INFORMAȚII OUT OF CHARACTER ))**

- Se cere din partea jucătorilor care vor să se înscrie în cadrul facțiunii **Los Santos Fire Department**:

- Să reprezinte în permanență, atât In Character cât şi Out of Character, departamentul cu maturitate şi profesionalism în cadrul comunităţii;
- Să fie capabili să mențină o activitate UCP minimă obligatorie de 0.8, conform regulamentului facțiunii;
- Să practice un roleplay realist, fidel dezvoltării personajului lor, mentalitatea de tip "play-to-win" fiind strict interzisă;
- Să nu facă parte din alte facțiuni oficiale la momentul aplicării (permisiunea de Double Faction se acordă doar membrilor care au atins minim rank-ul de Firefighter II);
- Cunoașterea în totalitate a regulamentului comunităţii şi respectarea acestuia. Orice abatere (Metagaming, Powergaming, toxicitate etc.) atrage de la sine excluderea imediată din facțiune;
- Nicio sancțiune administrativă severă (admin-jail, warn, ban) în ultimele 30 de zile din momentul în care se depune cererea de înscriere;
- Să își asume faptul că demisiile frecvente și reangajările ("faction hopping") sunt strict interzise.

---
